# Drone Physics and Simulation

This learning project models quadcopter flight from rigid-body physics through
learned guidance.

## Learned Flight Control

**High-level policy**:
An MLP that maps a measured drone state and a flight objective to stabilized
flight commands. It does not command individual motors.
_Avoid_: Motor controller, direct-PWM policy

**Low-level controller**:
The PID and motor mixer that convert high-level flight commands into four motor
commands while stabilizing the drone.
_Avoid_: Policy, neural controller

## Position Control

**Position command**:
A home-relative XYZ destination together with an absolute world-frame yaw
heading for the drone to achieve.
_Avoid_: Motor command, trajectory

**Estimated vehicle state**:
The time-aligned estimate of the drone's world position and velocity,
orientation, and body angular rates used for feedback control.
_Avoid_: PyBullet truth, raw sensor reading

**Realized command**:
The bounded force, torque, or virtual control signal that the next plant stage
can actually apply after feasibility and allocation limits.
_Avoid_: Requested command, unconstrained command

## External Flight Control

**SITL bridge**:
The boundary that exchanges simulated vehicle observations and pilot-style
commands with an external flight controller while PyBullet owns vehicle motion.
_Avoid_: Physics replacement, direct motor application
