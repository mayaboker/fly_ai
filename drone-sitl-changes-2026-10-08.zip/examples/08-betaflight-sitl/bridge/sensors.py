"""PyBullet-to-FDM observation adapter with one frame-conversion owner."""

from __future__ import annotations

from math import exp

import pybullet as p

from bridge.types import FlightObservation


class PyBulletObservationAdapter:
    """Read PyBullet state as home-relative ENU odometry and IMU data."""

    def __init__(self, home_position_world_m: tuple[float, float, float], gravity_mps2: float = 9.81) -> None:
        """Create an adapter whose local ENU origin is the takeoff base position."""
        self._home_position_world_m = home_position_world_m
        self._gravity_mps2 = gravity_mps2
        self._previous_velocity: tuple[float, float, float] | None = None

    def reset(self) -> None:
        """Discard the previous velocity before a new simulation run."""
        self._previous_velocity = None

    def read(self, drone: int, timestamp_s: float, dt: float) -> FlightObservation:
        """Return a home-relative snapshot using PyBullet world and body frames."""
        position, orientation = p.getBasePositionAndOrientation(drone)
        # ! Module 08 home-relative odometry: subtract the frozen takeoff base pose.
        # PyBullet X/Y/Z are the course ENU E/N/U axes, all measured in metres.
        position_home_enu_m = tuple(current - home for current, home in zip(position, self._home_position_world_m))
        velocity, angular_velocity_world = p.getBaseVelocity(drone)
        rotation = p.getMatrixFromQuaternion(orientation)
        # Body rate = R_world_to_body * omega_world.
        body_rates = tuple(
            sum(rotation[3 * row + axis] * angular_velocity_world[row] for row in range(3))
            for axis in range(3)
        )
        if self._previous_velocity is None:
            acceleration_world = (0.0, 0.0, 0.0)
        else:
            acceleration_world = tuple((current - previous) / dt for current, previous in zip(velocity, self._previous_velocity))
        self._previous_velocity = tuple(velocity)
        # Specific force is a - g; a level stationary vehicle reports +g in body +Z.
        non_gravitational_world = (acceleration_world[0], acceleration_world[1], acceleration_world[2] + self._gravity_mps2)
        specific_force_body = tuple(
            sum(rotation[3 * row + axis] * non_gravitational_world[row] for row in range(3))
            for axis in range(3)
        )
        pressure_pa = 101_325.0 * exp(-position_home_enu_m[2] / 8_434.5)
        return FlightObservation(
            timestamp_s,
            position_home_enu_m,
            tuple(velocity),
            tuple(orientation),
            body_rates,
            specific_force_body,
            pressure_pa,
        )
