# Module 1 — GIS & Real-World Terrain Fundamentals

## Zero-to-Hero: Real-World Terrain Environments in Godot

### Module Goal

This module establishes the GIS and coordinate-system foundations required to create geographically correct terrain environments in Godot.

At this stage, we are **not yet creating terrain in Godot**.

The objective is to understand:

- How real terrain is represented digitally.
- DEM, DTM, and DSM data.
- Raster GIS data and GeoTIFF.
- Latitude, longitude, and altitude.
- Coordinate Reference Systems (CRS).
- WGS84 and projected coordinate systems such as UTM.
- Elevation and vertical references.
- Local coordinate systems.
- Mapping geographic coordinates into Godot coordinates.
- How to inspect a real DEM before using it.

By the end of this module, you should be able to take a terrain dataset and answer:

> What geographic area does this dataset represent?

> What does each pixel represent?

> What is the horizontal resolution?

> What coordinate system is being used?

> What does the elevation value mean?

> How large should this terrain be in Godot?

> Where should a particular latitude/longitude appear in the Godot world?

---

# 1.1 How Real Terrain Becomes 3D Terrain

The basic concept behind terrain generation is surprisingly simple.

A Digital Elevation Model can be considered a two-dimensional matrix containing elevation values.

For example:

```text
        X →
      0    1    2    3

0    120  121  124  126
1    119  123  128  131
2    117  121  130  137
3    115  119  127  134
↓
Z
```

Each value represents terrain elevation.

Conceptually, the terrain generator turns those samples into vertices:

```text
                 137 m
                   *
                 /   \
            130 *     *
               /       \
         121  *         *
             /
       117  *
```

Therefore, each DEM sample can eventually be interpreted as:

```text
DEM

(column, row, elevation)

        ↓

Geographic / projected position

(Easting, Northing, elevation)

        ↓

Local simulation coordinates

(East, North, Up)

        ↓

Godot

Vector3(x, y, z)
```

This transformation is one of the fundamental operations behind the entire project.

---

# 1.2 DEM, DTM and DSM

These terms are related but should not be treated as interchangeable.

## DEM — Digital Elevation Model

DEM is the general term for digital elevation information.

It represents elevation values sampled over an area.

Depending on the source, a DEM may represent bare terrain or may contain surface features.

---

## DTM — Digital Terrain Model

A DTM attempts to represent the **bare-earth surface**.

For example:

```text
             Tree
              🌲
               |
               |
---------------+---------------- Ground


DTM --------------------------------
```

The tree does not become part of the terrain elevation.

For our Godot simulator, this is usually desirable.

The terrain should represent the ground, while objects are added independently.

Conceptually:

```text
DTM
 |
 v
Terrain3D
 |
 v
Bare terrain

+

Trees
Buildings
Warehouses
Roads
Rocks
Poles
Fences
Other objects
```

This gives us significantly more control over the simulation.

---

## DSM — Digital Surface Model

A DSM represents the upper visible surface.

It may therefore include:

- Buildings
- Trees
- Infrastructure
- Other objects

For example:

```text
       Tree                 Building
        🌲                  +------+
         |                  |      |
         |                  |      |
---------+------------------+------+------


DSM      /\                 +------+
        /  \________________|      |
```

This can be useful for some applications but is generally not what we want as the primary terrain representation.

For our simulator, the preferred approach is generally:

```text
DTM
+
3D objects
```

rather than:

```text
DSM containing terrain + objects
```

---

# 1.3 Raster GIS Data

A DEM is commonly stored as raster data.

A raster is a rectangular grid of samples.

A normal image might contain:

```text
Width:  4096 pixels
Height: 4096 pixels

Channels:
R
G
B
```

A terrain raster might instead contain:

```text
Width:  4096 samples
Height: 4096 samples

Value:
Elevation
```

For example:

```text
Pixel (100, 200)

value = 637.4

meaning:

terrain elevation = 637.4 m
```

The exact meaning depends on the dataset's metadata and vertical reference.

---

# 1.4 GeoTIFF

One of the most important file formats we will encounter is:

```text
GeoTIFF
```

A normal TIFF stores image/raster information.

A GeoTIFF can additionally contain geographic metadata.

For example:

```text
Width
Height

Pixel values

Coordinate Reference System

Geographic extent

Pixel size

Geographic origin

NoData value
```

Example metadata:

```text
Size:
3601 x 3601

Pixel size:
approximately 30 m

CRS:
EPSG:4326

Bounds:

West  = 34°
East  = 35°

South = 31°
North = 32°
```

This information allows GIS software to determine where the raster belongs on Earth.

---

# 1.5 DEM Resolution

Terrain datasets have a spatial resolution.

For example:

```text
30 m / pixel
```

means approximately one elevation measurement for every 30 meters horizontally.

A simple example:

```text
DEM dimensions:

1000 x 1000

Resolution:

10 m / pixel
```

The physical coverage is approximately:

```text
1000 × 10 m = 10,000 m
```

Therefore:

```text
Terrain size:

10 km × 10 km
```

This relationship will become important when importing terrain into Godot.

---

# 1.6 NoData

GIS rasters can contain pixels for which no valid measurement exists.

These are normally represented using a special value called:

```text
NoData
```

For example:

```text
NoData = -9999
```

A DEM might therefore contain:

```text
532
535
537
-9999
-9999
541
```

We must detect and process these areas before creating terrain.

Otherwise they can produce extreme spikes or holes.

---

# 1.7 Geographic Coordinates

Most GPS systems represent position using:

```text
Latitude
Longitude
Altitude
```

Example:

```text
Latitude  = 31.500000°
Longitude = 35.000000°
Altitude  = 650 m
```

Latitude describes north/south position.

Longitude describes east/west position.

---

# 1.8 Degrees Are Not Meters

This is an extremely important concept.

Latitude and longitude use:

```text
degrees
```

Godot uses approximately:

```text
meters
```

for our simulation convention.

Therefore this is incorrect:

```text
Godot X = longitude
Godot Z = latitude
```

One degree does not equal one meter.

Furthermore, the physical distance represented by one degree of longitude changes depending on latitude.

We therefore need a conversion between geographic coordinates and a metric coordinate system.

---

# 1.9 Coordinate Reference Systems

A Coordinate Reference System is normally abbreviated:

```text
CRS
```

A CRS defines how coordinates correspond to locations on Earth.

GIS datasets should always be interpreted together with their CRS.

Without the CRS, numbers such as:

```text
31.5
35.0
```

or:

```text
688421
3486923
```

cannot be interpreted correctly.

---

# 1.10 EPSG Codes

Coordinate systems are commonly identified using EPSG codes.

For example:

```text
EPSG:4326
```

represents the commonly used WGS84 geographic coordinate system.

Instead of describing the complete coordinate system configuration manually, GIS tools can use its EPSG identifier.

We will encounter EPSG codes frequently when using:

- GDAL
- QGIS
- DEM datasets
- Satellite imagery
- OpenStreetMap-derived data
- Coordinate transformations

---

# 1.11 WGS84

GPS coordinates are commonly represented using WGS84.

Typical coordinates look like:

```text
Latitude  = 31.500000
Longitude = 35.000000
```

A common GIS representation is:

```text
EPSG:4326
```

The important characteristic for us is:

```text
units = degrees
```

WGS84 is excellent for specifying global positions.

It is not ideal for directly positioning objects in Godot.

---

# 1.12 Projected Coordinate Systems

A projected coordinate system transforms geographic coordinates into coordinates that are easier to work with locally.

Instead of:

```text
Latitude  = 31.500000°
Longitude = 35.000000°
```

we might obtain something resembling:

```text
Easting  = 688421 m
Northing = 3486923 m
```

The important difference is:

```text
units = meters
```

This is much more convenient for a simulation engine.

---

# 1.13 UTM

UTM stands for:

```text
Universal Transverse Mercator
```

UTM divides Earth into geographic zones and provides metric coordinates within each zone.

Conceptually:

```text
GPS / JSBSim

latitude
longitude

     |
     v

WGS84

     |
     v

Projection

     |
     v

UTM

Easting  [meters]
Northing [meters]

     |
     v

Subtract simulation origin

     |
     v

Local coordinates

     |
     v

Godot
```

We do not need to become GIS specialists to use UTM effectively.

We do need to understand:

- Which UTM zone our terrain belongs to.
- Which CRS the DEM uses.
- When reprojection is necessary.
- Why we should work in meters when creating the simulation world.

---

# 1.14 Altitude Is More Complicated Than It Appears

For UAV simulation, elevation requires special attention.

There are several altitude concepts that must not be mixed.

---

## Mean Sea Level — MSL

MSL altitude means approximately:

```text
height above mean sea level
```

Example:

```text
UAV altitude = 750 m MSL
```

---

## Ellipsoidal Height

GPS systems can provide altitude relative to a mathematical Earth ellipsoid.

This is not necessarily the same as altitude above mean sea level.

The difference can be significant enough to matter in UAV simulation.

---

## Terrain Elevation

The DEM might tell us:

```text
terrain elevation = 600 m MSL
```

---

## AGL — Above Ground Level

For many UAV applications we care about:

```text
AGL
```

If:

```text
UAV altitude     = 750 m MSL

Terrain altitude = 600 m MSL
```

then approximately:

```text
AGL = UAV altitude - terrain altitude

AGL = 750 - 600

AGL = 150 m
```

This will eventually be important for:

- Camera footprint calculations
- Collision avoidance
- Terrain following
- Optical navigation
- RL observations
- Ray casting
- Sensor simulation

---

# 1.15 Vertical Datum

Horizontal coordinates and vertical coordinates can use different references.

A DEM may specify elevations relative to one vertical datum while another system reports altitude relative to another.

Therefore:

```text
DEM elevation
```

and:

```text
GPS altitude
```

must not automatically be assumed to use exactly the same reference.

This is especially important when integrating:

```text
DEM
Godot
JSBSim
GPS simulation
Autopilot SITL
```

Later modules should explicitly define the vertical reference used throughout the simulation.

---

# 1.16 The Three Coordinate Spaces

Throughout the project, we should think in terms of three coordinate spaces.

## Space 1 — Global Geographic Coordinates

```text
Latitude
Longitude
Altitude
```

Example:

```text
31.500000°
35.000000°
650 m
```

Used by:

```text
GPS
JSBSim
GIS data
real-world coordinates
```

---

## Space 2 — Projected / Local Geographic Coordinates

Coordinates are represented in meters.

For example:

```text
East
North
Up
```

or:

```text
Easting
Northing
Elevation
```

This is the bridge between geographic coordinates and the simulation engine.

---

## Space 3 — Godot Coordinates

Godot uses:

```text
Vector3(X, Y, Z)
```

We need to define exactly how geographic directions correspond to these axes.

---

# 1.17 Godot Coordinate Convention

Godot uses:

```text
+Y = Up
```

For this project, we will define:

```text
+X = East

+Y = Up

-Z = North
```

Graphically:

```text
                     North
                       ^
                       |
                       | -Z
                       |
                       |
West <---------------- O ----------------> East
                                         +X

                       |
                       |
                      +Y
                       Up
```

Therefore a position:

```text
500 m East
1000 m North
100 m Up
```

would approximately become:

```text
Vector3(
    500,
    100,
    -1000
)
```

This convention should remain consistent throughout the project.

---

# 1.18 Geographic Simulation Origin

We should not place enormous global coordinates directly into Godot.

Instead, define a geographic origin.

For example:

```text
Simulation Origin

Latitude:
LAT0

Longitude:
LON0

Altitude:
ALT0
```

This location corresponds to:

```text
Godot

Vector3(0, 0, 0)
```

Other positions are calculated relative to this origin.

---

# 1.19 Example Local Conversion

Suppose our origin is:

```text
LAT0
LON0
ALT0
```

and another geographic point is approximately:

```text
500 m East
1000 m North
50 m above the origin
```

Our Godot position becomes:

```text
X = +500
Y = +50
Z = -1000
```

or:

```gdscript
Vector3(500.0, 50.0, -1000.0)
```

Eventually we will implement proper geographic conversion rather than manually entering these values.

---

# 1.20 Future Coordinate Architecture

The eventual simulator architecture should resemble:

```text
                     JSBSim
                        |
                        |
                  lat / lon / alt
                        |
                        v
                +---------------+
                | Geographic    |
                | Converter     |
                +-------+-------+
                        |
                        |
                    ENU meters
                        |
                        v
                +---------------+
                | Godot         |
                | Coordinates   |
                +-------+-------+
                        |
          +-------------+-------------+
          |             |             |
          v             v             v

       Vehicle        Camera        Sensors

          |
          v

       Terrain
```

The geographic conversion layer should remain independent of the terrain renderer.

This allows:

- JSBSim
- Terrain3D
- Cameras
- Roads
- Buildings
- Sensors
- Autopilot interfaces

to share the same geographic reference.

---

# 1.21 Tools Introduced in Module 1

We will primarily use two GIS tools.

## QGIS

QGIS provides visual inspection and manipulation of geographic data.

Initially we will use it to:

- Open DEM files.
- Inspect terrain.
- Check coordinates.
- Inspect CRS.
- Measure distances.
- Check elevation.
- Verify geographic alignment.

Later it can also help inspect:

- Satellite imagery.
- Roads.
- Buildings.
- Land-cover datasets.

---

## GDAL

GDAL provides command-line tools for working with geographic raster and vector data.

This is important because we eventually want the terrain pipeline to be reproducible and automatable.

One of the first commands we will learn is:

```bash
gdalinfo terrain.tif
```

This displays information about a geographic raster.

We will later use other GDAL tools for:

```text
cropping
reprojection
resampling
format conversion
DEM processing
```

---

# 1.22 Practical Exercise

The final part of Module 1 should use a small real DEM.

We will **not import it into Godot yet**.

The objective is simply to understand the dataset.

---

## Exercise A — Open the DEM in QGIS

Load:

```text
terrain.tif
```

Identify:

- Mountains
- Valleys
- Flat areas
- Geographic boundaries
- Minimum elevation
- Maximum elevation

Use the coordinate display to examine different locations.

---

## Exercise B — Inspect Metadata

Run:

```bash
gdalinfo terrain.tif
```

Identify:

```text
CRS

Raster width

Raster height

Pixel size

Geographic bounds

Data type

NoData value

Minimum elevation

Maximum elevation
```

Record the results.

---

## Exercise C — Determine Physical Size

Suppose:

```text
DEM:

2048 × 2048 pixels
```

and:

```text
resolution:

10 m / pixel
```

Then approximately:

```text
Width:

2048 × 10
= 20,480 m
```

and:

```text
Height:

2048 × 10
= 20,480 m
```

Therefore the terrain covers approximately:

```text
20.48 km × 20.48 km
```

This is approximately the physical size we would expect when constructing the terrain in Godot.

---

# 1.23 Important Distinction: Geographic Truth vs Synthetic Content

Later our environment will contain both real geographic information and synthetic content.

We should maintain a clear distinction between them.

## Geographic Data

Examples:

```text
DEM elevation
real roads
building footprints
satellite imagery
land-cover information
```

These may correspond to actual geographic features.

---

## Synthetic Enrichment

Examples:

```text
procedurally scattered rocks
extra trees
custom warehouse
fences
training targets
vehicles
artificial obstacles
```

These objects may not exist at the real location.

Keeping these categories separate is useful for:

- Computer vision experiments
- Reinforcement learning
- Dataset generation
- Ground-truth creation
- Simulation reproducibility

---

# 1.24 Why This Matters for UAV Simulation

For a normal game, small geographic inaccuracies might be acceptable.

For our UAV simulator, they can affect:

```text
Camera geometry

AGL calculations

Terrain collision

Line of sight

Optical flow

Visual navigation

Object locations

Sensor simulation

RL observations

Autopilot