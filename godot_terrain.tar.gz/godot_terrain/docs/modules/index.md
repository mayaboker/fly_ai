

| # | Chapter | Result |
|---|---|---|
| 1 | GIS fundamentals | Understand DEM, DTM, DSM, GeoTIFF, WGS84, UTM |
| 2 | Choose a real area | Define exact geographic bounds |
| 3 | Download DEM | Obtain real elevation data |
| 4 | GIS preprocessing | Crop, reproject and normalize DEM |
| 5 | First Godot terrain | Real terrain visible at correct scale |
| 6 | Terrain materials | Soil, rock, sand, grass etc. |
| 7 | Satellite/orthophoto | Visually align real imagery |
| 8 | Roads | Import/create geographically correct roads |
| 9 | Buildings | OSM footprints → buildings |
| 10 | Vegetation & rocks | Procedural trees, bushes, grass and rocks |
| 11 | Large-world optimization | LOD, instancing, streaming, collision |
| 12 | UAV integration | Geographic coordinates ↔ Godot ↔ JSBSim |