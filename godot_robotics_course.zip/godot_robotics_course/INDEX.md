# Course index

Every file in the course, in reading order. Start with [README.md](README.md).

## Start here

- [Godot for Robotics Simulation, with PyBullet and JSBSim](README.md)
- [00 Setup (about 1 hour, once)](00_setup/README.md)

## Reference

- [Frames cheat sheet](reference/frames.md)
- [Log format](reference/logging.md)
- [The `robosim/` project](reference/project_layout.md)
- [robosim bridge protocol, version 1](reference/protocol.md)
- [Shared terrain contract](reference/terrain.md)

## Module 1: Godot editor and GDScript essentials (5 h)

- [Module 1: Godot editor and GDScript essentials (5 h)](m01_editor_gdscript/README.md)
- [01 Project structure, the editor and exported properties (45 min)](m01_editor_gdscript/01_project_and_editor.md)
- [02 Scenes, nodes, the scene tree, instancing and signals (45 min)](m01_editor_gdscript/02_scenes_nodes_signals.md)
- [03 Typed GDScript, the frame callbacks, and input (60 min)](m01_editor_gdscript/03_gdscript_and_callbacks.md)
- [04 Building scenes from code vs saving `.tscn` (30 min)](m01_editor_gdscript/04_scenes_from_code.md)
- [05 Debugging, VS Code and headless runs (30 min)](m01_editor_gdscript/05_debugging_and_tools.md)
- [Lab 1: The robosim viewer (90 min)](m01_editor_gdscript/lab.md)
- [Module 1 reference code](m01_editor_gdscript/code/README.md)

## Module 2: Scenes, terrain and vehicle assets (6 h)

- [Module 2: Scenes, terrain and vehicle assets (6 h)](m02_scene_assets/README.md)
- [01 Node3D transforms and the parent/child hierarchy (40 min)](m02_scene_assets/01_transforms_and_hierarchy.md)
- [02 Meshes, materials, lights and model scale (50 min)](m02_scene_assets/02_meshes_materials_lights.md)
- [03 Collision layers, sensor mounts and world organisation (40 min)](m02_scene_assets/03_collision_mounts_organisation.md)
- [04 Terrain: one heightmap, two engines (60 min)](m02_scene_assets/04_terrain_heightmap.md)
- [05 The range layout and the vehicle scenes (40 min)](m02_scene_assets/05_range_and_vehicles.md)
- [Lab 2: The test range (130 min)](m02_scene_assets/lab.md)
- [Module 2 reference code](m02_scene_assets/code/README.md)

## Module 3: Frames, units, quaternions and camera mounts (9 h)

- [Module 3: Frames, units, quaternions and camera mounts (9 h)](m03_frames/README.md)
- [1. Why frames matter, and how to write them down](m03_frames/01_why_frames.md)
- [2. Godot's conventions: +Y up, −Z forward, Transform3D](m03_frames/02_godot_conventions.md)
- [3. PyBullet conventions: Z-up ENU world, FLU body](m03_frames/03_pybullet_conventions.md)
- [4. JSBSim: geodetic position, NED, FRD, feet](m03_frames/04_jsbsim_geodetic.md)
- [5. Quaternions in practice](m03_frames/05_quaternions.md)
- [6. Camera mounts and the optical frame](m03_frames/06_camera_mounts.md)
- [Lab 3: Verified frame adapters, a rotating test body, and an FPV mount (about 2 h)](m03_frames/lab.md)
- [Module 3 reference code](m03_frames/code/README.md)

## Module 4: External simulator bridge (8 h)

- [Module 4: External simulator bridge (8 h)](m04_bridge/README.md)
- [01 Two processes, one physics owner](m04_bridge/01_process_separation.md)
- [02 UDP basics, and why poses use it](m04_bridge/02_udp_basics.md)
- [03 Message schema: fixed layouts, magic, version, seq and t_sim](m04_bridge/03_message_schema.md)
- [04 Reliable commands: ACK, resend, de-duplicate](m04_bridge/04_reliable_commands.md)
- [05 Handshake, stale data, and restarts](m04_bridge/05_handshake_and_failures.md)
- [06 The sensor back channel](m04_bridge/06_sensor_back_channel.md)
- [Lab 4: Two bodies over the bridge, and breaking it on purpose (about 2 h 15)](m04_bridge/lab.md)
- [Module 4 reference code](m04_bridge/code/README.md)

## Module 5: Time, rates, interpolation and resets (7 h)

- [Module 5: Time, rates, interpolation and resets (7 h)](m05_time_rates/README.md)
- [01 Fixed physics step, render frames, and two clocks](m05_time_rates/01_fixed_step_and_clocks.md)
- [02 Rates, latency, pose age and jitter](m05_time_rates/02_rates_age_jitter.md)
- [03 Interpolation: render a little in the past](m05_time_rates/03_interpolation.md)
- [04 Pause, single-step, reset and replay](m05_time_rates/04_pause_step_reset_replay.md)
- [05 Lock-step and determinism](m05_time_rates/05_lockstep_determinism.md)
- [06 The log format](m05_time_rates/06_logging.md)
- [Lab 5: Smooth, steppable, logged and repeatable (about 1 h 15)](m05_time_rates/lab.md)
- [Module 5 reference code](m05_time_rates/code/README.md)

## Module 6: Cameras and image formation (8 h)

- [Module 6: Cameras and image formation (8 h)](m06_cameras/README.md)
- [01 Camera3D and SubViewport](m06_cameras/01_camera_and_subviewport.md)
- [02 Field of view and pinhole intrinsics](m06_cameras/02_fov_and_intrinsics.md)
- [03 Checking projection; near, far and depth precision](m06_cameras/03_projection_and_depth.md)
- [04 Camera mounts and extrinsics](m06_cameras/04_camera_mounts.md)
- [05 Lighting and visual artifacts](m06_cameras/05_lighting_and_artifacts.md)
- [06 Ideal target detection: ground-truth boxes](m06_cameras/06_ground_truth_boxes.md)
- [Lab 6: Camera rigs and the 1 m board check (2.25 h)](m06_cameras/lab.md)
- [Module 6 reference code](m06_cameras/code/README.md)

## Module 7: RGB frame transport and measurement (8 h)

- [Module 7: RGB frame transport and measurement (8 h)](m07_frame_transport/README.md)
- [01 Getting pixels: GPU → CPU readback](m07_frame_transport/01_readback.md)
- [02 Shared memory: layout, seqlock and buffering](m07_frame_transport/02_shared_memory_layout.md)
- [03 The writer in Godot, the reader in Python](m07_frame_transport/03_writer_and_reader.md)
- [04 Measuring: FPS, drops, latency, bandwidth](m07_frame_transport/04_measuring.md)
- [05 Cross-platform fallback and recording](m07_frame_transport/05_fallback_and_recording.md)
- [Lab 7: Shared-memory video, a recording and a performance report (2.75 h)](m07_frame_transport/lab.md)
- [Module 7 reference code](m07_frame_transport/code/README.md)

## Module 8: Synthetic sensors and ground truth (8 h)

- [Module 8: Synthetic sensors and ground truth (8 h)](m08_sensors/README.md)
- [01 Ground truth, measurements and error models (1 h)](m08_sensors/01_truth_and_error_models.md)
- [02 The IMU: specific force, and where to get it (1.25 h)](m08_sensors/02_imu.md)
- [03 Barometer, magnetometer, GPS, air data and friends (1 h)](m08_sensors/03_baro_mag_gps_air.md)
- [04 Godot-side sensors: range, lidar, proximity, contact (1.25 h)](m08_sensors/04_godot_range_lidar_contact.md)
- [05 Timestamps and alignment (0.75 h)](m08_sensors/05_timestamps_alignment.md)
- [Lab: sensors on the rover, end to end (2.75 h)](m08_sensors/lab.md)
- [Module 8 reference code](m08_sensors/code/README.md)

## Module 9: PyBullet UGV lab (9 h)

- [Module 9: PyBullet UGV lab (9 h)](m09_ugv_pybullet/README.md)
- [01 PyBullet essentials for this course](m09_ugv_pybullet/01_pybullet_essentials.md)
- [02 The shared heightmap as a PyBullet heightfield](m09_ugv_pybullet/02_heightfield_terrain.md)
- [03 Differential drive: kinematics and wheel motors](m09_ugv_pybullet/03_differential_drive.md)
- [04 Friction and slip](m09_ugv_pybullet/04_friction_and_slip.md)
- [05 Road following: route, cross-track error, pure pursuit](m09_ugv_pybullet/05_road_following.md)
- [06 Manual driving, wheel odometry, collision feedback](m09_ugv_pybullet/06_manual_odometry_contacts.md)
- [Module 9 lab: a PyBullet rover on the Module 2 range](m09_ugv_pybullet/lab.md)
- [Module 9 reference code](m09_ugv_pybullet/code/README.md)

## Module 10: Multirotor lab, PyBullet or JSBSim (10 h)

- [Module 10: Multirotor lab, PyBullet or JSBSim (10 h)](m10_multirotor/README.md)
- [01 Quad frame, motor layout, thrust and torque](m10_multirotor/01_quad_frame_motors.md)
- [02 Quad dynamics: gravity, drag, motor lag, and why it needs a controller](m10_multirotor/02_dynamics_and_open_loop.md)
- [03 Attitude PD + mixer, altitude PI, and loop rates](m10_multirotor/03_attitude_altitude_control.md)
- [04 The PyBullet quad: forces, torques and frames](m10_multirotor/04_pybullet_quad.md)
- [05 The JSBSim option: `quad_rpy` with its built-in controller](m10_multirotor/05_jsbsim_quad.md)
- [06 The Godot side: stick input, spinning rotors, FPV](m10_multirotor/06_godot_quad_view.md)
- [Module 10 lab: one quad, two physics engines, one Godot scene](m10_multirotor/lab.md)
- [Module 10 reference code](m10_multirotor/code/README.md)

## Module 11: JSBSim fixed-wing lab (8 h)

- [Module 11: JSBSim fixed-wing lab (8 h)](m11_jsbsim_fixed_wing/README.md)
- [01 JSBSim recap: the trainer, stepping, controls and state](m11_jsbsim_fixed_wing/01_jsbsim_recap_and_stepping.md)
- [02 Initial conditions and trim](m11_jsbsim_fixed_wing/02_initial_conditions_and_trim.md)
- [03 From JSBSim state to the Godot node, and back to the HUD](m11_jsbsim_fixed_wing/03_state_to_godot.md)
- [04 The terrain feed: one ground for JSBSim and Godot](m11_jsbsim_fixed_wing/04_terrain_feed.md)
- [05 Obstacles only Godot knows: contact and the crash decision](m11_jsbsim_fixed_wing/05_obstacles_and_crash.md)
- [06 Chase and onboard cameras, the HUD, and a telemetry extension](m11_jsbsim_fixed_wing/06_cameras_hud_telemetry.md)
- [Lab 11: the JSBSim trainer over the shared terrain (2.5 h)](m11_jsbsim_fixed_wing/lab.md)
- [Module 11 reference code](m11_jsbsim_fixed_wing/code/README.md)

## Module 12: Integration capstone and evaluation (10 h)

- [Module 12: Integration capstone and evaluation (10 h)](m12_capstone/README.md)
- [01 Choosing an option](m12_capstone/01_choosing_an_option.md)
- [02 Requirements and documents](m12_capstone/02_requirements_and_documents.md)
- [03 Measurement and validation](m12_capstone/03_measurement_and_validation.md)
- [04 Failure injection](m12_capstone/04_failure_injection.md)
- [05 The option A reference starter](m12_capstone/05_reference_starter_option_a.md)
- [Lab 12: the capstone (6 h)](m12_capstone/lab.md)
- [Capstone demo checklist](m12_capstone/demo_checklist.md)
- [Capstone grading rubric](m12_capstone/grading_rubric.md)
- [Option A: quadcopter, time to contact from vision](m12_capstone/option_a_ttc.md)
- [Option B: UGV road following with camera and IMU](m12_capstone/option_b_ugv.md)
- [Option C: fixed-wing approach visualised from JSBSim](m12_capstone/option_c_fixed_wing.md)
- [Capstone report: <title>](m12_capstone/report_template.md)
- [Module 12 reference code: option A starter](m12_capstone/code/README.md)
