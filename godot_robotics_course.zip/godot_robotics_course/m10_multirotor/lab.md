# Module 10 lab: one quad, two physics engines, one Godot scene

You will build two interchangeable quadcopter simulators, `quad_pybullet.py` and `quad_jsbsim.py`. Both fly the same airframe with the same controller, send the same pose and motor telemetry, and write the same log columns. The mission runs step tests above Module 2's pad, then flies through Module 2's three gates and lands. At the end you show that the two engines agree, and use the comparison to catch frame and sign errors.

Time: about 3.5 h after the sub-topics.

## Files added or changed

| Path in `robosim/` | New / changed | From |
|---|---|---|
| `physics/aircraft/quad_rpy/` | new (copy) | [reference/code/aircraft/quad_rpy](../reference/code/aircraft/quad_rpy/quad_rpy.xml) |
| `physics/sims/quad_common.py` | new | [code/physics/sims/quad_common.py](code/physics/sims/quad_common.py) |
| `physics/sims/quad_pybullet.py` | new | [code/physics/sims/quad_pybullet.py](code/physics/sims/quad_pybullet.py) |
| `physics/sims/quad_jsbsim.py` | new | [code/physics/sims/quad_jsbsim.py](code/physics/sims/quad_jsbsim.py) |
| `physics/tests/test_quad_signs.py` | new | [code/physics/tests/test_quad_signs.py](code/physics/tests/test_quad_signs.py) |
| `physics/robosim/telemetry.py` | already there from setup (shared code; identical copy here) | [code/physics/robosim/telemetry.py](code/physics/robosim/telemetry.py) |
| `tools/plot_quad_response.py` | new | [code/tools/plot_quad_response.py](code/tools/plot_quad_response.py) |
| `godot/bridge/telemetry_bridge.gd` | already there from setup (shared code; identical copy here) | [code/godot/bridge/telemetry_bridge.gd](code/godot/bridge/telemetry_bridge.gd) |
| `godot/vehicles/rotor_spinner.gd` | new | [code/godot/vehicles/rotor_spinner.gd](code/godot/vehicles/rotor_spinner.gd) |
| `godot/scenes/quad_lab.tscn`, `quad_lab.gd` | new | [code/godot/scenes/](code/godot/scenes/quad_lab.gd) |

Used unchanged: Module 2 (terrain, `range.json`, `terrain.py`, `HeightmapTerrain`, `RangeBuilder`, `quad.tscn`, input actions), Module 4 (bridge), Module 5 (`RenderClock`), Module 6 (`CameraRig`) and Module 9 (`physics/robosim/pybullet_world.py`). No shared file is modified.

## Step 0: the pad

The quad takes off from Module 2's pad at ENU (0, 0). It is part of the apron, which Module 2 flattened to exactly 0 m. That is also JSBSim's origin (`ground.xml`'s lat/lon is the heightmap center). Both sims take `--pad E,N` if you want to start elsewhere, but check the slope there first: PyBullet's quad slides on a slope, while JSBSim's flat-plane ground keeps it level.

## Step 1: the JSBSim model and the shared module

```bash
cd ~/robosim/physics
mkdir -p aircraft && cp -r <course>/reference/code/aircraft/quad_rpy aircraft/
cp <course>/m10_multirotor/code/physics/sims/quad_*.py sims/
ls robosim/telemetry.py          # TELEMETRY extension: shared code, copied during setup
python -c "import sys; sys.path.insert(0, 'sims'); import quad_common as Q; print(round(Q.HOVER_CMD, 4))"
# 0.4591
```

Read `quad_common.py` against pages 01–03. It is the one place that defines the motor layout, the controllers and the mission, so the two engines cannot drift apart.

## Step 2: the open-loop demo

```bash
python sims/quad_pybullet.py --fast --open-loop-demo --duration 10
# quad_pybullet summary: {'end': 'flipped (|roll| > 90 deg) at t = 2.15 s', ..., 'final_rpy_deg': [-90.6, 47.0, -42.0]}
```

Roll goes **left** and pitch goes **up**, because motor 1 sits front-right. If you see anything else, stop and fix the motor table before going on.

## Step 3: fly the mission in both engines

The mission (`quad_common.STEPS`, then `Mission`) holds each step long enough to measure it, then flies the gates:

| t (s) | Command | Purpose |
|---:|---|---|
| 0 | disarmed on the pad | |
| 1 | altitude 3 m | takeoff |
| 8 | altitude 5 m | **altitude step** |
| 14 / 16 / 18 | roll +10°, −10°, 0 | **roll step** (a doublet, so the drift cancels) |
| 21 / 23 / 25 | pitch +10°, −10°, 0 | **pitch step** |
| 28 / 32 | yaw rate 45 °/s, then 0 | **yaw-rate step** |
| 34 → ~100 | path follower: gates 1, 2, 3, swing east at 8 m, back over the pad | **gate run** |
| end | descend onto the pad, disarm 1 s after touchdown | landing |

```bash
python sims/quad_pybullet.py --fast --run-name quad_pb
python sims/quad_jsbsim.py   --fast --run-name quad_js
```

Expected summaries (shortened):

```
quad_pybullet summary: {'end': 'mission end', 't_sim': 101.65, 'wall_s': 2.2, 'final_enu': [-0.02, -0.02, 0.08], ...
  'gates': [{'gate': 'gate_1', 'lateral_m': 0.258, 'height_m': 1.505, 'ok': True},
            {'gate': 'gate_2', 'lateral_m': -0.508, 'height_m': 1.621, 'ok': True},
            {'gate': 'gate_3', 'lateral_m': 0.083, 'height_m': 1.819, 'ok': True}], 'hits': []}
quad_jsbsim: vehicle 2, mode mission, accel at rest 9.7951 m/s^2, ...
quad_jsbsim summary: {'end': 'mission end', 't_sim': 101.517, 'wall_s': 1.49, 'final_enu': [-0.02, -0.02, 0.08], ...
  'gates': [{'gate': 'gate_1', 'lateral_m': 0.257, 'height_m': 1.506, 'ok': True}, ...
```

Both engines land within 2 cm of each other after 100 s of flight. Both runs write `state.csv` (truth: ENU position and velocity, measured vertical acceleration, aerospace angles, body rates) and `control.csv` (setpoints, throttle, intended and actual thrust, m1–m4). The PyBullet run also writes `contact.csv` if the quad touches a gate or obstacle. `"hits": []` means it never did.

## Step 4: step responses, the thrust check and the gate run

```bash
cd ~/robosim
python tools/plot_quad_response.py logs/*_quad_pb logs/*_quad_js -o quad_response.png
```

Expected output:

```
== 20261001T073633Z_quad_pb  (pybullet 240 Hz)
  altitude 3->5 m      t63  0.93 s   t90  1.47 s   overshoot   1.8 %   value at window end   5.01
  roll 0->10 deg       t63  0.23 s   t90  0.40 s   overshoot   0.0 %   value at window end  10.00
  pitch 0->10 deg      t63  0.23 s   t90  0.40 s   overshoot   0.0 %   value at window end  10.00
  yaw rate 0->45 dps   t63  0.70 s   t90   nan s   overshoot   0.0 %   value at window end  35.58
  hover 12-14 s: intended thrust 14.700 N, actual 14.700 N, m*g = 14.692 N, mean az_meas +0.0051 m/s^2
  whole flight 2-34 s: a_meas - a_pred  mean -0.004, RMS 0.028 m/s^2
  gate_1: lateral +0.26 m, height 1.50 m, PASS
  gate_2: lateral -0.51 m, height 1.62 m, PASS
  gate_3: lateral +0.08 m, height 1.82 m, PASS
  collisions with range objects: none

== 20261001T073701Z_quad_js  (jsbsim 120 Hz)
  altitude 3->5 m      t63  0.92 s   t90  1.45 s   overshoot   1.8 %   value at window end   5.01
  roll 0->10 deg       t63  0.23 s   t90  0.35 s   overshoot   0.0 %   value at window end  10.00
  pitch 0->10 deg      t63  0.23 s   t90  0.35 s   overshoot   0.0 %   value at window end  10.00
  yaw rate 0->45 dps   t63  0.70 s   t90   nan s   overshoot   0.0 %   value at window end  35.58
  hover 12-14 s: intended thrust 14.699 N, actual 14.700 N, m*g = 14.693 N, mean az_meas +0.0048 m/s^2
  whole flight 2-34 s: a_meas - a_pred  mean -0.004, RMS 0.040 m/s^2
  gate_1: lateral +0.26 m, height 1.51 m, PASS
  gate_2: lateral -0.50 m, height 1.62 m, PASS
  gate_3: lateral +0.09 m, height 1.82 m, PASS
```

![step responses and gate run, both engines](img/quad_response.png)

How to read the thrust check:

- **Hover.** Intended thrust (what the altitude loop asked for) ≈ actual thrust (after the motor lag) ≈ m·g. A gap between *intended* and *actual* means motor saturation or lag. A gap between *actual* and m·g means the engines disagree on mass or gravity (page 02). Here: 14.700 N vs 14.692 N, which is 0.05 %, and the quad was still settling by millimeters.
- **Step phase.** `a_pred = T_actual·cos φ·cos θ / m − g` is Newton's law along the vertical, without drag. `a_meas` is the finite difference of the logged vertical velocity. A mean difference of −0.004 m/s² says the force bookkeeping is right. The RMS (0.03–0.04 m/s²) is the drag the prediction ignores, plus the half-sample delay of the finite difference.
- **Yaw rate t90 = nan** is correct. The P-only yaw loop settles at 79 % of the command (page 03), so it never reaches 90 %.

## Step 5: the sign checklist

```bash
cd ~/robosim/physics && python tests/test_quad_signs.py
```

```
pybullet
  [PASS] roll +10 -> drifts EAST (right of a north-facing quad)  v_enu=(+2.18,-0.00,-0.00)  nose_godot=(+0.00,-0.00,-1.00)
  [PASS] pitch +10 (nose up) -> drifts SOUTH (backward)          v_enu=(-0.00,-2.18,-0.00)  nose_godot=(+0.00,+0.17,-0.98)
  [PASS] yaw rate +30 -> nose turns from north toward EAST       v_enu=(+0.00,+0.00,-0.00)  nose_godot=(+0.60,-0.00,-0.80)
  [PASS] throttle 1.0 -> climbs (+U, Godot +Y)                   v_enu=(+0.00,+0.00,+1.40)  nose_godot=(+0.00,+0.00,-1.00)
jsbsim
  [PASS] roll +10 -> drifts EAST (right of a north-facing quad)  v_enu=(+2.14,+0.00,-0.00)  ...
  ...
quad sign checklist: PASS
```

Each test starts from a hover facing north and holds one stick. It checks the response in ENU **and** in the Godot pose that would go on the wire (`nose_godot` is the model's −Z axis in Godot world coordinates). Pitch +10° tips the nose up, so the nose vector has +Y = sin 10° = 0.17. A +30 °/s yaw for 2 s turns the nose about 37° toward +X (east).

### When something fails: symptom → likely cause

| Symptom | Likely cause | Where to look |
|---|---|---|
| open-loop demo rolls right / pitches down with motor 1 high | motor positions wrong (FLU vs structural frame) | `quad_common.MOTORS`, page 01 |
| flips within a second of arming | a mixer column has the wrong sign | `attitude_mixer`, page 01 table |
| spins up in yaw and never stops | reaction torque sign inverted | `-spin * K_TORQUE`, page 01 |
| roll + drifts **west** | p or φ sign: FLU→FRD conversion missing | `R_ned_frd`, `p = w_flu[0]`, `q = −w_flu[1]`, `r = −w_flu[2]` |
| pitch + flies **forward** | θ sign (FLU y = −FRD y) | same |
| gate run heads off at 90° to the path | heading convention: compass ψ = atan2(east, north), not atan2(north, east) | `PathFollower.update` |
| Godot shows the PyBullet quad nose **east** at the start, the JSBSim one nose north | missing +90° ENU yaw at the PyBullet start | `QuadPyBullet.reset()` |
| quad looks mirrored or upside down in Godot only | quaternion order (w first) or a missing `C_FLU_MODEL` | [frames](../reference/frames.md), `enu_flu_to_godot` |
| JSBSim quad climbs tens of meters at the start | terrain set **after** `run_ic()` (only visible away from the 0 m pad) | page 05 |
| PyBullet hovers with a constant extra throttle vs JSBSim | gravity 9.81 vs 9.795, or default damping left on | pages 02 and 04 |
| quad flips when you add a wind or drag force | `WORLD_FRAME` with a body-frame `posObj` | page 04 |
| rotors spin the wrong way in Godot | `RotorSpinner.SPIN` signs or rotor order | page 06 |

## Step 6: the Godot scene

1. Check that `godot/bridge/telemetry_bridge.gd` is there (shared code from setup; copy it from `code/` if not). Copy `rotor_spinner.gd` to `godot/vehicles/`, and the two `quad_lab` files to `godot/scenes/`. Run `godot --headless --path godot --import` once.
2. The scene tree:

   ```
   QuadLab (Node3D, quad_lab.gd)          RenderClock, keys/gamepad -> ATTITUDE at 50 Hz, HUD, views
   ├── SimBridge (telemetry_bridge.gd)    Module 4 bridge + TELEMETRY (type 100)
   ├── WorldEnvironment, Sun
   ├── Terrain (HeightmapTerrain)         Module 2
   ├── Range (RangeBuilder)               Module 2: pad, gates, obstacles, roads
   ├── Quad (quad.tscn instance)          Module 2; quad_lab.gd sets its transform every frame
   │   └── RotorSpinner                   blades, spin from TELEMETRY code 2, visual layer 2
   │                                      (+ a CameraRig on Mounts/fpv_cam, added in _ready)
   ├── ViewCam (Camera3D)                 chase or onboard
   └── UI/Hud, UI/Pip                     status text; FPV picture-in-picture
   ```

3. Watch the mission. Start either engine without `--fast` and run `scenes/quad_lab.tscn`. Press C for the onboard view during the gate run.

   ```bash
   python sims/quad_pybullet.py           # or: python sims/quad_jsbsim.py
   ```

4. Fly it yourself. Start either engine with `--mode manual`, press M in Godot, then fly with W/A/S/D, the arrow keys and E/Q.
5. The automated end-to-end test, once per engine:

   ```bash
   python sims/quad_jsbsim.py --mode manual --duration 15 &
   godot --headless --path godot res://scenes/quad_lab.tscn -- --autotest
   # quad_autotest: t_sim 12.93 stale false poses 776 motors_rx 776 roll range -10.0..10.0 deg, climb 4.02 m, motors [...]
   ```

   `--autotest` holds the sticks centered for 3 s, rolls +10° and −10° for 2 s each, climbs for 2 s at full throttle, and yaws right at 30 °/s for 3 s. Other options: `--ports=L,P`, `--shot=DIR@T`, `--quit-after=S`.

## Check

| # | Test | Pass if | Reference (PyBullet / JSBSim) |
|---|---|---|---|
| 1 | thrust vs acceleration | hover intended thrust within 0.5 % of m·g; step-phase mean \|a_meas − a_pred\| < 0.05 m/s² | 14.700 / 14.699 N vs 14.692 N; −0.004 / −0.004 m/s² (RMS 0.028 / 0.040) |
| 2 | step responses, one plot | both engines within 20 % on t63, t90 and overshoot, for altitude and roll | alt t63 0.93/0.92 s, t90 1.47/1.45 s, OS 1.8/1.8 %; roll t63 0.23/0.23 s, t90 0.40/0.35 s |
| 3 | gate run | all 3 gates PASS in both engines; no PyBullet hits; landed on the pad | lateral +0.26/−0.51/+0.08 and +0.26/−0.50/+0.09 m; `hits: []`; both at (−0.02, −0.02) |
| 4 | `test_quad_signs.py` | PASS for both engines | PASS |
| 5 | open-loop demo | flips (\|roll\| > 90°) within 5 s, rolling left and pitching up | 2.15 s, roll −90.6°, pitch +47° |
| 6 | Godot, both engines | same scene; ~60 poses and 60 motor packets per second; ±10° roll command shows ±10° in Godot; climbs on throttle 1.0 | 771 / 776 packets in ~12.9 s; −10.0…10.0°; 4.02 / 4.02 m |

## Stretch goals

1. Replace truth with the Module 8 IMU and baro. Run the attitude loop on gyro + accelerometer through a complementary filter, and the altitude loop on the noisy baro. Plot the hover jitter and the new gate offsets.
2. Make the thrust quadratic (T = T_max·u²) in **both** engines (XML and `quad_common.py`). Linearize it in the mixer (u = √(T/T_max)) and rerun the comparison.
3. Fly the gate run faster (`PathFollower.V_MAX` 4 m/s). Which gate fails first, and in which engine does the quad actually hit it?
4. Add wind: a constant 3 m/s from the west, as a `WORLD_FRAME` force in PyBullet and `atmosphere/wind-east-fps` in JSBSim. Check that the steady roll angle needed to hold position matches in both.
5. Stream the FPV picture-in-picture with your Module 7 transport during the gate run, and measure the end-to-end latency from a pose's `t_sim` to the frame that shows it.
6. Add a stick-loss failsafe test. Stop sending ATTITUDE mid-roll and check that the quad levels within 0.5 s plus the attitude settling time.
