# 02 Quad dynamics: gravity, drag, motor lag, and why it needs a controller

A quadcopter is a rigid body pushed by the four motor forces of page 01, pulled by gravity and slowed by air. This page adds the three physical effects both engines must agree on: gravity, drag and motor lag. Then it runs the most important experiment in the module. With no controller at all, a quad that is almost perfectly trimmed still flips within about two seconds.

## Equations of motion (what both engines integrate)

```
m · dv/dt  =  R · (0, 0, ΣT_i)  −  m g ẑ  −  ½ ρ C_D S |v| v                  world frame (ENU)
I · dω/dt  =  Σ r_i × F_i  +  Σ Q_i  −  c_ω ω  −  ω × (I ω)                  body frame
```

Here R is the body-to-world rotation, ω the body angular rate, Q_i the reaction torques, and c_ω the rotational damping. JSBSim integrates this (on a rotating Earth) from the XML model. In PyBullet we supply every term except gravity and the gyroscopic term ω × Iω, which Bullet adds itself.

## Gravity at the origin

PyBullet has whatever gravity you set. JSBSim computes gravity from a WGS84 Earth model and integrates on a **rotating** Earth. For the two engines to agree, PyBullet needs JSBSim's *effective* gravity at the place where the quad flies. We measured it in JSBSim 1.3.1 at the `ground.xml` start point:

| Measurement | Value | Meaning |
|---|---|---|
| `accelerations/gravity-ft_sec2` | 32.215 ft/s² = **9.819** m/s² | gravitation only (mass attraction, with J2) |
| `-accelerations/a-pilot-z-ft_sec2` at rest on the ground | 32.136 ft/s² = **9.795** m/s² | what an accelerometer reads: gravitation minus the centrifugal part |
| first 0.1 s of free fall from 500 ft | 9.786 m/s² | the same 9.795, minus a little drag |
| WGS84 normal-gravity formula at 32.25° N | 9.795 m/s² | textbook value |

So `quad_common.G_ORIGIN = 9.795`, and PyBullet uses `p.setGravity(0, 0, -9.795)`. The often-quoted 9.81 would make the PyBullet quad 0.15 % heavier. That is small, but it shows up as an offset in the altitude integrator and in the thrust check.

**Watch the latitude.** `ground.xml` says `<latitude unit="DEG"> 32.08 </latitude>` with no `type` attribute. JSBSim reads that as **geocentric** latitude, which is 32.25° geodetic. The quad's `run.json` records `origin_lat_deg: 32.2534`. It is a 0.17° (19 km) difference, harmless here, but it matters when you compare JSBSim positions with a map (Module 11).

## Drag

Both engines use the same simple body drag: C_D = 1.0 on S = 0.06 m², opposite to the airspeed.

```
F_drag = ½ ρ C_D S |v|²  ≈  0.0368 · |v|²  N        (ρ = 1.225 kg/m³)
```

At 5 m/s that is 0.92 N, enough to stop a 1.5 kg quad from drifting forever after a tilt. There is also rotational damping, c_ω = 0.01 lbf·ft per rad/s = 0.0136 N·m·s/rad on each axis. That is `-0.01 · p` in the model's `<aerodynamics>`, whose moments are in lbf·ft.

In PyBullet:

```python
v = s["lin"]                                                   # world velocity (ENU)
drag = -0.5 * Q.RHO * Q.CD_S * np.linalg.norm(v) * v
p.applyExternalForce(quad, -1, drag.tolist(), s["pos"].tolist(), p.WORLD_FRAME)
tau = np.array([0, 0, tau_z]) - Q.ROT_DAMP * s["w_flu"]       # body frame
p.applyExternalTorque(quad, -1, tau.tolist(), p.LINK_FRAME)
```

## Motor lag

An ESC and motor do not change speed instantly. Both engines model each motor as a first-order lag, τ = 0.05 s:

```
du/dt = (u_cmd − u) / τ          T = 8 N · u
```

JSBSim: `<lag_filter>` with `c1 = 20` (= 1/τ). PyBullet: the exact discrete form, which is stable for any step size:

```python
self.motor += (self.cmd - self.motor) * (1 - math.exp(-dt / Q.TAU_MOTOR))
```

The lag matters for control. It adds about 0.05 s of phase delay inside the attitude loop. That is one reason the attitude gains cannot simply be raised forever.

## The open-loop instability demo

Set all four motors to the hover command, 0.459, and give motor 1 just **2 % more**. No controller. What happens?

```bash
python sims/quad_pybullet.py --fast --open-loop-demo --duration 10
# quad_pybullet summary: {'end': 'flipped (|roll| > 90 deg) at t = 2.15 s', ...
#                         'final_rpy_deg': [-90.6, 47.0, -42.0]}
```

The quad flips in **2.15 s**. Predict it by hand. Motor 1 produces 0.02 · 3.67 N = 0.073 N extra at (x, y) = (0.177, −0.177):

```
roll moment  = y · ΔT = −0.177 · 0.073 = −0.0130 N m     → roll LEFT  (motor 1 is on the right)
pitch moment = −x · ΔT (FLU)           = −0.0130 N m     → nose UP    (motor 1 is in front)
angular acceleration ≈ 0.0130 / 0.015 = 0.87 rad/s²
time to 90° ≈ sqrt(2 · 1.571 / 0.87) ≈ 1.9 s
```

The simulation says 2.15 s. The motor lag and the rotational damping slow it slightly. The signs match too: roll −90.6° (left), pitch +47° (nose up). The yaw of −42° comes from coupling once the body is tilted.

**Why this matters.** A quad has **no restoring moment**. Nothing pulls it back to level. Any torque imbalance, from a 2 % motor mismatch, a CG 5 mm off-center, or a gust, integrates twice into an ever-growing angle. Every multirotor needs closed-loop attitude control at a high rate. That is the next page.

This is also a free frame test. If your demo rolls **right** or pitches **down** with motor 1 high, your motor positions or your force frame are wrong.

## Try it

- Run the demo with motors 2, 3 and 4 high in turn. Predict the roll and pitch signs from the table on page 01 before each run.
- Make the excess 0.5 % instead of 2 %. Predict the flip time from t ∝ 1/√ΔT, then measure it.
- Set `G_ORIGIN = 9.81` and repeat the hover part of the lab mission. How large is the thrust offset, in newtons and as a throttle value?
- In JSBSim, print `accelerations/gravity-ft_sec2` at latitudes 0°, 45° and 90° (change the IC). Compare with the WGS84 formula.

## References

- JSBSim Reference Manual (FGInitialCondition, latitude types): <https://jsbsim-team.github.io/jsbsim-reference-manual/>
- WGS84 normal gravity (Somigliana formula): NGA.STND.0036, *World Geodetic System 1984*
- [Frames cheat sheet](../reference/frames.md), section "Where gravity points"
