# 06 The Godot side: stick input, spinning rotors, FPV

One Godot scene, `scenes/quad_lab.tscn`, shows the quad whichever engine runs it. That works because both sims send the same things: vehicle id 2, a Godot-frame pose with a MODEL-frame quaternion at 60 Hz, and the four motor outputs. The scene is built from earlier parts: Module 2's terrain, range and `quad.tscn`, Module 5's `RenderClock`, and Module 6's `CameraRig`. It adds three things: stick input (ATTITUDE, cmd 10), rotors that spin with the real motor outputs, and an FPV picture-in-picture without propellers in it.

## ATTITUDE from keyboard and gamepad

The scene reuses Module 2's input actions and adds the arrow keys for yaw:

| Input | Keyboard (action) | Gamepad (Mode 2) | ATTITUDE arg | Sign |
|---|---|---|---|---|
| roll | D / A (`move_right` / `move_left`) | right stick X | `roll_deg` (±20) | right = + |
| pitch | S / W (`move_back` / `move_forward`) | right stick Y | `pitch_deg` (±20) | **W = nose down = negative** = fly forward |
| yaw | → / ← (`ui_right` / `ui_left`) | left stick X | `yawrate_dps` (±60) | right (nose right) = + |
| throttle | E / Q (`move_up` / `move_down`) | left stick Y | `throttle` 0–1 | 0.5 = hold altitude (page 03) |

M toggles manual mode, C (`camera_next`) switches the main view between chase and onboard, P (`pause_toggle`) pauses, N single-steps, and R (`reset`) resets. P and R are Module 2's own actions, so the keys mean the same thing in every scene of the course.

```gdscript
func _read_input() -> void:
	var roll := Input.get_axis("move_left", "move_right")       # D = roll right = +
	var pitch := Input.get_axis("move_forward", "move_back")    # W = nose DOWN = - = fly forward
	var yaw := Input.get_axis("ui_left", "ui_right")            # right arrow = nose right = +
	var thr := 0.5 + 0.5 * Input.get_axis("move_down", "move_up")   # E climb, Q sink
	if Input.get_connected_joypads().size() > 0:                # Mode 2, small deadzone
		var dz := func(v: float) -> float: return 0.0 if absf(v) < 0.08 else v
		roll += dz.call(Input.get_joy_axis(0, JOY_AXIS_RIGHT_X))
		pitch += dz.call(Input.get_joy_axis(0, JOY_AXIS_RIGHT_Y))       # stick forward = -1 = nose down
		yaw += dz.call(Input.get_joy_axis(0, JOY_AXIS_LEFT_X))
		thr -= 0.5 * dz.call(Input.get_joy_axis(0, JOY_AXIS_LEFT_Y))     # stick forward = climb
	set_sticks(clampf(roll, -1, 1) * MAX_ANGLE_DEG, clampf(pitch, -1, 1) * MAX_ANGLE_DEG,
			clampf(yaw, -1, 1) * MAX_YAWRATE_DPS, clampf(thr, 0, 1))
```

Godot's joystick Y axes read **−1 when pushed forward**. Pushing the right stick forward must fly forward, which needs a nose-down (negative) pitch, so `pitch += axis_y` has the correct sign without negation. Pushing the left stick forward should climb, so throttle **subtracts** the axis. Check every axis on your own gamepad with the HUD before you fly. Gamepads differ, and this mapping was not tested with real hardware here.

Like `DIFF_DRIVE` in Module 9, ATTITUDE goes out unreliably at 50 Hz while manual mode is on. Physics treats it as stick input with a 0.5 s timeout. An ATTITUDE packet also switches a running mission to manual, at the current altitude.

## Motor outputs: the TELEMETRY extension

The pose says where the quad is. It says nothing about how fast each rotor spins. Godot could guess from the throttle it sends, but in mission mode it sends nothing, and it could never see the mixer's differential. The protocol's rule is clear ([protocol.md](../reference/protocol.md), "Changing the protocol"): add a **new message type**, never change an existing layout.

The course already has one: **TELEMETRY, type 100**, specified in [protocol.md](../reference/protocol.md) ("Extension: TELEMETRY"). Its code is in the shared files you copied during setup (`physics/robosim/telemetry.py`, `godot/bridge/telemetry_bridge.gd`). Its body is a vehicle id, a **code**, a count and that many floats. This module uses code 2 (Module 11 will use code 1 for flight data, Module 12 code 3):

| Type | Code | Direction | Values |
|---|---|---|---|
| TELEMETRY (100) | 2 = MOTORS | physics → viewer, unreliable, 60 Hz | 4 normalized motor outputs 0–1 after the lag, motor order 1…4 |

Python side, in `quad_common.py`:

```python
from robosim import telemetry
TELEM_MOTORS = 2                     # code 2: values = 4 normalized motor outputs 0..1, order 1..4

def send_motors(bridge, t_sim, values):
    telemetry.send_telemetry(bridge, t_sim, VEHICLE_ID, TELEM_MOTORS, [float(v) for v in values])
```

Godot side: the scene's `SimBridge` node runs `telemetry_bridge.gd` instead of `sim_bridge.gd`. `TelemetryBridge` *extends* `SimBridge`, drains the socket itself, hands POSE and ACK to the parent's code and emits `telemetry_received` for type 100. `sim_bridge.gd` stays untouched, and a viewer without the extension simply ignores type 100.

```gdscript
bridge.telemetry_received.connect(func(vid: int, code: int, _t: float, values: PackedFloat32Array) -> void:
	if vid == VID and code == TELEM_MOTORS:
		rotors.set_outputs(values))
```

## Spinning rotors that tell the truth

`vehicles/rotor_spinner.gd` is a small node you add as a child of Module 2's quad instance. Module 2 drew each rotor as a flat colored disc, and a disc spinning about its own axis looks exactly like a disc standing still. So `RotorSpinner` gives each of the four `Rotor_*` nodes a thin dark blade, then spins them:

```gdscript
const ROTOR_NAMES := ["Rotor_FR", "Rotor_BL", "Rotor_FL", "Rotor_BR"]   # motors 1, 2, 3, 4
const SPIN := [1.0, 1.0, -1.0, -1.0]       ## +1 = CCW seen from above = positive rotation about +Y
const VISUAL_RAD_S_AT_FULL := 40.0         ## real props turn ~1000 rad/s; on screen that only aliases

func _process(delta: float) -> void:
	for i in mini(4, outputs.size()):
		var u := clampf(outputs[i], 0.0, 1.0)
		# thrust ~ rpm^2, so the spin speed goes with sqrt(thrust)
		_rotors[i].rotate_y(SPIN[i] * VISUAL_RAD_S_AT_FULL * sqrt(u) * delta)
```

| Choice | Why |
|---|---|
| speed ∝ √u | for a real propeller thrust ∝ rpm², so rpm ∝ √thrust. Our model's thrust is linear in u, so √u is the honest mapping. |
| 40 rad/s at full output | a two-blade prop looks the same after half a turn. At 60 fps, anything above about 94 rad/s (a quarter turn per frame) starts to look slower or backwards (the wagon-wheel effect). Slow and readable beats fast and wrong. |
| `rotate_y(spin · …)` | Godot +Y is up, and a positive rotation about +Y is CCW seen from above, so motors 1 and 2 use spin = +1 |

The HUD prints the four outputs. In the end-to-end test, just after a right yaw command ended, it showed motors 1–2 at 0.455 and 3–4 at 0.464. The CW pair was working harder to stop the nose-right rotation. That is the reaction-torque sign from page 01, visible in Godot.

## FPV: a Module 6 rig, minus the props

The scene adds a Module 6 `CameraRig` (RIGID, 640 × 360, vertical fov 70°) under Module 2's `Mounts/fpv_cam`, and shows its texture as a picture-in-picture. For the course's pinhole convention (vertical fov), the intrinsics are:

```
fy = (H/2) / tan(35°) = 180 / 0.7002 = 257.1 px,  fx = fy,  cx = 320,  cy = 180
```

To stream it, point your Module 7 capture at this rig's viewport (`onboard.viewport`), exactly as you did for the Module 6 rigs. No code in this module changes for that.

In the first renders, the front rotor discs showed in the corners of the FPV image. Real FPV cameras often see props too, but here they only hide the gates. So `RotorSpinner` puts the rotors and blades on **visual layer 2**, and the scene removes that layer from the rig's camera:

```gdscript
quad.mount("fpv_cam").add_child(onboard)          # the rig builds its camera in _ready
onboard.camera.cull_mask &= ~(1 << (RotorSpinner.ROTOR_LAYER - 1))   # no props in the FPV
```

The chase camera still sees the rotors. This is a Godot-only visual choice, and physics never knew about the discs.

Chase view during the gate run, at t = 41.5 s, lined up for gate 1 (FPV picture-in-picture at the bottom right):

![chase view with FPV picture-in-picture](img/quad_chase.png)

The FPV image at the same moment, with gate 1 ahead and gates 2 and 3 behind it:

![FPV camera](img/quad_fpv.png)

## The HUD attitude, from the Godot basis

The [frames shortcut](../reference/frames.md) says that the Godot basis equals `Basis.from_euler(Vector3(θ, −ψ, −φ))` in YXZ order. So `get_euler()` gives the aerospace angles back:

```gdscript
func attitude_deg() -> Vector3:
	var e := quad.global_transform.basis.get_euler()      # x = θ, y = −ψ, z = −φ
	return Vector3(rad_to_deg(-e.z), rad_to_deg(e.x), wrapf(rad_to_deg(-e.y), -180.0, 180.0))
```

That holds for the PyBullet quad too, because both sims put the same MODEL-frame quaternion on the wire. The autotest uses it to check that a ±10° roll command arrives as −10.0…10.0° in Godot, for both engines.

## Try it

- Fly with the keyboard. Then hold A and D together and explain why nothing happens.
- Remove the `cull_mask` line and fly the gate run in the onboard view (C).
- Send the motor telemetry at 10 Hz instead of 60 Hz. Can you see the difference in the rotors? (They hold the last value; Module 5's interpolation only covers poses.)
- Log `telemetry_received` in Godot and compare the values with `control.csv` columns `m1`…`m4` at the same `t_sim`.

## References

- Godot `Input.get_joy_axis`: <https://docs.godotengine.org/en/stable/classes/class_input.html>
- Godot `Camera3D.cull_mask` and `VisualInstance3D.layers`: <https://docs.godotengine.org/en/stable/classes/class_camera3d.html>, <https://docs.godotengine.org/en/stable/classes/class_visualinstance3d.html>
- [Protocol](../reference/protocol.md); [Module 6: cameras](../m06_cameras/README.md); [Module 7: frame transport](../m07_frame_transport/README.md); [protocol: Extension TELEMETRY](../reference/protocol.md)
