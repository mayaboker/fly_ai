class_name RotorSpinner
extends Node
## Spins the four rotor discs of Module 2's quad.tscn at the motor outputs physics reports
## (TELEMETRY code 2, see physics/sims/quad_common.py). Add it as a child of the quad.
## Motor order is ArduPilot/PX4 Quad-X: 1 front-right CCW, 2 back-left CCW, 3 front-left CW,
## 4 back-right CW. A plain disc spinning about its axis looks still, so each rotor gets a blade.
## Rotors and blades go to visual layer ROTOR_LAYER, so an FPV camera can leave them out.

const ROTOR_NAMES := ["Rotor_FR", "Rotor_BL", "Rotor_FL", "Rotor_BR"]
const SPIN := [1.0, 1.0, -1.0, -1.0]       ## +1 = CCW seen from above = positive rotation about +Y
const VISUAL_RAD_S_AT_FULL := 40.0         ## real props turn ~1000 rad/s; on screen that only aliases
const ROTOR_LAYER := 2

var outputs := PackedFloat32Array([0.0, 0.0, 0.0, 0.0])
var _rotors: Array[Node3D] = []


func _ready() -> void:
	var visual := get_parent().get_node("Visual")
	for n in ROTOR_NAMES:
		var rotor: MeshInstance3D = visual.get_node(n)
		var blade := MeshInstance3D.new()
		var mesh := BoxMesh.new()
		mesh.size = Vector3(0.21, 0.004, 0.025)
		blade.mesh = mesh
		blade.position = Vector3(0, 0.006, 0)
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.08, 0.08, 0.08)
		blade.material_override = mat
		rotor.add_child(blade)
		rotor.layers = 1 << (ROTOR_LAYER - 1)
		blade.layers = 1 << (ROTOR_LAYER - 1)
		_rotors.append(rotor)


func set_outputs(values: PackedFloat32Array) -> void:
	outputs = values


func _process(delta: float) -> void:
	for i in mini(4, outputs.size()):
		var u := clampf(outputs[i], 0.0, 1.0)
		# thrust ~ rpm^2, so the spin speed goes with sqrt(thrust)
		_rotors[i].rotate_y(SPIN[i] * VISUAL_RAD_S_AT_FULL * sqrt(u) * delta)
