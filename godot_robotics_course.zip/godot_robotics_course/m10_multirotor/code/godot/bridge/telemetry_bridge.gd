class_name TelemetryBridge
extends SimBridge
## SimBridge + the TELEMETRY extension (message type 100, see physics/robosim/telemetry.py).
## sim_bridge.gd stays untouched: this subclass drains the socket itself, hands POSE and ACK
## to the parent's code and handles type 100. Everything else (HELLO, resends) is the parent's.
##   body: vehicle_id u16, code u16, count u16, reserved u16, count x f32  (same layout as SENSOR)

signal telemetry_received(vehicle_id: int, code: int, t_sim: float, values: PackedFloat32Array)

const MSG_TELEMETRY := 100
const TELEM_FLIGHT := 1

var telemetry := {}          ## vehicle_id -> {code, t_sim, values} (newest only)


func _process(delta: float) -> void:
	while _udp.get_available_packet_count() > 0:
		var pkt := _udp.get_packet()
		var msg := RsProtocol.unpack(pkt)
		if msg.is_empty():
			continue
		match msg.type:
			RsProtocol.MSG_POSE:
				_on_pose(msg)
			RsProtocol.MSG_ACK:
				_pending.erase(msg.acked_seq)
			MSG_TELEMETRY:
				_on_telemetry(pkt, msg)
	super._process(delta)        # finds the socket empty; sends HELLO and resends commands


func _on_telemetry(pkt: PackedByteArray, msg: Dictionary) -> void:
	var o := RsProtocol.HEADER_SIZE
	if pkt.size() < o + 8:
		return
	var vid := pkt.decode_u16(o)
	var code := pkt.decode_u16(o + 2)
	var n := pkt.decode_u16(o + 4)
	if pkt.size() < o + 8 + 4 * n:
		return
	var values := PackedFloat32Array()
	values.resize(n)
	for i in n:
		values[i] = pkt.decode_float(o + 8 + 4 * i)
	telemetry[vid] = {"code": code, "t_sim": msg.t_sim, "values": values}
	telemetry_received.emit(vid, code, msg.t_sim, values)


## Velocity (Godot frame, m/s) of the newest pose. Zero if none yet.
func latest_velocity(vehicle_id: int) -> Vector3:
	return _buffers[vehicle_id].back().vel if has_vehicle(vehicle_id) else Vector3.ZERO


## Wall-clock seconds since the last pose arrived (INF before the first one).
func seconds_since_pose() -> float:
	return INF if _last_rx_wall < 0.0 else _wall() - _last_rx_wall
