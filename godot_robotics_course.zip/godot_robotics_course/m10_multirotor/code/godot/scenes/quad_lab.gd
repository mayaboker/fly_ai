extends Node3D
## Module 10 viewer: the quad (vehicle 2) from quad_pybullet.py OR quad_jsbsim.py, same scene.
##   - places Module 2's quad.tscn from POSE with the Module 5 render clock + SimBridge.sample()
##   - TELEMETRY code 2 (motor outputs, see reference/protocol.md) spins the rotors
##   - main view: chase or onboard (camera_next, C); FPV picture-in-picture from a Module 6
##     CameraRig on the fpv_cam mount; the rotors are hidden from it with a cull mask
##   - manual flying: M toggles; ATTITUDE (cmd 10) at 50 Hz from keys or a gamepad (Mode 2)
##       W/S pitch (W = nose down = forward)   A/D roll   left/right arrow yaw   E/Q climb/sink
##   - pause_toggle (P), N single step, reset (R)
## Test options (after "--"):  --ports=9200,9201   --autotest   --shot=DIR@T   --quit-after=S

const VID := 2
const TELEM_MOTORS := 2               ## same code as quad_common.TELEM_MOTORS
const MAX_ANGLE_DEG := 20.0
const MAX_YAWRATE_DPS := 60.0
const SEND_HZ := 50.0

@onready var bridge: TelemetryBridge = $SimBridge
@onready var terrain: HeightmapTerrain = $Terrain
@onready var quad: Vehicle = $Quad
@onready var rotors: RotorSpinner = $Quad/RotorSpinner
@onready var view_cam: Camera3D = $ViewCam
@onready var hud: Label = $UI/Hud
@onready var pip: TextureRect = $UI/Pip

var clock := RenderClock.new()
var onboard: CameraRig
var manual := false
var use_input := true                 ## the autotest switches this off and calls set_sticks()
var sticks := Vector4(0, 0, 0, 0.5)   ## roll_deg, pitch_deg, yawrate_dps, throttle 0..1
var paused := false
var motors_rx := 0
var poses_rx := 0
var _send_acc := 0.0
var _onboard_main := false
var _args := {}
var _t_wall := 0.0
var _shot_done := false
var _roll_range := Vector2(INF, -INF)
var _alt0 := NAN
var _alt_max := -INF


func _enter_tree() -> void:
	for a in OS.get_cmdline_user_args():
		var kv := a.trim_prefix("--").split("=", true, 1)
		_args[kv[0]] = kv[1] if kv.size() > 1 else ""
	if _args.has("ports"):
		var p: PackedStringArray = _args.ports.split(",")
		$SimBridge.listen_port = int(p[0])
		$SimBridge.physics_port = int(p[1])


func _ready() -> void:
	onboard = CameraRig.new()
	onboard.camera_name = "fpv"
	onboard.mode = CameraRig.Mode.RIGID
	onboard.image_size = Vector2i(640, 360)
	onboard.fov_v_deg = 70.0
	quad.mount("fpv_cam").add_child(onboard)          # the rig builds its camera in _ready
	onboard.camera.cull_mask &= ~(1 << (RotorSpinner.ROTOR_LAYER - 1))   # no props in the FPV
	pip.texture = onboard.viewport.get_texture()
	bridge.pose_received.connect(func(_vid: int, msg: Dictionary) -> void:
		poses_rx += 1
		paused = (msg.flags & RsProtocol.POSE_FLAG_PAUSED) != 0
		clock.observe(msg.t_sim, Time.get_ticks_usec() / 1e6))
	bridge.physics_reset.connect(func() -> void: clock.reset())
	bridge.telemetry_received.connect(func(vid: int, code: int, _t: float, values: PackedFloat32Array) -> void:
		if vid == VID and code == TELEM_MOTORS:
			rotors.set_outputs(values)
			motors_rx += 1)
	if _args.has("autotest") or _args.has("quit-after"):
		Engine.max_fps = 60
	if _args.has("autotest"):
		use_input = false
		manual = true


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("camera_next"):
		_onboard_main = not _onboard_main
	elif event.is_action_pressed("pause_toggle"):
		bridge.send_command(VID, RsProtocol.CMD_RESUME if paused else RsProtocol.CMD_PAUSE)
	elif event.is_action_pressed("reset"):
		bridge.send_command(VID, RsProtocol.CMD_RESET)
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_M:
			manual = not manual
		elif event.keycode == KEY_N:
			bridge.send_command(VID, RsProtocol.CMD_STEP)


func set_sticks(roll_deg: float, pitch_deg: float, yawrate_dps: float, throttle: float) -> void:
	sticks = Vector4(roll_deg, pitch_deg, yawrate_dps, throttle)


func _read_input() -> void:
	var roll := Input.get_axis("move_left", "move_right")       # D = roll right = +
	var pitch := Input.get_axis("move_forward", "move_back")    # W = nose DOWN = - = fly forward
	var yaw := Input.get_axis("ui_left", "ui_right")            # right arrow = nose right = +
	var thr := 0.5 + 0.5 * Input.get_axis("move_down", "move_up")   # E climb, Q sink
	if Input.get_connected_joypads().size() > 0:                # Mode 2, small deadzone
		var dz := func(v: float) -> float: return 0.0 if absf(v) < 0.08 else v
		roll += dz.call(Input.get_joy_axis(0, JOY_AXIS_RIGHT_X))
		pitch += dz.call(Input.get_joy_axis(0, JOY_AXIS_RIGHT_Y))       # stick forward = -1 = nose down
		yaw += dz.call(Input.get_joy_axis(0, JOY_AXIS_LEFT_X))
		thr -= 0.5 * dz.call(Input.get_joy_axis(0, JOY_AXIS_LEFT_Y))     # stick forward = climb
	set_sticks(clampf(roll, -1, 1) * MAX_ANGLE_DEG, clampf(pitch, -1, 1) * MAX_ANGLE_DEG,
			clampf(yaw, -1, 1) * MAX_YAWRATE_DPS, clampf(thr, 0, 1))


func _process(delta: float) -> void:
	_t_wall += delta
	if manual and use_input:
		_read_input()
	_send_acc += delta
	if manual and _send_acc >= 1.0 / SEND_HZ:
		_send_acc = 0.0
		bridge.send_command_unreliable(VID, RsProtocol.CMD_ATTITUDE, [sticks.x, sticks.y, sticks.z, sticks.w])
	if bridge.has_vehicle(VID):
		var t := clock.advance(delta, bridge.latest_t_sim, paused)
		quad.global_transform = bridge.sample(VID, t)
		_update_view_cam(delta)
		onboard.sync_now()
	_update_hud()
	_test_hooks()


func _update_view_cam(delta: float) -> void:
	if _onboard_main:
		view_cam.global_transform = quad.mount("fpv_cam").global_transform
		return
	var t := quad.global_transform
	var back := t.basis.z
	back.y = 0.0
	if back.length() < 0.1:
		back = Vector3.BACK
	var want := t.origin + back.normalized() * 3.5 + Vector3.UP * 1.3
	view_cam.global_position = view_cam.global_position.lerp(want, minf(1.0, delta * 3.0))
	view_cam.look_at(t.origin, Vector3.UP)


## Aerospace angles back from the Godot basis (frames.md shortcut: from_euler(theta, -psi, -phi), YXZ).
func attitude_deg() -> Vector3:
	var e := quad.global_transform.basis.get_euler()
	return Vector3(rad_to_deg(-e.z), rad_to_deg(e.x), wrapf(rad_to_deg(-e.y), -180.0, 180.0))


func _update_hud() -> void:
	var s := "NO DATA FROM PHYSICS" if bridge.is_stale() else "t_sim %.2f s" % bridge.latest_t_sim
	if bridge.has_vehicle(VID):
		var p := quad.global_position
		var a := attitude_deg()
		s += "   ENU E %.1f N %.1f U %.1f (%.1f m above ground)   roll %.1f pitch %.1f yaw %.1f" % [
				p.x, -p.z, p.y, p.y - terrain.height_at_world(p.x, p.z), a.x, a.y, a.z]
	var m := rotors.outputs
	s += "\nmotors 1-4: %.2f %.2f %.2f %.2f   (%d telemetry packets)" % [m[0], m[1], m[2], m[3], motors_rx]
	s += "\n%s%s   sticks roll %.0f pitch %.0f yaw %.0f thr %.2f" % ["MANUAL" if manual else "mission/hold",
			"  PAUSED" if paused else "", sticks.x, sticks.y, sticks.z, sticks.w]
	s += "\n[M] manual  [W/S] pitch [A/D] roll [arrows] yaw [E/Q] climb/sink  [C] camera [P] pause [N] step [R] reset"
	hud.text = s


func _test_hooks() -> void:
	if _args.has("autotest"):            # a pilot's script: hold, roll right, roll left, climb, yaw right
		var k := Vector4(0, 0, 0, 0.5)
		if _t_wall > 3.0 and _t_wall < 5.0: k = Vector4(10, 0, 0, 0.5)
		elif _t_wall >= 5.0 and _t_wall < 7.0: k = Vector4(-10, 0, 0, 0.5)
		elif _t_wall >= 7.0 and _t_wall < 9.0: k = Vector4(0, 0, 0, 1.0)
		elif _t_wall >= 9.0 and _t_wall < 12.0: k = Vector4(0, 0, 30, 0.5)
		set_sticks(k.x, k.y, k.z, k.w)
		if bridge.has_vehicle(VID):
			var r := attitude_deg().x
			_roll_range = Vector2(minf(_roll_range.x, r), maxf(_roll_range.y, r))
			if is_nan(_alt0) and _t_wall > 2.5:
				_alt0 = quad.global_position.y
			_alt_max = maxf(_alt_max, quad.global_position.y)
		if _t_wall > 13.0:
			print("quad_autotest: t_sim %.2f stale %s poses %d motors_rx %d roll range %.1f..%.1f deg, climb %.2f m, motors %s"
					% [bridge.latest_t_sim, bridge.is_stale(), poses_rx, motors_rx, _roll_range.x, _roll_range.y,
					_alt_max - _alt0, str(rotors.outputs)])
			get_tree().quit()
	if _args.has("shot") and not _shot_done:
		var spec: PackedStringArray = _args.shot.split("@")
		if bridge.latest_t_sim >= float(spec[1]):
			_shot_done = true
			_save_shots(spec[0])
	if _args.has("quit-after") and _t_wall > float(_args["quit-after"]):
		get_tree().quit()


func _save_shots(dir: String) -> void:
	DirAccess.make_dir_recursive_absolute(dir)
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(dir.path_join("quad_chase.png"))
	onboard.viewport.get_texture().get_image().save_png(dir.path_join("quad_fpv.png"))
	print("saved shots at t_sim %.2f" % bridge.latest_t_sim)
