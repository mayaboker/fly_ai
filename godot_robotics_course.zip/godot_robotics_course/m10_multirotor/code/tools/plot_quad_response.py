"""
plot_quad_response.py - Module 10: step responses of one or more quad runs, plus the thrust check.

    cd robosim
    python tools/plot_quad_response.py logs/*_quad_pb logs/*_quad_js -o quad_response.png

Reads state.csv + control.csv + run.json (+ summary.json) of each run folder. Draws altitude,
roll, pitch and yaw rate against their commands for the step-test phase (0-34 s), a plan view
of the gate run with the gates from data/terrain/range.json, and prints:
  * step metrics: time to 63 % and 90 % of the step, overshoot, value at the end of the window
  * the thrust check: vertical acceleration predicted from the motors' total thrust
      a_pred = T_actual * cos(roll) * cos(pitch) / m - g        (drag ignored)
    against the measured vertical acceleration (finite difference of vz), in steady hover
    and over the whole flight.
  * the gate results from summary.json (lateral offset and height above the ground at each gate)
"""
import argparse, csv, json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

COLORS = ["#2a78d6", "#eb6834", "#1baf7a"]     # run 1, 2, 3 (fixed order)
CMD_COLOR = "#52514e"


def load(run):
    def rd(name):
        rows = list(csv.DictReader(open(os.path.join(run, name))))
        return {k: np.array([float(r[k]) if k != "mode" else 0.0 for r in rows]) for k in rows[0]}
    return json.load(open(os.path.join(run, "run.json"))), rd("state.csv"), rd("control.csv")


def step_metrics(t, y, t0, t1, y_from, y_to):
    """Step y_from -> y_to commanded at t0, window ends at t1.
    Returns time to 63 % and to 90 % of the commanded change (nan = never), overshoot % of the
    commanded change, and the value averaged over the last 0.2 s of the window."""
    m = (t >= t0) & (t < t1)
    tt, frac = t[m], (y[m] - y_from) / (y_to - y_from)
    t63 = tt[np.argmax(frac >= 0.63)] - t0 if np.any(frac >= 0.63) else np.nan
    t90 = tt[np.argmax(frac >= 0.90)] - t0 if np.any(frac >= 0.90) else np.nan
    over = max(0.0, (np.max(frac) - 1.0) * 100)
    final = np.mean(y[(t >= t1 - 0.2) & (t < t1)])
    return t63, t90, over, final


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("runs", nargs="+")
    ap.add_argument("-o", "--out", default="quad_response.png")
    ap.add_argument("--range", default="data/terrain/range.json", help="for the gates in the plan view")
    a = ap.parse_args()

    fig = plt.figure(figsize=(14, 9))
    gs = fig.add_gridspec(4, 2, width_ratios=[1.6, 1.0])
    axes = [fig.add_subplot(gs[0, 0])]
    axes += [fig.add_subplot(gs[k, 0], sharex=axes[0]) for k in (1, 2, 3)]
    plan = fig.add_subplot(gs[:, 1])
    panels = [("alt", "alt_cmd", "altitude (m)"), ("roll_deg", "roll_cmd_deg", "roll (deg)"),
              ("pitch_deg", "pitch_cmd_deg", "pitch (deg)"), ("r_dps", "yawrate_cmd_dps", "yaw rate (deg/s)")]
    for i, run in enumerate(a.runs[:len(COLORS)]):
        meta, s, c = load(run)
        name = f"{meta.get('physics')} {meta.get('physics_hz'):.0f} Hz"
        t = s["t_sim"]
        for ax, (k, kc, lab) in zip(axes, panels):
            if i == 0:
                ax.plot(c["t_sim"], c[kc], color=CMD_COLOR, lw=1.2, ls="--", label="command")
            ax.plot(t, s[k], color=COLORS[i], lw=2.4 if i == 0 else 1.2, label=name)
            ax.set_ylabel(lab)
        plan.plot(s["x"], s["y"], color=COLORS[i], lw=2.4 if i == 0 else 1.2, label=name)

        # ---- step metrics (windows match quad_common.MISSION)
        print(f"\n== {os.path.basename(run.rstrip('/'))}  ({name})")
        for label, k, t0, t1, y0, y1 in [("altitude 3->5 m", "alt", 8.0, 14.0, 3.0, 5.0),
                                         ("roll 0->10 deg", "roll_deg", 14.0, 16.0, 0.0, 10.0),
                                         ("pitch 0->10 deg", "pitch_deg", 21.0, 23.0, 0.0, 10.0),
                                         ("yaw rate 0->45 dps", "r_dps", 28.0, 32.0, 0.0, 45.0)]:
            t63, t90, over, final = step_metrics(t, s[k], t0, t1, y0, y1)
            print(f"  {label:<20} t63 {t63:5.2f} s   t90 {t90:5.2f} s   overshoot {over:5.1f} %   "
                  f"value at window end {final:6.2f}")

        # ---- thrust check: intended/actual thrust vs measured vertical acceleration
        g, m = meta.get("g", None), meta.get("mass_kg", 1.5)
        if g is None:
            g = meta.get("g_accel_at_rest", 9.795)
        tilt = np.cos(np.radians(s["roll_deg"])) * np.cos(np.radians(s["pitch_deg"]))
        a_pred = c["thrust_actual_n"] * tilt / m - g
        a_meas = s["az_meas"]
        hover = (t > 12.0) & (t < 14.0)                     # hover at 5 m, after the altitude step
        fly = (t > 2.0) & (t < 34.0)
        print(f"  hover 12-14 s: intended thrust {np.mean(c['thrust_intended_n'][hover]):.3f} N, "
              f"actual {np.mean(c['thrust_actual_n'][hover]):.3f} N, m*g = {m * g:.3f} N, "
              f"mean az_meas {np.mean(a_meas[hover]):+.4f} m/s^2")
        err = a_meas[fly] - a_pred[fly]
        print(f"  whole flight 2-34 s: a_meas - a_pred  mean {np.mean(err):+.3f}, RMS {np.sqrt(np.mean(err ** 2)):.3f} m/s^2")
        sp = os.path.join(run, "summary.json")
        if os.path.exists(sp):
            summ = json.load(open(sp))
            for g in summ.get("gates", []):
                print(f"  {g['gate']}: lateral {g.get('lateral_m', float('nan')):+.2f} m, "
                      f"height {g.get('height_m', float('nan')):.2f} m, {'PASS' if g['ok'] else 'FAIL'}")
            if "hits" in summ:
                print(f"  collisions with range objects: {summ['hits'] or 'none'}")

    if os.path.exists(a.range):                         # gates as short bars across the flight path
        for g in json.load(open(a.range)).get("gates", []):
            psi = np.radians(g["heading_deg"])
            r = np.array([np.cos(psi), -np.sin(psi)]) * g["width_m"] / 2
            c = np.array([g["e"], g["n"]])
            plan.plot(*np.c_[c - r, c + r], color=CMD_COLOR, lw=3)
            plan.annotate(g["name"], c + r, xytext=(4, 0), textcoords="offset points", fontsize=8,
                          color=CMD_COLOR, va="center")
    plan.set_aspect("equal")
    plan.set_xlabel("east (m)")
    plan.set_ylabel("north (m)")
    plan.set_title("Plan view: pad (0, 0) and the gate run", loc="left", fontsize=11)
    plan.legend(frameon=False, fontsize=9, loc="lower right")
    for ax in axes + [plan]:
        ax.grid(True, color="#e4e3df", lw=0.6)
        for sp in ("top", "right"):
            ax.spines[sp].set_visible(False)
    axes[0].set_xlim(0, 34)
    axes[0].legend(frameon=False, fontsize=9, ncol=3, loc="lower right")
    axes[-1].set_xlabel("sim time (s)")
    axes[0].set_title("Step tests above the pad (mission in quad_common.py)", loc="left", fontsize=11)
    fig.tight_layout()
    fig.savefig(a.out, dpi=110)
    print("\nwrote", a.out)


if __name__ == "__main__":
    main()
