# Module 10 reference code

These files mirror their paths in `robosim/`. [lab.md](../lab.md) says where each one goes. They build on Module 2 (terrain, `range.json`, `terrain.py`, `HeightmapTerrain`, `RangeBuilder`, `quad.tscn`), Module 4 (bridge), Module 5 (`RenderClock`), Module 6 (`CameraRig`) and Module 9 (`physics/robosim/pybullet_world.py`). Copy the JSBSim model from `reference/code/aircraft/quad_rpy` to `physics/aircraft/quad_rpy`. No shared file is modified.

```
physics/sims/quad_common.py         airframe, Quad-X table, attitude PD + mixer, altitude PI (+anti-windup),
                                    PathFollower, Mission (steps + gate run + landing), ManualInput,
                                    motor outputs as TELEMETRY code 2
physics/sims/quad_pybullet.py       PyBullet quad: 4 motor forces + reaction torque in LINK_FRAME (vehicle 2)
physics/sims/quad_jsbsim.py         JSBSim quad_rpy with its built-in controller (vehicle 2)
physics/tests/test_quad_signs.py    sign/frame checklist for both engines
physics/robosim/telemetry.py        TELEMETRY extension (type 100); identical to reference/code
tools/plot_quad_response.py         step metrics, thrust check, gate results, plot with plan view
godot/bridge/telemetry_bridge.gd    SimBridge subclass for type 100; identical to reference/code
godot/vehicles/rotor_spinner.gd     blades + spin for Module 2's quad rotors; rotors on visual layer 2
godot/scenes/quad_lab.tscn/.gd      the viewer: range + quad, chase/onboard view, FPV PiP, ATTITUDE, tests
```

## How to run

```bash
cd ~/robosim/physics
python sims/quad_pybullet.py --fast --open-loop-demo --duration 10
python sims/quad_pybullet.py --fast --run-name quad_pb
python sims/quad_jsbsim.py   --fast --run-name quad_js
python tests/test_quad_signs.py
cd .. && python tools/plot_quad_response.py logs/*_quad_pb logs/*_quad_js -o quad_response.png

godot --headless --path godot --import
python physics/sims/quad_jsbsim.py --mode manual       # then run godot/scenes/quad_lab.tscn
```

Options shared by both sims: `--mode mission|manual`, `--pad E,N` (default 0,0), `--duration`, `--fast`, `--no-wait`, `--physics-hz`, `--decim`, `--run-name`, `--viewer-port`, `--listen-port`. PyBullet only: `--open-loop-demo`. `quad_lab.gd` test options (after `--`): `--ports=L,P`, `--autotest`, `--shot=DIR@T`, `--quit-after=S`.

## What was verified, and how

Tested on Linux (2 CPU cores) with Python 3.11, PyBullet 3.2.7, JSBSim 1.3.1, numpy 2.4, matplotlib 3.10 and Godot 4.7.2-stable, in a scratch copy of `robosim/` assembled from the Module 2, 4, 5, 6, 9 and 11 reference code, on Module 2's terrain (seed 42). The bridge used test ports 9200/9201; the defaults in the code are 9001/9002.

| What | How | Result |
|---|---|---|
| PyBullet force/torque frames | probe body rolled 90°, one step per call | `LINK_FRAME` torque and force correct; `WORLD_FRAME` `posObj` is a world point (a 5 m lever-arm error when misused) |
| JSBSim gravity at the origin | `gravity-ft_sec2`, `a-pilot-z` at rest, 0.1 s of free fall | 9.819 / 9.795 / 9.786 m/s²; WGS84 formula at 32.2534° N: 9.795 |
| JSBSim origin latitude | `ic/lat-geod-rad` after `load_ic("ground")` | 32.2534° geodetic (`ground.xml`'s 32.08° is geocentric) |
| JSBSim roll moment | `moments/l-external-lbsft` vs thrusts × arm | equal (0.1329 N·m) |
| terrain before `run_ic` | set it after the IC instead, ground at 7.15 m | quad launched to 87 m AGL, hence the order |
| open-loop demo | motor 1 +2 %, no controller | flips at 2.15 s, roll −90.6°, pitch +47° |
| mission, both engines | `--fast`, `plot_quad_response.py` | numbers in [lab.md](../lab.md) Step 4; all gates PASS; no PyBullet hits; both land at (−0.02, −0.02) |
| anti-windup | `I_ZONE` = 0.3 m vs none | altitude overshoot 1.8 % vs 21.3 % |
| tilt compensation | on vs off, ±10° roll doublet | altitude 5.000–5.006 m vs 4.97–5.02 m |
| PyBullet default damping | 0.04 vs 0 | yaw rate 34.6 vs 35.6 °/s; mission 105.0 vs 101.7 s |
| JSBSim rate | 120 vs 240 Hz | roll t90 0.35 vs 0.42 s (PyBullet at 240 Hz: 0.40 s) |
| sign checklist | `test_quad_signs.py` | PASS, both engines |
| Godot ↔ Python, both engines | `quad_lab.tscn --autotest` headless, sims in `--mode manual` | ~60 poses and 60 telemetry packets/s (771 and 776 in ~12.9 s), not stale; Godot roll −10.0…10.0°; climb 4.02 m in both |
| pause / step / resume / reset | a Python stand-in viewer, both sims | ACKed; time frozen while paused; STEP = +1/60 s; RESET flag on the next pose |
| rendering | `xvfb-run ... --rendering-driver opengl3`, `--shot=DIR@41` during the gate run | rotors visible in the chase view, hidden from the FPV by `cull_mask` (`../img/`) |
| telemetry files | `diff` against `reference/code` and Module 11's code | identical |

## Not tested here

- **Gamepad input.** No gamepad was attached. The axis mapping in `quad_lab.gd` follows Godot's documented conventions (stick forward = −1) but was not exercised. Check every axis with the HUD before flying.
- **Keyboard input by a human.** The autotest calls `set_sticks()` directly.
- **FPV streaming through Module 7.** The FPV rig was rendered offscreen and saved as PNG; the Module 7 transport itself was not connected.
- Windows and macOS.
