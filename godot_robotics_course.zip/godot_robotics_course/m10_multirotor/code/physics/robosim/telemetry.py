"""
telemetry.py - protocol v1 EXTENSION (a new message type, nothing changed). First used in Module 10.

TELEMETRY (type 100), physics -> viewer, unreliable, latest wins.
    header (16 B, as every v1 packet) + vehicle_id u16, code u16, count u16, reserved u16, count x f32
The body layout is the same as SENSOR, so both sides reuse the same packing code.

    code 1 = FLIGHT   values: airspeed_mps, alpha_deg, agl_m, terrain_m, crashed 0/1, phase, mode_ref
           phase: 0 = none (fixed-wing), 1 HOVER_UP, 2 TRANSITION, 3 CRUISE, 4 BACK_TRANS,
                  5 HOVER_DOWN, 6 LANDED (quadplane)
    code 2 = MOTORS   values: four normalized motor outputs 0..1, order 1..4      (Module 10)
    code 3 = TTC      values: state, tau_est, forward speed, true distance, true tau (Module 12)
    codes 100-199: free for your own experiments

Viewers that do not know type 100 ignore it (SimBridge's match falls through), so old
viewers keep working. That is the rule in reference/protocol.md: add a type, never change one.
"""
import struct
from . import protocol as P

MSG_TELEMETRY = 100
TELEM_FLIGHT = 1
TELEM_MOTORS = 2
TELEM_TTC = 3
PHASES = ["NONE", "HOVER_UP", "TRANSITION", "CRUISE", "BACK_TRANS", "HOVER_DOWN", "LANDED"]


def pack_telemetry(seq, t_sim, vehicle_id, code, values):
    return (P._header(MSG_TELEMETRY, seq, t_sim) + P.SENSOR_HEAD.pack(vehicle_id, code, len(values), 0)
            + struct.pack(f"<{len(values)}f", *values))


def unpack_telemetry(data):
    """bytes -> dict or None (for tests and log tools)."""
    msg = P.unpack(data)
    if msg is None or msg["type"] != MSG_TELEMETRY:
        return None
    body = data[P.HEADER.size:]
    vid, code, n, _ = P.SENSOR_HEAD.unpack_from(body)
    msg.update(vehicle_id=vid, code=code, values=struct.unpack_from(f"<{n}f", body, P.SENSOR_HEAD.size))
    return msg


def send_telemetry(bridge, t_sim, vehicle_id, code, values):
    """Send through an existing PhysicsBridge (uses its socket and sequence counter)."""
    bridge.tx.sendto(pack_telemetry(bridge._next(), t_sim, vehicle_id, code, values), bridge.viewer)
