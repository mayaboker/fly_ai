"""
test_quad_signs.py - Module 10 sign/frame checklist, automated, for BOTH engines.

    cd robosim/physics && python tests/test_quad_signs.py

Each test starts a fresh hover (nose north, 2 m), holds one stick for a moment and checks
the SIGN of the response in ENU and in the Godot pose that goes on the wire.
"""
import argparse, os, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(HERE, "..", "sims"))
from robosim.frames import quat_to_matrix, enu_flu_to_godot, jsbsim_state_to_godot
import quad_pybullet, quad_jsbsim

TESTS = [  # name, stick (roll_deg, pitch_deg, yawrate_dps, throttle), hold s, check(start, end)
    ("roll +10 -> drifts EAST (right of a north-facing quad)", (10, 0, 0, 0.5), 1.5,
     lambda a, b: b["v"][0] > 0.3 and abs(b["v"][1]) < 0.1),
    ("pitch +10 (nose up) -> drifts SOUTH (backward)", (0, 10, 0, 0.5), 1.5,
     lambda a, b: b["v"][1] < -0.3 and abs(b["v"][0]) < 0.1),
    ("yaw rate +30 -> nose turns from north toward EAST", (0, 0, 30, 0.5), 2.0,
     lambda a, b: b["fwd_godot"][0] > 0.3),
    ("throttle 1.0 -> climbs (+U, Godot +Y)", (0, 0, 0, 1.0), 1.0,
     lambda a, b: b["v"][2] > 0.5 and b["pos_godot"][1] > a["pos_godot"][1]),
]


def snapshot(sim, engine):
    s = sim.read()
    if engine == "pybullet":
        pos_g, q_g = enu_flu_to_godot(s["pos"], s["q"])
    else:
        pos_g, q_g = jsbsim_state_to_godot(sim.fdm, sim.origin)
    fwd = quat_to_matrix(q_g) @ np.array([0.0, 0.0, -1.0])         # model nose in Godot world
    return {"v": s["lin"], "pos_godot": pos_g, "fwd_godot": fwd}


def tick(sim, engine):
    if engine == "pybullet":
        th = np.zeros(4)
        for _ in range(sim.a.decim):
            th = sim.step_physics(sim.read())
        sim.outer_tick(sim.read(), th)
    else:
        for _ in range(sim.a.decim):
            sim.step_physics()
        sim.outer_tick()


def run(engine):
    common = dict(mode="manual", duration=0, fast=True, no_wait=True, run_name=f"signs_{engine}",
                  viewer_port=9200, listen_port=9201, pad="0,0")
    if engine == "pybullet":
        sim = quad_pybullet.QuadPyBullet(argparse.Namespace(physics_hz=240.0, decim=4, open_loop_demo=False, **common))
    else:
        sim = quad_jsbsim.QuadJSBSim(argparse.Namespace(physics_hz=120.0, decim=2, **common))
    ok = True
    for name, stick, hold, check in TESTS:
        sim.reset()
        while sim.t < 4.0:                                          # take off, hover at 2 m
            tick(sim, engine)
        a = snapshot(sim, engine)
        t_end = sim.t + hold
        while sim.t < t_end:
            sim.state["manual"].on_command(sim.t, stick)
            tick(sim, engine)
        b = snapshot(sim, engine)
        good = bool(check(a, b))
        ok &= good
        print(f"  [{'PASS' if good else 'FAIL'}] {name:<55} v_enu=({b['v'][0]:+.2f},{b['v'][1]:+.2f},"
              f"{b['v'][2]:+.2f})  nose_godot=({b['fwd_godot'][0]:+.2f},{b['fwd_godot'][1]:+.2f},{b['fwd_godot'][2]:+.2f})")
    sim.br.rx.close()
    sim.br.tx.close()
    sim.log.close()
    return ok


if __name__ == "__main__":
    all_ok = True
    for eng in ("pybullet", "jsbsim"):
        print(eng)
        all_ok &= run(eng)
    print("quad sign checklist:", "PASS" if all_ok else "FAIL")
    sys.exit(0 if all_ok else 1)
