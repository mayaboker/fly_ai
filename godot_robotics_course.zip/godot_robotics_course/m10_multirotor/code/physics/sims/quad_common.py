"""
quad_common.py - Module 10: what quad_pybullet.py and quad_jsbsim.py share.

  * the quad's numbers (same as aircraft/quad_rpy/quad_rpy.xml)
  * Quad-X motor layout in FLU, spin directions
  * the attitude PD + mixer (a line-by-line copy of the JSBSim model's controller)
  * the altitude controller (PI with tilt compensation, plus climb-rate damping)
  * the scripted mission (step tests, then a run through the Module 2 gates), manual ATTITUDE
  * motor outputs to Godot through the TELEMETRY extension (type 100, code 2)

Conventions: angles are AEROSPACE (roll right +, pitch nose-up +, yaw/yaw-rate nose-right +),
because that is what the ATTITUDE command and JSBSim use. Positions/velocities are ENU.
"""
import math
import numpy as np
from robosim import protocol as P
from robosim import telemetry

VEHICLE_ID = 2
FT, LBF = 0.3048, 4.44822

# ---- the airframe (keep in sync with quad_rpy.xml)
MASS = 1.5                         # kg
INERTIA = (0.015, 0.015, 0.028)    # kg m^2, body axes
T_MAX = 8.0                        # N per motor at cmd = 1
TAU_MOTOR = 0.05                   # s, first-order spin-up lag (JSBSim lag_filter c1 = 20)
K_TORQUE = 0.016                   # m: yaw reaction torque = K_TORQUE * thrust
CD_S = 0.06 * 1.0                  # m^2: drag coefficient x reference area
RHO = 1.225                        # kg/m^3 (JSBSim standard atmosphere near sea level)
ROT_DAMP = 0.01 * LBF * FT         # N m s/rad: JSBSim aero moment -0.01 lbf ft per rad/s
# Effective gravity at the JSBSim origin (lat 32.08 N). JSBSim 1.3.1 integrates on a rotating
# WGS84 Earth: accelerometer at rest reads 32.136 ft/s^2 = 9.795 m/s^2 (gravitation 9.818 minus
# the centrifugal part). PyBullet has no Earth, so we give it this number.
G_ORIGIN = 9.795

# Quad-X, ArduPilot/PX4 numbering. Positions in FLU (x fwd, y left), meters.
# spin: +1 = CCW seen from above. A CCW prop pushes the body CW (nose right, -z in FLU).
MOTORS = [  # (name, x, y, spin)
    ("1 front-right CCW", 0.177, -0.177, +1),
    ("2 back-left  CCW", -0.177, 0.177, +1),
    ("3 front-left  CW", 0.177, 0.177, -1),
    ("4 back-right  CW", -0.177, -0.177, -1),
]
HOVER_CMD = MASS * G_ORIGIN / (4 * T_MAX)   # 0.459


def motor_wrench_flu(thrusts):
    """Per-motor thrusts (N) -> total force and torque about the CG, both in FLU."""
    f = np.zeros(3)
    tau = np.zeros(3)
    for (_, x, y, spin), t in zip(MOTORS, thrusts):
        r = np.array([x, y, 0.0])
        F = np.array([0.0, 0.0, t])
        f += F
        tau += np.cross(r, F)
        tau[2] += -spin * K_TORQUE * t           # reaction torque
    return f, tau


# ---- attitude PD + mixer (identical to quad_rpy.xml's <system name="attitude-controller">)
KP_ATT, KD_ATT, KP_YAWRATE, YAW_CLIP = 0.25, 0.05, 0.10, 0.15


def attitude_mixer(throttle, roll_cmd, pitch_cmd, yawrate_cmd, phi, theta, p, q, r):
    """All angles rad, rates rad/s, aerospace signs. Returns 4 motor commands 0..1."""
    roll_out = KP_ATT * (roll_cmd - phi) - KD_ATT * p
    pitch_out = KP_ATT * (pitch_cmd - theta) - KD_ATT * q
    yaw_out = min(max(KP_YAWRATE * (yawrate_cmd - r), -YAW_CLIP), YAW_CLIP)
    m = [throttle - roll_out + pitch_out + yaw_out,     # 1 FR CCW
         throttle + roll_out - pitch_out + yaw_out,     # 2 BL CCW
         throttle + roll_out + pitch_out - yaw_out,     # 3 FL CW
         throttle - roll_out - pitch_out - yaw_out]     # 4 BR CW
    return [min(max(v, 0.0), 1.0) for v in m]


# ---- altitude: PI on altitude error, damping on measured climb rate, tilt compensation
class AltitudeController:
    KP, KI, KD = 4.0, 1.0, 3.2         # (m/s^2)/m, (m/s^2)/(m s), (m/s^2)/(m/s)
    I_LIMIT = 3.0                      # m/s^2
    I_ZONE = 0.3                       # m

    def __init__(self):
        self.i = 0.0

    def update(self, z_ref, z, vz, phi, theta, dt, armed=True):
        """z_ref, z: ENU up, m (absolute). Returns (throttle 0..1, intended total thrust N)."""
        if not armed:
            self.i = 0.0
            return 0.0, 0.0
        e = z_ref - z
        if abs(e) < self.I_ZONE:                 # integrate only near the setpoint (anti-windup):
            self.i = min(max(self.i + self.KI * e * dt, -self.I_LIMIT), self.I_LIMIT)
        a_cmd = self.KP * e + self.i - self.KD * vz
        tilt = max(math.cos(phi) * math.cos(theta), 0.5)            # never divide by ~0
        thrust = MASS * (G_ORIGIN + a_cmd) / tilt
        thr = min(max(thrust / (4 * T_MAX), 0.0), 0.9)              # leave 10 % for attitude
        return thr, thr * 4 * T_MAX


# ---- what the pilot (mission script or Godot) asks for
class Setpoint:
    def __init__(self):
        self.roll = self.pitch = self.yawrate = 0.0   # deg, deg, deg/s (aerospace signs)
        self.z_ref = 0.0                              # m, ENU up (absolute, like the terrain)
        self.armed = False


def wrap_deg(a):
    return (a + 180.0) % 360.0 - 180.0


class PathFollower:
    """Fly a 3D polyline (ENU m) with a carrot point, through attitude commands only.
    position -> carrot -> desired velocity -> desired acceleration -> tilt angles; heading
    follows the path direction so the FPV camera looks where the quad goes."""
    LOOKAHEAD, V_MAX, KP_POS, KV, A_MAX, TILT_MAX, K_PSI = 3.0, 2.5, 0.8, 1.5, 3.0, 20.0, 1.5

    def __init__(self, pts):
        self.p = np.asarray(pts, float)
        seg = np.diff(self.p[:, :2], axis=0)
        self.seg_len = np.maximum(np.hypot(seg[:, 0], seg[:, 1]), 1e-6)
        self.s = np.r_[0.0, np.cumsum(self.seg_len)]
        self.length = self.s[-1]
        self.i = 0

    def _point(self, s):
        s = min(max(s, 0.0), self.length)
        i = min(int(np.searchsorted(self.s, s, side="right")) - 1, len(self.seg_len) - 1)
        t = (s - self.s[i]) / self.seg_len[i]
        return self.p[i] + t * (self.p[i + 1] - self.p[i]), i

    def update(self, pos, vel, psi_deg, sp):
        best = (1e18, 0.0)
        for i in range(max(self.i - 1, 0), min(self.i + 3, len(self.seg_len))):   # progress window
            a, b = self.p[i, :2], self.p[i + 1, :2]
            t = min(max(np.dot(pos[:2] - a, b - a) / self.seg_len[i] ** 2, 0.0), 1.0)
            d = float(np.sum((a + t * (b - a) - pos[:2]) ** 2))
            if d < best[0]:
                best, self.i = (d, self.s[i] + t * self.seg_len[i]), i
        s = best[1]
        carrot, i = self._point(s + self.LOOKAHEAD)
        to_go = self.length - s
        err = carrot[:2] - pos[:2]
        v_ref = self.KP_POS * err
        v_cap = min(self.V_MAX, 0.6 * to_go + 0.3)                     # slow down at the end
        if np.linalg.norm(v_ref) > v_cap:
            v_ref *= v_cap / np.linalg.norm(v_ref)
        a = self.KV * (v_ref - vel[:2])
        if np.linalg.norm(a) > self.A_MAX:
            a *= self.A_MAX / np.linalg.norm(a)
        psi = math.radians(psi_deg)
        fwd, right = np.array([math.sin(psi), math.cos(psi)]), np.array([math.cos(psi), -math.sin(psi)])
        lim = self.TILT_MAX
        sp.pitch = min(max(-math.degrees(math.atan2(np.dot(a, fwd), G_ORIGIN)), -lim), lim)   # nose down = forward
        sp.roll = min(max(math.degrees(math.atan2(np.dot(a, right), G_ORIGIN)), -lim), lim)
        d = self.p[i + 1, :2] - self.p[i, :2]                         # heading of the carrot's segment
        psi_ref = math.degrees(math.atan2(d[0], d[1]))                 # compass: atan2(east, north)
        sp.yawrate = min(max(self.K_PSI * wrap_deg(psi_ref - psi_deg), -60.0), 60.0)
        sp.z_ref = float(carrot[2])
        return to_go


STEPS = [  # (t_start s, roll deg, pitch deg, yawrate deg/s, altitude m above the pad)
    (0.0, 0, 0, 0, 0.0),        # on the pad, motors off
    (1.0, 0, 0, 0, 3.0),        # take off to 3 m
    (8.0, 0, 0, 0, 5.0),        # ALTITUDE STEP 3 -> 5 m
    (14.0, 10, 0, 0, 5.0),      # ROLL DOUBLET: +10 deg for 2 s ...
    (16.0, -10, 0, 0, 5.0),     # ... then -10 deg for 2 s, so the sideways speed cancels
    (18.0, 0, 0, 0, 5.0),
    (21.0, 0, 10, 0, 5.0),      # PITCH DOUBLET: +10 deg (nose up) for 2 s, then -10 deg
    (23.0, 0, -10, 0, 5.0),
    (25.0, 0, 0, 0, 5.0),
    (28.0, 0, 0, 45, 5.0),      # YAW RATE 45 deg/s for 4 s
    (32.0, 0, 0, 0, 5.0),
]
GATE_RUN_START = 34.0           # then: fly through the Module 2 gates and land on the pad
MISSION_TIMEOUT = 150.0
GATE_CLEAR = 0.35               # m: quad half-span (0.177 arm + 0.11 prop) + margin


class Mission:
    """Step tests above the pad, then a gate run through range.json's gates, then landing."""
    def __init__(self, hm, layout, pad_en, z0):
        self.z0, self.pad = z0, np.array(pad_en, float)
        self.gates = []
        for g in layout.get("gates", []):
            psi = math.radians(g["heading_deg"])
            ground = hm.height_at(g["e"], g["n"])
            self.gates.append(dict(name=g["name"], c=np.array([g["e"], g["n"]]), ground=ground,
                                   fwd=np.array([math.sin(psi), math.cos(psi)]),
                                   right=np.array([math.cos(psi), -math.sin(psi)]),
                                   w=g["width_m"], h=g["height_m"], z=ground + g["height_m"] / 2,
                                   side=None, result=None))
        hover = z0 + 5.0
        pts = [(*self.pad, hover)]
        for k, g in enumerate(self.gates):                  # line up 6 m before the first gate
            if k == 0:
                pts.append((*(g["c"] - 6.0 * g["fwd"]), g["z"]))
            pts.append((*g["c"], g["z"]))
        last = self.gates[-1] if self.gates else None
        # Way home: leave straight and climbing, then swing 22 m east and come back at 8 m,
        # well clear of the gate bars. Never fly back through a gate from behind.
        if last:
            exit_pt = last["c"] + 8.0 * last["fwd"]
            pts.append((*exit_pt, last["z"] + 1.5))
            pts.append((*(exit_pt + np.array([22.0, 0.0])), z0 + 8.0))
        pts += [(*(self.pad + np.array([20.0, 20.0])), z0 + 8.0),
                (*self.pad, z0 + 4.0), (*self.pad, z0 + 0.4)]          # descend over the pad
        self.follower = PathFollower(pts)
        self.landed_t = None
        self.done = False

    def setpoint(self, t, s, sp):
        """s: dict with pos (ENU), lin (ENU vel), psi (rad). Fills sp; returns True when done."""
        if t < GATE_RUN_START:
            row = STEPS[0]
            for r in STEPS:
                if t >= r[0]:
                    row = r
            sp.roll, sp.pitch, sp.yawrate, sp.z_ref = row[1], row[2], row[3], self.z0 + row[4]
            sp.armed = row[4] > 0.05 or s["pos"][2] > self.z0 + 0.1
            return False
        to_go = self.follower.update(s["pos"], s["lin"], math.degrees(s["psi"]), sp)
        self._check_gates(s["pos"])
        sp.armed = True
        if to_go < 0.3 and np.hypot(*s["lin"][:2]) < 0.3:            # over the pad: put it down
            sp.roll = sp.pitch = sp.yawrate = 0.0
            sp.z_ref = self.z0 - 0.5
            if s["pos"][2] < self.z0 + 0.05:
                self.landed_t = self.landed_t or t
        if self.landed_t is not None and t - self.landed_t > 1.0:
            sp.armed, self.done = False, True
        return self.done or t > MISSION_TIMEOUT

    def _check_gates(self, pos):
        for g in self.gates:
            d = float(np.dot(pos[:2] - g["c"], g["fwd"]))           # signed distance along the gate axis
            side = d > 0
            if g["side"] is False and side and g["result"] is None:  # crossed from - to +
                lat = float(np.dot(pos[:2] - g["c"], g["right"]))
                up = float(pos[2] - g["ground"])
                ok = abs(lat) <= g["w"] / 2 - GATE_CLEAR and GATE_CLEAR <= up <= g["h"] - GATE_CLEAR
                g["result"] = dict(gate=g["name"], lateral_m=round(lat, 3), height_m=round(up, 3), ok=ok)
            g["side"] = side

    def gate_results(self):
        return [g["result"] or dict(gate=g["name"], ok=False, missed=True) for g in self.gates]


class ManualInput:
    """ATTITUDE (cmd 10) from Godot: roll_deg, pitch_deg, yawrate_dps, throttle 0..1.
    Throttle works like ArduPilot's AltHold: 0.5 = hold altitude, 1 = climb 2 m/s, 0 = sink 2 m/s.
    No ATTITUDE for TIMEOUT_S -> sticks centred (level, hold altitude)."""
    TIMEOUT_S, CLIMB_MAX, DEADBAND = 0.5, 2.0, 0.05

    def __init__(self, hover_alt=2.0):
        self.args = (0.0, 0.0, 0.0, 0.5)
        self.t_last = -1e9
        self.alt = hover_alt                  # m above the pad

    def on_command(self, t, args):
        self.args = tuple(args[:4])
        self.t_last = t

    def setpoint(self, t, dt, z0, sp):
        roll, pitch, yawrate, thr = self.args if t - self.t_last < self.TIMEOUT_S else (0, 0, 0, 0.5)
        lim = 30.0
        sp.roll, sp.pitch = min(max(roll, -lim), lim), min(max(pitch, -lim), lim)
        sp.yawrate = min(max(yawrate, -90.0), 90.0)
        stick = thr - 0.5
        if abs(stick) > self.DEADBAND:
            self.alt = min(max(self.alt + 2 * stick * self.CLIMB_MAX * dt, 0.0), 50.0)
        sp.z_ref, sp.armed = z0 + self.alt, True
        return sp


# ---- motor outputs to the viewer: the TELEMETRY extension (type 100, robosim/telemetry.py)
TELEM_MOTORS = 2                     # code 2: values = 4 normalized motor outputs 0..1, order 1..4


def send_motors(bridge, t_sim, values):
    telemetry.send_telemetry(bridge, t_sim, VEHICLE_ID, TELEM_MOTORS, [float(v) for v in values])


def handle_commands(bridge, t, state):
    """Common command handling. state: dict with 'manual' (ManualInput), 'paused', 'steps', 'reset'."""
    for msg in bridge.poll(t):
        if msg["type"] != P.MSG_COMMAND or msg["vehicle_id"] not in (VEHICLE_ID, 0):
            continue
        c = msg["cmd"]
        if c == P.CMD_ATTITUDE:
            state["manual"].on_command(t, msg["args"])
            state["mode"] = "manual"
        elif c == P.CMD_PAUSE:
            state["paused"] = True
        elif c == P.CMD_RESUME:
            state["paused"], state["steps"] = False, 0
        elif c == P.CMD_STEP:
            state["steps"] += 1
        elif c == P.CMD_RESET:
            state["reset"] = True


def euler_from_R_ned_frd(R):
    """ZYX Euler (phi, theta, psi) from R_ned_frd."""
    return (math.atan2(R[2, 1], R[2, 2]), -math.asin(max(-1.0, min(1.0, R[2, 0]))),
            math.atan2(R[1, 0], R[0, 0]))
