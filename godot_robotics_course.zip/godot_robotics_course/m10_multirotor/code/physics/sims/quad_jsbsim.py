"""
quad_jsbsim.py - Module 10, JSBSim option: the quad_rpy model with its BUILT-IN attitude controller.

    cd robosim/physics
    python sims/quad_jsbsim.py                     # scripted mission, real time, waits for Godot
    python sims/quad_jsbsim.py --mode manual       # hover at 2 m, fly with ATTITUDE (cmd 10)
    python sims/quad_jsbsim.py --fast              # as fast as possible, no viewer needed

Vehicle id 2, same pose format as quad_pybullet.py, so the same Godot scene shows either.
JSBSim 120 Hz (its FCS runs the attitude PD + mixer at that rate). We only set
ap/roll-cmd-deg, ap/pitch-cmd-deg, ap/yawrate-cmd-dps and ap/throttle-cmd at 60 Hz.
Terrain: each step we write the shared heightmap's height under the quad into
position/terrain-elevation-asl-ft, so the legs touch the same ground Godot draws.
"""
import argparse, json, math, os, sys, time
import numpy as np
import jsbsim

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
from robosim import protocol as P
from robosim.bridge import PhysicsBridge
from robosim.frames import GeoOrigin, jsbsim_state_to_godot, enu_to_godot_pos, FT, EARTH_R
from robosim.logger import RunLogger
from robosim.terrain import Heightmap
from robosim import pybullet_world as W            # only for load_range(); no PyBullet here
import quad_common as Q

ROOT = os.path.join(HERE, "..", "..")


class QuadJSBSim:
    def __init__(self, a):
        self.a = a
        self.hm = Heightmap.load(os.path.join(ROOT, "data", "terrain", "heightmap.png"))
        self.layout = W.load_range(os.path.join(ROOT, "data", "terrain", "range.json"))
        self.br = PhysicsBridge(viewer_port=a.viewer_port, listen_port=a.listen_port)
        self.reset()
        self.log = RunLogger(os.path.join(ROOT, "logs"), run_name=a.run_name, seed=0, meta={
            "physics": "jsbsim", "physics_hz": a.physics_hz, "attitude_hz": a.physics_hz,
            "outer_hz": a.physics_hz / a.decim, "pose_hz": a.physics_hz / a.decim,
            "vehicle_id": Q.VEHICLE_ID, "mode": a.mode, "model": "quad_rpy",
            "origin_lat_deg": math.degrees(self.origin.lat0), "origin_lon_deg": math.degrees(self.origin.lon0),
            "g_gravitation": round(self.fdm["accelerations/gravity-ft_sec2"] * FT, 4),
            "g_accel_at_rest": round(-self.fdm["accelerations/a-pilot-z-ft_sec2"] * FT, 4)})

    def reset(self):
        fdm = jsbsim.FGFDMExec(os.path.join(HERE, ".."))       # finds aircraft/quad_rpy/quad_rpy.xml
        fdm.set_debug_level(0)
        fdm.load_model("quad_rpy")
        fdm.set_dt(1.0 / self.a.physics_hz)
        # terrain under the start point BEFORE run_ic, so altitudeAGL in ground.xml means our ground
        e, n = (float(v) for v in self.a.pad.split(","))
        fdm["position/terrain-elevation-asl-ft"] = self.hm.height_at(e, n) / FT
        fdm.load_ic("ground", True)
        # ENU origin = ground.xml's lat/lon = the heightmap center, at sea level (heights are ASL)
        self.origin = GeoOrigin(fdm["ic/lat-geod-rad"], fdm["ic/long-gc-rad"], 0.0)
        fdm["ic/lat-geod-rad"] = self.origin.lat0 + n / EARTH_R               # move to the pad
        fdm["ic/long-gc-rad"] = self.origin.lon0 + e / (EARTH_R * math.cos(self.origin.lat0))
        fdm.run_ic()
        self.arm(fdm, False)
        for _ in range(int(self.a.physics_hz)):                # settle on the legs for 1 s
            fdm.run()
        self.fdm = fdm
        self.t0_fdm = fdm.get_sim_time()
        self.t = 0.0
        self.z0 = fdm["position/h-sl-ft"] * FT
        self.sp = Q.Setpoint()
        self.mission = Q.Mission(self.hm, self.layout, (e, n), self.z0)
        self.alt_ctl = Q.AltitudeController()
        self.throttle, self.thrust_int = 0.0, 0.0
        self.state = {"mode": self.a.mode, "manual": Q.ManualInput(), "paused": False, "steps": 0,
                      "reset": False}
        self.prev_mode = self.a.mode
        self.vz_prev = 0.0
        self.wall0 = time.monotonic()
        self.g_rest = -fdm["accelerations/a-pilot-z-ft_sec2"] * FT

    @staticmethod
    def arm(fdm, on):
        """Disarmed = gains to zero, so the built-in mixer cannot spin motors on the ground."""
        fdm["ap/kp-att"] = Q.KP_ATT if on else 0.0
        fdm["ap/kd-att"] = Q.KD_ATT if on else 0.0
        fdm["ap/kp-yawrate"] = Q.KP_YAWRATE if on else 0.0

    def read(self):
        f = self.fdm
        e, n, u = self.origin.to_enu(f["position/lat-geod-rad"], f["position/long-gc-rad"],
                                     f["position/h-sl-ft"] * FT)
        v_enu = np.array([f["velocities/v-east-fps"], f["velocities/v-north-fps"],
                          -f["velocities/v-down-fps"]]) * FT
        return dict(pos=np.array([e, n, u]), lin=v_enu,
                    phi=f["attitude/phi-rad"], theta=f["attitude/theta-rad"], psi=f["attitude/psi-rad"],
                    p=f["velocities/p-rad_sec"], q_rate=f["velocities/q-rad_sec"], r=f["velocities/r-rad_sec"])

    def motors(self):
        return [self.fdm[f"fcs/motor{i}-lag"] for i in (1, 2, 3, 4)]

    def step_physics(self):
        e, n = self.read()["pos"][:2]
        self.fdm["position/terrain-elevation-asl-ft"] = self.hm.height_at(e, n) / FT
        self.fdm.run()
        self.t = self.fdm.get_sim_time() - self.t0_fdm

    def outer_tick(self):
        Q.handle_commands(self.br, self.t, self.state)
        if self.state["reset"]:
            self.reset()
            self.br.mark_reset()
            return False
        s = self.read()
        dt_o = self.a.decim / self.a.physics_hz
        if self.state["mode"] == "manual":
            if self.prev_mode != "manual":
                self.state["manual"].alt = max(s["pos"][2] - self.z0, 1.0)
            self.state["manual"].setpoint(self.t, dt_o, self.z0, self.sp)
            done = False
        else:
            done = self.mission.setpoint(self.t, s, self.sp)
        self.prev_mode = self.state["mode"]
        armed = self.sp.armed
        self.throttle, self.thrust_int = self.alt_ctl.update(
            self.sp.z_ref, s["pos"][2], s["lin"][2], s["phi"], s["theta"], dt_o, armed)
        f = self.fdm                                   # JSBSim's own controller does the rest
        self.arm(f, armed)
        f["ap/roll-cmd-deg"] = self.sp.roll
        f["ap/pitch-cmd-deg"] = self.sp.pitch
        f["ap/yawrate-cmd-dps"] = self.sp.yawrate
        f["ap/throttle-cmd"] = self.throttle
        self.send_and_log(s)
        return self.state["mode"] == "mission" and done

    def send_and_log(self, s):
        pos_g, q_g = jsbsim_state_to_godot(self.fdm, self.origin)       # the tested adapter
        self.br.send_pose(self.t, Q.VEHICLE_ID, pos_g, q_g, enu_to_godot_pos(s["lin"]),
                          paused=self.state["paused"])
        m = self.motors()
        Q.send_motors(self.br, self.t, m)
        dt_o = self.a.decim / self.a.physics_hz
        az = (s["lin"][2] - self.vz_prev) / dt_o
        self.vz_prev = s["lin"][2]
        self.log.write("state", t_sim=self.t, x=s["pos"][0], y=s["pos"][1], z=s["pos"][2],
                       alt=s["pos"][2] - self.z0, vx=s["lin"][0], vy=s["lin"][1], vz=s["lin"][2],
                       az_meas=az, roll_deg=math.degrees(s["phi"]), pitch_deg=math.degrees(s["theta"]),
                       yaw_deg=(math.degrees(s["psi"]) + 180.0) % 360.0 - 180.0, p_dps=math.degrees(s["p"]),
                       q_dps=math.degrees(s["q_rate"]), r_dps=math.degrees(s["r"]))
        self.log.write("control", t_sim=self.t, mode=self.state["mode"], roll_cmd_deg=self.sp.roll,
                       pitch_cmd_deg=self.sp.pitch, yawrate_cmd_dps=self.sp.yawrate,
                       alt_cmd=self.sp.z_ref - self.z0, throttle=self.throttle, thrust_intended_n=self.thrust_int,
                       thrust_actual_n=Q.T_MAX * sum(m), m1=m[0], m2=m[1], m3=m[2], m4=m[3])

    def run(self):
        a = self.a
        print(f"quad_jsbsim: vehicle {Q.VEHICLE_ID}, mode {a.mode}, accel at rest {self.g_rest:.4f} m/s^2, "
              f"log {self.log.dir}")
        if not (a.fast or a.no_wait):
            print("waiting for the Godot viewer (HELLO)... use --no-wait to start anyway")
            self.br.wait_for_viewer()      # HELLO (or any packet) from the viewer; works in either start order
            self.wall0 = time.monotonic()
        end = "duration"
        t_start = time.monotonic()
        try:
            while a.duration <= 0 or self.t < a.duration:
                if self.state["paused"] and self.state["steps"] == 0:
                    w0 = time.monotonic()
                    Q.handle_commands(self.br, self.t, self.state)
                    pos_g, q_g = jsbsim_state_to_godot(self.fdm, self.origin)
                    self.br.send_pose(self.t, Q.VEHICLE_ID, pos_g, q_g, (0, 0, 0), paused=True)
                    time.sleep(1 / 60)
                    self.wall0 += time.monotonic() - w0
                    continue
                for _ in range(a.decim):
                    self.step_physics()
                if self.state["paused"]:
                    self.state["steps"] -= 1
                if self.outer_tick():
                    end = "mission end"
                    break
                if not a.fast:
                    lag = self.t - (time.monotonic() - self.wall0)
                    if lag > 0:
                        time.sleep(lag)
        except KeyboardInterrupt:
            end = "ctrl-c"
        s = self.read()
        summary = {"end": end, "t_sim": round(self.t, 3), "wall_s": round(time.monotonic() - t_start, 2),
                   "final_enu": [round(float(v), 2) for v in s["pos"]],
                   "final_rpy_deg": [round(math.degrees(v), 1) for v in (s["phi"], s["theta"], s["psi"])]}
        if a.mode == "mission":
            summary["gates"] = self.mission.gate_results()
        json.dump(summary, open(os.path.join(self.log.dir, "summary.json"), "w"), indent=2)
        print("quad_jsbsim summary:", summary)
        self.log.close()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--mode", choices=["mission", "manual"], default="mission")
    ap.add_argument("--physics-hz", type=float, default=120.0)
    ap.add_argument("--decim", type=int, default=2, help="JSBSim steps per outer/pose tick (120/2 = 60 Hz)")
    ap.add_argument("--duration", type=float, default=0.0)
    ap.add_argument("--pad", default="0,0", help="start point 'east,north' in ENU m (range.json pad)")
    ap.add_argument("--fast", action="store_true")
    ap.add_argument("--no-wait", action="store_true")
    ap.add_argument("--run-name", default="quad_jsbsim")
    ap.add_argument("--viewer-port", type=int, default=P.PORT_TO_VIEWER)
    ap.add_argument("--listen-port", type=int, default=P.PORT_TO_PHYSICS)
    QuadJSBSim(ap.parse_args()).run()


if __name__ == "__main__":
    main()
