"""
quad_pybullet.py - Module 10: Quad-X multirotor in PyBullet, four motor forces + reaction torque.

    cd robosim/physics
    python sims/quad_pybullet.py                    # scripted mission, real time, waits for Godot
    python sims/quad_pybullet.py --mode manual      # hover at 2 m, fly with ATTITUDE (cmd 10)
    python sims/quad_pybullet.py --fast             # mission as fast as possible, no viewer needed
    python sims/quad_pybullet.py --fast --open-loop-demo   # one motor 2 % high, no controller

Vehicle id 2. World ENU, body FLU. Physics 240 Hz; attitude PD + mixer at 240 Hz;
altitude loop, pose, MOTORS and logs at 60 Hz. Same pose format as quad_jsbsim.py.
"""
import argparse, json, math, os, sys, time
import numpy as np
import pybullet as p

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
from robosim import protocol as P
from robosim.bridge import PhysicsBridge
from robosim.frames import (enu_flu_to_godot, enu_to_godot_pos, quat_to_matrix, T_ENU_NED, D_FRD_FLU)
from robosim.logger import RunLogger
from robosim.terrain import Heightmap
from robosim import pybullet_world as W
import quad_common as Q

ROOT = os.path.join(HERE, "..", "..")
LEG_Z = 0.08                     # landing legs reach 8 cm below the CG (as in quad_rpy.xml)


class QuadPyBullet:
    def __init__(self, a):
        self.a = a
        self.dt = 1.0 / a.physics_hz
        self.hm = Heightmap.load(os.path.join(ROOT, "data", "terrain", "heightmap.png"))
        self.layout = W.load_range(os.path.join(ROOT, "data", "terrain", "range.json"))
        p.connect(p.DIRECT)
        p.setGravity(0, 0, -Q.G_ORIGIN)                 # match JSBSim's effective g at the origin
        p.setTimeStep(self.dt)
        self.terrain = W.add_heightfield(p, self.hm)                # Module 9: same ground as Godot
        self.objects = W.add_range_objects(p, self.hm, self.layout, gates=True)   # obstacles + gates

        # body: one box whose bottom is LEG_Z below the CG; CG = link origin
        col = p.createCollisionShape(p.GEOM_BOX, halfExtents=[0.15, 0.15, LEG_Z / 2],
                                     collisionFramePosition=[0, 0, -LEG_Z / 2])
        self.quad = p.createMultiBody(Q.MASS, col)
        # Use OUR inertia (PyBullet would compute one from the box), and switch off PyBullet's
        # default damping (0.04): drag and rotational damping are modelled explicitly below.
        p.changeDynamics(self.quad, -1, localInertiaDiagonal=list(Q.INERTIA),
                         linearDamping=0.0, angularDamping=0.0, lateralFriction=0.8)
        self.reset()

        self.br = PhysicsBridge(viewer_port=a.viewer_port, listen_port=a.listen_port)
        self.log = RunLogger(os.path.join(ROOT, "logs"), run_name=a.run_name, seed=0, meta={
            "physics": "pybullet", "physics_hz": a.physics_hz, "attitude_hz": a.physics_hz,
            "outer_hz": a.physics_hz / a.decim, "pose_hz": a.physics_hz / a.decim,
            "vehicle_id": Q.VEHICLE_ID, "mode": a.mode, "g": Q.G_ORIGIN, "mass_kg": Q.MASS,
            "t_max_n": Q.T_MAX, "tau_motor_s": Q.TAU_MOTOR, "open_loop_demo": a.open_loop_demo})

    def reset(self):
        e, n = (float(v) for v in self.a.pad.split(","))
        self.z0 = self.hm.height_at(e, n) + LEG_Z + 0.005            # CG height when sitting
        # nose NORTH, like JSBSim's psi = 0: ENU yaw +90 deg turns body x from east to north
        p.resetBasePositionAndOrientation(self.quad, [e, n, self.z0],
                                          p.getQuaternionFromEuler([0, 0, math.pi / 2]))
        p.resetBaseVelocity(self.quad, [0, 0, 0], [0, 0, 0])
        self.t, self.k = 0.0, 0
        self.motor = np.zeros(4)                                     # lagged outputs 0..1
        self.cmd = np.zeros(4)
        self.sp = Q.Setpoint()
        self.mission = Q.Mission(self.hm, self.layout, (e, n), self.z0)
        self.alt_ctl = Q.AltitudeController()
        self.throttle, self.thrust_int = 0.0, 0.0
        self.armed = False
        self.state = {"mode": self.a.mode, "manual": Q.ManualInput(), "paused": False, "steps": 0,
                      "reset": False}
        self.wall0 = time.monotonic()
        self.vz_prev = 0.0
        self.prev_mode = self.a.mode
        self.hits = set()
        if self.a.open_loop_demo:                                    # start in the air, already hovering
            p.resetBasePositionAndOrientation(self.quad, [e, n, self.z0 + 10.0],
                                              p.getQuaternionFromEuler([0, 0, math.pi / 2]))
            self.motor[:] = Q.HOVER_CMD

    # ---- sensors (truth): attitude in aerospace convention, body rates FRD
    def read(self):
        pos, q = p.getBasePositionAndOrientation(self.quad)
        lin, ang = p.getBaseVelocity(self.quad)
        R = quat_to_matrix(q)                                        # R_enu_flu
        R_ned_frd = T_ENU_NED @ R @ D_FRD_FLU                        # T and D are their own inverses
        phi, theta, psi = Q.euler_from_R_ned_frd(R_ned_frd)
        w_flu = R.T @ np.array(ang)
        return dict(pos=np.array(pos), q=q, R=R, lin=np.array(lin), ang=np.array(ang),
                    phi=phi, theta=theta, psi=psi,
                    p=w_flu[0], q_rate=-w_flu[1], r=-w_flu[2], w_flu=w_flu)

    def step_physics(self, s):
        if not self.a.open_loop_demo and not self.armed:
            self.cmd = np.zeros(4)                                   # disarmed: motors off
        elif not self.a.open_loop_demo:
            self.cmd = np.array(Q.attitude_mixer(
                self.throttle, math.radians(self.sp.roll), math.radians(self.sp.pitch),
                math.radians(self.sp.yawrate), s["phi"], s["theta"], s["p"], s["q_rate"], s["r"]))
        else:
            self.cmd = np.full(4, Q.HOVER_CMD)
            self.cmd[0] *= 1.02                                      # motor 1 just 2 % high
        self.motor += (self.cmd - self.motor) * (1 - math.exp(-self.dt / Q.TAU_MOTOR))
        thrusts = Q.T_MAX * self.motor
        # forces are cleared after every stepSimulation(): apply them every step
        for (_, x, y, spin), t in zip(Q.MOTORS, thrusts):
            p.applyExternalForce(self.quad, -1, [0, 0, t], [x, y, 0], p.LINK_FRAME)   # pos in BODY frame
        tau_z = sum(-spin * Q.K_TORQUE * t for (_, _, _, spin), t in zip(Q.MOTORS, thrusts))
        tau = np.array([0.0, 0.0, tau_z]) - Q.ROT_DAMP * s["w_flu"]
        p.applyExternalTorque(self.quad, -1, tau.tolist(), p.LINK_FRAME)
        v = s["lin"]
        drag = -0.5 * Q.RHO * Q.CD_S * np.linalg.norm(v) * v
        p.applyExternalForce(self.quad, -1, drag.tolist(), s["pos"].tolist(), p.WORLD_FRAME)  # pos in WORLD
        p.stepSimulation()
        self.t += self.dt
        self.k += 1
        return thrusts

    def outer_tick(self, s, thrusts):
        Q.handle_commands(self.br, self.t, self.state)
        if self.state["reset"]:
            self.reset()
            self.br.mark_reset()
            return False
        dt_o = self.dt * self.a.decim
        if self.state["mode"] == "manual":
            if self.prev_mode != "manual":                           # take over at the current altitude
                self.state["manual"].alt = max(s["pos"][2] - self.z0, 1.0)
            self.state["manual"].setpoint(self.t, dt_o, self.z0, self.sp)
            done = False
        else:
            done = self.mission.setpoint(self.t, s, self.sp)
        self.armed = self.sp.armed
        self.throttle, self.thrust_int = self.alt_ctl.update(
            self.sp.z_ref, s["pos"][2], s["lin"][2], s["phi"], s["theta"], dt_o, self.armed)
        self.prev_mode = self.state["mode"]
        for c in p.getContactPoints(bodyA=self.quad):              # anything but the terrain?
            if c[2] in self.objects and c[9] > 0:
                self.hits.add(self.objects[c[2]])
                self.log.write("contact", t_sim=self.t, other=self.objects[c[2]], normal_force_n=c[9])
        self.send_and_log(s, thrusts)
        return self.state["mode"] == "mission" and done

    def send_and_log(self, s, thrusts):
        pos_g, q_g = enu_flu_to_godot(s["pos"], s["q"])
        self.br.send_pose(self.t, Q.VEHICLE_ID, pos_g, q_g, enu_to_godot_pos(s["lin"]),
                          paused=self.state["paused"])
        Q.send_motors(self.br, self.t, [float(m) for m in self.motor])
        dt_o = self.dt * self.a.decim
        az = (s["lin"][2] - self.vz_prev) / dt_o
        self.vz_prev = s["lin"][2]
        self.log.write("state", t_sim=self.t, x=s["pos"][0], y=s["pos"][1], z=s["pos"][2],
                       alt=s["pos"][2] - self.z0, vx=s["lin"][0], vy=s["lin"][1], vz=s["lin"][2],
                       az_meas=az, roll_deg=math.degrees(s["phi"]), pitch_deg=math.degrees(s["theta"]),
                       yaw_deg=(math.degrees(s["psi"]) + 180.0) % 360.0 - 180.0, p_dps=math.degrees(s["p"]),
                       q_dps=math.degrees(s["q_rate"]), r_dps=math.degrees(s["r"]))
        self.log.write("control", t_sim=self.t, mode=self.state["mode"], roll_cmd_deg=self.sp.roll,
                       pitch_cmd_deg=self.sp.pitch, yawrate_cmd_dps=self.sp.yawrate,
                       alt_cmd=self.sp.z_ref - self.z0, throttle=self.throttle, thrust_intended_n=self.thrust_int,
                       thrust_actual_n=float(sum(thrusts)), m1=self.motor[0], m2=self.motor[1],
                       m3=self.motor[2], m4=self.motor[3])

    def run(self):
        a = self.a
        print(f"quad_pybullet: vehicle {Q.VEHICLE_ID}, mode {a.mode}, log {self.log.dir}")
        if not (a.fast or a.no_wait):
            print("waiting for the Godot viewer (HELLO)... use --no-wait to start anyway")
            self.br.wait_for_viewer()      # HELLO (or any packet) from the viewer; works in either start order
            self.reset()
        thrusts = np.zeros(4)
        end = "duration"
        t_start = time.monotonic()
        try:
            while a.duration <= 0 or self.t < a.duration:
                if self.state["paused"] and self.state["steps"] == 0:
                    w0 = time.monotonic()
                    Q.handle_commands(self.br, self.t, self.state)
                    s = self.read()
                    pos_g, q_g = enu_flu_to_godot(s["pos"], s["q"])
                    self.br.send_pose(self.t, Q.VEHICLE_ID, pos_g, q_g, (0, 0, 0), paused=True)
                    time.sleep(1 / 60)
                    self.wall0 += time.monotonic() - w0
                    continue
                for _ in range(a.decim):
                    thrusts = self.step_physics(self.read())
                if self.state["paused"]:
                    self.state["steps"] -= 1
                if self.outer_tick(self.read(), thrusts):
                    end = "mission end"
                    break
                if a.open_loop_demo and abs(self.read()["phi"]) > math.radians(90):
                    end = f"flipped (|roll| > 90 deg) at t = {self.t:.2f} s"
                    break
                if not a.fast:
                    lag = self.t - (time.monotonic() - self.wall0)
                    if lag > 0:
                        time.sleep(lag)
        except KeyboardInterrupt:
            end = "ctrl-c"
        s = self.read()
        summary = {"end": end, "t_sim": round(self.t, 3), "wall_s": round(time.monotonic() - t_start, 2),
                   "final_enu": [round(float(v), 2) for v in s["pos"]],
                   "final_rpy_deg": [round(math.degrees(v), 1) for v in (s["phi"], s["theta"], s["psi"])]}
        if self.a.mode == "mission" and not self.a.open_loop_demo:
            summary["gates"] = self.mission.gate_results()
            summary["hits"] = sorted(self.hits)
        json.dump(summary, open(os.path.join(self.log.dir, "summary.json"), "w"), indent=2)
        print("quad_pybullet summary:", summary)
        self.log.close()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--mode", choices=["mission", "manual"], default="mission")
    ap.add_argument("--physics-hz", type=float, default=240.0)
    ap.add_argument("--decim", type=int, default=4, help="physics steps per outer/pose tick (240/4 = 60 Hz)")
    ap.add_argument("--duration", type=float, default=0.0, help="sim seconds, 0 = until the mission ends")
    ap.add_argument("--pad", default="0,0", help="start point 'east,north' in ENU m (range.json pad)")
    ap.add_argument("--open-loop-demo", action="store_true", help="no controller, motor 1 at +2 %%")
    ap.add_argument("--fast", action="store_true", help="do not pace to the wall clock, do not wait for Godot")
    ap.add_argument("--no-wait", action="store_true")
    ap.add_argument("--run-name", default="quad_pybullet")
    ap.add_argument("--viewer-port", type=int, default=P.PORT_TO_VIEWER)
    ap.add_argument("--listen-port", type=int, default=P.PORT_TO_PHYSICS)
    QuadPyBullet(ap.parse_args()).run()


if __name__ == "__main__":
    main()
