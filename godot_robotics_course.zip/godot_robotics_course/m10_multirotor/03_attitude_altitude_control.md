# 03 Attitude PD + mixer, altitude PI, and loop rates

Page 02 showed that a quad cannot fly without feedback. This page builds the smallest controller that flies well. It has two layers: a fast **attitude** loop that holds the commanded roll, pitch and yaw rate, and a slower **altitude** loop that sets the collective throttle. Both engines use the *same* controller. JSBSim runs the attitude part inside the XML model, and PyBullet runs a Python copy of it. That is what makes the two step responses comparable.

```
 pilot / mission                  outer loop, 60 Hz                    inner loop, physics rate
 ───────────────                  ─────────────────                    ────────────────────────
 roll_cmd, pitch_cmd,  ────────────────────────────────────▶  attitude PD  ─▶ mixer ─▶ 4 motors
 yawrate_cmd                                                        ▲         (page 01)   (lag)
 altitude_cmd          ─▶ altitude PI + damping + tilt comp ─▶ throttle        │
                                     ▲                              │          ▼
                              z, vz, φ, θ (truth)            φ θ p q r   rigid body
```

## The attitude loop (identical in both engines)

```
roll_out  = Kp (φ_cmd − φ) − Kd p          Kp = 0.25 per rad,  Kd = 0.05 per rad/s
pitch_out = Kp (θ_cmd − θ) − Kd q
yaw_out   = clip( Kr (r_cmd − r), ±0.15 )  Kr = 0.10 per rad/s
```

The outputs are fractions of full motor command and go straight into the mixer (page 01). Aerospace conventions apply throughout: φ roll right +, θ nose up +, and p, q, r are body rates in FRD. JSBSim gives them directly (`attitude/phi-rad`, `velocities/p-rad_sec`...). In PyBullet we compute them once from the quaternion:

```python
R = quat_to_matrix(q)                         # R_enu_flu from PyBullet
R_ned_frd = T_ENU_NED @ R @ D_FRD_FLU         # both constant matrices are their own inverse
phi, theta, psi = euler_from_R_ned_frd(R_ned_frd)
w_flu = R.T @ np.array(ang_world)             # PyBullet gives angular velocity in WORLD frame
p, q, r = w_flu[0], -w_flu[1], -w_flu[2]      # FLU -> FRD
```

**Why PD and no I term?** The quad has no aerodynamic restoring moment. So the proportional term acts like a spring and the derivative term like a damper, which is all a hover needs. Linearize the roll axis. One unit of `roll_out` changes four motors by 8 N each, at an arm of 0.177 m, so it gives 4 · 0.177 · 8 = 5.66 N·m:

```
I φ'' = 5.66 (Kp e − Kd p) − c_ω p      →    φ'' = 94.4 e − 19.8 p
natural frequency ω_n = √94.4 = 9.7 rad/s,   damping ζ = 19.8 / (2 · 9.7) = 1.02
```

That is a critically damped attitude loop. Predicted 63 % time: about 0.2 s. Measured: t63 = 0.23 s in both engines, with no overshoot.

**Yaw has only a P term**, so it settles below the command. At steady state, the yaw torque from `yaw_out` (0.512 N·m per unit) balances the rotational damping:

```
0.512 · 0.10 · (r_cmd − r) = 0.0136 r   →   r = 0.79 r_cmd      (45 °/s commanded → 35.6 °/s)
```

Measured in both engines: **35.58 °/s**. Any "my yaw rate is 20 % low" bug report should be checked against this number first. It is the controller, not the physics.

## The altitude loop

The throttle that holds a hover is m·g / (4 · T_max) = 0.459. An altitude controller computes the vertical acceleration it wants, adds gravity, and converts that to thrust:

```python
e = z_ref - z
if abs(e) < I_ZONE:                                    # 0.3 m: integrate only near the setpoint
    i = clamp(i + KI * e * dt, -I_LIMIT, I_LIMIT)
a_cmd  = KP * e + i - KD * vz                          # KP 4, KI 1, KD 3.2
tilt   = max(cos(phi) * cos(theta), 0.5)               # tilt compensation (never divide by ~0)
thrust = MASS * (G_ORIGIN + a_cmd) / tilt              # intended total thrust, N
throttle = clamp(thrust / (4 * T_MAX), 0, 0.9)         # keep 10 % for attitude control
```

| Term | Role |
|---|---|
| feed-forward `G_ORIGIN` | hover needs no error at all; the integrator only mops up small mismatches |
| P on altitude, D on **measured** vz | a damped spring: ω_n = 2 rad/s, ζ = 0.8. D on the measurement (not on the error) avoids a kick when the setpoint steps. |
| I with a zone | removes steady-state error (mass, gravity, drag) without winding up during big steps |
| tilt compensation | thrust tilts with the body; dividing by cos φ cos θ keeps the vertical part constant |
| throttle cap 0.9 | the mixer needs headroom, or a climb would starve the attitude loop |

### Two measured design decisions

**Anti-windup.** Without the 0.3 m integration zone, the integrator charged up during the 2 m climb and the 3 → 5 m step overshot by **21.3 %** (5.43 m). With the zone, the overshoot was **1.8 %**, with t63 = 0.93 s and t90 = 1.47 s.

**Tilt compensation.** In the lab mission's ±10° roll doublet, the altitude stayed within 5.000–5.006 m with compensation, and 4.97–5.02 m without it. At 10° the loss of lift is only 1.5 % (1 − cos 10°), and the integrator catches it. At the 30° manual limit the loss would be 13 % (1 − cos 30°), and the quad would sink noticeably during every hard turn.

## A position loop on top: the gate run

Attitude and altitude control hold a hover. To *go* somewhere, a third loop turns position errors into tilt commands. A tilted quad accelerates sideways at about g·tan(tilt), so tilt is the quad's "steering".

```
carrot point on the path (3 m ahead) ─▶ v_ref = 0.8 · (carrot − p), |v_ref| ≤ 2.5 m/s
                                     ─▶ a_ref = 1.5 · (v_ref − v),   |a_ref| ≤ 3 m/s²
a_ref in the heading frame:  a_fwd = a·(sin ψ, cos ψ),  a_right = a·(cos ψ, −sin ψ)
pitch_cmd = −atan(a_fwd / g)     (nose DOWN to accelerate forward)      both ≤ 20°
roll_cmd  =  atan(a_right / g)   (roll right to accelerate right)
yawrate_cmd = 1.5 · wrap(ψ_path − ψ),  ≤ 60 °/s      z_ref = the carrot's altitude
```

`quad_common.PathFollower` implements this for a 3D polyline. `Mission` builds the path from `range.json`: from the hover point above the pad to a point 6 m before gate 1, through the centers of gates 1, 2 and 3 at half the gate height above the ground, straight out of gate 3 while climbing, a wide swing east at 8 m (never back through a gate), and down onto the pad. It is the same carrot idea as the rover's pure pursuit in Module 9, with an acceleration stage in between, because a quad cannot turn its velocity instantly.

A gate counts as passed when the quad crosses the gate's plane in the flight direction with its center at least 0.35 m (half-span: 0.177 m arm + 0.11 m prop, plus margin) inside the posts and the bar. Reference results, in the same order for both engines:

| Gate | PyBullet lateral / height | JSBSim lateral / height |
|---|---|---|
| gate_1 | +0.26 m / 1.50 m | +0.26 m / 1.51 m |
| gate_2 | −0.51 m / 1.62 m | −0.50 m / 1.62 m |
| gate_3 | +0.08 m / 1.82 m | +0.09 m / 1.82 m |

Gate 2 is the hardest: the path turns by about 60° there (its bearing goes from +30° to −30°), and the carrot cuts the corner by half a meter. The gates are 4 m wide, so that is still well inside.

## Command and sensor rates

| Signal | Rate | Path | Why this rate |
|---|---|---|---|
| physics step | 240 Hz (PyBullet), 120 Hz (JSBSim) | inside the sim | per-vehicle parameter ([README](../README.md) conventions) |
| attitude PD + mixer | same as physics | PyBullet: Python every step; JSBSim: FCS every step | the attitude loop needs ω_n ≈ 10 rad/s, so ≥ 100 Hz keeps the delay small |
| motor lag | same as physics | | τ = 50 ms ≫ step |
| altitude loop, path follower, mission script | 60 Hz | Python, both sims | ω_n = 2 rad/s; 60 Hz is plenty |
| POSE and motor TELEMETRY to Godot | 60 Hz | unreliable UDP | course pose rate |
| ATTITUDE from Godot | 50 Hz | unreliable UDP, latest wins | stick input; old values are worthless |
| ATTITUDE timeout | 0.5 s | physics side | lost link → sticks centered → level hover (a failsafe) |
| logs | 60 Hz | `state.csv`, `control.csv` | one row per outer tick |

Sensors here are **truth**. The controller reads the exact attitude and altitude. Module 8's IMU and baro, with noise and bias, are the natural next step (stretch goal). Then you will see why real autopilots filter the D term.

## What the ATTITUDE throttle means

The protocol defines ATTITUDE as `roll_deg, pitch_deg, yawrate_dps, throttle 0–1`. It does not say what "throttle" does, so both sims use **altitude-hold** semantics, like ArduPilot's AltHold mode:

| Throttle | Effect |
|---|---|
| 0.5 ± 0.05 | hold the current altitude setpoint |
| 1.0 | climb at 2 m/s (the setpoint moves up) |
| 0.0 | descend at 2 m/s |

Keyboard pilots cannot hold an exact hover throttle, but they can leave a key alone. A raw-throttle mode would be another command (ids 100–199 are free for experiments).

## Try it

- Double `KP_ATT` to 0.5 in **both** `quad_common.py` and the XML (`ap/kp-att`). Predict ω_n and ζ, then measure t63 and the overshoot with `plot_quad_response.py`.
- Set `I_ZONE = 100` (no anti-windup) and reproduce the 21 % overshoot.
- Add an integrator to the yaw-rate loop in `quad_common.py` only. Show the PyBullet yaw rate reaching 45 °/s while JSBSim's stays at 35.6 °/s. This is a deliberate way to make the engines disagree, so you can practice reading the comparison plot.
- Command a 30° roll for 2 s in manual mode and log the altitude dip with and without tilt compensation.
- Raise `PathFollower.V_MAX` to 4 m/s and rerun the mission in both engines. Which gate fails first, and do both engines agree on it?

## References

- R. Mahony, V. Kumar, P. Corke, "Multirotor Aerial Vehicles: Modeling, Estimation, and Control of Quadrotor", IEEE RAM 19(3), 2012
- ArduPilot, *AltHold mode*: <https://ardupilot.org/copter/docs/altholdmode.html>
- K. J. Åström, R. M. Murray, *Feedback Systems*, ch. 10 (PID, anti-windup): <https://fbswiki.org/>
