# 01 Quad frame, motor layout, thrust and torque

A quadcopter has no control surfaces. Four fixed-pitch propellers produce everything: lift, roll, pitch and yaw. Before any controller or engine code, you must know where each motor is, which way it spins, and what force and torque it puts on the body. Every sign error later in this module traces back to this page.

## Quad-X, ArduPilot/PX4 numbering

```
                 FRONT (body +x)
          3 (CW)            1 (CCW)
              ╲   ▲ +x     ╱
               ╲  │       ╱          seen from ABOVE
                ╲ │      ╱
   +y (left) ◀───[ CG ]               arm: 0.177 m along x and y from the CG
                ╱        ╲            (0.25 m diagonal, a "450-class" frame)
               ╱          ╲
          2 (CCW)           4 (CW)
                 BACK
```

| Motor | Position | FLU (x, y) m | JSBSim structural (x aft, y right) m | Spin (from above) |
|---:|---|---|---|---|
| 1 | front-right | (+0.177, −0.177) | (−0.177, +0.177) | CCW |
| 2 | back-left | (−0.177, +0.177) | (+0.177, −0.177) | CCW |
| 3 | front-left | (+0.177, +0.177) | (−0.177, −0.177) | CW |
| 4 | back-right | (−0.177, −0.177) | (+0.177, +0.177) | CW |

The numbering is not around the frame. It pairs the motors diagonally: 1–2 spin CCW, 3–4 spin CW. Diagonal pairs that spin the same way cancel each other's yaw torque in hover. This is the ArduPilot and PX4 convention, so a real flight controller and this simulator agree.

Module 2's `quad.tscn` draws the same frame. Its rotor nodes are named by position, and the front pair is red: `Rotor_FR` is motor 1, `Rotor_BL` is 2, `Rotor_FL` is 3 and `Rotor_BR` is 4. In the Godot model frame (x right, z back), motor 1 sits at (+0.177, −0.177).

JSBSim's `<location>` uses the **structural** frame (x aft, y right, z up). That is why motor 1 sits at x = −0.177 in `quad_rpy.xml`. Its `<direction>` uses the **body** frame FRD, so "up" is z = −1. The table converts all of it to FLU, the body frame we use in PyBullet.

## What one motor does to the body

A propeller pushes air down, so it gets a thrust **T** along body +z (FLU up). Turning the propeller takes torque. The motor pushes the propeller one way, and the propeller pushes the motor, and so the body, the **other** way. This is the reaction torque, roughly proportional to thrust:

```
thrust     F_i  = (0, 0, T_i)                      FLU, at r_i = (x_i, y_i, 0)
moment     M_i  = r_i × F_i = (y_i T_i, −x_i T_i, 0)
reaction   Q_i  = −spin_i · k_Q · T_i  about +z    spin = +1 for CCW, −1 for CW;  k_Q = 0.016 m
```

Check the reaction sign. A CCW propeller (seen from above) is driven CCW, so the body is pushed CW. Seen from above, CW is a rotation about **−z** (FLU), which is nose **right**. In aerospace terms (FRD, z down) that is a **positive** yaw. `quad_rpy.xml` says the same: "CCW props (1,2) push the body nose-right (+yaw)."

Summing the four motors gives the total force and moment about the CG:

```python
def motor_wrench_flu(thrusts):
    f, tau = np.zeros(3), np.zeros(3)
    for (_, x, y, spin), t in zip(MOTORS, thrusts):
        r, F = np.array([x, y, 0.0]), np.array([0.0, 0.0, t])
        f += F
        tau += np.cross(r, F)
        tau[2] += -spin * K_TORQUE * t           # reaction torque
    return f, tau
```

## The mixer: from "what I want" to four motor commands

The controller thinks in four channels: collective throttle and roll, pitch and yaw efforts. The **mixer** maps them to the four motors. For Quad-X, with aerospace signs (roll right +, pitch nose-up +, yaw nose-right +):

| Motor | throttle | roll | pitch | yaw |
|---:|:---:|:---:|:---:|:---:|
| 1 FR CCW | + | − | + | + |
| 2 BL CCW | + | + | − | + |
| 3 FL CW | + | + | + | − |
| 4 BR CW | + | − | − | − |

Read the table one column at a time:

- **roll right** needs more lift on the left: motors 2 and 3 get +
- **nose up** needs more lift at the front: motors 1 and 3 get +
- **nose right** (+yaw) needs more of the CCW motors, whose reaction pushes the nose right: motors 1 and 2 get +

This is exactly the `<channel name="mixer">` in `quad_rpy.xml`, and `attitude_mixer()` in `quad_common.py` copies it line by line:

```python
m = [throttle - roll_out + pitch_out + yaw_out,     # 1 FR CCW
     throttle + roll_out - pitch_out + yaw_out,     # 2 BL CCW
     throttle + roll_out + pitch_out - yaw_out,     # 3 FL CW
     throttle - roll_out - pitch_out - yaw_out]     # 4 BR CW
return [min(max(v, 0.0), 1.0) for v in m]           # a motor cannot push down or exceed 100 %
```

## The numbers for this quad

| Quantity | Value | Source |
|---|---|---|
| mass | 1.5 kg | `quad_rpy.xml` |
| inertia Ixx, Iyy, Izz | 0.015, 0.015, 0.028 kg·m² | `quad_rpy.xml` |
| max thrust per motor | 8 N at command 1.0, linear in the command | `motors/max-thrust-N` |
| thrust-to-weight | 32 N / 14.7 N = 2.2 | |
| hover command | m·g / (4 · 8 N) = **0.459** | g = 9.795 m/s² (page 02) |
| reaction torque coefficient | k_Q = 0.016 m (N·m per N of thrust) | `motors/k-torque-m` |
| motor lag | first order, τ = 0.05 s | `lag_filter` with c1 = 20 |

Control authority around hover, with every motor having 1 − 0.459 = 0.541 of headroom (4.3 N):

```
roll/pitch torque max ≈ 4 · 0.177 m · 4.3 N ≈ 3.1 N m    → angular acceleration 200 rad/s²
yaw torque max        ≈ 4 · 0.016 m · 4.3 N ≈ 0.28 N m   → angular acceleration 10 rad/s²
```

Yaw authority is about 11 times weaker than roll authority. That is normal for multirotors, and it is why yaw responds slowly in every plot of this module.

Linear thrust in the command is a teaching simplification. A real propeller gives T ∝ rpm², and an ESC command maps to rpm roughly linearly. The JSBSim model's comment says the same. Change both engines together if you change it.

## Try it

- Use `motor_wrench_flu([T, T, T, T])` with T = 3.67 N (hover). Confirm the moment is (0, 0, 0). Then raise motor 1 alone by 2 % and predict the signs of roll, pitch and yaw acceleration before you compute them.
- Write the mixer as a 4 × 4 matrix A with `[T1..T4] = A · [thr, roll, pitch, yaw]`. Invert it with numpy. What does the inverse tell you about how to estimate the efforts from measured motor outputs?
- Swap motors 3 and 4 in the table (a common wiring mistake). Which of roll, pitch and yaw now has the wrong sign?
- Look up the Quad-X diagram in the ArduPilot or PX4 docs and check every row of the table above against it.

## References

- ArduPilot, *Connect ESCs and Motors* (frame diagrams): <https://ardupilot.org/copter/docs/connect-escs-and-motors.html>
- PX4, *Airframe reference*, Quadrotor x: <https://docs.px4.io/main/en/airframes/airframe_reference.html>
- R. Mahony, V. Kumar, P. Corke, "Multirotor Aerial Vehicles", IEEE Robotics & Automation Magazine, 2012
