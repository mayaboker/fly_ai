# Module 10: Multirotor lab, PyBullet or JSBSim (10 h)

## What you will build

A 1.5 kg Quad-X quadcopter (vehicle id 2) with two interchangeable physics engines. In PyBullet you apply the four motor forces and the yaw reaction torque yourself. In JSBSim you fly the course's `quad_rpy` model with its built-in attitude controller. Both scripts send the same pose and motor stream, so one Godot scene shows either one, using Module 2's quad with spinning rotors, a chase view and an FPV picture-in-picture. You will fly it from the keyboard, run a scripted mission (step tests, then a run through Module 2's three gates and back to the pad), and prove that the two engines agree.

## Prerequisites

- Modules 1–8, and [Module 9](../m09_ugv_pybullet/README.md) for `physics/robosim/pybullet_world.py` (heightfield, obstacles, gates in PyBullet).
- From [Module 2](../m02_scene_assets/README.md): `quad.tscn` (motors at ±0.177 m, rotors `Rotor_FR/BL/FL/BR`), the pad at ENU (0, 0) and the gates in `range.json`.
- For the JSBSim option: lessons 4–6 of the companion *JSBSim from zero to quad and VTOL* course (see the course [README](../README.md)). The model is [`reference/code/aircraft/quad_rpy`](../reference/code/aircraft/quad_rpy/quad_rpy.xml).
- Reference pages: [frames](../reference/frames.md), [protocol](../reference/protocol.md), [logging](../reference/logging.md), [terrain](../reference/terrain.md).

## Sub-topics

| File | Topic | Time |
|---|---|---:|
| [01_quad_frame_motors.md](01_quad_frame_motors.md) | Quad-X layout and numbering, per-motor thrust and reaction torque, the mixer | 1 h |
| [02_dynamics_and_open_loop.md](02_dynamics_and_open_loop.md) | Gravity at the origin, drag, motor lag, and the open-loop instability demo | 1 h |
| [03_attitude_altitude_control.md](03_attitude_altitude_control.md) | Attitude PD + mixer, altitude PI with tilt compensation and anti-windup, a position loop for the gate run, command and sensor rates | 1.5 h |
| [04_pybullet_quad.md](04_pybullet_quad.md) | PyBullet implementation: `applyExternalForce/Torque`, `LINK_FRAME` vs `WORLD_FRAME`, defaults to switch off | 1 h |
| [05_jsbsim_quad.md](05_jsbsim_quad.md) | JSBSim option: `quad_rpy`, the `ap/*` properties, the terrain feed, `jsbsim_state_to_godot` | 1 h |
| [06_godot_quad_view.md](06_godot_quad_view.md) | ATTITUDE from keyboard/gamepad, motor outputs as TELEMETRY and spinning rotors, FPV reuse | 1 h |
| [lab.md](lab.md) | Both sims, the Godot scene, the mission, the plots and the sign checklist | 3.5 h |

## Deliverables

- `physics/sims/quad_common.py`: airframe numbers, Quad-X layout, attitude PD + mixer, altitude controller, path follower, mission, motor telemetry.
- `physics/sims/quad_pybullet.py` and `physics/sims/quad_jsbsim.py`: the same command set, pose stream and log columns.
- `physics/tests/test_quad_signs.py`: the frame/sign checklist, automated for both engines.
- `tools/plot_quad_response.py` and one plot with both engines' step responses and gate runs.
- `godot/scenes/quad_lab.tscn` with `vehicles/rotor_spinner.gd`.
- The TELEMETRY extension (message type 100) in `physics/robosim/telemetry.py` and `godot/bridge/telemetry_bridge.gd`. They are part of the shared code (`reference/code`, copied during setup) and specified in [protocol.md](../reference/protocol.md); this module's copies are identical, and Modules 11 and 12 use the same files.

## Check

Measured with the reference code on Module 2's terrain (pad at ENU (0, 0)).

1. **Thrust vs acceleration.** In steady hover, the intended total thrust equals m·g within 0.5 %. Over the step-test phase, the measured vertical acceleration matches T·cos φ·cos θ/m − g with a mean error under 0.05 m/s². Reference: hover 14.700 N intended vs m·g = 14.692 N (both engines); mean error −0.004 m/s² for both, RMS 0.028 m/s² (PyBullet) and 0.040 m/s² (JSBSim).
2. **Step responses, both engines, one plot.** Altitude 3 → 5 m and roll/pitch 0 → 10°. Report the time to 63 % and 90 % and the overshoot. The engines must agree within 20 % on each number. Reference (PyBullet/JSBSim): altitude t63 0.93/0.92 s, t90 1.47/1.45 s, overshoot 1.8/1.8 %; roll t63 0.23/0.23 s, t90 0.40/0.35 s, no overshoot.
3. **Gate run.** Both engines pass all three gates with the quad's 0.35 m half-span clear of the posts and bar, then land on the pad. Reference: lateral offsets +0.26, −0.51 and +0.08 m (PyBullet) and +0.26, −0.50 and +0.09 m (JSBSim). No PyBullet contact with any gate or obstacle. Both landed within 3 cm of the pad center.
4. **Sign checklist.** `python tests/test_quad_signs.py` prints PASS for both engines: roll + drifts east, pitch + drifts south, yaw rate + turns the nose from north to east, throttle up climbs. All four are checked in ENU **and** in the Godot pose on the wire.
5. **Open-loop demo.** With the controller off and motor 1 at +2 %, the quad flips past 90° of roll. Reference: after 2.15 s, rolling left and pitching up, as the motor position predicts.
6. **Godot, both engines.** With each sim in `--mode manual`, the same scene flies the quad from ATTITUDE commands. Godot receives poses and motor telemetry at 60 Hz, and a ±10° roll command shows up as ±10° roll in the Godot pose. Reference: 771 poses and 771 telemetry packets in 12.9 s (PyBullet), roll range −10.0…10.0°, climb 4.02 m for both engines.

## Common mistakes

- Numbering the motors 1-2-3-4 around the frame. ArduPilot/PX4 Quad-X is 1 front-right, 2 back-left, 3 front-left, 4 back-right, and the mixer signs depend on it.
- Getting the yaw reaction torque backwards. A CCW propeller pushes the body **clockwise** (nose right).
- Passing a body-frame offset as `posObj` with `WORLD_FRAME` in PyBullet. With `WORLD_FRAME` the position is a world position. Use `LINK_FRAME` for motor forces.
- Applying motor forces once. PyBullet clears external forces after every `stepSimulation()`.
- Leaving PyBullet's default damping (0.04) on. It adds drag that JSBSim does not have: the steady yaw rate fell from 35.6 to 34.6 °/s, and the mission took 3.4 s longer.
- Mixing angle conventions. ATTITUDE and JSBSim use aerospace angles (roll right +, pitch nose-up +, yaw nose-right +), while PyBullet's own Euler angles are ENU/FLU. Convert once, through R_ned_frd.
