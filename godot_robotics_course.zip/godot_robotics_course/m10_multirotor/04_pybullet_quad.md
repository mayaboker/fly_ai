# 04 The PyBullet quad: forces, torques and frames

In PyBullet the quad is one rigid body with no propellers, joints or aerodynamics. Everything that makes it fly is an **external force or torque that you apply every step**. That makes PyBullet a transparent multirotor sim: every newton is in your code. It also means every frame mistake is yours. This page builds `quad_pybullet.py` and shows, with measurements, the three calls you must get right.

## The body

```python
LEG_Z = 0.08                                     # landing legs reach 8 cm below the CG (as in quad_rpy.xml)
col = p.createCollisionShape(p.GEOM_BOX, halfExtents=[0.15, 0.15, LEG_Z / 2],
                             collisionFramePosition=[0, 0, -LEG_Z / 2])   # box hangs BELOW the CG
quad = p.createMultiBody(Q.MASS, col)            # link origin = CG
p.changeDynamics(quad, -1,
                 localInertiaDiagonal=list(Q.INERTIA),   # (0.015, 0.015, 0.028), not the box's own
                 linearDamping=0.0, angularDamping=0.0,  # PyBullet's default is 0.04 each
                 lateralFriction=0.8)
```

| Line | Why |
|---|---|
| `collisionFramePosition` | moves only the collision box; the center of mass stays at the link origin |
| `localInertiaDiagonal` | PyBullet would otherwise compute inertia from the box (a solid 0.3 m slab), not the real quad |
| damping = 0 | drag and rotational damping are modeled explicitly, the same way JSBSim does |

**Measured: why the damping matters.** We ran the full lab mission twice, with damping 0 and with PyBullet's default 0.04. The steady yaw rate fell from 35.6 to 34.6 °/s, the roll t90 grew from 0.40 to 0.42 s, the gate offsets grew by up to 6 cm, and the mission took 3.4 s longer (105.0 s instead of 101.7 s). The default damping is an invisible extra drag that JSBSim does not have.

**Start pose: nose north.** JSBSim's ψ = 0 means north. PyBullet's identity quaternion points body x (forward) **east**. To make both engines start the same, the PyBullet quad starts with an ENU yaw of +90°:

```python
p.resetBasePositionAndOrientation(quad, [e, n, z0], p.getQuaternionFromEuler([0, 0, math.pi / 2]))
```

## Applying motor forces: `LINK_FRAME`

```python
for (_, x, y, spin), t in zip(Q.MOTORS, thrusts):
    p.applyExternalForce(quad, -1, [0, 0, t], [x, y, 0], p.LINK_FRAME)     # force AND position in body frame
tau_z = sum(-spin * Q.K_TORQUE * t for (_, _, _, spin), t in zip(Q.MOTORS, thrusts))
tau = np.array([0.0, 0.0, tau_z]) - Q.ROT_DAMP * w_flu
p.applyExternalTorque(quad, -1, tau.tolist(), p.LINK_FRAME)                # torque in body frame
```

| Flag | `forceObj` is in | `posObj` is | Use for |
|---|---|---|---|
| `p.LINK_FRAME` | the link (body) frame | a point in the **link frame** (relative to the link origin) | motor thrust: the motor moves with the body |
| `p.WORLD_FRAME` | the world frame | a point in **world coordinates** | drag, wind, gravity-like forces |

### We measured it, and so should you

A probe body (1.5 kg, inertia 0.015/0.015/0.028) was rolled +90° about x, so body z points to world −y and body y to world +z. One step with each call (PyBullet 3.2.7):

```
torque (0,0,1) body z, LINK_FRAME       angacc (0, -35.71, 0)    = 1/Izz about world -y   correct
torque (0,0,1),        WORLD_FRAME      angacc (0, 0, 66.67)     = 1/Iyy about world +z   correct
force (0,0,1) at body (0.177,0,0),
               LINK_FRAME               lin (0, -0.667, 0), angacc z -11.8 = 0.177/Iyy  correct
```

Then the classic mistake: a body at world z = 5, and a horizontal 1 N force with `WORLD_FRAME` and `posObj = [0, 0, 0]`. The author meant "at the CG", but wrote a body-frame offset:

```
WORLD_FRAME, posObj [0,0,0] (body at z=5):  angacc (0, -333.33, 0)   ← a 5 m lever arm!
WORLD_FRAME, posObj [0,0,5] (the CG):       angacc (0, 0, 0)
```

The wrong call produced a 5 N·m pitch moment from a 1 N force. In flight this shows up as "the quad flips whenever I add wind". The drag force in `quad_pybullet.py` therefore passes the **current world position** of the CG:

```python
p.applyExternalForce(quad, -1, drag.tolist(), s["pos"].tolist(), p.WORLD_FRAME)
```

Do not trust a frame flag from memory, not even from this page. 3.2.7 behaves as shown above. Run the probe (in the Try it section) once on your own install.

### Forces last one step

`stepSimulation()` clears all external forces and torques after it integrates. Apply them **inside** the physics loop, before every step. If you apply them only at the 60 Hz outer rate, the quad gets thrust for one step in four and falls.

```python
def step_physics(self, s):
    self.cmd = attitude_mixer(...)                               # 240 Hz, from the current state
    self.motor += (self.cmd - self.motor) * (1 - math.exp(-self.dt / Q.TAU_MOTOR))
    thrusts = Q.T_MAX * self.motor
    ... applyExternalForce x4, applyExternalTorque, drag ...
    p.stepSimulation()
```

## The loop

```
every physics step (240 Hz):    read state -> attitude PD + mixer -> motor lag -> apply forces -> step
every 4th step (60 Hz):          commands (ATTITUDE, PAUSE/RESUME/STEP/RESET)
                                 -> mission or manual setpoint -> altitude controller -> throttle
                                 -> send POSE (enu_flu_to_godot) + TELEMETRY (motor outputs)
                                 -> contacts with gates/obstacles -> log state.csv, control.csv
```

Disarmed means motors off. Before takeoff, and whenever the altitude setpoint is 0 with the quad on the ground, the motor commands are 0. Without this, the attitude loop sees the quad tilted on its legs, spins up motors to level it, and makes it hop. Module 2's pad and apron are flat (exactly 0 m), so the quad sits level there. Start it anywhere else and check the slope first.

## The ground and the gates

The quad flies over the same heightfield as the rover, and Module 9's `pybullet_world.add_range_objects(..., gates=True)` also adds Module 2's obstacles and the three gates (two posts and a bar each) as static bodies. So in PyBullet the quad can really hit a gate. Every outer tick the sim checks the quad's contacts with these objects, writes any hit to `contact.csv`, and lists the hit objects in `summary.json` under `"hits"`. In the reference mission the list stayed empty.

The altitude setpoint is absolute (ENU up), and the mission computes it from the terrain under each gate. In manual mode the setpoint is relative to the **takeoff point**, like a barometer: hills are real, and a long low flight can end in a hillside. JSBSim sees the terrain only through `terrain-elevation-asl-ft` under the CG, as a flat plane, and it knows nothing about the gates (page 05). A JSBSim quad flies straight through a gate post without noticing.

## Try it

- Run this probe, then change one flag at a time and predict the result before you look:

  ```python
  import pybullet as p, numpy as np
  p.connect(p.DIRECT); p.setGravity(0, 0, 0); p.setTimeStep(1 / 240)
  s = p.createCollisionShape(p.GEOM_BOX, halfExtents=[0.15, 0.15, 0.04])
  b = p.createMultiBody(1.5, s, basePosition=[0, 0, 5],
                        baseOrientation=p.getQuaternionFromEuler([np.pi / 2, 0, 0]))
  p.changeDynamics(b, -1, localInertiaDiagonal=[0.015, 0.015, 0.028], linearDamping=0, angularDamping=0)
  p.applyExternalTorque(b, -1, [0, 0, 1], p.LINK_FRAME); p.stepSimulation()
  print(np.array(p.getBaseVelocity(b)[1]) * 240)          # expect (0, -35.7, 0)
  ```
- Move the motor forces to the 60 Hz loop only (apply them every 4th step). Describe what happens and why.
- Restore the default damping: `p.changeDynamics(quad, -1, linearDamping=0.04, angularDamping=0.04)`. Rerun the mission and compare with `plot_quad_response.py`.
- Give the quad a CG offset: put `baseInertialFramePosition=[0.01, 0, 0]` in `createMultiBody`. Which controller term absorbs it, and how large is the steady pitch error?

## References

- PyBullet Quickstart Guide, `applyExternalForce` / `applyExternalTorque`: <https://docs.google.com/document/d/10sXEhzFRSnvFcl3XxNGhnD4N2SedqwdAvK3dsihxVUA>
- gym-pybullet-drones (a larger PyBullet multirotor project using the same approach): <https://github.com/utiasDSL/gym-pybullet-drones>
- [Frames cheat sheet](../reference/frames.md)
