# 05 The JSBSim option: `quad_rpy` with its built-in controller

JSBSim is a flight dynamics model. You describe the aircraft in XML: mass, forces and a flight control system (FCS). JSBSim integrates it on a round, rotating Earth. For a quad, the companion JSBSim course built `quad_rpy`: four thrust forces and a yaw torque through `<external_reactions>`, a motor lag, and an attitude PD + mixer written as FCS channels. In this module you **do not** reimplement any of that. You set four properties at 60 Hz and read the state back.

## What you set, what you read

| Property | Direction | Unit | Meaning |
|---|---|---|---|
| `ap/roll-cmd-deg` | in | deg | roll angle command (right +) |
| `ap/pitch-cmd-deg` | in | deg | pitch angle command (nose up +) |
| `ap/yawrate-cmd-dps` | in | deg/s | yaw rate command (nose right +) |
| `ap/throttle-cmd` | in | 0–1 | collective, from our altitude loop |
| `ap/kp-att`, `ap/kd-att`, `ap/kp-yawrate` | in | – | gains (0.25, 0.05, 0.10); we set them to 0 when disarmed |
| `position/terrain-elevation-asl-ft` | in | ft | ground height under the quad, from the shared heightmap |
| `attitude/phi-rad`, `theta-rad`, `psi-rad` | out | rad | Euler angles, NED/FRD |
| `velocities/p-rad_sec`, `q-rad_sec`, `r-rad_sec` | out | rad/s | body rates, FRD |
| `velocities/v-north-fps`, `v-east-fps`, `v-down-fps` | out | ft/s | NED velocity |
| `position/lat-geod-rad`, `long-gc-rad`, `h-sl-ft` | out | rad, ft | position |
| `fcs/motor1-lag` … `fcs/motor4-lag` | out | 0–1 | motor outputs after the lag (sent to Godot as TELEMETRY code 2) |

Note the units: feet, ft/s, degrees **and** radians, depending on the property. The suffix tells you which one. Convert once, with the helpers in `robosim.frames` (`FT = 0.3048`).

## Setting up the run

```python
fdm = jsbsim.FGFDMExec(os.path.join(HERE, ".."))       # root: finds aircraft/quad_rpy/quad_rpy.xml
fdm.set_debug_level(0)
fdm.load_model("quad_rpy")
fdm.set_dt(1.0 / 120)                                  # JSBSim default rate for this course

e, n = pad                                             # launch pad in ENU (default 0, 0)
fdm["position/terrain-elevation-asl-ft"] = hm.height_at(e, n) / FT  # BEFORE run_ic
fdm.load_ic("ground", True)                            # aircraft/quad_rpy/ground.xml
origin = GeoOrigin(fdm["ic/lat-geod-rad"], fdm["ic/long-gc-rad"], 0.0)   # ENU (0,0) = heightmap center
fdm["ic/lat-geod-rad"] = origin.lat0 + n / EARTH_R    # move the start to the pad
fdm["ic/long-gc-rad"]  = origin.lon0 + e / (EARTH_R * math.cos(origin.lat0))
fdm.run_ic()
for _ in range(120):                                   # settle on the landing legs for 1 s
    fdm.run()
```

Three details matter:

1. **Terrain before `run_ic()`.** `ground.xml` gives `altitudeAGL = 0.09 m`. JSBSim turns it into an altitude above sea level using the terrain elevation it knows *at that moment*. Set the terrain first. Module 2's pad is at exactly 0 m, so there you would not notice the mistake. Anywhere else you would: the quad starts at 0.09 m ASL, below the real ground, and when the terrain is set afterwards the leg springs fire it upward. In our test with the ground at 7.15 m, it climbed to 87 m AGL within 2 s.
2. **The origin is the heightmap center, which is also Module 2's pad.** `ground.xml`'s lat/lon is ENU (0, 0), and the origin height is sea level, so heightmap heights (ASL, minimum 0 m) and JSBSim's `h-sl` are on the same scale. For another start point (`--pad E,N`), the offset is applied to the IC with the same flat-earth formula that `GeoOrigin.to_enu` inverts.
3. **Geocentric vs geodetic.** `ground.xml`'s latitude has no `type`, so JSBSim treats 32.08° as geocentric. The geodetic origin is 32.2534° (page 02). Always read `ic/lat-geod-rad` back instead of typing 32.08.

## Each step: the terrain feed

JSBSim does not know our heightmap. It has a single number, the terrain elevation under the aircraft, and it treats the ground as flat at that height. So before every `fdm.run()` we write the height under the current position:

```python
def step_physics(self):
    e, n = self.read()["pos"][:2]
    self.fdm["position/terrain-elevation-asl-ft"] = self.hm.height_at(e, n) / FT
    self.fdm.run()
```

Module 11 uses the same trick for the fixed-wing plane. Its limit: the contact model sees a **horizontal** plane at the right height, not the slope. A JSBSim quad sitting on a 20 % slope stays level, while a PyBullet quad tilts and slides. JSBSim also knows nothing about the gates and obstacles: it flies straight through a gate post. Fly both from the flat pad, and judge gate passes from the logged positions (page 03), not from collisions.

## Each outer tick: commands in, pose out

```python
f["ap/roll-cmd-deg"] = sp.roll
f["ap/pitch-cmd-deg"] = sp.pitch
f["ap/yawrate-cmd-dps"] = sp.yawrate
f["ap/throttle-cmd"] = throttle                       # from AltitudeController, same as PyBullet
pos_g, q_g = jsbsim_state_to_godot(f, origin)         # the tested adapter from frames.py
br.send_pose(t, 2, pos_g, q_g, enu_to_godot_pos(v_enu))
```

`jsbsim_state_to_godot` reads lat/lon/h and φ θ ψ and does the full chain from [frames.md](../reference/frames.md): GeoOrigin → ENU → Godot, and T_ENU_NED · R_zyx(φ, θ, ψ) · D_FRD_FLU · C_FLU_MODEL. The velocity is converted separately, from the NED components to ENU (E, N, −D), then to Godot.

**Disarming.** The built-in mixer always adds the attitude terms to the throttle. On the ground with throttle 0, any small tilt would spin up motors. The sim therefore sets the three gains to 0 while disarmed, and back to their XML values when armed:

```python
fdm["ap/kp-att"] = Q.KP_ATT if armed else 0.0          # 0.25
fdm["ap/kd-att"] = Q.KD_ATT if armed else 0.0          # 0.05
fdm["ap/kp-yawrate"] = Q.KP_YAWRATE if armed else 0.0  # 0.10
```

## Does JSBSim match PyBullet?

This is the payoff of using the same controller and the same airframe numbers. Same mission, same terrain:

| Quantity | PyBullet (240 Hz) | JSBSim (120 Hz) |
|---|---:|---:|
| altitude 3 → 5 m: t63 / t90 / overshoot | 0.93 s / 1.47 s / 1.8 % | 0.92 s / 1.45 s / 1.8 % |
| roll 0 → 10°: t63 / t90 | 0.23 s / 0.40 s | 0.23 s / 0.35 s |
| yaw rate, 45 °/s commanded: steady value | 35.58 °/s | 35.58 °/s |
| hover thrust (12–14 s) | 14.700 N | 14.700 N |
| gate offsets (lateral, gates 1/2/3) | +0.26 / −0.51 / +0.08 m | +0.26 / −0.50 / +0.09 m |
| landing point (ENU) | (−0.02, −0.02) | (−0.02, −0.02) |
| mission length | 101.65 s | 101.52 s |
| final yaw | −47.1° | −48.3° (311.7°) |
| wall time for the mission (`--fast`) | 2.2 s | 1.5 s |

![step responses, both engines](img/quad_response.png)

In the plot the lines lie on top of each other. The small t90 difference in roll comes from the **step rate**, not from the physics. The last few percent of the response creep slowly toward 10°, so the 90 % crossing is sensitive to small changes. Run JSBSim at 240 Hz (`--physics-hz 240 --decim 4`) and its roll t90 becomes 0.42 s, next to PyBullet's 0.40 s. We also checked the physics directly. JSBSim's external roll moment (`moments/l-external-lbsft`) equals the moment computed from its four motor thrusts (0.1329 N·m), and the inertia reads back as 0.0150 kg·m².

## Try it

- Print `fdm.query_property_catalog("ap/")` and find every property the controller uses.
- Comment out the terrain feed in `step_physics()`. Take off from the pad, fly toward a hill with manual roll, and compare with PyBullet. What does each engine do at the hillside?
- Set `motors/tau-sec` to 0.2 and notice that nothing changes. The property is declared but not used; the lag is hard-coded as `c1 = 20` in each `<lag_filter>`. Change `c1` to 10 in a copy of the model, and τ = 0.1 s in `quad_common.py`, then compare the roll responses again.
- Run JSBSim at 60 Hz (`--physics-hz 60 --decim 1`) and at 240 Hz. Tabulate roll t63 and t90 for 60, 120 and 240 Hz. (Reference: 0.35 s at 120 Hz, 0.42 s at 240 Hz.)

## References

- JSBSim Reference Manual: <https://jsbsim-team.github.io/jsbsim-reference-manual/>
- JSBSim Python API (`FGFDMExec`): <https://jsbsim-team.github.io/jsbsim/>
- The companion *JSBSim from zero to quad and VTOL* course, lessons 4–6
- [Frames cheat sheet](../reference/frames.md), section "JSBSim"
