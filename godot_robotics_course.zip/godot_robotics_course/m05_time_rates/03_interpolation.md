# 03 Interpolation: render a little in the past

The Module 4 viewer shows the newest pose every frame. That is only smooth when exactly one new pose arrives per frame. This page shows when it is not, then builds the standard fix: draw the scene about one pose period in the past, where there are always two real poses to interpolate between.

## What goes wrong with the newest pose

Three situations, all measured with `plot_pose_age.py` on the spinning cube (0.5 rev/s, so a steady 3.00° per frame at 60 fps):

| Situation | Frames with no new pose | Cube step per frame, raw | ... interpolated |
|---|---|---|---|
| 60 fps, 60 Hz poses, no loss (good phase) | 0.0 % | 3.00° ± 0.00° | 3.00° ± 0.00° |
| 60 fps, 60 Hz poses, no loss (another run) | 0.8 % | 3.00° ± 0.59° | 3.00° ± 0.32° |
| 60 fps, 20 % pose loss | 4.4 % | 3.00° ± 2.21° | 3.00° ± 0.66° |
| 144 fps, 60 Hz poses | 58.4 % | 1.25° ± 1.48° | 1.25° ± 0.05° |
| 60 fps, physics at 4× real time | 0.1 % | 12.00° ± 1.51° | 12.00° ± 0.27° |

(± is the standard deviation over all frames of a 20 s run.)

The first row is a fair warning: in one run, raw looked perfect. Two 60 Hz loops in a stable phase deliver exactly one pose per frame. Change anything (a lost packet, a faster monitor, a busy CPU) and raw shows its true nature. At 144 fps, 58 % of frames repeat the previous pose and the rest jump by two or three frames' worth: the motion stutters at a steady 60 Hz under a 144 Hz display.

![Raw vs interpolated at 144 fps](code/screenshots/pose_age_144fps.png)

Bottom left: the sphere's height per rendered frame. Raw (orange) is a staircase, interpolated (blue) a smooth curve. Bottom right: the cube's rotation per frame. Raw alternates between 0° and 3°, interpolated stays at 1.25°.

## The idea

Keep a short buffer of recent poses per vehicle, each with its `t_sim`. Render at a time `t_render` slightly older than the newest pose. Then `t_render` almost always falls between two received poses, and you can blend them:

```
received poses (t_sim):   p(4.000)     p(4.017)     p(4.033)     p(4.050) ← newest
                                              ▲
                                    t_render = 4.050 − 0.025 = 4.025
                                    w = (4.025 − 4.017) / (4.033 − 4.017) = 0.5
                                    pos  = lerp(p4.017.pos,  p4.033.pos,  0.5)
                                    quat = slerp(p4.017.quat, p4.033.quat, 0.5)
```

The delay is the price. With 25 ms of delay the screen shows the world as it was 25 ms (of sim time) before the newest data. In return, one or even two lost poses in a row are bridged by a straight line between their neighbors, instead of a freeze followed by a jump.

## `SimBridge.sample`

The reference bridge already has it. Module 4 did not use it:

```gdscript
## Interpolated pose at sim time t. Between samples: lerp + slerp.
## After the newest sample: extrapolate with velocity for at most max_extrapolate_s.
func sample(vehicle_id: int, t: float) -> Transform3D:
	var buf: Array = _buffers[vehicle_id]
	if t <= buf[0].t:
		return Transform3D(Basis(buf[0].quat), buf[0].pos)
	for i in range(buf.size() - 1, 0, -1):            # newest first: t is usually near the end
		var a: Dictionary = buf[i - 1]
		var b: Dictionary = buf[i]
		if t >= a.t and t <= b.t:
			var w: float = 0.0 if b.t == a.t else (t - a.t) / (b.t - a.t)
			return Transform3D(Basis(a.quat.slerp(b.quat, w)), a.pos.lerp(b.pos, w))
	var last: Dictionary = buf.back()
	var dt: float = minf(t - last.t, max_extrapolate_s)
	return Transform3D(Basis(last.quat), last.pos + last.vel * dt)
```

Points worth knowing:

- **Positions lerp, orientations slerp.** Lerping quaternion components and re-normalizing would speed up and slow down through the middle of a large rotation. Slerp rotates at a constant rate. Godot's `Quaternion.slerp` also takes the short way round when q and −q meet ([Module 3](../m03_frames/05_quaternions.md)).
- **Quaternions are normalized on receipt** (`msg.quat.normalized()` in `_on_pose`). Slerp expects unit quaternions, and float32 on the wire leaves them slightly off.
- **`w = 0` when two samples share a `t_sim`.** That happens while paused, when physics resends the same pose as keep-alive.
- **Extrapolation is bounded.** Past the newest pose, `sample` moves the position forward along the received velocity for at most `max_extrapolate_s` (50 ms), then holds. Orientation is not extrapolated. A 50 ms guess along a straight line is usually close. A guess 500 ms ahead puts a falling sphere through the floor.
- **The buffer is short** (`buffer_len = 32` poses, about 0.5 s at 60 Hz). Only the last two or three entries matter.

## The render clock

The obvious choice, `t_render = latest_t_sim − delay` every frame, does not work well. `latest_t_sim` jumps whenever a packet arrives. When two packets come in one frame and none in the next, `t_render` jumps by 33 ms and then stands still, which is the same stutter as before.

So `t_render` gets its own clock, [`RenderClock`](code/godot/bridge/render_clock.gd). It moves forward by the frame's `delta`, scaled by how fast sim time is running, and is gently pulled toward the target:

```gdscript
func advance(delta: float, latest_t_sim: float, paused: bool) -> float:
	var target := latest_t_sim - delay_s
	if paused:                             # show exactly the paused (or single-stepped) pose
		t = latest_t_sim
		_was_paused = true
		return t
	if t < 0.0 or _was_paused or absf(target - t) > snap_s:
		t = target                         # start, resume, reset or lost track: jump
		_was_paused = false
		return t
	t += delta * rate                      # move smoothly with the render frames ...
	t += (target - t) * (1.0 - exp(-delta / tau_s))   # ... and slowly pull toward the target
	t = minf(t, latest_t_sim + max_ahead_s)   # stream stalled: do not run away from the data
	return t
```

| Parameter | Default | Role |
|---|---|---|
| `delay_s` | 0.025 s | how far behind the newest pose to render (1.5 periods at 60 Hz) |
| `tau_s` | 0.3 s | how quickly drift is corrected (about 5 % per frame at 60 fps, frame-rate independent) |
| `snap_s` | 0.25 s | beyond this error, jump instead of slewing (start, reset, long stall) |
| `max_ahead_s` | 0.05 s | never run further past the newest pose than `sample` will extrapolate |
| `rate` | measured | sim seconds per wall second |

`rate` comes from `observe(t_sim, wall)`, called for every received pose. Every 0.5 s of wall time it divides the sim time that passed by the wall time that passed. At `--speed 4` it measures 4, and the clock follows without being told. Windows in which physics was paused are ignored. The first measurement takes 0.5 s. Until then the clock assumes real time and snaps whenever it falls 0.25 s behind, so the first half second at 4× is jerky. `plot_pose_age.py` skips the first second for that reason.

When physics is paused, the clock shows the paused pose exactly (`t = latest_t_sim`), so STEP moves the picture by exactly one frame. On resume, it jumps back to `latest − delay` and continues.

## Wiring it into the viewer

```gdscript
var clock := RenderClock.new()

func _on_pose(vehicle_id: int, msg: Dictionary) -> void:
	paused = (msg.flags & RsProtocol.POSE_FLAG_PAUSED) != 0
	newest_t[vehicle_id] = msg.t_sim
	clock.observe(msg.t_sim, _wall())

func _on_reset() -> void:                          # bridge.physics_reset
	newest_t.clear()
	clock.reset()

func _process(delta: float) -> void:
	if bridge.latest_seq < 0:
		return
	var t_render := clock.advance(delta, bridge.latest_t_sim, paused)
	for id: int in bodies:
		if bridge.has_vehicle(id):
			var raw := bridge.latest_transform(id)
			var smooth := bridge.sample(id, t_render)
			bodies[id].transform = smooth if interpolate else raw
```

One more detail from Module 4 matters even more now: **`SimBridge` must process before the viewer.** Godot calls `_process` parent first within the same priority, so without help the viewer would use the packets of the previous frame. `SimBridge` therefore sets `process_priority = -100` in its own `_ready()`. We measured the difference (with a lower priority on `SimBridge` vs the default 0): without it, the median pose age was 21.2 ms at a median latency of 4.3 ms, so one whole frame was added. With it, the median pose age was 7.8 ms at a latency of 7.7 ms.

## Choosing the delay

| Delay | Effect |
|---|---|
| < 1 pose period | frequent extrapolation even without loss: the clock runs past the newest pose every frame |
| ≈ 1.5 periods (25 ms at 60 Hz) | one lost pose is bridged by interpolation; two in a row extrapolate briefly |
| ≈ 2.5 periods | survives two lost poses; costs another 17 ms of age |

Size it for the **slowest** stream you interpolate. With the sphere at 30 Hz and 25 ms delay, the sphere sometimes extrapolates. In our 20 % loss run, 7.8 % of frames extrapolated at least one body. That was enough to see, not enough to look wrong. Measure your own with the lab's log and pick the delay from the data.

## Where interpolation is wrong

Interpolation assumes straight-line motion between samples. At an impact it cuts the corner. The sphere's bounce has a sharp bottom, and the interpolated curve rounds it off by up to the distance the sphere travels in one pose period. For display that is invisible. For anything measured from the picture, it is a reason to render the raw pose:

- **Sensors** (rays, contact): use the raw pose and its `t_sim` (Module 4, [06](../m04_bridge/06_sensor_back_channel.md)).
- **Camera frames for a dataset**: render the raw pose in lock-step ([05](05_lockstep_determinism.md)), so every image has an exact `t_sim`.
- **Human viewing, chase cameras, UI**: interpolate.

## Try it

- In the lab, set `clock.delay_s = 0.0` and run with `--loss 0.2`. Read "frames extrapolating" from the plot tool. Then try 0.025 and 0.040.
- Replace slerp with `a.quat * (1 - w) + b.quat * w` normalized, and rotate the cube faster (`axis * 2π * 5`). Plot the rotation step per frame. What pattern appears?
- Comment out the `process_priority = -100` line in `SimBridge._ready()` and compare the median pose age in the plot tool. Explain the difference. Put the line back.
- Start physics at `--speed 4` with the viewer already running. Watch the first second, then explain it using `rate` and `snap_s`.

## References

- Valve Developer Wiki, "Source Multiplayer Networking" (entity interpolation): <https://developer.valvesoftware.com/wiki/Source_Multiplayer_Networking>
- Glenn Fiedler, "Snapshot Interpolation": <https://gafferongames.com/post/snapshot_interpolation/>
- Godot `Quaternion.slerp`, `Vector3.lerp`: <https://docs.godotengine.org/en/stable/classes/class_quaternion.html>
- Godot `Node.process_priority`: <https://docs.godotengine.org/en/stable/classes/class_node.html>
