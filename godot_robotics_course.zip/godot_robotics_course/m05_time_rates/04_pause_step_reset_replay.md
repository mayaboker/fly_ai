# 04 Pause, single-step, reset and replay

Debugging a robot means stopping time, moving it forward one frame at a time, starting over, and watching the same thing again. In a two-process simulator each of these is a command to the process that owns time, and the viewer follows. This page defines the four operations exactly, because small differences in their meaning cause confusing bugs.

## Who pauses?

Physics. The viewer keeps rendering at full frame rate while the simulation is paused: you can orbit the camera, read values, and press STEP. This is why the course does not use Godot's `get_tree().paused` for simulation pause. Godot's own pause would freeze the viewer, not the experiment. ([Module 1](../m01_editor_gdscript/03_gdscript_and_callbacks.md) introduced the keys; from Module 4 on they send commands.)

| Command | Physics does | Viewer sees |
|---|---|---|
| PAUSE | stops stepping **at the next frame boundary**; keeps sending the paused pose at 60 Hz with the PAUSED flag | PAUSED label; `RenderClock` shows exactly the paused pose |
| RESUME | continues stepping; re-anchors its real-time schedule | LIVE; render clock jumps to `latest − delay` and continues |
| STEP | pauses, then advances exactly to the next frame boundary and sends that pose | one frame of motion, then PAUSED again |
| RESET | rebuilds the world from the seed, `t_sim = 0`, sends the RESET pose at once | buffers cleared, `physics_reset` signal, clock restarts |

## Frame boundaries

A "frame" here is one pose period of the reference vehicle: 4 physics steps at 240 / 60 Hz. The first version of the Module 5 scenario paused immediately, in the middle of a period. This is what the viewer then saw when stepping:

```
pause  (cube t_sim 4.8000)
step   (cube t_sim 4.8292)     ← paused pose at an odd time: 4.8 + 7/240
step   (cube t_sim 4.8333)     ← first STEP moved only 1/240 s
step   (cube t_sim 4.8500)     ← from here on, 1/60 s per STEP
```

The paused pose sat at a time no other run would ever produce, and the first STEP was a quarter of the size of the others. For a dataset or a frame-by-frame comparison that is a bug. The fix is to finish the current period before stopping:

```python
if cmd == P.CMD_PAUSE:                      # stop at the next frame boundary
    paused, step_budget = True, (-world.step_count) % frame_steps
elif cmd == P.CMD_STEP:                     # pause, then advance to the next frame boundary
    paused = True
    step_budget += frame_steps - (world.step_count + step_budget) % frame_steps
```

`step_budget` is the number of physics steps still owed. The main loop runs steps while `step_budget > 0`, even when paused, without real-time pacing. The `(step_count + step_budget) % frame_steps` term makes several quick STEPs add up to whole frames. Measured after the fix:

```
single steps: cube t_sim before/after each step [4.0, 4.01666666666667, 4.03333333333333, 4.05],
increments [0.016667, 0.016667, 0.016667]
```

## Keep-alive while paused

While paused, physics sends the same pose with the PAUSED flag every 1/60 s of wall time. Without it, the viewer would go STALE after 0.25 s, and "paused" would look exactly like "crashed". These keep-alive poses are **not** logged ([06](06_logging.md)): they carry no new information, and logging them would make a paused run's log differ from an unpaused one.

## Reset vs restart

| | RESET command | Restarting the process |
|---|---|---|
| World | rebuilt from the same seed | built from scratch |
| `t_sim` | back to 0 | starts at 0 |
| Viewer | RESET flag on the next pose | RESET flag on the first pose |
| Logger | same run folder, `t_sim` goes back to 0 in the CSV | a new run folder |
| Viewer connection, command session | unchanged | new; the viewer does not need to restart |

Because `build()` takes every random number from the seed, a RESET reproduces the start exactly. In our test, the 2402 pose rows logged after a RESET were identical to the first 2402 rows of a fresh run with the same seed. When paused, RESET sends its pose immediately, so the viewer updates even though physics is not stepping.

A note on the log: after a RESET, `t_sim` in `pose.csv` goes back to 0, so `t_sim` alone is no longer a unique key. Split the log at the backward jump, or restart the logger on reset if your analysis needs one episode per folder.

## Replay: physics without physics

Every pose the scenario computes is in `pose.csv`. `tools/replay_poses.py` reads it and plays it back into the viewer, using `PhysicsBridge` like a real scenario. It sends the same packets at the recorded `t_sim` pace, and it obeys PAUSE, RESUME, STEP and RESET:

```bash
python tools/replay_poses.py logs/20261001T063738Z_spin_bodies --speed 0.5 --loop
```

The viewer cannot tell the difference. That makes replay useful for:

- debugging viewer code (interpolation, cameras, UI) without waiting for physics, as often as you like;
- rendering the same motion again with different camera settings or lighting (Modules 6–7);
- showing a run to someone who does not have PyBullet or JSBSim installed.

The core of the replay loop:

```python
for t, group in groupby(rows, key=lambda r: float(r["t_sim"])):   # one frame = all poses with one t_sim
    frames.append((t, poses))
...
if not paused and now >= t_wall0 + frames[i + 1][0] / a.speed:     # same schedule idea as physics
    i += 1
    send(i)
```

In our test, replaying a 20 s log at 0.5× with PAUSE, two STEPs, RESUME and RESET from the viewer gave the same STEP increments (exactly 1/60 s) as live physics.

Replay is not re-simulation. The recorded poses cannot react to a new command. To answer "what if the controller had done X at t = 3.2 s?", you re-run physics with the same seed and the new input ([05](05_lockstep_determinism.md)).

## Try it

- Pause with P, press S ten times, and check that the info line's `t_sim` advanced by exactly 10/60 s.
- Revert the PAUSE fix (`step_budget = 0`) and reproduce the odd 4.8292 pose. Then put the fix back.
- Record a 20 s run with `--log`, then replay it at `--speed 0.25` with the viewer in raw and in interpolated mode. Does the render clock follow the slow-motion rate?
- Press R twice quickly. How many RESETs does Python apply, and how many `physics_reset` signals does the viewer see? Why can they differ?

## References

- [Protocol: commands](../reference/protocol.md#messages)
- [Module 4: reliable commands](../m04_bridge/04_reliable_commands.md) (STEP must be exactly-once)
- Python `itertools.groupby`: <https://docs.python.org/3/library/itertools.html#itertools.groupby>
