# 01 Fixed physics step, render frames, and two clocks

Two loops now run side by side: physics in Python, rendering in Godot. They run at different rates, and neither can rely on the other's timing. Before we smooth anything, we need to be precise about what each loop's clock means.

## A fixed step for physics, a variable frame for rendering

| | Physics (PyBullet, JSBSim) | Rendering (Godot `_process`) |
|---|---|---|
| Step | fixed `dt` (1/240 s, 1/120 s) | variable `delta`, whatever the last frame took |
| Must be repeatable | yes: same inputs, same outputs | no |
| If the machine is slow | physics falls behind real time, but every step is still `dt` | frames get longer, fewer per second |
| Owns | `t_sim` | nothing that matters to the experiment |

Physics uses a fixed step because integrators are only stable and accurate for the step they were tuned for. A contact solver at 240 Hz behaves differently at 60 Hz. More importantly, a fixed step is what makes a run **repeatable** ([05](05_lockstep_determinism.md)). If the step depended on how long the last frame took, two runs could never match.

Rendering uses whatever time it gets. A frame takes 7 ms or 17 ms or, while you drag the window, 100 ms. That is fine, as long as rendering never feeds its timing back into physics.

### And Godot's `_physics_process`?

Godot has its own fixed tick (`physics/common/physics_ticks_per_second`, 60 by default) that runs `_physics_process`. In this course it does **not** simulate vehicles. It is only a convenient fixed-rate callback for Godot-side queries, like the RANGE ray from Module 4. Do not confuse "Godot physics tick" with "the physics", which lives in Python.

## Two clocks

| | **t_sim** | **wall time** |
|---|---|---|
| Source | `step_count × dt` in the physics process | `time.monotonic()` / `Time.get_ticks_usec()` |
| Stops when | physics pauses | never |
| Speeds up when | you run 4× or as fast as possible | never |
| Goes back when | physics resets or restarts | never |
| Use it for | stamping every sample, joining logs, interpolation | latency, staleness, pacing |

Rule of thumb: if a number ends up in a dataset or a plot of the robot's behavior, it is `t_sim`. If it measures the computer, it is wall time.

## Pacing physics to real time

When a person watches, physics should advance 1 s of `t_sim` per 1 s of wall time. The naive loop drifts:

```python
while True:
    world.step()
    time.sleep(dt)          # WRONG: sleep(dt) plus the step's own run time, plus oversleep
```

`sleep` only promises "at least `dt`", and the step itself takes time too. On our machine, 5 s of simulated time with `sleep(1/240)` took **5.177 s** of wall time, 3.5 % slow, and the error grows without bound. Pace against a **schedule** instead:

```python
next_wall = time.monotonic()
while True:
    world.step()
    next_wall += dt / speed                   # the time this step SHOULD end
    now = time.monotonic()
    if now - next_wall > 0.25:                # hopelessly behind (debugger, laptop lid)
        next_wall = now                       # re-anchor instead of sprinting to catch up
        overruns += 1
    elif next_wall > now:
        time.sleep(next_wall - now)
```

The same 5 s took **5.000 s**. One late wake-up is absorbed by a shorter sleep next time, so the average rate is exact.

The re-anchor matters. After a 3 s pause in a debugger, a pure schedule would run 720 steps with no sleep at all to "catch up", and the viewer would see the bodies fast-forward. Re-anchoring accepts that real time was lost, and counts it. `spin_bodies.py` prints `pacing re-anchors N` in its summary. Anything above 0 in a normal run means your physics cannot keep up with real time.

## Faster and slower than real time

`speed` scales the schedule. `spin_bodies.py --speed 4` runs four times faster than real time, `--speed 0.25` in slow motion, and `--speed 0` skips sleeping entirely:

| Mode | Use | Measured on our machine |
|---|---|---|
| `--speed 1` | watching, interactive control | 1.000 s sim per s wall |
| `--speed 4` | watching a long scenario quickly | 4.00× (fit over 13 s of received poses) |
| `--speed 0` | tests, batch runs, data generation without a viewer | 60 s of sim in about 0.53 s of wall time, including start-up |

Nothing in the physics changes with speed: same `dt`, same steps, same results ([05](05_lockstep_determinism.md) proves it). Only the sleeps change. The viewer has to cope with poses arriving 4× faster, and [03](03_interpolation.md) makes the render clock measure the speed instead of assuming 1×.

## The Module 5 physics loop

Module 4's loop stepped 4 times per pose period, then slept. Module 5 loops once per **physics step**. That gives per-vehicle rates ([02](02_rates_age_jitter.md)), STEP at any boundary, and quick reaction to commands while paused:

```python
while not done:
    for msg in br.poll(world.t_sim):          # commands, sensors
        handle(msg)
    if not paused or step_budget > 0:         # running, or finishing a STEP
        world.step()
        if paused:
            step_budget -= 1
        for vid in bodies:                    # each vehicle at its own pose rate
            if world.step_count % decim[vid] == 0:
                send_pose(vid)
        if speed > 0 and not paused:
            pace_one_step()                   # the schedule above
    else:                                     # paused: stay responsive, stay "alive"
        if time.monotonic() >= next_keepalive:
            send all poses with the PAUSED flag
        time.sleep(0.001)
        next_wall = time.monotonic()          # do not "catch up" the pause afterwards
```

Two details:

- While paused, the loop sleeps 1 ms at a time and polls. A STEP command is handled within about a millisecond. Lock-step mode depends on this.
- `next_wall` is reset after a pause. Otherwise the schedule would think the whole pause was lost time and re-anchor, or fast-forward.

## Try it

- Run the naive and the scheduled loop above for 10 s each on your machine and write down the wall times.
- Run `spin_bodies.py --speed 0 --duration 60` under `time` and compute the real-time factor of your machine for this scene. What limits it?
- Put `time.sleep(0.5)` inside `handle()` for the RESET command and press R in the viewer. Read the `pacing re-anchors` count at the end. What did the viewer show during that half second?
- Run with `--physics-hz 120 --pose-hz 60` and then `--physics-hz 480 --pose-hz 60`. Does the sphere bounce the same? Why should it not be exactly the same? (Hint: [05](05_lockstep_determinism.md) and the contact solver.)

## References

- Glenn Fiedler, "Fix Your Timestep!": <https://gafferongames.com/post/fix_your_timestep/>
- Godot: Idle and physics processing: <https://docs.godotengine.org/en/stable/tutorials/scripting/idle_and_physics_processing.html>
- Python `time.monotonic` and `time.sleep`: <https://docs.python.org/3/library/time.html>
- PyBullet `setTimeStep`, `stepSimulation` (PyBullet Quickstart Guide): <https://pybullet.org>
