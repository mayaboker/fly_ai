# 05 Lock-step and determinism

Most of the time, physics and rendering run free and the viewer interpolates. Two jobs need more: **datasets**, where every image must belong to exactly one known physics state, and **experiments**, where you must be able to run the same thing twice and get the same numbers. This page covers both.

## Free-running vs lock-step

| | Free-running (default) | Lock-step |
|---|---|---|
| Who waits | nobody | physics waits for every rendered frame |
| Frame ↔ pose pairing | approximate; interpolated or newest | exact: one frame per physics frame, same `t_sim` |
| Frames dropped when rendering is slow | yes, physics keeps going | never; physics slows down instead |
| Real-time factor | set by `--speed` | whatever the slower side manages |
| Use for | watching, interactive control, closed-loop tests at real time | datasets, ground-truth images, offline evaluation |

Lock-step **deliberately** breaks Module 4's "neither process waits" rule. That is fine for dataset generation, where nobody is watching in real time. It is wrong for anything interactive.

## Lock-step with STEP

The protocol needs no new message. Lock-step is "pause, then STEP once per rendered frame":

```
viewer                                         physics (paused)
──────                                         ────────────────
L pressed: send STEP  ─────────────────────▶   advance 4 steps (one frame), send POSE(t)
frame N: pose t arrives, draw it
after frame N is drawn: send STEP ─────────▶   advance 4 steps, send POSE(t + 1/60)
frame N+1 (or N+2): pose t + 1/60 arrives, draw it
after it is drawn: send STEP ──────────────▶   ...
```

In the viewer:

```gdscript
if lockstep and paused and bridge.latest_t_sim > _ls_last_t and bridge.pending_commands() == 0:
	# This frame shows a new pose. Ask for the next one only after it has been drawn.
	_ls_last_t = bridge.latest_t_sim
	if DisplayServer.get_name() == "headless":     # nothing is drawn, frame_post_draw never fires
		_request_step.call_deferred()
	else:
		RenderingServer.frame_post_draw.connect(_request_step, CONNECT_ONE_SHOT)
```

Three conditions guard the STEP:

- **A new pose is on screen** (`latest_t_sim > _ls_last_t`). The viewer never asks twice for the same frame. After a reset, `_ls_last_t` goes back to `−INF`.
- **The previous STEP was acknowledged** (`pending_commands() == 0`). Physics ACKs before it steps, so the ACK usually arrives before the pose.
- **The frame has been drawn.** `RenderingServer.frame_post_draw` fires after the GPU work for the frame was submitted. That is where Module 7 will read the camera image back. In headless mode nothing is drawn and the signal never fires. We checked: zero emissions in 30 headless frames. So headless mode steps at the end of the frame instead.

STEP is a relative command, so exactly-once delivery is essential: a duplicated STEP would skip a frame of the dataset, and a lost one would stall the run until the 100 ms resend. Module 4's ACK and de-duplication make both impossible.

### Measured

From `check_m05.gd`, which records the `t_sim` of every lock-step frame that showed a new pose:

| Viewer frame rate | Lock-step frames | Spacing ≠ 1/60 s | Steps per wall second | Real-time factor |
|---|---|---|---|---|
| capped at 60 fps | 238 in 4 s | 0 | 59.5 | 0.99× |
| uncapped, headless | 866 in 6 s | 0 | 144 | 2.40× |

Every frame showed a pose exactly one physics frame after the previous one: no gaps and no repeats. Capped at 60 fps, lock-step is limited by the display. Uncapped, it is limited by the round trip: draw, STEP, Python wakes from its 1 ms sleep, steps, sends, Godot reads it on its next frame. With a real camera readback (Module 7) expect it to be slower. Measure it.

For a 30 Hz camera dataset, run physics with `--pose-hz 30`: one STEP is then 8 physics steps, one camera period.

## Determinism

A simulation is **deterministic** when the same inputs always produce bit-identical outputs. That is stronger than "looks the same". It is what lets you:

- re-run a failed test and get the same failure,
- change one parameter and know that every difference in the result comes from that parameter,
- check that a refactoring did not change behavior, by comparing logs.

### What it takes

| Requirement | In `spin_bodies.py` |
|---|---|
| A fixed step | `dt = 1/physics_hz`, never derived from wall time |
| Time as an integer count | `t_sim = step_count × dt` |
| Every random number from a seed | `np.random.default_rng(seed)` in `build()`; the seed goes into `run.json` |
| Transport randomness kept separate | the loss injector uses `default_rng(seed + 1000)`, so loss never changes physics |
| No wall-clock input to physics | pacing only decides **when** a step runs, never **what** it computes |
| Single-threaded, same build | PyBullet in DIRECT mode, same version and machine |

### Measured

Compared with `tools/compare_logs.py`, which checks every cell of every CSV as text, ignoring only `t_wall*` columns:

| Run A (20 s, `--speed 0`, seed 1) vs ... | Result |
|---|---|
| the same command again | `pose.csv: 2402 rows identical` |
| seed 2 | first difference at row 2: the sphere's start height, 2.4486 vs 1.5919 |
| real time with the viewer attached | identical (`run.json` differs only in `speed`) |
| real time, viewer, 20 % pose loss | identical (`run.json` differs in `speed` and `loss`) |
| real time, viewer, PAUSE, 3 STEPs, RESUME, 4 s of lock-step | identical |
| the part after a RESET | identical to a fresh start, 2402 rows |

`md5sum` of the two identical runs' `pose.csv` files still differs, because `t_wall` differs. Never compare raw files.

### What breaks it

| Cause | Example | Fix |
|---|---|---|
| Unseeded randomness | `np.random.rand()` without a generator, `random.random()` | one seeded generator per purpose, created in `build()` |
| Wall time inside physics | a controller that uses `time.monotonic()` for its derivative | use `t_sim` and `dt` |
| Commands applied "when they arrive" | a DIFF_DRIVE setpoint lands at step 1203 in one run and 1204 in the next | log the step it was applied at (`command.csv` has `step`), and re-simulate by applying commands at those steps |
| Iteration order | looping over a Python `set` of bodies | use lists or sorted keys |
| Threads | a physics engine running multi-threaded | single thread for reference runs |
| Different machine, library or compiler | another PyBullet build, another CPU's floating-point path | record versions in `run.json`; expect bit-identity only on the same setup |

PAUSE, STEP and RESUME did not break determinism above, because they change **when** steps run, not **what** happens in them. A setpoint command would. That is the next level: a scenario whose interactive inputs are logged by step and can be replayed into physics. It is the lab's stretch goal 3.

## Try it

- Run the repeatability test, then add `np.random.rand()` (unseeded) to the sphere's kick velocity. Run it twice and read `compare_logs.py`'s first difference.
- Run lock-step with `--pose-hz 30` and confirm the spacing is 1/30 s.
- Time lock-step with the windowed viewer (not headless) on your machine. Is it faster or slower than 60 steps/s? Why?
- Find out what PyBullet's `setPhysicsEngineParameter(deterministicOverlappingPairs=1)` does, and decide whether `spin_bodies.py` needs it. Test your answer with `compare_logs.py`.

## References

- Godot `RenderingServer.frame_post_draw`: <https://docs.godotengine.org/en/stable/classes/class_renderingserver.html>
- NumPy random `Generator` and seeding: <https://numpy.org/doc/stable/reference/random/generator.html>
- Bruce Dawson, "Floating-Point Determinism": <https://randomascii.wordpress.com/2013/07/16/floating-point-determinism/>
- CARLA, "Synchrony and time-step" (the same idea in a larger simulator): <https://carla.readthedocs.io/en/latest/adv_synchrony_timestep/>
