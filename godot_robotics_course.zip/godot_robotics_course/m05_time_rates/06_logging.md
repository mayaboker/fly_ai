# 06 The log format

From this module on, every run writes a log, and every later module uses the same format. This page explains why the course chose plain CSV plus a JSON sidecar, shows what `spin_bodies.py` and the viewer write, and how to join streams and compare runs. The short reference is [logging.md](../reference/logging.md).

## Choosing a format

| Format | Strengths | Weaknesses for this course |
|---|---|---|
| **CSV per stream + `run.json`** | readable by eye, Excel, numpy, pandas, any language; one file per stream; easy to diff | larger than binary; no built-in schema; floats as text |
| MCAP | the modern robotics container; ROS 2 default; Foxglove reads it; indexed, typed | needs a library on both sides; not human-readable |
| ROS bag (1/2) | ecosystem tools | ties the log to ROS |
| HDF5 | big numeric arrays, chunked, compressed | one big binary file; awkward for many small streams; concurrent writing is hard |
| Parquet | columnar, compact, fast in pandas | binary; append-while-running is awkward |

The course uses CSV because at these data rates (a few hundred rows per second) size and speed do not matter, while being able to open a file and *look* at it matters a lot when you are debugging time. Images are stored as files next to the CSVs (Module 7). If you later move to ROS 2, the structure maps directly onto MCAP: one CSV becomes one topic, and `run.json` becomes the metadata record.

## The rules (from the reference page)

1. **Every row has `t_sim` and `t_wall`.** Join streams on `t_sim`. Use `t_wall` only to measure the computer.
2. **Truth and measurement are separate columns** (`alt_true`, `alt_meas`). Never overwrite truth with noise.
3. **Seed everything** that is random, and write the seed to `run.json`.
4. **Units in column names** when not SI base units (`roll_deg`, `speed_kts`).
5. **One run = one folder.** Never append to an old run. Runs started in the same second get `_2`, `_3` … suffixes.

## `RunLogger`

```python
from robosim.logger import RunLogger

log = RunLogger(a.log_root, run_name="spin_bodies", seed=a.seed, meta={
    "scenario": "spin_bodies", "physics": "pybullet", "physics_hz": a.physics_hz,
    "pose_hz": {str(k): v for k, v in rates.items()}, "speed": a.speed,
    "loss": a.loss, "vehicles": {"10": "cube", "11": "sphere"}})

log.write("pose", world.t_sim, step=world.step_count, vehicle_id=vid,
          x=pos[0], y=pos[1], z=pos[2], qx=quat[0], qy=quat[1], qz=quat[2], qw=quat[3],
          vx=vel[0], vy=vel[1], vz=vel[2], t_wall_unix=round(time.time(), 6))
log.write("command", world.t_sim, step=world.step_count, seq=msg["seq"], cmd=name)
log.close()
```

`write(stream, t_sim, **values)` creates `<stream>.csv` on first use, with the keys of that first call as the header, and adds `t_sim` and `t_wall` (seconds since the logger started) as the first two columns. So the first call fixes the columns: always pass the same keys.

What the scenario writes:

```
logs/20261001T064317Z_spin_bodies/
├── run.json
├── pose.csv        one row per pose physics produced (not the paused keep-alives)
└── command.csv     one row per applied command, with the physics step it was applied at
```

```
pose.csv
t_sim,t_wall,step,vehicle_id,x,y,z,qx,qy,qz,qw,vx,vy,vz,t_wall_unix
0.0,0.008748,0,10,0.0,1.5,0.0,0.0,-0.7071067811865475,0.0,0.7071067811865476,0.0,0.0,0.0,1790836997.292331
0.0,0.008893,0,11,1.5,2.4486494471372438,0.0,0.0,-0.7071067811865475,0.0,0.7071067811865476,0.0,0.0,0.0,1790836997.292481
```

`run.json` (shortened) records everything needed to reproduce the run:

```json
{ "run": "spin_bodies", "started_utc": "20261001T064317Z", "seed": 1,
  "frames": "world=ENU (x E, y N, z U); wire=Godot (x E, y U, z S); body=FLU",
  "python": "3.11.15", "jsbsim": "1.3.1", "pybullet": "installed", "numpy": "2.4.4",
  "physics_hz": 240, "pose_hz": {"10": 60, "11": 60}, "speed": 1.0, "loss": 0.2 }
```

Design choices worth noticing:

- **Positions are in the Godot frame**, exactly what went over the wire. The `frames` key says so. A plot in ENU is one call to `frames.py` away.
- **Only produced poses are logged**, not the keep-alives sent while paused. A paused-and-stepped run then logs exactly the same rows as an unpaused one, which is what made the repeatability test in [05](05_lockstep_determinism.md) pass.
- **`step` is logged** next to `t_sim`. It is the exact integer behind `t_sim` and the key you need to re-apply commands at the same step.
- **`t_wall_unix`** is the send time on the system clock. It exists only for latency measurement. Its name starts with `t_wall` so `compare_logs.py` ignores it.

`RunLogger` names the folder by the UTC second the run started. Two runs started within the same second would get the same name, so the second one gets a `_2` suffix (`20261001T064317Z_spin_bodies_2`), the third `_3`, and so on. Nothing is ever overwritten. Scripts that start runs back to back can still give each run its own `log_root` (as `check_m05.sh` does), which makes the folders easier to find.

## The viewer logs too

The viewer is a separate process with its own clock, so it writes its own run folder, following the same rules. Start it with `--log`:

```
logs/20261001T064318Z_viewer/
├── run.json     godot version, interp_delay_s, max_extrapolate_s, max_fps
├── viewer.csv   one row per rendered frame
└── rx.csv       one row per received pose
```

| `viewer.csv` column | Meaning |
|---|---|
| `t_sim` | the sim time shown when interpolating (the render clock) |
| `t_wall`, `t_wall_unix` | frame time: since viewer start, and on the system clock |
| `latest_t_sim` | newest pose received |
| `since_rx_s` | wall seconds since the viewer last read a pose |
| `interp`, `extrap`, `paused` | display mode, whether any body was extrapolated, PAUSED flag |
| `sphere_y_raw`, `sphere_y_interp` | sphere height, newest pose vs interpolated |
| `cube_q*_raw`, `cube_q*_interp` | cube orientation, newest pose vs interpolated |

Both raw and interpolated values are logged every frame, whatever the display mode, so one run gives you the comparison.

GDScript has no `RunLogger`, so the viewer writes the files with `FileAccess` and `store_line`, and the same column rules. It writes the run folder under `res://../logs`, which is `robosim/logs` when you run from the editor. Pass `--log-root=DIR` to change it. Unlike `RunLogger`, the viewer adds no `_2` suffix, so do not start two logging viewers within the same second.

## Joining streams

Join on `t_sim`, never on wall time and never on row number. Because `t_sim = step × dt` and both sides write it with 6 decimals, an exact join on the text value works:

```python
ph = load("logs/..._spin_bodies/pose.csv")            # physics: send time per pose
rx = load("logs/..._viewer/rx.csv")                   # viewer: read time per pose
cube = ph["vehicle_id"] == 10
sent = dict(zip(np.round(ph["t_sim"][cube], 6), ph["t_wall_unix"][cube]))
latency = [u - sent[t] for t, u in zip(np.round(rx["t_sim"], 6), rx["t_wall_unix"]) if t in sent]
```

This is how `plot_pose_age.py` computes latency. It is the same join you will do in Module 7 between camera frames and poses, and in Module 8 between sensor readings and truth.

## Comparing runs

`tools/compare_logs.py run_a run_b` compares every CSV in two run folders cell by cell, as text, ignoring columns whose name starts with `t_wall`. It also compares `run.json`, ignoring `started_utc`. It prints the first difference with row and column, and exits with 0 for identical, 1 for different. Text comparison is intentional: a difference in the 17th digit is a difference.

```
$ python tools/compare_logs.py logs/A logs/B
pose.csv: 2402 rows identical (ignoring t_wall*)
IDENTICAL
```

## Try it

- Open a `pose.csv` in a spreadsheet and plot the sphere's `y` against `t_sim`. Find a bounce, and read the physics step it happened at.
- Add an `energy` stream to `spin_bodies.py` (kinetic + potential energy of the sphere, once per pose). Plot it. Where does PyBullet lose energy?
- Write `tools/split_resets.py`: it reads a `pose.csv` with RESETs in it and writes one folder per episode.
- Join `rx.csv` and `viewer.csv` to find, for every frame, how many poses arrived since the previous frame. Compare with the "frames with no new pose" number of the plot tool.

## References

- [Log format reference](../reference/logging.md), [`logger.py`](../reference/code/python/robosim/logger.py)
- Godot `FileAccess`: <https://docs.godotengine.org/en/stable/classes/class_fileaccess.html>
- MCAP: <https://mcap.dev/>
- Python `csv` module: <https://docs.python.org/3/library/csv.html>
