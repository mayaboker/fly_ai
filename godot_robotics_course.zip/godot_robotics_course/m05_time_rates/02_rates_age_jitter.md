# 02 Rates, latency, pose age and jitter

A simulator has many rates, and they rarely match. This page lists them, makes them per-vehicle parameters, and defines four numbers that tell you how old and how regular the data on screen is. Then it shows what those numbers were in our runs, including one surprise.

## The rates in this course

| Rate | Default | Owner | Why that value |
|---|---|---|---|
| PyBullet physics step | 240 Hz | physics, per vehicle | PyBullet's default; contacts stay stable |
| JSBSim physics step | 120 Hz | physics, per vehicle | JSBSim's default `dt`; flight dynamics are smooth |
| Pose stream | 60 Hz | physics, per vehicle | matches a 60 Hz display; 60 B × 60 Hz is nothing |
| Camera capture | 30 Hz | Godot (Modules 6–7) | typical robot camera; readback is expensive |
| Stick input | 50 Hz | viewer | typical RC rate |
| Render frame | whatever the GPU gives, often 60 fps | Godot | not under your control |

None of these needs to equal another. A 120 Hz JSBSim aircraft sends every 2nd step at 60 Hz. A 240 Hz PyBullet rover sends every 4th step. The camera takes every 2nd pose. Rendering takes whatever is newest.

## Rates are per-vehicle parameters

A rover and a plane in the same scenario can run different physics engines at different rates. Even inside one PyBullet world, you may want the slow rover's poses at 30 Hz and the fast drone's at 60 Hz. So the course treats the pose rate as a property of the vehicle, not of the program:

```python
# spin_bodies.py (Module 5)
rates = {CUBE: a.pose_hz, SPHERE: a.sphere_hz or a.pose_hz}
for vid, hz in rates.items():
    if a.physics_hz % hz:
        sys.exit(f"vehicle {vid}: pose rate {hz} Hz does not divide physics rate {a.physics_hz} Hz")
decim = {vid: a.physics_hz // hz for vid, hz in rates.items()}
...
for vid in bodies:
    if world.step_count % decim[vid] == 0:      # 240/60 = every 4th step, 240/30 = every 8th
        send_pose(vid)
```

Integer ratios keep every pose exactly on a physics step, so `t_sim` values are exact multiples of `dt` and compare with `==`. A 50 Hz pose rate on 240 Hz physics would need either uneven gaps (4.8 steps) or interpolation on the physics side. Avoid it: choose rates that divide.

The rates go into `run.json` (`"pose_hz": {"10": 60, "11": 30}`), so every log says how it was made. The viewer does not need to be told: it reads `t_sim` on each pose. It does need to know the *slowest* rate it must interpolate, to choose its delay ([03](03_interpolation.md)).

## Four numbers about time

| Number | Definition | Measured where |
|---|---|---|
| **Latency** | time the viewer *read* a pose − time physics *sent* it | per pose |
| **Pose age** | time a frame was rendered − time the newest pose on screen was sent | per frame |
| **Shown delay** | pose age + (newest `t_sim` − displayed `t_sim`), the age of what is actually drawn when interpolating | per frame |
| **Inter-arrival jitter** | spread of the gaps between consecutive poses of one vehicle, as the viewer reads them | per pose |

Latency and pose age need one clock on both sides. Python and Godot on the same machine share the operating system's clock. Python logs `time.time()` as `t_wall_unix` when it sends a pose, and Godot logs `Time.get_unix_time_from_system()` when it reads one and when it draws a frame. Both have microsecond resolution on Linux. On two machines you would need clock synchronization (NTP or PTP) first.

"Read" is the important word. The viewer drains the socket once per frame, so a packet that arrives just after a drain waits almost a whole frame in the kernel. That wait is part of the latency the viewer experiences, and the viewer cannot see it on its own. That is why the plot tool joins the viewer's log with the physics log.

## Measured: five runs on one machine

All five runs: physics 240 Hz, cube poses 60 Hz, viewer headless at 60 fps, 20 s, same machine, same code. Run A sent the sphere at 30 Hz, and D and E dropped 20 % of the poses on purpose. The table shows the cube.

| Run | Pose loss | Latency median | Latency p99 | Inter-arrival median / std |
|---|---|---|---|---|
| A | 0 | 1.0 ms | 2.0 ms | 16.7 / 1.86 ms |
| B | 0 | 4.8 ms | 8.7 ms | 16.7 / 3.25 ms |
| C | 0 | 9.0 ms | 11.0 ms | 16.7 / 0.66 ms |
| D | 20 % | 12.4 ms | 15.7 ms | 16.7 / 10.3 ms |
| E | 20 % | 15.0 ms | 16.6 ms | 16.7 / 9.98 ms |

The median latency varies from 1 ms to 15 ms between runs, and the network has nothing to do with it. Localhost delivery takes microseconds. The difference is the **phase** between two 60 Hz loops:

```
physics sends:   |P         |P         |P         |P            every 16.7 ms
viewer reads:    ....|R         |R         |R         |R        every 16.7 ms, offset by φ
                     ◀─ φ ─▶
latency ≈ φ, the same for every pose, set by when each process happened to start
```

Both loops run at exactly 60 Hz, so the offset stays almost constant for the whole run, anywhere between 0 and one period. The lesson: **a single latency number from one run says little.** Report a distribution over several runs, or measure the worst case (one full frame period plus transport).

With a faster viewer, the wait shrinks. At 144 fps, the median latency was 3.3 ms (p99 6.9 ms), because the socket is drained every 6.9 ms.

## Jitter you cause yourself

At 144 fps, the inter-arrival times of 60 Hz poses were not 16.7 ms. They fell into two spikes, at 13.9 ms and 20.8 ms: two or three frames of 6.94 ms. The poses were sent perfectly regularly. The viewer only looks every 6.94 ms, so the gaps it sees are multiples of that. At 60 fps the same effect shows up whenever a frame runs late: two poses are read in one frame (a gap of 0 ms), followed by a 33 ms gap.

This is why the viewer must **never use arrival time to place a pose in time**. It uses `t_sim`, which is exact. Arrival time is only for measuring.

Loss adds jitter of its own: with 20 % pose loss, inter-arrival p95 was 33.7 ms (one pose missing) and the worst gap 83 ms (four in a row).

## Pose age on screen

For the raw display, pose age is latency plus the time until the frame is drawn. For the interpolated display, add the interpolation delay, 25 ms by default ([03](03_interpolation.md)). From run E:

| Display | Age median | p99 | max |
|---|---|---|---|
| raw (newest pose) | 15.1 ms | 31.8 ms | 32.7 ms |
| interpolated | 40.5 ms | 43.2 ms | 47.5 ms |

Interpolation costs 25 ms of age and buys smooth motion. Whether that trade is right depends on the use: for a human watching, nobody notices 25 ms. For a camera image fed to a fast controller, 25 ms of extra delay can matter, and then the camera should render the raw pose at a known `t_sim` instead ([Module 7](../m07_frame_transport/README.md)).

## Try it

- Run the lab's logged run three times and compare the median latency. Explain the spread with the phase diagram.
- Run `spin_bodies.py --sphere-hz 30` and look at the sphere in raw mode. Then look at the cube. Which one looks smoother, and why?
- Try `--physics-hz 240 --sphere-hz 50`. Read the error message, then pick a rate that works.
- Start the viewer with Godot's `--max-fps 144` option (before the `--`; or set `Engine.max_fps` in a script) and repeat the inter-arrival histogram. Find the two spikes and compute their spacing.

## References

- Godot `Time.get_unix_time_from_system`, `Time.get_ticks_usec`: <https://docs.godotengine.org/en/stable/classes/class_time.html>
- Python `time.time` vs `time.monotonic`: <https://docs.python.org/3/library/time.html>
- [Log format](../reference/logging.md): why `t_wall` is only for latency
