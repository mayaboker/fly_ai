# Module 5: Time, rates, interpolation and resets (7 h)

## What you will build

You will make the Module 4 viewer smooth and honest about time. A render clock runs about one pose period behind the newest pose and interpolates between poses, with a raw / interpolated toggle so you can see and measure the difference. The physics process gains single-step, faster-than-real-time and lock-step modes. Both processes log in the course format, a plot shows how old the picture on screen really is, and two runs with the same seed produce identical logs.

## Prerequisites

- [Module 4](../m04_bridge/README.md) done: `spin_bodies.py` and `spin_viewer.tscn` in your project, with the reference bridge (its session and HELLO rules, Module 4 sub-topic 05).
- [Module 3](../m03_frames/05_quaternions.md): slerp, and q vs −q.
- Python: numpy, matplotlib, csv.
- Read the [log format](../reference/logging.md) page once. This module introduces it.

## Sub-topics

| File | Topic | Time |
|---|---|---:|
| [01_fixed_step_and_clocks.md](01_fixed_step_and_clocks.md) | Fixed physics step vs render frame. Sim time vs wall time. Real-time pacing and faster than real time | 1 h |
| [02_rates_age_jitter.md](02_rates_age_jitter.md) | 240 / 120 / 60 / 30 Hz. Rates as per-vehicle parameters. Latency, pose age and jitter, measured | 1 h |
| [03_interpolation.md](03_interpolation.md) | Render behind, lerp + slerp, `SimBridge.sample`, the render clock, bounded extrapolation | 1 h 15 |
| [04_pause_step_reset_replay.md](04_pause_step_reset_replay.md) | Pause and single-step at frame boundaries, reset, replaying a log into the viewer | 45 min |
| [05_lockstep_determinism.md](05_lockstep_determinism.md) | Lock-step for datasets. Determinism with a fixed seed, and what breaks it | 1 h |
| [06_logging.md](06_logging.md) | Choosing the log format. `RunLogger`, `run.json`, joining streams on `t_sim`, comparing runs | 45 min |
| [lab.md](lab.md) | Interpolation toggle, STEP, lock-step, logging, `plot_pose_age.py`, repeatability test | 1 h 15 |

## Deliverables

1. `godot/bridge/render_clock.gd` (`RenderClock`) and the extended `spin_viewer.gd`: raw / interpolated toggle (I), STEP (S), lock-step (L), and a per-frame log with `--log`.
2. `physics/sims/spin_bodies.py` with STEP, `--speed`, per-vehicle pose rates, `--paused`, and `--log` through `RunLogger`.
3. `tools/plot_pose_age.py`: latency, pose age, inter-arrival jitter, and raw vs interpolated motion, as numbers and as one PNG.
4. `tools/compare_logs.py` and a repeatability result: two runs with seed 1 identical, seed 2 different.
5. `tools/replay_poses.py`: a log played back into the viewer.

## Check

The module is done when all of the following are true. `tools/check_m05.sh` runs items 1, 3 and 4 (see the [lab](lab.md#8-run-the-whole-check)).

1. **Pose age graph.** `plot_pose_age.py` produces `pose_age.png` for a 20 s run and prints latency, pose age and inter-arrival percentiles. Your numbers are written down in your notes. Ours, at 60 fps with 20 % pose loss: pose age median 2.3 ms (p99 19.0 ms); the interpolated display is 25 ms older (median 28.0 ms).
2. **Raw vs interpolated.** In the same run, the interpolated cube's rotation step per frame varies much less than the raw one. Ours: std 0.64° (interpolated) vs 2.21° (raw), for a mean of 3.00° per frame. At 144 fps without loss: 0.05° vs 1.48°.
3. **Single step and lock-step.** Three STEP commands advance the cube's `t_sim` by exactly 1/60 s each. In lock-step mode, every rendered frame shows a new pose, and consecutive poses are exactly 1/60 s of sim time apart (0 exceptions over at least 200 frames).
4. **Repeatability.** `compare_logs.py` reports `pose.csv: 2402 rows identical (ignoring t_wall*)` for two 20 s runs with seed 1, and a difference at row 2 for seed 2. A real-time run with the viewer attached, 20 % pose loss, pauses, steps and lock-step also gives a `pose.csv` identical to a fast run with the same seed.

## Common mistakes

- **Rendering the newest pose and calling it smooth.** At exactly 60 fps and 60 Hz it can look fine, until a packet is lost, the frame rate changes, or the two loops drift in phase. Measure the step per frame and do not trust your eyes.
- **Interpolating to "now".** You cannot interpolate toward a pose that has not arrived. The render time must sit behind the newest pose, by roughly one pose period plus jitter.
- **Driving the render clock from `t_sim` packets directly.** Packets arrive in bursts, so the clock jumps. Advance it by the frame's `delta` and correct it slowly.
- **Pausing physics in the middle of a frame period.** The paused pose then sits at an odd time, and the next STEP is shorter than the others. Pause at frame boundaries.
- **Calling a run deterministic because the plots look the same.** Compare the files cell by cell, minus wall-clock columns. One different random call shows up as a different 17th digit.
- **Comparing log files with `md5sum`.** `t_wall` makes every file different. Use `compare_logs.py`, which ignores `t_wall*` columns.
