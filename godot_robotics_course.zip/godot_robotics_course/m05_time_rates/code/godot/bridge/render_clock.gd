class_name RenderClock
extends RefCounted
## The sim time the viewer DISPLAYS (Module 5).
##  - advances smoothly with the render frames, at the sim's measured speed
##  - stays delay_s behind the newest pose, so SimBridge.sample() can interpolate
##  - freezes on the exact paused pose, jumps after a reset or a big drift
## Usage, every frame:  t = clock.advance(delta, bridge.latest_t_sim, paused)
## and for every pose:   clock.observe(msg.t_sim, wall_seconds)

var delay_s := 0.025      ## render this far behind the newest pose (sim s); ~1.5 pose periods at 60 Hz
var snap_s := 0.25        ## further than this from the target: jump instead of slewing
var tau_s := 0.3          ## time constant of the drift correction (wall s); ~5 % per frame at 60 fps
var max_ahead_s := 0.05   ## never run further than this past the newest pose (= SimBridge.max_extrapolate_s)
var t := -1.0             ## displayed sim time; < 0 = not started
var rate := 1.0           ## measured sim seconds per wall second (1 = real time)

var _win_wall := -1.0
var _win_sim := 0.0
var _was_paused := false
var _rate_known := false


func reset() -> void:
	t = -1.0
	_win_wall = -1.0


## Feed every received pose. Measures how fast sim time runs against the wall clock,
## so the clock also works when physics runs at 4x or 0.5x real time.
func observe(t_sim: float, wall: float) -> void:
	if _win_wall < 0.0 or t_sim < _win_sim:
		_win_wall = wall
		_win_sim = t_sim
		return
	var dw := wall - _win_wall
	if dw >= 0.5:
		var r := (t_sim - _win_sim) / dw
		if r > 0.01:                       # ignore windows where physics was paused
			rate = r if not _rate_known else lerpf(rate, r, 0.5)
			_rate_known = true
		_win_wall = wall
		_win_sim = t_sim


func advance(delta: float, latest_t_sim: float, paused: bool) -> float:
	var target := latest_t_sim - delay_s
	if paused:                             # show exactly the paused (or single-stepped) pose
		t = latest_t_sim
		_was_paused = true
		return t
	if t < 0.0 or _was_paused or absf(target - t) > snap_s:
		t = target                         # start, resume, reset or lost track: jump
		_was_paused = false
		return t
	t += delta * rate                      # move smoothly with the render frames ...
	t += (target - t) * (1.0 - exp(-delta / tau_s))   # ... and slowly pull toward the target
	t = minf(t, latest_t_sim + max_ahead_s)   # stream stalled: do not run away from the data
	return t
