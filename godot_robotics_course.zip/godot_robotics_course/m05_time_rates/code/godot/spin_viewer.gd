extends Node3D
## Viewer for physics/sims/spin_bodies.py (Module 4, extended in Module 5).
##  Module 4: newest raw pose, stale indicator, reliable PAUSE/RESUME/RESET, RANGE sensor.
##  Module 5: render clock + interpolation (toggle raw/interpolated), single STEP,
##            lock-step mode, and a per-frame log for tools/plot_pose_age.py.
## Keys: P pause/resume, S step, R reset, I raw/interpolated, L lock-step.
## Command-line options (after "--"): --listen-port=N --physics-port=N --log --log-root=DIR

const CUBE := 10
const SPHERE := 11
const SPHERE_R := 0.25

@onready var bridge: SimBridge = $SimBridge
@onready var bodies := {CUBE: $Cube as Node3D, SPHERE: $Sphere as Node3D}
@onready var info: Label = $UI/Info

var interpolate := true        ## false = show the newest raw pose (Module 4 behaviour)
var lockstep := false          ## physics waits for every rendered frame
var paused := false            ## from the PAUSED flag of the newest pose
var commands_sent := 0
var resets_seen := 0
var clock := RenderClock.new()
var newest_t := {}             ## vehicle_id -> t_sim of its newest pose
var last_rx_wall := -1.0
var shown_t := 0.0             ## sim time on screen this frame
var extrapolating := false
var _sphere_pose := {}
var _ls_last_t := -INF         ## lock-step: t_sim of the last frame we asked to step past
var _log_frames: FileAccess
var _log_rx: FileAccess
var _t0 := 0.0


func _enter_tree() -> void:
	# Runs BEFORE the children's _ready, so SimBridge binds the ports we set here.
	var want_log := false
	var log_root := ProjectSettings.globalize_path("res://").path_join("../logs")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--listen-port="):
			$SimBridge.listen_port = int(arg.get_slice("=", 1))
		elif arg.begins_with("--physics-port="):
			$SimBridge.physics_port = int(arg.get_slice("=", 1))
		elif arg == "--log":
			want_log = true
		elif arg.begins_with("--log-root="):
			log_root = arg.get_slice("=", 1)
	_t0 = _wall()
	if want_log:
		_open_log(log_root)


func _ready() -> void:
	bridge.pose_received.connect(_on_pose)
	bridge.physics_reset.connect(_on_reset)
	$UI/Buttons/Pause.pressed.connect(toggle_pause)
	$UI/Buttons/Step.pressed.connect(step)
	$UI/Buttons/Reset.pressed.connect(reset)
	$UI/Buttons/Interp.pressed.connect(func() -> void: interpolate = not interpolate)
	$UI/Buttons/Lockstep.pressed.connect(func() -> void: set_lockstep(not lockstep))


func _on_pose(vehicle_id: int, msg: Dictionary) -> void:
	var now := _wall()
	paused = (msg.flags & RsProtocol.POSE_FLAG_PAUSED) != 0
	newest_t[vehicle_id] = msg.t_sim
	last_rx_wall = now
	clock.observe(msg.t_sim, now)
	if vehicle_id == SPHERE:
		_sphere_pose = msg
	if _log_rx:
		_log_rx.store_line("%.6f,%.6f,%.6f,%d,%d,%d" % [msg.t_sim, now - _t0,
				Time.get_unix_time_from_system(), vehicle_id, msg.seq, msg.flags])


func _on_reset() -> void:
	resets_seen += 1
	newest_t.clear()
	clock.reset()
	_ls_last_t = -INF


func _process(delta: float) -> void:
	if bridge.latest_seq < 0:
		return
	var now := _wall()
	var t_render := clock.advance(delta, bridge.latest_t_sim, paused)
	var raw := {}
	var smooth := {}
	extrapolating = false
	for id: int in bodies:
		if not bridge.has_vehicle(id):
			continue
		raw[id] = bridge.latest_transform(id)
		smooth[id] = bridge.sample(id, t_render)
		if t_render > newest_t.get(id, INF):
			extrapolating = true
		bodies[id].transform = smooth[id] if interpolate else raw[id]
	shown_t = t_render if interpolate else bridge.latest_t_sim
	var age := now - last_rx_wall
	info.text = ("t_sim %.3f  shown %.3f  since last pose %4.1f ms  %s%s\n" % [bridge.latest_t_sim, shown_t,
			age * 1000.0, "INTERPOLATED" if interpolate else "RAW", "  LOCK-STEP" if lockstep else ""]
			+ "[P] pause  [S] step  [R] reset  [I] raw/interp  [L] lock-step   waiting for ACK: %d" %
			bridge.pending_commands())
	if _log_frames and raw.size() == 2:
		_log_frame(now, age, t_render, raw, smooth)
	if lockstep and paused and bridge.latest_t_sim > _ls_last_t and bridge.pending_commands() == 0:
		# This frame shows a new pose. Ask for the next one only after it has been drawn.
		_ls_last_t = bridge.latest_t_sim
		if DisplayServer.get_name() == "headless":     # nothing is drawn, frame_post_draw never fires
			_request_step.call_deferred()
		else:
			RenderingServer.frame_post_draw.connect(_request_step, CONNECT_ONE_SHOT)


func _request_step() -> void:
	if lockstep:
		step()


func _physics_process(_delta: float) -> void:
	# World-geometry sensor (Module 4): ray from the sphere down to the floor,
	# tagged with the t_sim of the raw pose it was computed from.
	if _sphere_pose.is_empty() or bridge.is_stale():
		return
	var origin: Vector3 = _sphere_pose.pos
	var q := PhysicsRayQueryParameters3D.create(origin, origin + Vector3.DOWN * 20.0)
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	var range_m := INF if hit.is_empty() else origin.distance_to(hit.position) - SPHERE_R
	bridge.send_sensor(_sphere_pose.t_sim, SPHERE, RsProtocol.SENSOR_RANGE, PackedFloat32Array([range_m]))
	_sphere_pose = {}


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_P:
				toggle_pause()
			KEY_S:
				step()
			KEY_R:
				reset()
			KEY_I:
				interpolate = not interpolate
			KEY_L:
				set_lockstep(not lockstep)


func toggle_pause() -> void:
	_send(RsProtocol.CMD_RESUME if paused else RsProtocol.CMD_PAUSE)


func step() -> void:
	_send(RsProtocol.CMD_STEP)


func reset() -> void:
	_send(RsProtocol.CMD_RESET)


func set_lockstep(on: bool) -> void:
	lockstep = on
	_ls_last_t = -INF
	_send(RsProtocol.CMD_STEP if on else RsProtocol.CMD_RESUME)   # STEP also pauses


func _send(cmd: int) -> void:
	# PAUSE/RESUME/STEP/RESET act on the whole world; spin_bodies ignores the vehicle id.
	bridge.send_command(CUBE, cmd)
	commands_sent += 1


func _open_log(root: String) -> void:
	var stamp := Time.get_datetime_string_from_system(true).replace("-", "").replace(":", "") + "Z"
	var dir := root.path_join(stamp + "_viewer")
	DirAccess.make_dir_recursive_absolute(dir)
	var meta := FileAccess.open(dir.path_join("run.json"), FileAccess.WRITE)
	meta.store_string(JSON.stringify({"run": "viewer", "started_utc": stamp,
			"godot": Engine.get_version_info().string, "interp_delay_s": clock.delay_s,
			"max_extrapolate_s": $SimBridge.max_extrapolate_s, "max_fps": Engine.max_fps}, "  "))
	meta.close()
	_log_frames = FileAccess.open(dir.path_join("viewer.csv"), FileAccess.WRITE)
	_log_frames.store_line("t_sim,t_wall,t_wall_unix,latest_t_sim,since_rx_s,interp,extrap,paused,"
			+ "sphere_y_raw,sphere_y_interp,cube_qx_raw,cube_qy_raw,cube_qz_raw,cube_qw_raw,"
			+ "cube_qx_interp,cube_qy_interp,cube_qz_interp,cube_qw_interp")
	_log_rx = FileAccess.open(dir.path_join("rx.csv"), FileAccess.WRITE)
	_log_rx.store_line("t_sim,t_wall,t_wall_unix,vehicle_id,seq,flags")
	print("viewer log: ", dir)


func _log_frame(now: float, age: float, t_render: float, raw: Dictionary, smooth: Dictionary) -> void:
	# t_sim = the sim time on screen in interpolated mode (logging rule: every row has t_sim, t_wall)
	var qr: Quaternion = raw[CUBE].basis.get_rotation_quaternion()
	var qi: Quaternion = smooth[CUBE].basis.get_rotation_quaternion()
	_log_frames.store_line("%.6f,%.6f,%.6f,%.6f,%.6f,%d,%d,%d,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f" % [
			t_render, now - _t0, Time.get_unix_time_from_system(), bridge.latest_t_sim, age, int(interpolate), int(extrapolating), int(paused),
			raw[SPHERE].origin.y, smooth[SPHERE].origin.y, qr.x, qr.y, qr.z, qr.w, qi.x, qi.y, qi.z, qi.w])


func _exit_tree() -> void:
	if _log_frames:
		_log_frames.close()
		_log_rx.close()


func _wall() -> float:
	return Time.get_ticks_usec() / 1e6
