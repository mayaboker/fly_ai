extends SceneTree
## Automated Module 5 check: single-step, raw vs interpolated, lock-step pairing.
## Start physics/sims/spin_bodies.py first, then:
##
##   godot --headless --path godot --script res://tests/check_m05.gd -- --log \
##         --plan=pause@4,step@4.5,step@5,step@5.5,resume@6,lock@8,unlock@12 --duration=14
##
## Plan words: pause resume step reset raw interp lock unlock.
## Other options: --listen-port=N --physics-port=N --max-fps=N (default 60, 0 = unlimited)
## --log is passed through to the viewer (writes logs/<stamp>_viewer/).

var viewer: Node
var bridge: SimBridge
var plan := []
var duration := 10.0
var t0 := 0.0
var frames := 0
var steps_sent := 0
var step_results := []         # cube t_sim seen after each single step
var _last_cube_t := -1.0
var lock_shown := []           # t_sim shown in each lock-step frame where it changed
var lock_t0 := -1.0
var lock_t1 := -1.0
var _prev_shown := -1.0


func _initialize() -> void:
	Engine.max_fps = 60
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--plan="):
			for item in arg.get_slice("=", 1).split(",", false):
				plan.append([float(item.get_slice("@", 1)), item.get_slice("@", 0)])
		elif arg.begins_with("--duration="):
			duration = float(arg.get_slice("=", 1))
		elif arg.begins_with("--max-fps="):
			Engine.max_fps = int(arg.get_slice("=", 1))
	viewer = load("res://spin_viewer.tscn").instantiate()
	root.add_child(viewer)
	bridge = viewer.get_node("SimBridge")
	bridge.pose_received.connect(func(id: int, msg: Dictionary) -> void:
		if id == 10:
			_last_cube_t = msg.t_sim)
	t0 = _now()


func _process(_delta: float) -> bool:
	frames += 1
	var t := _now() - t0
	while not plan.is_empty() and t >= plan[0][0]:
		var what: String = plan.pop_front()[1]
		match what:
			"pause":
				viewer.bridge.send_command(10, RsProtocol.CMD_PAUSE)
			"resume":
				if steps_sent > 0 and step_results.size() == steps_sent:
					step_results.append(_last_cube_t)
				viewer.bridge.send_command(10, RsProtocol.CMD_RESUME)
			"step":
				step_results.append(_last_cube_t)
				viewer.step()
				steps_sent += 1
			"reset":
				viewer.reset()
			"raw":
				viewer.interpolate = false
			"interp":
				viewer.interpolate = true
			"lock":
				viewer.set_lockstep(true)
				lock_t0 = t
			"unlock":
				viewer.set_lockstep(false)
				lock_t1 = t
		_log("%s (cube t_sim %.4f)" % [what, _last_cube_t])
	if viewer.lockstep and viewer.paused and bridge.latest_t_sim != _prev_shown:
		lock_shown.append(bridge.latest_t_sim)
	_prev_shown = bridge.latest_t_sim
	if t >= duration:
		_report()
		quit()
	return false


func _report() -> void:
	var d := []
	for i in range(1, step_results.size()):
		d.append(snappedf(step_results[i] - step_results[i - 1], 1e-6))
	_log("single steps: cube t_sim before/after each step %s, increments %s" % [str(step_results), str(d)])
	if lock_shown.size() > 2:
		var bad := 0
		for i in range(1, lock_shown.size()):
			if absf(lock_shown[i] - lock_shown[i - 1] - 1.0 / 60.0) > 1e-9:
				bad += 1
		var span := (lock_t1 if lock_t1 > 0 else _now() - t0) - lock_t0
		_log("lock-step: %d frames, t_sim %.4f .. %.4f, spacing != 1/60 s in %d cases, %.1f steps/s (wall), %.2fx real time" % [
				lock_shown.size(), lock_shown[0], lock_shown[-1], bad, lock_shown.size() / span,
				(lock_shown[-1] - lock_shown[0]) / span])
	_log("frames %d, commands sent %d, waiting for ACK %d" % [frames, viewer.commands_sent,
			bridge.pending_commands()])


func _log(s: String) -> void:
	print("[wall %6.2f] %s" % [_now() - t0, s])


func _now() -> float:
	return Time.get_ticks_usec() / 1e6
