#!/usr/bin/env python3
"""replay_poses.py - play a logged run back into the Godot viewer, without physics (Module 5).

    python tools/replay_poses.py logs/<stamp>_spin_bodies              # real time
    python tools/replay_poses.py logs/<stamp>_spin_bodies --speed 0.25 --loop

It stands in for the physics process: same ports, same POSE packets, and it obeys
PAUSE / RESUME / STEP / RESET (RESET = start again from the first frame). The viewer
cannot tell the difference, which is the point: you can debug the viewer, its
interpolation or a camera from a recording, as often as you like.
"""
import argparse
import csv
import os
import sys
import time
from itertools import groupby

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "physics"))
from robosim import protocol as P            # noqa: E402
from robosim.bridge import PhysicsBridge      # noqa: E402


def load_frames(run):
    with open(os.path.join(run, "pose.csv"), newline="") as f:
        rows = list(csv.DictReader(f))
    frames = []
    for t, group in groupby(rows, key=lambda r: float(r["t_sim"])):
        poses = [(int(r["vehicle_id"]), tuple(float(r[k]) for k in ("x", "y", "z")),
                  tuple(float(r[k]) for k in ("qx", "qy", "qz", "qw")),
                  tuple(float(r[k]) for k in ("vx", "vy", "vz"))) for r in group]
        if frames and t <= frames[-1][0]:          # a reset inside the log: keep only the first part
            break
        frames.append((t, poses))
    return frames


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("run", help="physics run folder with pose.csv")
    ap.add_argument("--speed", type=float, default=1.0)
    ap.add_argument("--loop", action="store_true")
    ap.add_argument("--viewer-port", type=int, default=P.PORT_TO_VIEWER)
    ap.add_argument("--listen-port", type=int, default=P.PORT_TO_PHYSICS)
    a = ap.parse_args()
    frames = load_frames(a.run)
    print(f"replaying {len(frames)} frames, t_sim {frames[0][0]:.3f} .. {frames[-1][0]:.3f} s, "
          f"speed {a.speed}x", flush=True)
    br = PhysicsBridge(viewer_port=a.viewer_port, listen_port=a.listen_port)

    i, paused, steps = 0, False, 0
    t_wall0 = time.monotonic() - frames[0][0] / a.speed

    def send(idx):
        t, poses = frames[idx]
        for vid, pos, quat, vel in poses:
            br.send_pose(t, vid, pos, quat, vel, paused=paused)

    send(0)                                        # first pose carries RESET
    last_send = time.monotonic()
    try:
        while True:
            for msg in br.poll(frames[i][0]):
                if msg["type"] != P.MSG_COMMAND:
                    continue
                if msg["cmd"] == P.CMD_PAUSE:
                    paused = True
                elif msg["cmd"] == P.CMD_RESUME:
                    paused = False
                    t_wall0 = time.monotonic() - frames[i][0] / a.speed
                elif msg["cmd"] == P.CMD_STEP:
                    paused, steps = True, steps + 1
                elif msg["cmd"] == P.CMD_RESET:
                    i, steps = 0, 0
                    t_wall0 = time.monotonic() - frames[0][0] / a.speed
                    br.mark_reset()
                    send(0)
            now = time.monotonic()
            if paused and steps and i + 1 < len(frames):
                i, steps = i + 1, steps - 1
                send(i)
                last_send = now
            elif not paused and i + 1 < len(frames) and now >= t_wall0 + frames[i + 1][0] / a.speed:
                i += 1
                send(i)
                last_send = now
            elif not paused and i + 1 == len(frames):
                if not a.loop:
                    break
                i = 0
                t_wall0 = now - frames[0][0] / a.speed
                br.mark_reset()
                send(0)
            elif paused and now - last_send > 1 / 60:  # keep-alive while paused
                send(i)
                last_send = now
            time.sleep(0.001)
    except KeyboardInterrupt:
        pass
    br.tx.sendto(P.pack_simple(P.MSG_BYE, br._next(), frames[i][0]), br.viewer)
    print(f"stopped at frame {i}, t_sim {frames[i][0]:.3f}", flush=True)


if __name__ == "__main__":
    main()
