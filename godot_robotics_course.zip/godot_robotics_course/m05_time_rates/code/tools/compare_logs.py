#!/usr/bin/env python3
"""compare_logs.py - are two runs identical? (Module 5 repeatability test)

    python tools/compare_logs.py logs/<run_a> logs/<run_b>

Compares every CSV stream in the two run folders cell by cell, as text, so a
difference in the 17th digit counts. Ignored on purpose:
  - columns whose name starts with t_wall (wall-clock time is never repeatable)
  - run.json keys that describe *when* the run happened (started_utc)
Exit code 0 = identical, 1 = different.
"""
import csv
import json
import os
import sys

IGNORE_PREFIX = "t_wall"
IGNORE_META = {"started_utc"}


def read_csv(path):
    with open(path, newline="") as f:
        rows = list(csv.reader(f))
    header = rows[0]
    keep = [i for i, h in enumerate(header) if not h.startswith(IGNORE_PREFIX)]
    return [header[i] for i in keep], [[r[i] for i in keep] for r in rows[1:]]


def compare(a, b):
    same = True
    ja, jb = (json.load(open(os.path.join(d, "run.json"))) for d in (a, b))
    for k in sorted(set(ja) | set(jb)):
        if k not in IGNORE_META and ja.get(k) != jb.get(k):
            print(f"run.json  {k}: {ja.get(k)!r} != {jb.get(k)!r}")
            same = False
    streams = sorted({f for d in (a, b) for f in os.listdir(d) if f.endswith(".csv")})
    for s in streams:
        pa, pb = os.path.join(a, s), os.path.join(b, s)
        if not (os.path.exists(pa) and os.path.exists(pb)):
            print(f"{s}: only in one run")
            same = False
            continue
        ha, ra = read_csv(pa)
        hb, rb = read_csv(pb)
        if ha != hb:
            print(f"{s}: different columns {ha} vs {hb}")
            same = False
            continue
        diff = next((i for i, (x, y) in enumerate(zip(ra, rb)) if x != y), None)
        if diff is not None:
            col = next(j for j, (x, y) in enumerate(zip(ra[diff], rb[diff])) if x != y)
            print(f"{s}: first difference at row {diff + 1}, column {ha[col]}: "
                  f"{ra[diff][col]} != {rb[diff][col]}")
            same = False
        elif len(ra) != len(rb):
            print(f"{s}: identical for {min(len(ra), len(rb))} rows, then lengths differ "
                  f"({len(ra)} vs {len(rb)})")
            same = False
        else:
            print(f"{s}: {len(ra)} rows identical (ignoring {IGNORE_PREFIX}*)")
    print("IDENTICAL" if same else "DIFFERENT")
    return same


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    sys.exit(0 if compare(sys.argv[1], sys.argv[2]) else 1)
