#!/usr/bin/env python3
"""plot_pose_age.py - pose age, arrival jitter and raw vs interpolated motion (Module 5).

    python tools/plot_pose_age.py logs/<stamp>_viewer --physics logs/<stamp>_spin_bodies
    python tools/plot_pose_age.py logs/<stamp>_viewer --window 3.0 0.5   (viewer log only)

Reads the viewer's run folder (viewer.csv = one row per rendered frame,
rx.csv = one row per received pose) and, if given, the physics run folder
(pose.csv has the send time t_wall_unix of every pose). Both processes run on
the same machine, so their system clocks (unix time) are the same clock.
Writes pose_age.png into the viewer folder and prints the numbers it shows.

Definitions
  latency         rx time - send time of a pose; includes the time the packet waits in
                  the socket until the viewer's next frame reads it   (needs --physics)
  pose age        frame time - send time of the newest pose on screen (raw display);
                  without --physics: frame time - time the viewer read the newest pose
  shown delay     pose age + (latest_t_sim - shown t_sim): how old the INTERPOLATED
                  display is (sim s = wall s at 1x real time)
  inter-arrival   wall time between consecutive poses of the cube (id 10)
  rotation step   angle the cube turns between two rendered frames; smooth motion
                  at a steady rate gives a constant step
"""
import argparse
import csv
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

RAW, INTERP, INK, MUTED = "#eb6834", "#2a78d6", "#0b0b0b", "#8a8984"


def load(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    return {k: np.array([float(r[k]) for r in rows]) for k in rows[0]}


def pct(x, p):
    return float(np.percentile(x, p)) if len(x) else float("nan")


def quat_step_deg(qx, qy, qz, qw):
    """Rotation angle between consecutive quaternions. atan2 form: acos(dot) loses
    precision for tiny angles and shows float32 noise as fake 0.1 deg steps."""
    q = np.stack([qx, qy, qz, qw], axis=1)
    a, b = q[:-1], q[1:]
    # relative rotation r = b * conj(a); angle = 2 atan2(|r_xyz|, |r_w|)
    w = np.sum(a * b, axis=1)
    xyz = (a[:, 3:4] * b[:, :3] - b[:, 3:4] * a[:, :3] - np.cross(b[:, :3], a[:, :3]))
    return np.degrees(2 * np.arctan2(np.linalg.norm(xyz, axis=1), np.abs(w)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run", help="viewer run folder (contains viewer.csv and rx.csv)")
    ap.add_argument("--window", nargs=2, type=float, default=[3.0, 0.5],
                    metavar=("START_S", "LEN_S"), help="wall-time window for the motion plots")
    ap.add_argument("--physics", help="physics run folder (pose.csv with t_wall_unix)")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()

    v = load(os.path.join(a.run, "viewer.csv"))
    rx = load(os.path.join(a.run, "rx.csv"))
    live = ((v["paused"] == 0) & (v["since_rx_s"] < 0.25)     # skip paused and stale frames ...
            & (v["t_wall"] <= rx["t_wall"].max())            # ... the tail after physics stopped
            & (v["t_wall"] >= rx["t_wall"].min() + 1.0))     # ... and 1 s warm-up (rate estimate)
    cube = (rx["vehicle_id"] == 10) & ((rx["flags"].astype(int) & 2) == 0)
    lat_ms = None
    if a.physics:
        ph = load(os.path.join(a.physics, "pose.csv"))
        pc = ph["vehicle_id"] == 10
        sent = dict(zip(np.round(ph["t_sim"][pc], 6), ph["t_wall_unix"][pc]))
        lat_ms = np.array([(u - sent[t]) * 1000 for t, u in zip(np.round(rx["t_sim"][cube], 6),
                                                                rx["t_wall_unix"][cube]) if t in sent])
        tx = np.array([sent.get(t, np.nan) for t in np.round(v["latest_t_sim"], 6)])
        age_all = v["t_wall_unix"] - tx
        age_label = "pose age = frame time - send time"
    else:
        age_all = v["since_rx_s"]
        age_label = "time since the viewer read the newest pose"
    keep = live & np.isfinite(age_all)
    age_ms = age_all[keep] * 1000
    shown_ms = (age_all + v["latest_t_sim"] - v["t_sim"])[keep] * 1000
    arr_ms = np.diff(rx["t_wall"][cube]) * 1000
    tsim_gaps = np.round(np.diff(rx["t_sim"][cube]) * 60).astype(int)    # 1 = no pose missing
    lost = int(np.sum(np.clip(tsim_gaps - 1, 0, None)))
    frame_ms = np.diff(v["t_wall"]) * 1000
    new_pose = np.diff(v["latest_t_sim"]) != 0
    step_raw = quat_step_deg(v["cube_qx_raw"], v["cube_qy_raw"], v["cube_qz_raw"], v["cube_qw_raw"])
    step_int = quat_step_deg(v["cube_qx_interp"], v["cube_qy_interp"], v["cube_qz_interp"], v["cube_qw_interp"])
    ok = live[1:] & live[:-1]
    extrap = v["extrap"][live]

    print(f"frames {len(v['t_wall'])}, frame time median {np.median(frame_ms):.2f} ms "
          f"(p99 {pct(frame_ms, 99):.2f}), cube poses received {int(cube.sum())}, "
          f"cube poses missing (from t_sim gaps) {lost}")
    if lat_ms is not None:
        print(f"latency       ms: median {np.median(lat_ms):5.1f}  p95 {pct(lat_ms, 95):5.1f}  "
              f"p99 {pct(lat_ms, 99):5.1f}  max {lat_ms.max():5.1f}   (send -> read by viewer)")
    print(f"pose age      ms: median {np.median(age_ms):5.1f}  p95 {pct(age_ms, 95):5.1f}  "
          f"p99 {pct(age_ms, 99):5.1f}  max {age_ms.max():5.1f}")
    print(f"shown delay   ms: median {np.median(shown_ms):5.1f}  p95 {pct(shown_ms, 95):5.1f}  "
          f"p99 {pct(shown_ms, 99):5.1f}  max {shown_ms.max():5.1f}   (interpolated display)")
    print(f"inter-arrival ms: median {np.median(arr_ms):5.1f}  p5 {pct(arr_ms, 5):5.1f}  "
          f"p95 {pct(arr_ms, 95):5.1f}  max {arr_ms.max():5.1f}  std {np.std(arr_ms):.2f}")
    print(f"frames with no new pose {100 * np.mean(~new_pose[ok]):.1f} %, "
          f"frames extrapolating {100 * np.mean(extrap):.1f} %")
    print(f"cube rotation step per frame, deg: raw mean {step_raw[ok].mean():.2f} std {step_raw[ok].std():.2f}"
          f" | interpolated mean {step_int[ok].mean():.2f} std {step_int[ok].std():.2f}")

    fig, ax = plt.subplots(2, 2, figsize=(12, 7.5))
    for x in ax.flat:
        x.grid(color="#dddcd6", linewidth=0.6)
        x.set_axisbelow(True)
        for s in ("top", "right"):
            x.spines[s].set_visible(False)
    bins = np.linspace(0, max(60.0, pct(shown_ms, 99.5)), 61)
    ax[0, 0].hist(age_ms, bins=bins, color=RAW, alpha=0.85, label=f"raw display: {age_label}")
    ax[0, 0].hist(shown_ms, bins=bins, color=INTERP, alpha=0.6, label="interpolated display: + interpolation delay")
    ax[0, 0].set(xlabel="ms", ylabel="frames", title="How old is what is on screen?")
    ax[0, 0].legend(frameon=False)
    ax[0, 1].hist(arr_ms, bins=np.linspace(0, max(40.0, pct(arr_ms, 99.5)), 81), color=MUTED)
    ax[0, 1].set(xlabel="ms between cube poses", ylabel="poses", title="Pose inter-arrival (jitter)")

    t0, span = a.window
    w = (v["t_wall"] >= t0) & (v["t_wall"] <= t0 + span)
    tw = (v["t_wall"][w] - t0) * 1000
    ax[1, 0].step(tw, v["sphere_y_raw"][w], where="post", color=RAW, lw=2, label="raw (newest pose)")
    ax[1, 0].plot(tw, v["sphere_y_interp"][w], color=INTERP, lw=2, marker="o", ms=3, label="interpolated")
    ax[1, 0].set(xlabel=f"wall ms after {t0:.1f} s", ylabel="sphere height y, m",
                 title="Sphere height per rendered frame")
    ax[1, 0].legend(frameon=False)
    wf = w[1:] & ok
    tf = (v["t_wall"][1:][wf] - t0) * 1000
    ax[1, 1].plot(tf, step_raw[wf], color=RAW, lw=2, marker="o", ms=3, label="raw")
    ax[1, 1].plot(tf, step_int[wf], color=INTERP, lw=2, marker="o", ms=3, label="interpolated")
    ax[1, 1].set(xlabel=f"wall ms after {t0:.1f} s", ylabel="deg per frame",
                 title="Cube rotation step per frame (steady spin)")
    ax[1, 1].legend(frameon=False)
    fig.tight_layout()
    out = a.out or os.path.join(a.run, "pose_age.png")
    fig.savefig(out, dpi=110)
    print("wrote", out)


if __name__ == "__main__":
    main()
