#!/bin/bash
# check_m05.sh - the Module 5 Check, automated. Run from the robosim/ folder:
#     GODOT=~/tools/godot bash tools/check_m05.sh
# Optional: VIEWER_PORT=9001 PHYSICS_PORT=9002 (defaults), PY=python3, LOSS=0.2
#   A  logged 20 s real-time run with the viewer logging too, then the pose-age plot
#   B  single steps and lock-step (exact pairing of frames and poses)
#   C  repeatability: two fast runs with seed 1 and one with seed 2, compared
set -u
GODOT=${GODOT:-godot}
PY=${PY:-python3}
VP=${VIEWER_PORT:-9001}
PP=${PHYSICS_PORT:-9002}
LOSS=${LOSS:-0.2}
ROOT=$(cd "$(dirname "$0")/.." && pwd)
LOGS=$ROOT/logs/check_m05_$(date +%Y%m%dT%H%M%S)
mkdir -p "$LOGS"/{a,b,c1,c2,c3}
GD="$GODOT --headless --path $ROOT/godot --script res://tests/check_m05.gd -- --listen-port=$VP --physics-port=$PP"
SIM="$PY $ROOT/physics/sims/spin_bodies.py --viewer-port $VP --listen-port $PP --quiet"

echo "=== A: pose age, raw vs interpolated (pose loss $LOSS)"
timeout -s INT 30 $SIM --log --log-root "$LOGS/a" --duration 20 --loss "$LOSS" | grep summary &
sleep 1
$GD --log --log-root="$LOGS/a" --duration=21 > /dev/null 2>&1
wait
$PY "$ROOT/tools/plot_pose_age.py" "$LOGS"/a/*_viewer --physics "$LOGS"/a/*_spin_bodies

echo "=== B: single step and lock-step"
timeout -s INT 20 $SIM | grep summary &
sleep 1
$GD --plan=pause@3,step@3.5,step@4,step@4.5,resume@5,lock@7,unlock@11 --duration=13 2>&1 \
    | grep -E "single steps|lock-step:"
wait

echo "=== C: repeatability"
$SIM --speed 0 --duration 20 --log --log-root "$LOGS/c1" > /dev/null
$SIM --speed 0 --duration 20 --log --log-root "$LOGS/c2" > /dev/null
$SIM --speed 0 --duration 20 --log --log-root "$LOGS/c3" --seed 2 > /dev/null
echo "seed 1 vs seed 1:"; $PY "$ROOT/tools/compare_logs.py" "$LOGS"/c1/* "$LOGS"/c2/*
echo "seed 1 vs seed 2:"; $PY "$ROOT/tools/compare_logs.py" "$LOGS"/c1/* "$LOGS"/c3/* | tail -2
echo "seed 1 fast vs seed 1 real time with viewer and loss (run A):"
$PY "$ROOT/tools/compare_logs.py" "$LOGS"/c1/* "$LOGS"/a/*_spin_bodies
echo "logs in $LOGS"
