#!/usr/bin/env python3
"""spin_bodies.py - Module 4/5 test scenario: two bodies streamed to the Godot viewer.

    id 10  cube   spins about a tilted axis, pinned at its center 1.5 m above the ground
    id 11  sphere bounces on the ground (and is kicked up again when it settles)

PyBullet runs in DIRECT mode (no window) at --physics-hz (240). Poses go out at a
per-vehicle rate (default 60 Hz), already converted to the Godot frame. The viewer
sends PAUSE / RESUME / STEP / RESET as reliable commands, and RANGE sensor packets.
Module 5 added: STEP, --speed, per-vehicle rates, --paused (lock-step) and --log.

Run from the physics/ folder:
    python sims/spin_bodies.py                       # real time, ports 9001 / 9002
    python sims/spin_bodies.py --loss 0.2            # drop 20 % of POSE packets on purpose
    python sims/spin_bodies.py --ack-loss 0.5 --cmd-loss 0.3   # stress the reliable channel
    python sims/spin_bodies.py --speed 4 --sphere-hz 30        # 4x real time, sphere at 30 Hz
    python sims/spin_bodies.py --speed 0 --duration 20 --log   # as fast as possible, logged
"""
import argparse
import math
import os
import sys
import time
from collections import deque

import numpy as np
import pybullet as pb

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))       # the robosim/ folder
sys.path.insert(0, os.path.join(HERE, ".."))
from robosim import protocol as P                         # noqa: E402
from robosim.bridge import PhysicsBridge                   # noqa: E402
from robosim.frames import enu_flu_to_godot, enu_to_godot_pos  # noqa: E402
from robosim.logger import RunLogger                       # noqa: E402

CUBE, SPHERE = 10, 11
CUBE_HALF, SPHERE_R = 0.3, 0.25
CMD_NAMES = {P.CMD_HEARTBEAT: "HEARTBEAT", P.CMD_PAUSE: "PAUSE", P.CMD_RESUME: "RESUME",
             P.CMD_STEP: "STEP", P.CMD_RESET: "RESET"}


class SpinWorld:
    """The PyBullet world. Knows nothing about networking."""

    def __init__(self, physics_hz, seed):
        self.cid = pb.connect(pb.DIRECT)
        self.dt = 1.0 / physics_hz
        self.seed = seed
        self.build()

    def build(self):
        c = self.cid
        pb.resetSimulation(physicsClientId=c)
        pb.setGravity(0, 0, -9.81, physicsClientId=c)
        pb.setTimeStep(self.dt, physicsClientId=c)
        rng = np.random.default_rng(self.seed)          # every random choice comes from the seed

        ground = pb.createMultiBody(0, pb.createCollisionShape(pb.GEOM_PLANE, physicsClientId=c),
                                    physicsClientId=c)
        pb.changeDynamics(ground, -1, restitution=0.9, physicsClientId=c)

        box = pb.createCollisionShape(pb.GEOM_BOX, halfExtents=[CUBE_HALF] * 3, physicsClientId=c)
        self.cube = pb.createMultiBody(1.0, box, basePosition=[0, 0, 1.5], physicsClientId=c)
        pb.createConstraint(self.cube, -1, -1, -1, pb.JOINT_POINT2POINT, [0, 0, 0],
                            [0, 0, 0], [0, 0, 1.5], physicsClientId=c)   # pin the center
        axis = rng.normal(size=3) + np.array([0, 0, 2.0])
        axis /= np.linalg.norm(axis)
        pb.changeDynamics(self.cube, -1, linearDamping=0, angularDamping=0, physicsClientId=c)
        pb.resetBaseVelocity(self.cube, [0, 0, 0], list(axis * 2 * math.pi * 0.5),
                             physicsClientId=c)         # 0.5 rev/s

        ball = pb.createCollisionShape(pb.GEOM_SPHERE, radius=SPHERE_R, physicsClientId=c)
        h = float(rng.uniform(1.5, 2.5))
        self.sphere = pb.createMultiBody(1.0, ball, basePosition=[1.5, 0, h], physicsClientId=c)
        pb.changeDynamics(self.sphere, -1, restitution=0.9, linearDamping=0, physicsClientId=c)

        self.step_count = 0

    @property
    def t_sim(self):
        return self.step_count * self.dt                # exact multiple of dt, never accumulated

    def step(self):
        pb.stepSimulation(physicsClientId=self.cid)
        self.step_count += 1
        (x, y, z), _ = pb.getBasePositionAndOrientation(self.sphere, physicsClientId=self.cid)
        v, _ = pb.getBaseVelocity(self.sphere, physicsClientId=self.cid)
        if z < SPHERE_R + 0.02 and abs(v[2]) < 0.3:     # settled: kick it up again
            pb.resetBaseVelocity(self.sphere, [0, 0, 6.0], [0, 0, 0], physicsClientId=self.cid)

    def pose_godot(self, body):
        """(pos, quat, vel) of a body, converted once to the Godot frame."""
        p, q = pb.getBasePositionAndOrientation(body, physicsClientId=self.cid)
        v, _ = pb.getBaseVelocity(body, physicsClientId=self.cid)
        pos, quat = enu_flu_to_godot(p, q)
        return pos, quat, enu_to_godot_pos(v)


class LossySocket:
    """Wraps a UDP socket and drops packets on purpose, to test loss handling.
    Sending side: drops POSE packets (loss) and ACK packets (ack_loss).
    Receiving side: drops COMMAND packets (cmd_loss)."""

    def __init__(self, sock, rng, loss=0.0, ack_loss=0.0, cmd_loss=0.0):
        self.sock, self.rng = sock, rng
        self.loss = {P.MSG_POSE: loss, P.MSG_ACK: ack_loss, P.MSG_COMMAND: cmd_loss}
        self.dropped = {P.MSG_POSE: 0, P.MSG_ACK: 0, P.MSG_COMMAND: 0}
        self.cmd_packets_in = 0

    def _drop(self, data):
        typ = data[3] if len(data) > 3 else -1
        p = self.loss.get(typ, 0.0)
        if p > 0 and self.rng.random() < p:
            self.dropped[typ] += 1
            return True
        return False

    def sendto(self, data, addr):
        if self._drop(data):
            return len(data)                            # pretend it was sent
        return self.sock.sendto(data, addr)

    def recvfrom(self, n):
        while True:
            data, addr = self.sock.recvfrom(n)          # raises BlockingIOError when empty
            if len(data) > 3 and data[3] == P.MSG_COMMAND:
                self.cmd_packets_in += 1
            if not self._drop(data):
                return data, addr


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--physics-hz", type=int, default=240)
    ap.add_argument("--pose-hz", type=int, default=60, help="pose rate of the cube; also the STEP size")
    ap.add_argument("--sphere-hz", type=int, default=0, help="pose rate of the sphere (default: --pose-hz)")
    ap.add_argument("--speed", type=float, default=1.0,
                    help="1 = real time, 4 = four times faster, 0 = as fast as possible")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--paused", action="store_true", help="start paused (for lock-step)")
    ap.add_argument("--log", action="store_true", help="write a run folder to ../logs (RunLogger)")
    ap.add_argument("--log-root", default=os.path.join(ROOT, "logs"))
    ap.add_argument("--loss", type=float, default=0.0, help="fraction of POSE packets to drop")
    ap.add_argument("--ack-loss", type=float, default=0.0, help="fraction of ACK packets to drop")
    ap.add_argument("--cmd-loss", type=float, default=0.0, help="fraction of incoming COMMANDs to drop")
    ap.add_argument("--duration", type=float, default=0.0, help="stop after this many sim seconds (0 = never)")
    ap.add_argument("--viewer-port", type=int, default=P.PORT_TO_VIEWER)
    ap.add_argument("--listen-port", type=int, default=P.PORT_TO_PHYSICS)
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()

    # Rates are per vehicle. Each one must divide the physics rate exactly.
    rates = {CUBE: a.pose_hz, SPHERE: a.sphere_hz or a.pose_hz}
    for vid, hz in rates.items():
        if a.physics_hz % hz:
            sys.exit(f"vehicle {vid}: pose rate {hz} Hz does not divide physics rate {a.physics_hz} Hz")
    decim = {vid: a.physics_hz // hz for vid, hz in rates.items()}
    frame_steps = a.physics_hz // a.pose_hz             # one STEP = one cube pose period

    world = SpinWorld(a.physics_hz, a.seed)
    bodies = {CUBE: world.cube, SPHERE: world.sphere}
    br = PhysicsBridge(viewer_port=a.viewer_port, listen_port=a.listen_port)
    loss_rng = np.random.default_rng(a.seed + 1000)    # separate stream: loss never changes physics
    br.tx = LossySocket(br.tx, loss_rng, loss=a.loss, ack_loss=a.ack_loss)
    br.rx = LossySocket(br.rx, loss_rng, cmd_loss=a.cmd_loss)
    log = None
    if a.log:
        log = RunLogger(a.log_root, run_name="spin_bodies", seed=a.seed, meta={
            "scenario": "spin_bodies", "physics": "pybullet", "physics_hz": a.physics_hz,
            "pose_hz": {str(k): v for k, v in rates.items()}, "speed": a.speed,
            "loss": a.loss, "vehicles": {"10": "cube", "11": "sphere"}})
        print(f"logging to {log.dir}", flush=True)

    paused = a.paused
    step_budget = 0                                     # physics steps still owed to STEP commands
    applied = {}
    truth = deque(maxlen=240)
    range_err = []
    poses_sent = 0

    def send_pose(vid, logged):
        nonlocal poses_sent
        pos, quat, vel = world.pose_godot(bodies[vid])
        br.send_pose(world.t_sim, vid, pos, quat, vel, paused=paused)
        poses_sent += 1
        if vid == SPHERE:
            truth.append((world.t_sim, pos[1] - SPHERE_R))
        if log and logged:                              # log what physics produced, not keep-alives.
            # t_wall_unix = send time on the shared system clock, for latency (Module 5)
            log.write("pose", world.t_sim, step=world.step_count, vehicle_id=vid,
                      x=pos[0], y=pos[1], z=pos[2], qx=quat[0], qy=quat[1], qz=quat[2], qw=quat[3],
                      vx=vel[0], vy=vel[1], vz=vel[2], t_wall_unix=round(time.time(), 6))

    def handle(msg):
        nonlocal paused, step_budget
        if msg["type"] == P.MSG_COMMAND:
            cmd = msg["cmd"]
            name = CMD_NAMES.get(cmd, f"cmd{cmd}")
            if cmd == P.CMD_PAUSE:                      # stop at the next frame boundary
                paused, step_budget = True, (-world.step_count) % frame_steps
            elif cmd == P.CMD_RESUME:
                paused, step_budget = False, 0
            elif cmd == P.CMD_STEP:                     # pause, then advance to the next frame boundary
                paused = True
                step_budget += frame_steps - (world.step_count + step_budget) % frame_steps
            elif cmd == P.CMD_RESET:
                world.build()
                truth.clear()
                step_budget = 0
                br.mark_reset()
                for vid in bodies:                      # the RESET pose goes out at once, even when paused
                    send_pose(vid, logged=True)
            else:
                return
            applied[name] = applied.get(name, 0) + 1
            if log:
                log.write("command", world.t_sim, step=world.step_count, seq=msg["seq"], cmd=name)
            if not a.quiet and cmd != P.CMD_STEP:
                print(f"[t_sim {world.t_sim:7.3f}] applied {name} (seq {msg['seq']})", flush=True)
        elif msg["type"] == P.MSG_SENSOR and msg["sensor"] == P.SENSOR_RANGE and msg["vehicle_id"] == SPHERE:
            for t, h in truth:
                if t == msg["t_sim"]:
                    range_err.append(abs(msg["values"][0] - h))
                    break

    print(f"spin_bodies: physics {a.physics_hz} Hz, poses {rates} Hz, speed {a.speed or 'max'}, "
          f"seed {a.seed}, ports {a.viewer_port}/{a.listen_port}", flush=True)
    keepalive = 1.0 / a.pose_hz
    next_wall = time.monotonic()
    next_keepalive = next_wall
    next_report = next_wall + 2.0
    overruns = 0
    for vid in bodies:
        send_pose(vid, logged=True)                     # t_sim = 0 pose (carries RESET)
    try:
        while not (a.duration and world.t_sim >= a.duration - 1e-9):
            for msg in br.poll(world.t_sim):
                handle(msg)
            if not paused or step_budget > 0:
                world.step()
                if paused:
                    step_budget -= 1
                for vid in bodies:                      # each vehicle at its own rate
                    if world.step_count % decim[vid] == 0:
                        send_pose(vid, logged=True)
                if a.speed > 0 and not paused:          # real-time (or scaled) pacing
                    next_wall += world.dt / a.speed
                    now = time.monotonic()
                    if now - next_wall > 0.25:          # far behind (debugger, suspend): re-anchor
                        next_wall = now
                        overruns += 1
                    elif next_wall > now:
                        time.sleep(next_wall - now)
                next_keepalive = time.monotonic() + keepalive
            else:                                       # paused: keep the viewer from going stale
                now = time.monotonic()
                if now >= next_keepalive:
                    for vid in bodies:
                        send_pose(vid, logged=False)
                    next_keepalive = now + keepalive
                time.sleep(0.001)
                next_wall = time.monotonic()            # do not "catch up" the pause afterwards
            if not a.quiet and time.monotonic() > next_report:
                next_report += 2.0
                print(f"[t_sim {world.t_sim:7.3f}] {'PAUSED ' if paused else ''}poses sent {poses_sent}, "
                      f"dropped {br.tx.dropped[P.MSG_POSE]}, commands {applied}", flush=True)
    except KeyboardInterrupt:
        pass
    br.tx.sendto(P.pack_simple(P.MSG_BYE, br._next(), world.t_sim), br.viewer)
    if log:
        log.close()
    print(f"summary: t_sim {world.t_sim:.3f}, steps {world.step_count}, poses sent {poses_sent}, "
          f"pose packets dropped {br.tx.dropped[P.MSG_POSE]}, command packets in {br.rx.cmd_packets_in}, "
          f"commands applied {applied}, pacing re-anchors {overruns}"
          + (f", range err mean {np.mean(range_err) * 1000:.4f} mm over {len(range_err)}" if range_err else ""),
          flush=True)


if __name__ == "__main__":
    main()
