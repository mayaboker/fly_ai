# Module 5 reference code

The finished files for [lab.md](../lab.md). Paths mirror `robosim/`. They build on Module 4's files and the reference bridge ([m04 code](../../m04_bridge/code/README.md)).

| File | Copy to | Note |
|---|---|---|
| `physics/sims/spin_bodies.py` | `robosim/physics/sims/` | replaces the Module 4 version (a superset: all Module 4 options still work) |
| `godot/bridge/render_clock.gd` | `robosim/godot/bridge/` | `RenderClock` |
| `godot/spin_viewer.tscn`, `spin_viewer.gd` | `robosim/godot/` | replace the Module 4 versions |
| `godot/tests/check_m05.gd` | `robosim/godot/tests/` | scripted viewer for the Check |
| `tools/plot_pose_age.py` | `robosim/tools/` | needs numpy and matplotlib |
| `tools/compare_logs.py` | `robosim/tools/` | standard library only |
| `tools/replay_poses.py` | `robosim/tools/` | uses `physics/robosim` |
| `tools/check_m05.sh` | `robosim/tools/` | runs the whole Check |
| `screenshots/` | — | `m05_viewer.png` (xvfb), `pose_age_loss20.png`, `pose_age_144fps.png` from our runs |

## Run

```bash
cd ~/robosim/godot && godot --headless --import              # once: registers RenderClock

# the lab, two terminals
cd ~/robosim/physics && python sims/spin_bodies.py [--log] [--loss 0.2] [--speed 4] [--sphere-hz 30]
godot --path ~/robosim/godot res://spin_viewer.tscn [-- --log]

# analysis
cd ~/robosim
python tools/plot_pose_age.py logs/<stamp>_viewer --physics logs/<stamp>_spin_bodies [--window 3 0.5]
python tools/compare_logs.py logs/<run_a> logs/<run_b>
python tools/replay_poses.py logs/<stamp>_spin_bodies [--speed 0.5] [--loop]

# the whole Check, headless
GODOT=~/tools/godot bash tools/check_m05.sh
```

`spin_bodies.py` options (new in Module 5): `--sphere-hz`, `--speed` (0 = max), `--paused`, `--log`, `--log-root`, `--quiet`. Module 4 options are unchanged.
Viewer options after `--`: `--listen-port=N --physics-port=N --log --log-root=DIR`. Keys: P, S, R, I, L.
`check_m05.gd` options after `--`: `--plan=pause@4,step@4.5,resume@6,lock@8,unlock@12` (words: pause resume step reset raw interp lock unlock; times in wall seconds), `--duration=S`, `--max-fps=N` (default 60, 0 = unlimited), plus the viewer options.

## What was verified (Godot 4.7.2, Python 3.11, PyBullet 3.2.x, numpy 2.4, matplotlib, Linux, shared 2-core VM)

All runs used a throwaway copy of `robosim/` with ports 9150/9151. Other jobs were running on the machine at the same time, which shows up as occasional long frames and inter-arrival outliers.

| Test | Result |
|---|---|
| `check_m05.sh` end to end | passes; output as in the lab. Also run in a fresh project assembled only from `reference/code` + Module 4 `code/` + this folder |
| Single STEP (3 in a row, live physics and replay) | increments exactly 0.016667 s |
| Lock-step, viewer capped at 60 fps | 238 frames, 0 spacing errors, 59.4–59.5 steps/s |
| Lock-step, headless, uncapped | 866 frames, 0 spacing errors, 144 steps/s (2.40× real time) |
| Raw vs interpolated, cube step per frame (std) | 60 fps: 0.59° vs 0.32° (another run: 0.00° vs 0.00°); 20 % loss: 2.21° vs 0.64–0.66° (on a heavily loaded machine: 2.92° vs 1.16°); 144 fps: 1.48° vs 0.05°; 4× speed: 1.51° vs 0.27° |
| Latency median across 60 fps runs | 1.0 to 15.0 ms depending on loop phase; 3.3 ms at 144 fps |
| `SimBridge` process priority −1 vs 0 (the reference now sets −100 itself; same effect) | pose age median 7.8 ms vs 21.2 ms (one extra frame without it) |
| Repeatability | seed 1 twice: 2402 rows identical; seed 2: differs at row 2; real time with viewer, 20 % loss, pause/step/lock-step: identical; post-RESET part: identical to a fresh start |
| `--speed 0`, 60 s of sim | about 0.53 s wall including start-up |
| `--speed 4` | 4.00× measured from received poses; render clock follows after its first 0.5 s window |
| `replay_poses.py` | viewer follows; PAUSE, STEP, RESUME, RESET obeyed |
| `frame_post_draw` in headless mode | never emitted (0 in 30 frames), hence the headless fallback in the viewer |
| Rendering (`xvfb-run`, `--rendering-driver opengl3`) | `screenshots/m05_viewer.png` |

Not tested here: the lock-step `frame_post_draw` path with a real GPU and window (under xvfb we only took a screenshot), keyboard and mouse input by hand (the checks call the same functions), and Windows/macOS. `check_m05.sh` needs `timeout` (Linux, or coreutils on macOS).
