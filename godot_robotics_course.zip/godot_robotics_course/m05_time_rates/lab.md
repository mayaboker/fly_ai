# Lab 5: Smooth, steppable, logged and repeatable (about 1 h 15)

You will extend the Module 4 scenario and viewer. Physics gets per-vehicle rates, STEP, speed control and logging. The viewer gets a render clock, a raw / interpolated toggle, single-step and lock-step, and a per-frame log. Then you measure what the picture on screen really shows, and prove that the physics is repeatable.

## Files added or changed

| File in `robosim/` | Status | Purpose |
|---|---|---|
| `physics/sims/spin_bodies.py` | **changed** | per-step loop, per-vehicle rates, STEP, PAUSE at frame boundaries, `--speed`, `--paused`, `--log` |
| `godot/bridge/render_clock.gd` | **new** | `RenderClock`: the displayed sim time |
| `godot/spin_viewer.gd`, `spin_viewer.tscn` | **changed** | interpolation toggle, STEP, lock-step, `--log`; three new buttons |
| `godot/tests/check_m05.gd` | **new** | scripted viewer for the Check |
| `tools/plot_pose_age.py` | **new** | latency, pose age, jitter, raw vs interpolated |
| `tools/compare_logs.py` | **new** | cell-by-cell run comparison |
| `tools/replay_poses.py` | **new** | play a log back into the viewer |
| `tools/check_m05.sh` | **new** | runs the whole Check |

`sim_bridge.gd` is used unchanged from the reference (as read in Module 4). Its `sample()` function finally gets called. The finished files are in [code/](code/README.md).

## 1. Upgrade the physics loop (20 min)

Change `spin_bodies.py` as described in [01](01_fixed_step_and_clocks.md#the-module-5-physics-loop):

1. Loop once per physics step instead of once per pose period. Pace with `next_wall += dt / speed` and the 0.25 s re-anchor rule.
2. Make the pose rate per vehicle: `--pose-hz` (cube, also the STEP size) and `--sphere-hz`. Exit with a clear message when a rate does not divide `--physics-hz`.
3. Add `step_budget` and handle PAUSE and STEP at frame boundaries ([04](04_pause_step_reset_replay.md#frame-boundaries)).
4. While paused: poll every 1 ms, send keep-alive poses at the cube's rate, and reset `next_wall` so the pause is not "caught up" afterwards.
5. On RESET: rebuild, `mark_reset()`, and send the RESET pose immediately (the viewer must update even when paused).
6. Add `--log` with `RunLogger`. Log produced poses (not keep-alives) and applied commands, with `step` ([06](06_logging.md#runlogger)).
7. Add `--speed` (0 = as fast as possible), `--paused` (start paused, for lock-step) and `--duration` in sim seconds.

Test without a viewer:

```bash
cd ~/robosim/physics
python sims/spin_bodies.py --speed 0 --duration 20 --log
```

Expected: it finishes within about a second and prints `logging to .../logs/<stamp>_spin_bodies` and `summary: t_sim 20.000, steps 4800, poses sent 2402, ...`. 2402 = 2 bodies × (1 initial + 1200) poses.

## 2. The render clock (10 min)

Create `godot/bridge/render_clock.gd` from [03](03_interpolation.md#the-render-clock). It is a `RefCounted`, not a node: the viewer owns one and calls `observe()` for every pose and `advance()` once per frame. Run `godot --headless --import` once afterwards, so `RenderClock` is a known class.

## 3. Interpolation in the viewer (10 min)

In `spin_viewer.gd`:

- connect `pose_received` to record `newest_t[id]`, feed `clock.observe(t_sim, wall)`, and read the PAUSED flag;
- connect `physics_reset` to clear `newest_t` and call `clock.reset()`;
- in `_process`, compute `t_render = clock.advance(delta, bridge.latest_t_sim, paused)`, then **both** `bridge.latest_transform(id)` and `bridge.sample(id, t_render)` for every body. Apply one of them depending on `interpolate`, and set `extrapolating` when `t_render > newest_t[id]`;
- I toggles `interpolate`.

Add three buttons to `UI/Buttons` (Step, Raw / Interp, Lock-step), all with Focus ▸ Mode = None. The info line now shows `t_sim`, the shown time and the mode.

Run it with physics, at `--loss 0.2`, and press I a few times while watching the cube. The difference is easiest to see in the cube's spin.

![Module 5 viewer](code/screenshots/m05_viewer.png)

## 4. Single step and lock-step (10 min)

S sends `CMD_STEP`. L toggles lock-step: switching on sends STEP (which also pauses), switching off sends RESUME. The per-frame lock-step logic is in [05](05_lockstep_determinism.md#lock-step-with-step). Remember the headless fallback: `frame_post_draw` never fires without a renderer.

Try it: press P, then S several times, and watch `t_sim` in the info line go up by 0.017 per press. Press L and watch `t_sim` advance at about real time while every frame shows a new physics frame. Press L again to return to free running.

## 5. The viewer log (5 min)

Parse `--log` and `--log-root=` in `_enter_tree`. Open `run.json`, `viewer.csv` and `rx.csv` with `FileAccess`, write one row per frame and one per received pose, and close the files in `_exit_tree`. Columns are in [06](06_logging.md#the-viewer-logs-too). Then record a run with both sides logging:

```bash
cd ~/robosim/physics && python sims/spin_bodies.py --log --duration 20 --loss 0.2
godot --path ~/robosim/godot res://spin_viewer.tscn -- --log         # second terminal, right away
```

Close the viewer after physics ends.

## 6. Plot pose age and raw vs interpolated (10 min)

```bash
cd ~/robosim
python tools/plot_pose_age.py logs/<stamp>_viewer --physics logs/<stamp>_spin_bodies
```

It prints the numbers and writes `pose_age.png` into the viewer folder. It ignores paused frames, stale frames, the first second (the render clock's rate measurement) and the frames after physics stopped. Our run at 60 fps with 20 % pose loss:

```
frames 1260, frame time median 16.67 ms (p99 19.85), cube poses received 899, cube poses missing (from t_sim gaps) 244
latency       ms: median   2.2  p95   3.2  p99   5.8  max  16.2   (send -> read by viewer)
pose age      ms: median   2.3  p95   5.7  p99  19.0  max  20.1
shown delay   ms: median  28.0  p95  30.0  p99  31.7  max  37.1   (interpolated display)
inter-arrival ms: median  16.7  p5  16.0  p95  34.1  max  87.2  std 9.97
frames with no new pose 4.5 %, frames extrapolating 8.0 %
cube rotation step per frame, deg: raw mean 3.00 std 2.21 | interpolated mean 3.00 std 0.64
```

![Pose age and raw vs interpolated, 20 % loss](code/screenshots/pose_age_loss20.png)

How to read the four panels:

| Panel | What to look for |
|---|---|
| top left | raw age is one narrow peak (latency); interpolated is the same peak shifted by the 25 ms delay |
| top right | the 16.7 ms spike is the pose rate; the spike at 33 ms is one lost pose; anything further right is a run of losses or a stall |
| bottom left | raw sphere height is a staircase with flat steps where poses were lost; interpolated is smooth and slightly higher on the way down (it shows the past) |
| bottom right | raw cube rotation per frame jumps between 0°, 3° and 6°; interpolated stays at 3° |

Pick another window with `--window START LEN` (wall seconds) to find a run of lost poses. Repeat without loss, and with the viewer at 144 fps, and write down your numbers for all three. For 144 fps use Godot's own option **before** the `--`: `godot --max-fps 144 --path ~/robosim/godot res://spin_viewer.tscn -- --log` (with a window, also turn V-Sync off or use a 144 Hz monitor). `spin_viewer.gd` itself has no `--max-fps=` option; `check_m05.gd` does.

## 7. Repeatability (5 min)

```bash
cd ~/robosim/physics
python sims/spin_bodies.py --speed 0 --duration 20 --log
python sims/spin_bodies.py --speed 0 --duration 20 --log
python sims/spin_bodies.py --speed 0 --duration 20 --log --seed 2
cd ~/robosim
python tools/compare_logs.py logs/<first> logs/<second>      # IDENTICAL
python tools/compare_logs.py logs/<first> logs/<third>       # DIFFERENT, row 2
python tools/compare_logs.py logs/<first> logs/<the real-time run from step 5>
```

The first two runs usually start within the same second. `RunLogger` then names the second folder `<stamp>_spin_bodies_2` ([06](06_logging.md#runlogger)), so use `ls logs/` to find the names. The last comparison is the interesting one: real time, viewer attached, 20 % loss. `run.json` differs in `speed` and `loss`, and `pose.csv` is identical.

## 8. Run the whole Check

```bash
cd ~/robosim
GODOT=~/tools/godot bash tools/check_m05.sh
```

Our output (shortened):

```
=== A: pose age, raw vs interpolated (pose loss 0.2)
summary: t_sim 20.000, steps 4800, poses sent 2402, pose packets dropped 490, ...
latency       ms: median   2.2  p95   3.2  p99   5.8  max  16.2   (send -> read by viewer)
pose age      ms: median   2.3  p95   5.7  p99  19.0  max  20.1
shown delay   ms: median  28.0  p95  30.0  p99  31.7  max  37.1   (interpolated display)
cube rotation step per frame, deg: raw mean 3.00 std 2.21 | interpolated mean 3.00 std 0.64
=== B: single step and lock-step
[wall  13.00] single steps: cube t_sim before/after each step [4.16666666666667, 4.18333333333333, 4.2, 4.21666666666667], increments [0.016667, 0.016667, 0.016667]
[wall  13.00] lock-step: 238 frames, t_sim 6.2333 .. 10.1833, spacing != 1/60 s in 0 cases, 59.4 steps/s (wall), 0.99x real time
summary: t_sim 17.850, ..., commands applied {'PAUSE': 1, 'STEP': 243, 'RESUME': 2}, ...
=== C: repeatability
seed 1 vs seed 1:
pose.csv: 2402 rows identical (ignoring t_wall*)
IDENTICAL
seed 1 vs seed 2:
pose.csv: first difference at row 2, column y: 2.4486494471372438 != 1.5919159421350968
DIFFERENT
seed 1 fast vs seed 1 real time with viewer and loss (run A):
run.json  loss: 0.0 != 0.2
run.json  speed: 0.0 != 1.0
pose.csv: 2402 rows identical (ignoring t_wall*)
DIFFERENT
```

Against the [Check](README.md#check): A gives items 1 and 2; B gives item 3 (increments of exactly 0.016667, 0 spacing errors over 238 frames); C gives item 4. The last DIFFERENT is expected: only `run.json` differs, and that file is supposed to describe how the run was made.

The 243 STEPs in B are the 3 single steps plus roughly one per lock-step frame. Each lock-step frame asks for exactly one STEP, and Module 4's de-duplication makes sure none is applied twice.

Optional: replay the logged run into the viewer.

```bash
python tools/replay_poses.py logs/<stamp>_spin_bodies --speed 0.5 --loop
```

## Stretch goals

1. **Adaptive delay.** Make `RenderClock.delay_s` follow the measured inter-arrival p95 plus a margin. Show with the plot tool that it trades extrapolation against age automatically when you change `--loss`.
2. **Per-vehicle render delay.** Run `--sphere-hz 20`. A single delay that suits the cube makes the sphere extrapolate. Give each vehicle its own delay, sized from its own pose period.
3. **Deterministic re-simulation with inputs.** Add a custom command (id 100, `KICK vz`) that kicks the sphere, logged in `command.csv` with its `step`. Write `--replay-commands command.csv`, which applies each logged command at the logged step, and prove with `compare_logs.py` that an interactive run can be reproduced exactly.
4. **Lock-step at 30 Hz with frame capture.** Run lock-step with `--pose-hz 30`, save the viewport image in `_request_step` before sending STEP, and name each file by its `t_sim`. Module 7 does this properly. Measure how much the readback slows lock-step down.
5. **Slow-motion replay.** Replay a 4× run at 0.25× and confirm in the viewer log that the render clock measured `rate ≈ 0.25`.
