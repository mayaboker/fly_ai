"""
camera_model.py - read the intrinsics JSON that Godot exports (Module 6) and project points.

    from camera_model import CameraModel
    cam = CameraModel.load("logs/camera_check/intrinsics_fpv.json")
    uv = cam.project_cv(points_cv)          # Nx3 in the OpenCV optical frame -> Nx2 pixels
    uv = cam.project_godot(points_cam)      # Nx3 in the Godot camera frame (x right, y up, -z fwd)

Self-test:  python tools/camera_model.py logs/camera_check
  re-projects every board in results.json with numpy AND cv2.projectPoints and compares
  with the box Godot computed.
"""
import json, math, os, sys
import numpy as np

GODOT_TO_CV = np.diag([1.0, -1.0, -1.0])          # x_cv = x, y_cv = -y, z_cv = -z


def h_from_v(fov_v_deg, w, h):
    return math.degrees(2 * math.atan(math.tan(math.radians(fov_v_deg) / 2) * w / h))


def v_from_h(fov_h_deg, w, h):
    return math.degrees(2 * math.atan(math.tan(math.radians(fov_h_deg) / 2) * h / w))


def fy_from_fov_v(fov_v_deg, h):
    return (h / 2) / math.tan(math.radians(fov_v_deg) / 2)


class CameraModel:
    def __init__(self, d):
        self.d = d
        self.w, self.h = d["width"], d["height"]
        self.K = np.array(d["K"], dtype=float)
        self.T_body_cam_cv = np.array(d.get("T_body_cam_cv", np.eye(4)), dtype=float)

    @classmethod
    def load(cls, path):
        with open(path) as f:
            return cls(json.load(f))

    @classmethod
    def from_fov(cls, w, h, fov_v_deg, near=0.05, far=2000.0):
        fy = fy_from_fov_v(fov_v_deg, h)
        return cls({"width": w, "height": h, "fx": fy, "fy": fy, "cx": w / 2, "cy": h / 2,
                    "K": [[fy, 0, w / 2], [0, fy, h / 2], [0, 0, 1]], "near_m": near, "far_m": far})

    def project_cv(self, p):
        p = np.atleast_2d(np.asarray(p, dtype=float))
        uvw = p @ self.K.T
        return uvw[:, :2] / uvw[:, 2:3]

    def project_godot(self, p):
        return self.project_cv(np.atleast_2d(p) @ GODOT_TO_CV.T)


def _board_corners_godot(d, right, up, size=1.0, thick=0.02):
    """8 corners of the lab board in the Godot camera frame."""
    zc = -(d + thick / 2)
    return np.array([[right + sx * size / 2, up + sy * size / 2, zc + sz * thick / 2]
                     for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)])


def selftest(folder):
    import cv2
    res = json.load(open(os.path.join(folder, "results.json")))
    worst = 0.0
    for c in res["cases"]:
        cam = CameraModel.from_fov(c["width"], c["height"], c["fov_v_deg"])
        pg = _board_corners_godot(c["distance_m"], c["offset_right_m"], c["offset_up_m"])
        uv = cam.project_godot(pg)
        uv_cv, _ = cv2.projectPoints(pg @ GODOT_TO_CV.T, np.zeros(3), np.zeros(3), cam.K, None)
        uv_cv = uv_cv.reshape(-1, 2)
        box = [*uv.min(0), *uv.max(0)]
        e = max(max(abs(a - b) for a, b in zip(box, c["box"])), float(np.abs(uv - uv_cv).max()))
        worst = max(worst, e)
        print(f"{c['file']:36s} numpy box {np.round(box, 2)}  godot box {np.round(c['box'], 2)}  max diff {e:.2e} px")
    print("PASS" if worst < 1e-3 else "FAIL", f"(worst {worst:.2e} px)")
    return worst < 1e-3


if __name__ == "__main__":
    print("fov_v 60 at 640x360 -> fov_h %.2f deg, fy %.2f px" % (h_from_v(60, 640, 360), fy_from_fov_v(60, 360)))
    sys.exit(0 if selftest(sys.argv[1] if len(sys.argv) > 1 else "logs/camera_check") else 1)
