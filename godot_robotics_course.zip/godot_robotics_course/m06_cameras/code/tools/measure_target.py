"""
measure_target.py - Module 6 check: rendered red-board size vs pinhole prediction.

    python tools/measure_target.py ../logs/camera_check  [--tol 1.5]

Reads results.json + the PNGs written by cameras/camera_lab.gd, segments the pure-red
board (R > 200, G < 80, B < 80), and compares its pixel bounding box with
  pred = fy * board_size / distance       (pinhole, from the exported intrinsics)
  box  = TargetBox.compute()               (8 projected corners, Godot side)
  unproject = Camera3D.unproject_position  (Godot's own projection)
Exit code 1 if any size or centre error is larger than tol pixels.
"""
import argparse, json, os, sys
import numpy as np
from PIL import Image


def red_bbox(path):
    rgb = np.asarray(Image.open(path).convert("RGB")).astype(int)
    mask = (rgb[..., 0] > 200) & (rgb[..., 1] < 80) & (rgb[..., 2] < 80)
    if not mask.any():
        return None
    rows = np.where(mask.any(axis=1))[0]
    cols = np.where(mask.any(axis=0))[0]
    # pixel i covers [i, i+1): a box from column c0 to c1 inclusive is c1 + 1 - c0 wide
    return dict(x0=int(cols[0]), x1=int(cols[-1]) + 1, y0=int(rows[0]), y1=int(rows[-1]) + 1,
                w=int(cols[-1] + 1 - cols[0]), h=int(rows[-1] + 1 - rows[0]), n=int(mask.sum()))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder")
    ap.add_argument("--tol", type=float, default=1.5, help="allowed |measured - predicted| in px")
    a = ap.parse_args()
    res = json.load(open(os.path.join(a.folder, "results.json")))
    print(f"{'image':34s} {'fy':>7s} {'pred':>7s} {'box':>7s} {'unproj':>7s} {'meas w':>7s} {'meas h':>7s} {'err':>6s} {'ctr err':>8s}")
    worst = 0.0
    for c in res["cases"]:
        m = red_bbox(os.path.join(a.folder, c["file"]))
        if m is None:
            print(f"{c['file']:34s} board not found"); worst = float("inf"); continue
        err = max(abs(m["w"] - c["pred_w_px"]), abs(m["h"] - c["pred_w_px"]))
        bx = c["box"]
        cerr = max(abs((m["x0"] + m["x1"]) / 2 - (bx[0] + bx[2]) / 2),
                   abs((m["y0"] + m["y1"]) / 2 - (bx[1] + bx[3]) / 2))
        worst = max(worst, err, cerr)
        print(f"{c['file']:34s} {c['fy']:7.2f} {c['pred_w_px']:7.2f} {c['box_w_px']:7.2f} "
              f"{c['unproject_w_px']:7.2f} {m['w']:7d} {m['h']:7d} {err:6.2f} {cerr:8.2f}")
    ok = worst <= a.tol
    print(f"worst error (size or centre) = {worst:.2f} px  (tolerance {a.tol} px)  ->  {'PASS' if ok else 'FAIL'}")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
