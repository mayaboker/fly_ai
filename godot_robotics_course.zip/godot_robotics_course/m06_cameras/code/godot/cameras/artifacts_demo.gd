extends Node3D
## Module 6, sub-topics 03 and 05: measure how MSAA, depth precision and lighting change pixels.
## Run with rendering, from robosim/:  godot --path godot res://cameras/artifacts_demo.tscn
## Prints a table and saves PNGs to robosim/logs/artifacts/

var out_dir := ""
var vp: SubViewport
var cam: Camera3D


func _ready() -> void:
	out_dir = ProjectSettings.globalize_path("res://").path_join("../logs/artifacts").simplify_path()
	DirAccess.make_dir_recursive_absolute(out_dir)
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.0, 0.0, 0.0)
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	vp = SubViewport.new()
	vp.size = Vector2i(640, 360)
	vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(vp)
	cam = Camera3D.new()
	cam.fov = 60.0
	vp.add_child(cam)
	await _msaa_test()
	await _depth_test()
	await _light_test()
	get_tree().quit()


func _grab(file: String) -> Image:
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var img := vp.get_texture().get_image()
	img.convert(Image.FORMAT_RGB8)
	img.save_png(out_dir.path_join(file))
	return img


func _unshaded(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	return m


func _board(c: Color, size := 1.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(size, size, 0.001)
	mi.mesh = bm
	mi.material_override = _unshaded(c)
	add_child(mi)
	return mi


## Only the centre 100x100 pixels are analysed (the boards are ~31 px): GDScript loops are slow.
const ROI := Rect2i(270, 130, 100, 100)


## Count pure-red, pure-black and "mixed" pixels.
func _classify(img: Image) -> Vector3i:
	var red := 0
	var black := 0
	var mixed := 0
	for y in range(ROI.position.y, ROI.end.y):
		for x in range(ROI.position.x, ROI.end.x):
			var c := img.get_pixel(x, y)
			if c.r > 0.98 and c.g < 0.02:
				red += 1
			elif c.r < 0.02:
				black += 1
			else:
				mixed += 1
	return Vector3i(red, black, mixed)


func _msaa_test() -> void:
	# A red board rolled 20 deg, 10 m away: its edges are diagonal "staircases".
	var b := _board(Color(1, 0, 0))
	b.transform = Transform3D(Basis(Vector3.BACK, deg_to_rad(20.0)), Vector3(0, 0, -10))
	print("MSAA test: red board, 1 m, rolled 20 deg, 10 m, 640x360, fov_v 60")
	print("  %-10s %8s %8s %8s" % ["msaa", "red", "mixed", "sum"])
	for m in [Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X, Viewport.MSAA_8X]:
		vp.msaa_3d = m
		var img: Image = await _grab("msaa_%d.png" % m)
		var k := _classify(img)
		# area estimate: red pixels + mixed pixels weighted by their red fraction
		var area := 0.0
		for y in range(ROI.position.y, ROI.end.y):
			for x in range(ROI.position.x, ROI.end.x):
				area += img.get_pixel(x, y).r
		print("  %-10s %8d %8d %8.1f" % [["off", "2x", "4x", "8x"][m], k.x, k.z, area])
	vp.msaa_3d = Viewport.MSAA_DISABLED
	b.queue_free()
	await get_tree().process_frame
	var fy := 180.0 / tan(deg_to_rad(30.0))
	print("  ideal area = (fy * 1 / 10)^2 = %.1f px" % pow(fy / 10.0, 2))


func _depth_test() -> void:
	# Red board 1 cm in front of a blue board. Which colour wins at distance D?
	print("Depth test: red board 1 cm in front of blue board; fraction of board pixels that are red")
	print("  %-8s %-8s %8s %8s %8s %8s %8s %8s" % ["near", "far", "D=50", "D=100", "D=200", "D=400", "D=600", "D=800"])
	var red := _board(Color(1, 0, 0), 1.0)
	var blue := _board(Color(0, 0, 1), 1.0)
	for nf in [[0.01, 5000.0], [0.05, 2000.0], [0.5, 2000.0], [1.0, 1000.0], [0.05, 900.0]]:
		cam.near = nf[0]
		cam.far = nf[1]
		var cols := []
		for d in [50.0, 100.0, 200.0, 400.0, 600.0, 800.0]:
			var s: float = d / 10.0                     # scale boards to keep ~31 px on screen
			red.transform = Transform3D(Basis().scaled(Vector3(s, s, 1)), Vector3(0, 0, -d))
			blue.transform = Transform3D(Basis().scaled(Vector3(s, s, 1)), Vector3(0, 0, -d - 0.01))
			var img: Image = await _grab("depth_n%s_d%d.png" % [str(nf[0]), int(d)])
			var r := 0
			var bl := 0
			for y in range(ROI.position.y, ROI.end.y):
				for x in range(ROI.position.x, ROI.end.x):
					var c := img.get_pixel(x, y)
					if c.r > 0.5:
						r += 1
					elif c.b > 0.5:
						bl += 1
			cols.append("%7.0f%%" % (100.0 * r / maxf(1.0, r + bl)))
		print("  %-8s %-8s %s %s %s %s %s %s" % [str(nf[0]), str(nf[1]), cols[0], cols[1], cols[2], cols[3], cols[4], cols[5]])
	red.queue_free()
	blue.queue_free()
	cam.near = 0.05
	cam.far = 2000.0
	await get_tree().process_frame


func _light_test() -> void:
	# Same red albedo, lit (shaded) material: the pixel value depends on the light.
	print("Lighting test: lit red board (albedo 1,0,0), facing camera, 5 m; centre pixel")
	var b := _board(Color(1, 0, 0))
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1, 0, 0)
	b.material_override = mat
	b.transform = Transform3D(Basis.IDENTITY, Vector3(0, 0, -5))
	var sun := DirectionalLight3D.new()
	add_child(sun)
	for e in [[0.0, 1.0], [-60.0, 1.0], [-80.0, 1.0], [0.0, 0.3]]:
		sun.rotation_degrees = Vector3(e[0], 0, 0)      # 0 = light along -Z, straight onto the board
		sun.light_energy = e[1]
		var img: Image = await _grab("light_%d_%d.png" % [int(e[0]), int(e[1] * 10)])
		var c := img.get_pixel(320, 180)
		print("  sun pitch %5.0f deg energy %.1f -> RGB8 (%3d, %3d, %3d)" % [e[0], e[1], c.r8, c.g8, c.b8])
