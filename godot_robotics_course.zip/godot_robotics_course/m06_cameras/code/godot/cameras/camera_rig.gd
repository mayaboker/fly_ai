class_name CameraRig
extends Node3D
## One robot camera = this node + its own SubViewport + Camera3D (Module 6).
##
## Place a CameraRig as a child of a vehicle, at the camera mount (you can make it a child
## of the Marker3D mount from Module 2/3, or give it the mount's transform). Its -Z axis is
## the optical axis, its +Y is "image up". The rig copies its pose to the camera each frame:
##   RIGID         camera = this node (FPV hard-mounted, or the downward optical-flow camera)
##   GIMBAL_LEVEL  position from this node, heading from this node, roll = 0, pitch = tilt
##   CHASE         behind/above this node in its heading frame, looking at it (for humans)

enum Mode { RIGID, GIMBAL_LEVEL, CHASE }

@export var mode := Mode.RIGID
@export var camera_name := "fpv"
@export var image_size := Vector2i(640, 360)
@export_range(1.0, 179.0) var fov_v_deg := 60.0     ## vertical FOV (Godot default keep_aspect)
@export var near := 0.05
@export var far := 2000.0
@export var msaa := Viewport.MSAA_DISABLED
@export var update_mode := SubViewport.UPDATE_ALWAYS
@export var gimbal_tilt_deg := 0.0                   ## GIMBAL_LEVEL: + up, - down
@export var chase_offset := Vector3(0.0, 1.5, 5.0)   ## CHASE: in the heading frame, +Z = behind
@export var chase_look_ahead_m := 2.0
@export var chase_smooth_hz := 0.0                   ## 0 = rigid follow (no lag)

var viewport: SubViewport
var camera: Camera3D
var _yaw := 0.0


func _ready() -> void:
	process_priority = 1000          # run after whatever moves the vehicle this frame
	viewport = SubViewport.new()
	viewport.name = "View_" + camera_name
	viewport.size = image_size
	viewport.msaa_3d = msaa
	viewport.render_target_update_mode = update_mode
	add_child(viewport)              # shares the main World3D (own_world_3d = false)
	camera = Camera3D.new()
	camera.name = "Cam_" + camera_name
	camera.keep_aspect = Camera3D.KEEP_HEIGHT
	camera.fov = fov_v_deg
	camera.near = near
	camera.far = far
	viewport.add_child(camera)       # the camera of THIS viewport; parent is not a Node3D,
	camera.current = true            # so camera.transform is a world transform
	_update_camera(0.0)


func _process(delta: float) -> void:
	_update_camera(delta)


## Call after you move the vehicle yourself (e.g. in a test) to sync the camera immediately.
func sync_now() -> void:
	_update_camera(0.0)


func _update_camera(delta: float) -> void:
	var t := global_transform
	var fwd := -t.basis.z
	if Vector2(fwd.x, fwd.z).length() > 1e-3:   # keep the old heading when looking straight down
		_yaw = atan2(-fwd.x, -fwd.z)
	match mode:
		Mode.RIGID:
			camera.global_transform = t
		Mode.GIMBAL_LEVEL:
			camera.global_transform = Transform3D(
					Basis.from_euler(Vector3(deg_to_rad(gimbal_tilt_deg), _yaw, 0.0)), t.origin)
		Mode.CHASE:
			var heading := Basis(Vector3.UP, _yaw)
			var target_pos := t.origin + heading * chase_offset
			if chase_smooth_hz > 0.0 and delta > 0.0:
				var a := 1.0 - exp(-chase_smooth_hz * delta)
				target_pos = camera.global_position.lerp(target_pos, a)
			var look := t.origin + heading * Vector3(0.0, 0.0, -chase_look_ahead_m)
			camera.global_transform = Transform3D(Basis.IDENTITY, target_pos).looking_at(look, Vector3.UP)


func intrinsics() -> Dictionary:
	return CameraIntrinsics.from_camera(camera, viewport.size)


## Camera pose in the vehicle's frame right now (constant for RIGID rigs). The vehicle is the
## nearest ancestor with a mount() method (a Module 2 Vehicle), so a rig placed under a
## Marker3D mount still reports its pose in the body frame; otherwise the direct parent.
func body_from_camera() -> Transform3D:
	var p := get_parent()
	while p != null and not p.has_method("mount"):
		p = p.get_parent()
	if p == null:
		p = get_parent()
	var body := p as Node3D
	if body == null:
		return camera.global_transform
	return body.global_transform.affine_inverse() * camera.global_transform


func save_intrinsics(path: String) -> Error:
	return CameraIntrinsics.save_json(path, intrinsics(), camera_name, body_from_camera())


## CPU copy of the last rendered image (stalls until the GPU is done; see Module 7).
func get_image() -> Image:
	return viewport.get_texture().get_image()
