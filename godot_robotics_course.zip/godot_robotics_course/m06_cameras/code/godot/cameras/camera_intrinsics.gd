class_name CameraIntrinsics
extends RefCounted
## Pinhole intrinsics derived from a Godot Camera3D and its image size (Module 6).
##
## Godot convention: Camera3D.fov is VERTICAL when keep_aspect = KEEP_HEIGHT (the default).
##   fy = (H/2) / tan(fov_v/2),  fx = fy (square pixels),  cx = W/2,  cy = H/2
## Pixel coordinates: origin at the TOP-LEFT CORNER of the image, u to the right, v down.
## The pixel centre of column i is u = i + 0.5. This matches Camera3D.unproject_position().
##
## Optical frame used in the JSON (OpenCV style): x right, y down, z forward.
## Godot camera frame: x right, y up, looks along -Z. So x_cv = x, y_cv = -y, z_cv = -z.


static func h_from_v(fov_v_deg: float, width: int, height: int) -> float:
	var t := tan(deg_to_rad(fov_v_deg) / 2.0) * float(width) / float(height)
	return rad_to_deg(2.0 * atan(t))


static func v_from_h(fov_h_deg: float, width: int, height: int) -> float:
	var t := tan(deg_to_rad(fov_h_deg) / 2.0) * float(height) / float(width)
	return rad_to_deg(2.0 * atan(t))


## Intrinsics for camera `cam` rendering into an image of `size` pixels.
static func from_camera(cam: Camera3D, size: Vector2i) -> Dictionary:
	var w := float(size.x)
	var h := float(size.y)
	var fov_v: float
	var fov_h: float
	if cam.keep_aspect == Camera3D.KEEP_HEIGHT:
		fov_v = cam.fov
		fov_h = h_from_v(fov_v, size.x, size.y)
	else:
		fov_h = cam.fov
		fov_v = v_from_h(fov_h, size.x, size.y)
	var fy := (h / 2.0) / tan(deg_to_rad(fov_v) / 2.0)
	var fx := fy
	return {
		"model": "pinhole",
		"width": size.x,
		"height": size.y,
		"fov_v_deg": fov_v,
		"fov_h_deg": fov_h,
		"keep_aspect": "height" if cam.keep_aspect == Camera3D.KEEP_HEIGHT else "width",
		"fx": fx, "fy": fy, "cx": w / 2.0, "cy": h / 2.0,
		"K": [[fx, 0.0, w / 2.0], [0.0, fy, h / 2.0], [0.0, 0.0, 1.0]],
		"distortion": [0.0, 0.0, 0.0, 0.0, 0.0],
		"near_m": cam.near,
		"far_m": cam.far,
		"pixel_origin": "top-left corner, u right, v down, pixel centre at +0.5",
		"optical_frame": "x right, y down, z forward (OpenCV); Godot camera looks along -Z",
	}


## Project a point given in the CAMERA's local Godot frame (x right, y up, -z forward).
## Returns Vector2(u, v) in pixels. The caller must check p_cam.z < 0 (in front).
static func project_cam(intr: Dictionary, p_cam: Vector3) -> Vector2:
	var depth := -p_cam.z
	return Vector2(intr.cx + intr.fx * p_cam.x / depth, intr.cy - intr.fy * p_cam.y / depth)


## Same, for a WORLD point and the camera's global transform.
static func project_world(intr: Dictionary, cam_xform: Transform3D, p_world: Vector3) -> Vector2:
	return project_cam(intr, cam_xform.affine_inverse() * p_world)


## 4x4 row-major matrix as nested arrays (for JSON).
static func xform_to_rows(t: Transform3D) -> Array:
	var b := t.basis
	return [
		[b.x.x, b.y.x, b.z.x, t.origin.x],
		[b.x.y, b.y.y, b.z.y, t.origin.y],
		[b.x.z, b.y.z, b.z.z, t.origin.z],
		[0.0, 0.0, 0.0, 1.0],
	]


## Write intrinsics + extrinsics to JSON. `body_from_cam` is the camera pose in the vehicle
## (MODEL) frame, i.e. the mount transform. Pass Transform3D.IDENTITY if not on a vehicle.
static func save_json(path: String, intr: Dictionary, name: String, body_from_cam: Transform3D) -> Error:
	var d := intr.duplicate(true)
	d["camera"] = name
	d["T_body_cam_godot"] = xform_to_rows(body_from_cam)
	# Same mount, but for the OpenCV optical frame (x right, y down, z forward):
	var flip := Basis(Vector3(1, 0, 0), Vector3(0, -1, 0), Vector3(0, 0, -1))
	d["T_body_cam_cv"] = xform_to_rows(Transform3D(body_from_cam.basis * flip, body_from_cam.origin))
	d["T_body_cam_note"] = "4x4 row-major. Maps camera-frame points into the vehicle MODEL frame (x right, y up, z back). _godot: camera x right, y up, looks -z. _cv: x right, y down, looks +z."
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return FileAccess.get_open_error()
	f.store_string(JSON.stringify(d, "  ", false))
	f.close()
	return OK
