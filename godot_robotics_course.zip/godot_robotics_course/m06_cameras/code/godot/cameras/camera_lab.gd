extends Node3D
## Module 6 lab: camera rigs on a stand-in quad + the 1 m target board size check.
## Run WITH rendering (not --headless), from robosim/:  godot --path godot res://cameras/camera_lab.tscn
## Writes PNGs, intrinsics JSON and results.json to robosim/logs/camera_check/
## then quits. Analyse with:  python tools/measure_target.py logs/camera_check

const BOARD_SIZE := 1.0           # m, square red board
const BOARD_THICK := 0.02         # m

## (width, height, fov_v_deg, distance_m, right_m, up_m) for the FPV camera.
## right/up shift the board off the optical axis (in the camera frame).
const CASES := [
	[640, 360, 60.0, 5.0, 0.0, 0.0],
	[640, 360, 60.0, 10.0, 0.0, 0.0],
	[1280, 720, 60.0, 5.0, 0.0, 0.0],
	[1280, 720, 60.0, 10.0, 0.0, 0.0],
	[640, 360, 90.0, 5.0, 0.0, 0.0],
	[640, 360, 90.0, 10.0, 0.0, 0.0],
	[640, 360, 60.0, 5.0, 3.0, 1.0],
	[1280, 720, 60.0, 10.0, -4.0, -1.0],
]

var out_dir := ""
var vehicle: Node3D
var board: MeshInstance3D
var rigs := {}                    # name -> CameraRig


func _ready() -> void:
	out_dir = ProjectSettings.globalize_path("res://").path_join("../logs/camera_check").simplify_path()
	DirAccess.make_dir_recursive_absolute(out_dir)
	_build_world()
	_build_vehicle()
	_build_board()
	_build_ui()
	await _run()
	get_tree().quit()


func _build_world() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.55, 0.7, 0.9)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.6, 0.6, 0.6)
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50.0, 30.0, 0.0)
	sun.shadow_enabled = true
	add_child(sun)
	# Ground: 200 m checkerboard with 1 m squares (texture gives optical flow something to see)
	var img := Image.create(2, 2, false, Image.FORMAT_RGB8)
	img.set_pixel(0, 0, Color(0.45, 0.45, 0.45))
	img.set_pixel(1, 1, Color(0.45, 0.45, 0.45))
	img.set_pixel(1, 0, Color(0.3, 0.32, 0.3))
	img.set_pixel(0, 1, Color(0.3, 0.32, 0.3))
	var mat := StandardMaterial3D.new()
	mat.albedo_texture = ImageTexture.create_from_image(img)
	mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS
	mat.uv1_scale = Vector3(100.0, 100.0, 1.0)  # 2 px per UV unit -> 1 m squares on 200 m
	var plane := PlaneMesh.new()
	plane.size = Vector2(200.0, 200.0)
	var ground := MeshInstance3D.new()
	ground.mesh = plane
	ground.material_override = mat
	add_child(ground)


func _build_vehicle() -> void:
	vehicle = Node3D.new()                       # stand-in for your Module 2 quad scene
	vehicle.name = "Quad"
	vehicle.position = Vector3(0.0, 2.0, 0.0)    # 2 m above ground, nose toward -Z (north)
	add_child(vehicle)
	var body := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.4, 0.1, 0.4)
	body.mesh = bm
	vehicle.add_child(body)
	# Mounts. Each rig IS the mount: position + orientation in the vehicle MODEL frame.
	_add_rig("fpv", CameraRig.Mode.RIGID, Transform3D(Basis.IDENTITY, Vector3(0.0, 0.0, -0.25)))
	_add_rig("gimbal", CameraRig.Mode.GIMBAL_LEVEL, Transform3D(Basis.IDENTITY, Vector3(0.0, 0.0, -0.25)))
	_add_rig("down", CameraRig.Mode.RIGID,
			Transform3D(Basis.from_euler(Vector3(deg_to_rad(-90.0), 0.0, 0.0)), Vector3(0.0, -0.06, 0.0)))
	_add_rig("chase", CameraRig.Mode.CHASE, Transform3D.IDENTITY)


func _add_rig(n: String, m: CameraRig.Mode, mount: Transform3D) -> void:
	var r := CameraRig.new()
	r.name = "Rig_" + n
	r.camera_name = n
	r.mode = m
	r.transform = mount
	r.image_size = Vector2i(640, 360)
	r.fov_v_deg = 60.0 if n != "down" else 70.0
	vehicle.add_child(r)
	rigs[n] = r


func _build_board() -> void:
	board = MeshInstance3D.new()
	board.name = "TargetBoard"
	var bm := BoxMesh.new()
	bm.size = Vector3(BOARD_SIZE, BOARD_SIZE, BOARD_THICK)
	board.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1, 0, 0)
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED  # pure red: easy to segment
	board.material_override = mat
	add_child(board)


func _build_ui() -> void:
	var box := HBoxContainer.new()
	add_child(box)
	for n in ["fpv", "down", "chase"]:
		var tr := TextureRect.new()
		tr.texture = rigs[n].viewport.get_texture()
		tr.custom_minimum_size = Vector2(320, 180)
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		box.add_child(tr)


func _place_board(fpv: CameraRig, d: float, right := 0.0, up := 0.0) -> void:
	# Board parallel to the image plane, front face exactly d metres in front of the camera,
	# centre shifted right/up in the camera frame.
	var cam_t := fpv.global_transform
	var local := Vector3(right, up, -(d + BOARD_THICK / 2.0))
	board.global_transform = Transform3D(cam_t.basis, cam_t * local)


func _capture(rig: CameraRig, file: String) -> Image:
	rig.sync_now()
	await RenderingServer.frame_post_draw   # this frame's transforms are now drawn
	await RenderingServer.frame_post_draw   # one more, in case the change landed mid-frame
	var img := rig.get_image()
	img.save_png(out_dir.path_join(file))
	return img


func _run() -> void:
	var fpv: CameraRig = rigs["fpv"]
	var results := []
	for c in CASES:
		var w: int = c[0]
		var h: int = c[1]
		var fov: float = c[2]
		var d: float = c[3]
		fpv.viewport.size = Vector2i(w, h)
		fpv.camera.fov = fov
		_place_board(fpv, d, c[4], c[5])
		var file := "fpv_%dx%d_fov%d_d%d_x%d_y%d.png" % [w, h, int(fov), int(d), int(c[4]), int(c[5])]
		await _capture(fpv, file)
		var intr := fpv.intrinsics()
		var aabb := board.mesh.get_aabb()
		var gt := TargetBox.compute(intr, fpv.camera.global_transform, aabb, board.global_transform)
		var up := TargetBox.compute_unproject(fpv.camera, aabb, board.global_transform)
		var pred: float = intr.fy * BOARD_SIZE / d     # front face at distance d
		var row := {"file": file, "width": w, "height": h, "fov_v_deg": fov, "distance_m": d,
				"offset_right_m": c[4], "offset_up_m": c[5],
				"fx": intr.fx, "fy": intr.fy, "pred_w_px": pred,
				"box_w_px": gt.w_px, "box_h_px": gt.h_px, "box": [gt.x0, gt.y0, gt.x1, gt.y1],
				"unproject_w_px": up.w_px, "unproject_h_px": up.h_px,
				"unproject_box": [up.x0, up.y0, up.x1, up.y1]}
		results.append(row)
		print("%-34s fy=%7.2f pred=%6.2f box=%6.2fx%6.2f unproject=%6.2fx%6.2f" % [
				file, intr.fy, pred, gt.w_px, gt.h_px, up.w_px, up.h_px])
	# Reset FPV and save one image + intrinsics per rig, with the board 8 m ahead.
	fpv.viewport.size = Vector2i(640, 360)
	fpv.camera.fov = 60.0
	vehicle.rotation = Vector3.ZERO
	_place_board(fpv, 8.0)
	for n in rigs:
		await _capture(rigs[n], "%s.png" % n)
		rigs[n].save_intrinsics(out_dir.path_join("intrinsics_%s.json" % n))
	# Pitch the vehicle 15 deg nose-down and roll 10 deg: rigid FPV tilts, gimbal stays level.
	vehicle.rotation = Vector3(deg_to_rad(-15.0), 0.0, deg_to_rad(-10.0))
	await _capture(rigs["fpv"], "fpv_tilted.png")
	await _capture(rigs["gimbal"], "gimbal_tilted.png")
	vehicle.rotation = Vector3.ZERO
	var f := FileAccess.open(out_dir.path_join("results.json"), FileAccess.WRITE)
	f.store_string(JSON.stringify({"board_size_m": BOARD_SIZE, "cases": results}, "  ", false))
	f.close()
	print("wrote ", out_dir)
