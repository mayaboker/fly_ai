extends SceneTree
## Module 6 test (headless, no rendering needed):
##   godot --headless --path godot -s res://cameras/target_box_test.gd
## Compares TargetBox.compute() with a brute-force box: thousands of points sampled on the
## target's surface, kept if in front of the near plane, projected, min/max taken.

func _init() -> void:
	var cam := Camera3D.new()
	cam.fov = 60.0
	cam.near = 0.05
	var intr := CameraIntrinsics.from_camera(cam, Vector2i(640, 360))
	var cam_t := Transform3D.IDENTITY                     # camera at origin, looking along -Z
	var aabb := AABB(Vector3(-0.5, -0.5, -0.5), Vector3(1, 1, 1))
	var cases := {
		"in front":          Transform3D(Basis.IDENTITY, Vector3(0.3, -0.2, -4.0)),
		"rotated":           Transform3D(Basis.from_euler(Vector3(0.4, 0.7, 0.2)), Vector3(-1.0, 0.5, -6.0)),
		"straddles camera":  Transform3D(Basis.IDENTITY.scaled(Vector3(1, 1, 6)), Vector3(1.0, 0.3, -1.0)),
		"partly off-image":  Transform3D(Basis.IDENTITY, Vector3(4.5, 0.0, -5.0)),
		"behind":            Transform3D(Basis.IDENTITY, Vector3(0.0, 0.0, 5.0)),
	}
	var worst := 0.0
	for name in cases:
		var xf: Transform3D = cases[name]
		var a := TargetBox.compute(intr, cam_t, aabb, xf)
		var b := _brute(intr, aabb, xf)
		var err := 0.0
		if a.visible != b.visible:
			err = INF
		elif a.visible:
			err = maxf(maxf(absf(a.x0 - b.x0), absf(a.x1 - b.x1)), maxf(absf(a.y0 - b.y0), absf(a.y1 - b.y1)))
		worst = maxf(worst, err)
		print("%-18s visible=%-5s box=(%.1f, %.1f, %.1f, %.1f)  brute-force diff %.3f px" % [
				name, a.visible, a.x0, a.y0, a.x1, a.y1, err])
	print("PASS" if worst < 0.5 else "FAIL", " (worst %.3f px)" % worst)
	cam.free()
	quit()


func _brute(intr: Dictionary, aabb: AABB, xf: Transform3D) -> Dictionary:
	var lo := Vector2(INF, INF)
	var hi := Vector2(-INF, -INF)
	var n := 60
	for face in 6:
		var axis := face % 3
		var side := float(face / 3)
		for i in n + 1:
			for j in n + 1:
				var p := Vector3()
				p[axis] = side
				p[(axis + 1) % 3] = float(i) / n
				p[(axis + 2) % 3] = float(j) / n
				var w := xf * (aabb.position + p * aabb.size)
				if -w.z < intr.near_m:
					continue
				var uv := CameraIntrinsics.project_cam(intr, w)
				lo = lo.min(uv)
				hi = hi.max(uv)
	if lo.x == INF:
		return {"visible": false}
	lo = lo.clamp(Vector2.ZERO, Vector2(intr.width, intr.height))
	hi = hi.clamp(Vector2.ZERO, Vector2(intr.width, intr.height))
	if hi.x - lo.x <= 0.0 or hi.y - lo.y <= 0.0:
		return {"visible": false}
	return {"visible": true, "x0": lo.x, "y0": lo.y, "x1": hi.x, "y1": hi.y}
