class_name TargetBox
extends RefCounted
## Ideal ("ground truth") 2D bounding box of a 3D box seen by a camera (Module 6).
## Projects the 8 corners of the box; edges that cross the near plane are clipped there,
## so a target that is partly behind the camera still gets a correct box.
## No occlusion test: a target behind a wall still gets a box (Module 8 adds a ray check).

const _EDGES := [[0, 1], [0, 2], [0, 4], [1, 3], [1, 5], [2, 3], [2, 6], [3, 7],
		[4, 5], [4, 6], [5, 7], [6, 7]]


## The 8 world-space corners of `aabb` (in the local frame of `xform`).
static func corners(aabb: AABB, xform: Transform3D) -> Array[Vector3]:
	var out: Array[Vector3] = []
	for i in 8:
		out.append(xform * aabb.get_endpoint(i))
	return out


## Returns {visible, x0, y0, x1, y1, w_px, h_px, cx, cy}; cx, cy in -1..1 (protocol TARGET_BOX).
## Uses the pinhole intrinsics (pure math, works in --headless). The box is clamped to the image.
static func compute(intr: Dictionary, cam_xform: Transform3D, aabb: AABB, xform: Transform3D) -> Dictionary:
	var inv := cam_xform.affine_inverse()
	var near: float = intr.near_m
	var pc: Array[Vector3] = []
	for p in corners(aabb, xform):
		pc.append(inv * p)                       # camera frame: in front means z < -near
	var pts: Array[Vector2] = []
	for i in 8:
		if -pc[i].z >= near:
			pts.append(CameraIntrinsics.project_cam(intr, pc[i]))
	for e in _EDGES:                             # clip edges that cross the near plane
		var a: Vector3 = pc[e[0]]
		var b: Vector3 = pc[e[1]]
		if (-a.z >= near) != (-b.z >= near):
			var s := (-near - a.z) / (b.z - a.z)
			pts.append(CameraIntrinsics.project_cam(intr, a.lerp(b, s)))
	var res := {"visible": false, "x0": 0.0, "y0": 0.0, "x1": 0.0, "y1": 0.0,
			"w_px": 0.0, "h_px": 0.0, "cx": 0.0, "cy": 0.0}
	if pts.is_empty():
		return res
	var lo := pts[0]
	var hi := pts[0]
	for p in pts:
		lo = lo.min(p)
		hi = hi.max(p)
	var w: float = intr.width
	var h: float = intr.height
	lo = lo.clamp(Vector2.ZERO, Vector2(w, h))
	hi = hi.clamp(Vector2.ZERO, Vector2(w, h))
	if hi.x - lo.x <= 0.0 or hi.y - lo.y <= 0.0:
		return res                               # entirely outside the image
	res.visible = true
	res.x0 = lo.x
	res.y0 = lo.y
	res.x1 = hi.x
	res.y1 = hi.y
	res.w_px = hi.x - lo.x
	res.h_px = hi.y - lo.y
	res.cx = (lo.x + hi.x) / w - 1.0             # -1 = left edge, +1 = right edge
	res.cy = (lo.y + hi.y) / h - 1.0             # -1 = top edge,  +1 = bottom edge
	return res


## Same box using Godot's own Camera3D.unproject_position (needs a camera in a viewport).
## Only valid when all 8 corners are in front of the camera. Used to cross-check compute().
static func compute_unproject(cam: Camera3D, aabb: AABB, xform: Transform3D) -> Dictionary:
	var lo := Vector2(INF, INF)
	var hi := Vector2(-INF, -INF)
	for p in corners(aabb, xform):
		if cam.is_position_behind(p):
			return {"visible": false}
		var uv := cam.unproject_position(p)
		lo = lo.min(uv)
		hi = hi.max(uv)
	return {"visible": true, "x0": lo.x, "y0": lo.y, "x1": hi.x, "y1": hi.y,
			"w_px": hi.x - lo.x, "h_px": hi.y - lo.y}
