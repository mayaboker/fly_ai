# Module 6 reference code

Copy these into your `robosim/` project (paths mirror it):

| File | robosim path | What it is |
|---|---|---|
| `godot/cameras/camera_intrinsics.gd` | same | `CameraIntrinsics`: FOV conversions, K from a Camera3D, projection, JSON export |
| `godot/cameras/camera_rig.gd` | same | `CameraRig`: SubViewport + Camera3D, modes RIGID / GIMBAL_LEVEL / CHASE |
| `godot/cameras/target_box.gd` | same | `TargetBox`: ideal 2D box from 8 corners with near-plane clipping |
| `godot/cameras/camera_lab.gd` + `.tscn` | same | lab scene: rigs on a stand-in quad, 1 m board size check |
| `godot/cameras/target_box_test.gd` | same | headless test of `TargetBox` against brute force |
| `godot/cameras/artifacts_demo.gd` + `.tscn` | same | MSAA, depth precision and lighting measurements (sub-topics 03, 05) |
| `tools/measure_target.py` | same | counts red pixels, compares with prediction; exit code 1 on failure |
| `tools/camera_model.py` | same | loads the intrinsics JSON in Python; self-test against `cv2.projectPoints` |

## How to run

From `robosim/`, after copying:

```bash
godot --headless --path godot --import                                   # once, registers the classes
godot --headless --path godot -s res://cameras/target_box_test.gd        # no GPU needed
godot --path godot res://cameras/camera_lab.tscn                         # needs rendering
python tools/measure_target.py logs/camera_check
python tools/camera_model.py logs/camera_check
godot --path godot res://cameras/artifacts_demo.tscn                     # optional, prints tables
```

On a machine without a display, prefix the rendering runs with a virtual X server and use the OpenGL driver:

```bash
xvfb-run -a -s "-screen 0 1280x720x24" godot --path godot --rendering-driver opengl3 res://cameras/camera_lab.tscn
```

## What was verified

Tested with Godot 4.7.2-stable (official Linux build) and Python 3.11, numpy 2.4, OpenCV 4.13, on a 2-core Xeon VM **without a GPU**: rendering ran in the Compatibility renderer on Mesa llvmpipe (software) under Xvfb.

| Test | Result |
|---|---|
| `target_box_test.gd` (headless) | PASS, 0.000 px difference to brute force in all 5 cases |
| `camera_lab.tscn` + `measure_target.py` | PASS, worst 0.82 px (tolerance 1.5 px), 8 cases |
| `TargetBox.compute` vs `Camera3D.unproject_position` | max difference 3·10⁻⁵ px |
| `camera_model.py` (numpy and `cv2.projectPoints` vs Godot) | PASS, max difference 3·10⁻⁵ px |
| `artifacts_demo.tscn` | ran; its tables are in sub-topics 03 and 05 |
| Images | inspected by eye: FPV, downward, chase, tilted FPV vs gimbal all as described in lab.md |
| GDScript warnings | none printed |

## Not tested here

- The Forward+ and Mobile renderers on a real GPU. Geometry (box sizes, intrinsics) does not depend on the renderer. Pixel colours at edges, MSAA levels and the depth-precision table may differ: rerun `artifacts_demo.tscn` on your machine.
- The editor variant of step 8 (*Editable Children* on the `Quad` instance). The code variant (`_add_camera_rigs()` in the Module 2 `main.gd`) was run headless: it writes `intrinsics_fpv/down/chase.json` with `T_body_cam_godot` equal to the Module 2 mount offsets, e.g. down = pitched −90°, 4 cm below the CG. `CameraRig.body_from_camera()` reports the pose in the nearest ancestor `Vehicle`'s frame (anything with a `mount()` method), so a rig under a `Marker3D` mount still gets the body-frame extrinsics.
- Interactive editor use (adding `CameraRig` through *Add Child Node*). It is a normal `class_name` script, so it should appear after `--import`.
