# 04 Camera mounts and extrinsics

Intrinsics say how a camera turns rays into pixels. **Extrinsics** say where the camera is and which way it points. For a robot camera, the useful extrinsic is the mount: the camera pose in the vehicle's body frame, `T_body_cam`. It is fixed for a hard-mounted camera, and it is what you hand to a visual-odometry or target-tracking algorithm together with K. This page shows four mounts and how each one moves the camera.

## Mounts are Marker3D nodes

In Module 2 the vehicle generator placed `Marker3D` mounts on every vehicle (`Mounts/fpv_cam`, `Mounts/down_cam`, …), and Module 3 used the same idea for the test body's `FpvMount`. A `Marker3D` is just a `Node3D` with a gizmo, so its transform relative to the vehicle **is** `T_body_cam`, in the Godot MODEL frame (x right, y up, z back). The camera looks along the marker's −Z and "image up" is the marker's +Y.

Put a `CameraRig` as a child of the marker with an identity transform, or give the rig the marker's transform directly. Either way the rig's world transform is

```
T_world_cam = T_world_body · T_body_cam
```

and the rig copies it to its camera every frame (after the vehicle moved, thanks to `process_priority = 1000`). When it exports the mount, the rig looks up the tree for the vehicle (the nearest ancestor with a `mount()` method), so a rig under `Mounts/fpv_cam` still reports `T_body_cam` relative to the vehicle, not to the marker.

## Four mounts

| Mount | `CameraRig.mode` | Mount orientation | Moves with | Used for |
|---|---|---|---|---|
| Forward FPV (rigid) | `RIGID` | identity, or tilted up 10–30° on racing quads | full vehicle attitude | piloting, VIO, obstacle detection |
| Gimbal-level | `GIMBAL_LEVEL` | position from the mount; heading from the vehicle; roll = 0, pitch = `gimbal_tilt_deg` | position and heading only | mapping, inspection, smooth video |
| Downward (optical flow) | `RIGID` | rotated −90° about x | full attitude | optical-flow velocity, landing-pad detection |
| Chase | `CHASE` | behind and above, in the heading frame | position and heading, optionally smoothed | the human operator; not a sensor |

### Rigid FPV

The simplest case: the camera is bolted to the frame.

```gdscript
camera.global_transform = global_transform
```

When the quad pitches forward to accelerate, the camera pitches too and the horizon moves up in the image. That is realistic and it is what a VIO algorithm expects.

### Gimbal-level

A stabilised gimbal cancels roll and pitch but follows heading. The rig extracts the heading (yaw about world +Y) from its forward vector, then builds a level orientation:

```gdscript
var fwd := -t.basis.z
if Vector2(fwd.x, fwd.z).length() > 1e-3:      # keep the old heading when looking straight down
	_yaw = atan2(-fwd.x, -fwd.z)                # 0 = looking along world -Z (north)
camera.global_transform = Transform3D(
		Basis.from_euler(Vector3(deg_to_rad(gimbal_tilt_deg), _yaw, 0.0)), t.origin)
```

`Basis.from_euler` uses Godot's default YXZ order: yaw about Y first, then pitch about the new X. Positive `gimbal_tilt_deg` tilts the view up; −30 looks 30° down.

This is an **ideal** gimbal: no lag, no limits. A real gimbal has a response time and angle limits; add them if your algorithm cares.

In the lab, the quad was pitched 15° nose-down and rolled 10°. The rigid FPV image showed a horizon tilted by about 10° and moved up; the gimbal image showed a level horizon at the same height as when the quad was level.

### Downward (optical flow)

Point the camera's −Z at body −Y by rotating the mount −90° about x:

```gdscript
var down_mount := Transform3D(Basis.from_euler(Vector3(deg_to_rad(-90.0), 0.0, 0.0)),
		Vector3(0.0, -0.06, 0.0))         # 6 cm below the body centre
```

The exported `T_body_cam_godot` for this mount is

```
[[1,  0,  0,  0    ],
 [0,  0,  1, -0.06 ],
 [0, -1,  0,  0    ],
 [0,  0,  0,  1    ]]
```

Read it column by column: camera +X = body +X (right), camera +Y = body −Z (forward), camera +Z = body +Y (up). So the camera looks down and the **top of the image is the vehicle's forward direction**. Write that down; flow algorithms need it.

Two numbers decide whether optical flow works:

| Quantity | Formula | Example: h = 2 m, fy = 257 px (640×360, fov 70°), v = 5 m/s, 30 Hz |
|---|---|---|
| Ground sampling distance | h / fy | 7.8 mm per pixel |
| Image motion per frame | fy · v / (h · rate) | 21 px per frame |

Many flow algorithms track well only up to roughly 10–20 px per frame (an estimate; it depends on the algorithm and window size). At 5 m/s and 2 m altitude, 30 Hz is marginal. Raise the camera rate, fly higher or slower, or lower the resolution. Also note that the ground needs texture: a flat-coloured terrain gives no flow at all. The lab's ground is a 1 m checkerboard for this reason.

### Chase

A chase camera is for people. It sits behind and above the vehicle in the heading frame and looks a little ahead of it:

```gdscript
var heading := Basis(Vector3.UP, _yaw)
var target_pos := t.origin + heading * chase_offset          # e.g. (0, 1.5, 5): 5 m behind
if chase_smooth_hz > 0.0 and delta > 0.0:
	target_pos = camera.global_position.lerp(target_pos, 1.0 - exp(-chase_smooth_hz * delta))
var look := t.origin + heading * Vector3(0.0, 0.0, -chase_look_ahead_m)
camera.global_transform = Transform3D(Basis.IDENTITY, target_pos).looking_at(look, Vector3.UP)
```

The `1 - exp(-k·dt)` factor makes the smoothing independent of the frame rate. Never feed a smoothed camera to an algorithm: its pose is not a rigid function of the vehicle pose, so `T_body_cam` is meaningless for it.

## Exporting extrinsics

`CameraRig.save_intrinsics()` writes two versions of the mount next to K:

| Key | Camera axes | Use it with |
|---|---|---|
| `T_body_cam_godot` | x right, y up, looks along −z | Godot code, the course's wire frames |
| `T_body_cam_cv` | x right, y down, looks along +z | OpenCV, most VIO and SLAM code |

`T_body_cam_cv = T_body_cam_godot · diag(1, −1, −1)`. Both map camera-frame points into the vehicle MODEL frame. To get a camera pose in the world for ground truth, multiply the vehicle's world pose (from `pose.csv`, Godot frame) by `T_body_cam`. For a gimbal or chase camera the export is only a snapshot; log the camera's world pose per frame instead (Module 7 does this through `t_sim` and `pose_seq`).

## Try it

- Give the FPV mount a 20° up-tilt (`Basis.from_euler(Vector3(deg_to_rad(20), 0, 0))`). Export the JSON and check that the camera's −Z column has a positive y component.
- Fly the quad forward in a straight line with a fixed nose-down pitch (send poses from a small script, or set `vehicle.rotation` in the lab scene). Compare where the horizon sits in the FPV and gimbal images.
- Compute the image motion per frame for your downward camera at 1 m altitude and 3 m/s. Is 30 Hz enough by the 20 px rule?

## References

- Godot docs: [Marker3D](https://docs.godotengine.org/en/4.7/classes/class_marker3d.html), [Transform3D.looking_at](https://docs.godotengine.org/en/4.7/classes/class_transform3d.html), [Basis.from_euler](https://docs.godotengine.org/en/4.7/classes/class_basis.html)
- [Frames cheat sheet](../reference/frames.md) (MODEL frame, quaternion order)
- PX4 docs, [Optical flow](https://docs.px4.io/main/en/sensor/optical_flow.html) (how a real downward flow sensor is used)
