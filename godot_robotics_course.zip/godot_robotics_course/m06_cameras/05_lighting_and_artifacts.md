# 05 Lighting and visual artifacts

A rendered image is not a photograph. It has its own artifacts: jagged edges, shimmering textures, hard shadows, a tone curve someone chose. Vision code that works on rendered images can fail on real ones, and the reverse. You cannot remove the gap, but you can control it: know which artifacts your images have, switch them off for measurement tests, and switch them on (or randomise them) when you want robustness. This page measures a few of them.

All numbers here come from [artifacts_demo.gd](code/godot/cameras/artifacts_demo.gd) (Godot 4.7.2, Compatibility renderer, Mesa llvmpipe). Run it on your machine; a GPU renderer may give somewhat different values.

## Aliasing

A pixel is a sample at one point (its centre). An edge that crosses a pixel is either "in" or "out", so slanted edges come out as staircases. When the camera or the object moves, the steps jump from pixel to pixel. Fine repeating textures far away (a checkerboard ground near the horizon) produce moiré patterns that crawl as the camera moves; you can see this in the lab's chase image.

| Artifact | Where you see it | Effect on vision code |
|---|---|---|
| Staircase edges | slanted object outlines | edge and line detectors return jagged segments; corner positions jump by whole pixels |
| Edge crawling | moving camera | feature trackers jitter by ±0.5 px even when nothing moves in the world |
| Moiré on textures | distant fine textures | false optical flow; fake features near the horizon |

## MSAA

Multi-sample anti-aliasing tests coverage at several points per pixel and blends edge pixels. In Godot it is per viewport: `SubViewport.msaa_3d`. The demo renders a red 1 m board, rolled 20°, 10 m away, on black, at 640×360 / 60°:

| `msaa_3d` | Pure red pixels | Mixed (edge) pixels | Red area (sum of red fraction) |
|---|---:|---:|---:|
| disabled | 968 | 0 | 968.0 px |
| 2× | 924 | 96 | 973.0 px |
| 4× | 924 | 96 | 973.0 px |
| 8× | 924 | 96 | 973.0 px |

The ideal area is (fy · 1 / 10)² = 972.0 px. On llvmpipe, 2×, 4× and 8× produced identical images. On a GPU, expect more distinct blend levels at 4× and 8×; check your own numbers.

What it means for you:

- **With MSAA off**, every pixel is pure object or pure background. Colour thresholds are exact, and pixel counts are integers. Use this for measurement tests like this module's lab.
- **With MSAA on**, edge pixels are mixtures. The *area* gets closer to the truth (973 vs 972 instead of 968), so sub-pixel methods (centroids, edge fitting) get more accurate. But a strict colour threshold now loses the 96 edge pixels.
- Avoid **TAA** (temporal anti-aliasing, `use_taa`) for robot cameras. It blends the current frame with previous frames, so moving objects leave ghosts and a frame is no longer a function of one pose. FXAA (`screen_space_aa`) is a single-frame blur filter: harmless for timing, but it softens texture detail that feature detectors need.

## Lighting and shading

A lit material's colour depends on the light. The demo shows a red board (albedo exactly (1, 0, 0)) facing the camera at 5 m, lit by a directional light:

| Sun direction vs board normal | Light energy | Centre pixel (RGB8) |
|---|---:|---|
| head-on (0°) | 1.0 | (255, 25, 25) |
| 60° off | 1.0 | (191, 19, 19) |
| 80° off | 1.0 | (130, 10, 10) |
| head-on | 0.3 | (150, 10, 10) |

Two lessons. First, the red channel halves when the light swings round; a fixed threshold like `R > 200` would lose the board. Second, even green and blue are not zero, because the default material also reflects some light specularly. For tests where you segment by colour, use an **unshaded** material:

```gdscript
var mat := StandardMaterial3D.new()
mat.albedo_color = Color(1, 0, 0)
mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED   # pixel = albedo, whatever the light
```

That is what the lab's board uses, and why its pixels are exactly (255, 0, 0).

## Shadows

`DirectionalLight3D.shadow_enabled = true` gives hard, moving shadows. They help depth perception for people. For algorithms they are a mixed blessing:

- Shadow edges are strong image edges that do not belong to any object. Segmentation and line detectors pick them up.
- A shadow moves when the sun moves. A static scene with a moving sun is a classic way to break place recognition.
- The vehicle's own shadow moves with the vehicle. A downward flow camera may track it and report zero motion. The lab's downward image shows the quad's shadow at the top edge.
- Shadows cost render time. In Module 7, under the software renderer, turning shadows off raised the 640×360 capture rate from 20–22 to 30 frames per second.

## Exposure and tone mapping

A real camera adjusts exposure; Godot can too, through the `Environment` (tone mapper, glow, adjustments) and `Camera3D.attributes` (`CameraAttributesPractical` with auto-exposure). For robot cameras:

| Setting | For repeatable tests | For realism / robustness |
|---|---|---|
| Tone mapper (`Environment.tonemap_mode`) | Linear (the default) | Filmic/ACES/AgX if you match a real camera's look |
| Auto exposure (`CameraAttributesPractical.auto_exposure_enabled`) | off | on, so the image darkens and brightens like a real camera |
| Glow, fog, adjustments | off | on, randomised per run |

A camera in a `SubViewport` that shares the main `World3D` also shares its `WorldEnvironment`. The Module 1/2 main scene uses *Filmic*, so robot cameras placed there are tone-mapped too; the lab scene builds its own environment with the default (Linear). Decide which one your measurements need, and write it into `run.json`.

Auto exposure makes a pixel value depend on everything else in the frame, and it adapts over several frames. That is realistic, but your test results then depend on history. Keep it off until a module asks for it.

## The general approach

1. **Measurement tests** (this module's lab, Module 8's ground truth): unshaded targets, MSAA off, no shadows on the target, linear tone mapping, no auto exposure. You want the image to match the geometry exactly.
2. **Algorithm development**: realistic lighting, MSAA 2×–4×, shadows on.
3. **Robustness**: randomise sun angle and energy, ground texture, exposure, and add noise in Python. This is *domain randomization*, and it is cheap once your pipeline logs every setting with the run (Module 5 log format: put them in `run.json`).

## Try it

- Run the lab scene with `msaa = Viewport.MSAA_4X` on the FPV rig. Does `measure_target.py` still pass? Which threshold would you change?
- Change the board to a lit material and run the size check at sun angles 0° and 70°. At which angle does the red threshold (R > 200) start missing pixels?
- Look at the chase image with and without mipmaps on the ground texture (`texture_filter = TEXTURE_FILTER_NEAREST` vs `TEXTURE_FILTER_NEAREST_WITH_MIPMAPS`). Describe the difference near the horizon.

## References

- Godot docs: [3D antialiasing](https://docs.godotengine.org/en/4.7/tutorials/3d/3d_antialiasing.html)
- Godot docs: [3D lights and shadows](https://docs.godotengine.org/en/4.7/tutorials/3d/lights_and_shadows.html)
- Godot docs: [Environment and post-processing](https://docs.godotengine.org/en/4.7/tutorials/3d/environment_and_post_processing.html)
- Tobin et al., *Domain Randomization for Transferring Deep Neural Networks from Simulation to the Real World*, IROS 2017
