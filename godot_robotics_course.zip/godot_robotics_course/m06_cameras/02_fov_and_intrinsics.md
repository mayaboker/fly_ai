# 02 Field of view and pinhole intrinsics

A vision algorithm does not know what "FOV 60" means. It needs the camera matrix **K**: focal lengths `fx`, `fy` in pixels and the principal point `cx`, `cy`. This page derives K from Godot's camera settings, so that every image you export comes with numbers a Python or OpenCV program can use directly.

## Godot's FOV is vertical

`Camera3D.fov` is one angle, but an image has two. Which one it means depends on `keep_aspect`:

| `keep_aspect` | `fov` means | When the window gets wider |
|---|---|---|
| `KEEP_HEIGHT` (**default**) | vertical angle | you see more on the sides |
| `KEEP_WIDTH` | horizontal angle | you see less at the top and bottom |

The course uses the default everywhere: **`fov` is vertical**. Many camera datasheets and games quote the horizontal (or diagonal) angle instead, so you will convert often.

## Converting horizontal ↔ vertical

The image plane is a rectangle W × H pixels. Put it at distance *f* from the pinhole. Half the width subtends half the horizontal angle, half the height half the vertical angle:

```
          image plane
   ┌──────────────────────┐   ▲
   │                      │   │ H/2 = f · tan(fov_v / 2)
   │           ●──────────┼───┘
   │      (cx, cy)        │
   └──────────────────────┘
               ◀──────────▶
               W/2 = f · tan(fov_h / 2)
```

Divide the two lines and *f* cancels:

```
tan(fov_h / 2) = tan(fov_v / 2) · W / H
fov_h = 2 · atan( tan(fov_v / 2) · W / H )
fov_v = 2 · atan( tan(fov_h / 2) · H / W )
```

Note the `tan`. You cannot scale the angles by W/H directly: 60° × 16/9 = 106.7°, but the real answer is 91.5°.

| Image | `fov` (vertical) | Horizontal FOV |
|---|---:|---:|
| 640×360 (16:9) | 60° | 91.49° |
| 1280×720 (16:9) | 60° | 91.49° |
| 640×480 (4:3) | 60° | 75.18° |
| 640×360 (16:9) | 70° | 102.45° |
| 640×480: a camera sold as "90° horizontal" | **73.74°** | 90° |

So to simulate a camera with a 90° horizontal FOV at 640×480, set `fov = 73.74`.

## The pinhole model

A point in front of the camera at (X, Y, Z) in the **optical frame** (x right, y down, z forward, the OpenCV convention) lands on pixel

```
u = fx · X / Z + cx
v = fy · Y / Z + cy
```

or, with the camera matrix,

```
    ┌ fx   0  cx ┐
K = │  0  fy  cy │        [u v 1]ᵀ ∝ K · [X Y Z]ᵀ
    └  0   0   1 ┘
```

From the figure above, `H/2 = fy · tan(fov_v/2)`. That gives the course's formula:

```
fy = (H / 2) / tan(fov_v / 2)
fx = fy                (Godot renders square pixels)
cx = W / 2
cy = H / 2
```

| Image | `fov` | fx = fy (px) |
|---|---:|---:|
| 640×360 | 60° | 311.77 |
| 1280×720 | 60° | 623.54 |
| 640×360 | 90° | 180.00 |
| 640×360 | 70° | 257.07 |

## Where (0, 0) is

Both Godot (`unproject_position`, `Image.get_pixel`) and OpenCV put (0, 0) at the **top-left corner** of the top-left pixel. The centre of pixel column *i* is at u = *i* + 0.5. The image centre is therefore exactly (W/2, H/2), which is why `cx = W/2` and not `(W−1)/2`. The lab confirms this: the measured centre of the rendered board matched the projected centre with 0.00 px error for every centred case.

## Godot camera frame vs optical frame

Godot's camera looks along its own −Z with +Y up. OpenCV's optical frame looks along +Z with +Y down. Same x. So:

```
x_cv =  x_godot
y_cv = −y_godot
z_cv = −z_godot          (depth = −z_godot, positive in front)
```

In Godot you can therefore project a point that is already in the camera's local frame like this ([camera_intrinsics.gd](code/godot/cameras/camera_intrinsics.gd)):

```gdscript
static func project_cam(intr: Dictionary, p_cam: Vector3) -> Vector2:
	var depth := -p_cam.z
	return Vector2(intr.cx + intr.fx * p_cam.x / depth, intr.cy - intr.fy * p_cam.y / depth)
```

## Deriving and exporting intrinsics

`CameraIntrinsics.from_camera()` handles both `keep_aspect` modes, so it stays right even if someone changes the setting:

```gdscript
static func from_camera(cam: Camera3D, size: Vector2i) -> Dictionary:
	var w := float(size.x)
	var h := float(size.y)
	var fov_v: float
	var fov_h: float
	if cam.keep_aspect == Camera3D.KEEP_HEIGHT:
		fov_v = cam.fov
		fov_h = h_from_v(fov_v, size.x, size.y)
	else:
		fov_h = cam.fov
		fov_v = v_from_h(fov_h, size.x, size.y)
	var fy := (h / 2.0) / tan(deg_to_rad(fov_v) / 2.0)
	var fx := fy
	return {"model": "pinhole", "width": size.x, "height": size.y,
		"fov_v_deg": fov_v, "fov_h_deg": fov_h,
		"fx": fx, "fy": fy, "cx": w / 2.0, "cy": h / 2.0,
		"K": [[fx, 0.0, w / 2.0], [0.0, fy, h / 2.0], [0.0, 0.0, 1.0]],
		"distortion": [0.0, 0.0, 0.0, 0.0, 0.0],
		"near_m": cam.near, "far_m": cam.far}    # (the real file adds notes on conventions)
```

**Export it with every camera, every time.** The intrinsics depend on the image size, and the image size is the setting people change most casually. `CameraRig.save_intrinsics(path)` writes the dictionary plus the mount transform (sub-topic 04) to JSON. A shortened example, written by the lab for the downward camera:

```json
{
  "model": "pinhole", "width": 640, "height": 360,
  "fov_v_deg": 70.0, "fov_h_deg": 102.447857777988,
  "fx": 257.066641213581, "fy": 257.066641213581, "cx": 320.0, "cy": 180.0,
  "K": [[257.07, 0.0, 320.0], [0.0, 257.07, 180.0], [0.0, 0.0, 1.0]],
  "distortion": [0.0, 0.0, 0.0, 0.0, 0.0],
  "near_m": 0.05, "far_m": 2000.0,
  "camera": "down",
  "T_body_cam_godot": [[1,0,0,0],[0,0,1,-0.06],[0,-1,0,0],[0,0,0,1]],
  "T_body_cam_cv": "…"
}
```

`distortion` is all zeros because Godot renders an ideal pinhole image. A real lens is not ideal; if you want lens distortion, add it in post-processing (Python, with `cv2.remap`) and keep these zeros as the "undistorted" model.

## Reading it in Python

[code/tools/camera_model.py](code/tools/camera_model.py) loads the JSON and projects points:

```python
from camera_model import CameraModel
cam = CameraModel.load("logs/camera_check/intrinsics_fpv.json")
print(cam.K)
uv = cam.project_cv([[0.5, -0.5, 5.0]])     # optical frame: 0.5 m right, 0.5 m up, 5 m ahead
print(uv)                                   # [[351.18 148.82]] at 640x360, fov 60
```

Its self-test re-projects every board from the lab with numpy and with `cv2.projectPoints` and compares with the box Godot computed. In the reference run the largest difference was 3·10⁻⁵ px, which is float32 rounding.

## Resolution vs FOV

Two knobs change how big things look, and they are easy to confuse:

| You change | fx | Horizontal FOV | A 1 m board at 10 m |
|---|---|---|---|
| 640×360 → 1280×720, same `fov` | doubles (311.8 → 623.5) | same (91.5°) | 31 px → 62 px: same view, more pixels on it |
| `fov` 60° → 90°, same size | drops (311.8 → 180.0) | wider (91.5° → 121.3°) | 31 px → 18 px: more scene, fewer pixels per metre |

Rule of thumb: **pixels on target = fx · size / distance**. Resolution raises fx without changing what you see. A wider FOV shows more of the world but lowers fx. A detector that needs 20 px on a 1 m target sees it out to fx · 1 / 20 metres: 15.6 m at 640×360 / 60°, 31.2 m at 1280×720 / 60°, 9.0 m at 640×360 / 90°.

## Try it

- Compute by hand the `fov` you need in Godot to match a camera with fx = fy = 615 px at 640×480. (Answer: `fov_v = 2·atan(240/615) = 42.64°`.) Set it and check the exported JSON.
- Switch a camera to `KEEP_WIDTH` with `fov = 90` at 640×360 and export the JSON. Which angle is 90 now, and what is fy?
- Use the rule of thumb to find the distance at which the 1 m board is 10 px wide at 1280×720 / 60°. Check it in the lab scene.

## References

- Godot docs: [Camera3D](https://docs.godotengine.org/en/4.7/classes/class_camera3d.html) (`fov`, `keep_aspect`, `get_camera_projection`)
- OpenCV docs: [Camera calibration and 3D reconstruction](https://docs.opencv.org/4.x/d9/d0c/group__calib3d.html) (the pinhole model and `projectPoints`)
- Hartley and Zisserman, *Multiple View Geometry*, chapter 6 (camera models)
