# 06 Ideal target detection: ground-truth boxes

A simulator knows where everything is. So it can tell you, for every frame, where a target *should* appear in the image: an ideal detector with no false positives, no misses and no noise. You need that ground truth to score a real detector (intersection-over-union, centre error, miss rate) and to drive controllers before any vision code exists. This page builds it from the 8 corners of the target's bounding box.

## The idea

```
   3D box (8 corners)                  image
        4───────5                ┌──────────────────────┐
       /│      /│                │     x0          x1   │
      0───────1 │    project     │  y0 ┌──────────┐     │
      │ 6─────│─7   ────────▶    │     │  ·  ·    │     │
      │/      │/                 │     │ ·    ·   │     │
      2───────3                  │  y1 └──────────┘     │
                                 └──────────────────────┘
   box = min/max of the projected corners, clamped to the image
```

1. Take the target's local `AABB` (for a mesh: `mesh.get_aabb()`) and its world transform.
2. Transform the 8 corners into the camera frame.
3. Project each corner with the pinhole model (sub-topic 02).
4. Take the minimum and maximum u and v. Clamp to the image.

For a box-shaped target this is exact. For other shapes it is conservative: the box of the projected AABB is at least as big as the box of the real silhouette.

## The near-plane trap

Step 3 breaks when a corner is **behind** the camera. Its depth is negative, so `X/Z` flips sign and the corner lands on the wrong side of the image. `unproject_position` has the same problem, which is why Godot also offers `is_position_behind()`.

Simply dropping corners behind the camera is also wrong. Picture a long truck passing beside you: its rear corners are behind the camera, but its side still fills half the image. The right answer is to **clip** each of the box's 12 edges at the near plane and project the clip points too:

```
   behind │ in front                     edge a──b crosses the near plane z = −near:
          │                              s = (−near − a.z) / (b.z − a.z)
     a ●──┼──────● b                     p = a + s · (b − a)       ← project p, not a
          │
        near plane
```

## The code

[target_box.gd](code/godot/cameras/target_box.gd), core part:

```gdscript
static func compute(intr: Dictionary, cam_xform: Transform3D, aabb: AABB, xform: Transform3D) -> Dictionary:
	var inv := cam_xform.affine_inverse()
	var near: float = intr.near_m
	var pc: Array[Vector3] = []
	for p in corners(aabb, xform):
		pc.append(inv * p)                       # camera frame: in front means z < -near
	var pts: Array[Vector2] = []
	for i in 8:
		if -pc[i].z >= near:
			pts.append(CameraIntrinsics.project_cam(intr, pc[i]))
	for e in _EDGES:                             # clip edges that cross the near plane
		var a: Vector3 = pc[e[0]]
		var b: Vector3 = pc[e[1]]
		if (-a.z >= near) != (-b.z >= near):
			var s := (-near - a.z) / (b.z - a.z)
			pts.append(CameraIntrinsics.project_cam(intr, a.lerp(b, s)))
	# ... min/max over pts, clamp to [0, W] x [0, H], visible = box has area
```

It returns `{visible, x0, y0, x1, y1, w_px, h_px, cx, cy}`, where `cx`, `cy` are the box centre scaled to −1…1 (−1 = left/top edge, +1 = right/bottom edge: **+cx right, +cy down**, the image convention that [protocol.md](../reference/protocol.md) fixes for `TARGET_BOX`). Those last five values are exactly the `TARGET_BOX` sensor of the [bridge protocol](../reference/protocol.md): `visible, cx, cy, w_px, h_px`.

It uses only the intrinsics dictionary and transforms, so it also runs in `--headless` mode, with no rendering at all.

## Testing it

Two tests come with the code:

1. **Against the renderer** (the lab): for the 1 m board, the box matched the red pixels to within 0.82 px in size and 0.30 px in centre over 8 cases.
2. **Against brute force** ([target_box_test.gd](code/godot/cameras/target_box_test.gd), headless): sample 22 000 points on the box's surface, keep those in front of the near plane, project them, take min/max. Reference output:

```
in front           visible=true  box=(302.2, 153.3, 391.3, 242.4)  brute-force diff 0.000 px
rotated            visible=true  box=(232.2, 120.0, 306.0, 193.3)  brute-force diff 0.000 px
straddles camera   visible=true  box=(359.0, 0.0, 640.0, 360.0)  brute-force diff 0.000 px
partly off-image   visible=true  box=(546.7, 145.4, 640.0, 214.6)  brute-force diff 0.000 px
behind             visible=false box=(0.0, 0.0, 0.0, 0.0)  brute-force diff 0.000 px
PASS (worst 0.000 px)
```

Run it with `godot --headless --path godot -s res://cameras/target_box_test.gd`.

## What "ideal" leaves out

| Real detector effect | The ideal box | How to add it (later) |
|---|---|---|
| Occlusion by terrain, buildings, other vehicles | ignores it | ray casts from the camera to the corners or centre (Module 8) |
| Too small or too far to detect | always reports it | drop boxes with `w_px` below a threshold |
| Bad lighting, motion blur | ignores them | drop or jitter boxes by a randomised rule |
| Pixel noise in the box edges | exact | add Gaussian noise in Python, keep the truth column (logging rule 2) |

We met the first row while writing the lab. An off-axis test board placed 2 m below the camera was half under the ground. The ideal box said 62.8 × 62.5 px; the rendered red area was 63 × 32 px, because the ground hid the lower half. That is not a bug in the box. It is the reason Module 8 adds an occlusion check.

## Sending it to the physics side

The camera pose comes from a vehicle pose with a sim time. Tag the box with that time, so the physics process can match it to its own state (the protocol's rule for viewer → physics data):

```gdscript
var gt := TargetBox.compute(rig.intrinsics(), rig.camera.global_transform,
		board.mesh.get_aabb(), board.global_transform)
bridge.send_sensor(t_sim_of_pose, 2, RsProtocol.SENSOR_TARGET_BOX,
		PackedFloat32Array([1.0 if gt.visible else 0.0, gt.cx, gt.cy, gt.w_px, gt.h_px]))
```

Module 8 turns this into a proper sensor node.

## Try it

- Make the board 3 m × 0.2 m (a "pole") and roll it 45°. Compare the ideal box with the red pixel box. Why is the ideal box bigger now?
- Move the board so it straddles the image's left edge. Check that `cx` approaches −1 and `w_px` shrinks smoothly as it leaves.
- Write the naive version (project all 8 corners, no clipping) and run the "straddles camera" case. What box does it produce?

## References

- Godot docs: [Camera3D.is_position_behind](https://docs.godotengine.org/en/4.7/classes/class_camera3d.html), [AABB](https://docs.godotengine.org/en/4.7/classes/class_aabb.html)
- [Bridge protocol](../reference/protocol.md), sensor 3 `TARGET_BOX`
- Padilla et al., *A Survey on Performance Metrics for Object-Detection Algorithms*, 2020 (IoU and friends)
