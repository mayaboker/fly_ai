# 03 Checking projection; near, far and depth precision

You now have a formula for K. Before trusting it with an algorithm, check it against what Godot actually does. Godot gives you its own projection function, `Camera3D.unproject_position()`. If your intrinsics and Godot disagree, one of them has a bug, and it is usually yours. This page also covers the two camera settings that silently change what gets drawn: `near` and `far`.

## Godot's projection helpers

| Method | Input | Output | Use |
|---|---|---|---|
| `unproject_position(world_point)` | 3D world point | 2D pixel in the camera's viewport | world → pixel, the check below |
| `is_position_behind(world_point)` | 3D world point | bool | `unproject_position` gives nonsense for points behind the camera |
| `project_ray_origin(pixel)` / `project_ray_normal(pixel)` | 2D pixel | 3D ray | pixel → world (clicking, ray casts from pixels) |
| `project_position(pixel, depth)` | pixel + depth | 3D world point | pixel + depth → world |
| `get_camera_projection()` | — | `Projection` (4×4) | the full GPU projection matrix |

The pixel coordinates use the viewport the camera renders into. For a camera inside a 640×360 `SubViewport`, `unproject_position` returns values in 0…640 × 0…360, with (0, 0) at the top-left corner.

## The check

Project one point both ways and compare:

```gdscript
var intr := CameraIntrinsics.from_camera(cam, sub.size)
var p := Vector3(0.5, 0.5, -5.0)                       # a world point
var a := cam.unproject_position(p)                     # Godot
var b := CameraIntrinsics.project_world(intr, cam.global_transform, p)   # our pinhole math
print(a, " ", b, " diff ", a.distance_to(b))
```

`TargetBox.compute_unproject()` in [target_box.gd](code/godot/cameras/target_box.gd) does this for all 8 corners of the target. In the lab (8 cases: two resolutions, two FOVs, distances of 5 m and 10 m, two off-axis positions) the boxes from `unproject_position` and from the pinhole formula agreed to 3·10⁻⁵ px. That is float rounding, so the formula `fy = (H/2)/tan(fov_v/2)`, `cx = W/2` is exactly what Godot renders.

The third check is the pixels themselves. The lab renders the board, counts red pixels, and compares. Here are the reference numbers (board 1 m × 1 m, front face at distance d):

| Image, fov | d | fy | Predicted fy·1/d | `unproject_position` box | Red pixels (w × h) |
|---|---:|---:|---:|---:|---:|
| 640×360, 60° | 5 m | 311.77 | 62.35 | 62.35 | 62 × 62 |
| 640×360, 60° | 10 m | 311.77 | 31.18 | 31.18 | 32 × 32 |
| 1280×720, 60° | 5 m | 623.54 | 124.71 | 124.71 | 124 × 124 |
| 1280×720, 60° | 10 m | 623.54 | 62.35 | 62.35 | 62 × 62 |
| 640×360, 90° | 5 m | 180.00 | 36.00 | 36.00 | 36 × 36 |
| 640×360, 90° | 10 m | 180.00 | 18.00 | 18.00 | 18 × 18 |

Why 32 px for a 31.18 px board? The rasterizer colours a pixel when the triangle covers the pixel's **centre**. The board spans u = 304.41 … 335.59. Pixel centres 304.5, 305.5, …, 335.5 are inside: that is 32 pixels. So a counted width can be up to 1 px larger or smaller than the true width. A tolerance below 1 px is not achievable without anti-aliasing and sub-pixel edge fitting.

## Near and far

Godot draws only what lies between the `near` and `far` planes:

```
 camera ●──near──┬────────────── visible ──────────────┬── far ── (not drawn)
                 │                                     │
           too close: clipped                    too far: clipped
```

| Setting | Too small | Too large |
|---|---|---|
| `near` (default 0.05 m) | distant surfaces flicker (z-fighting, below) | the vehicle's own nose, or a close obstacle, gets cut away |
| `far` (default 4000 m) | terrain and sky objects disappear at a hard line | little effect on precision (see below), some wasted work |

A robot camera should see its own airframe only if the real one does, so put the mount just outside the body, or set `near` to clear it. For a 2 m drone FPV, `near = 0.05`–`0.1` m is reasonable. For a chase camera 5 m behind the vehicle, `near = 0.5` m is fine. For a fixed-wing flying at 300 m with terrain to the horizon, `far` = 5000–10000 m.

## Depth precision

The GPU keeps one depth value per pixel to decide which surface is in front. It has a fixed number of bits, and they are not spread evenly over distance: the spacing between representable depths grows roughly with **z² / near**. Far away, two surfaces a few centimetres apart can map to the same depth value. Then the GPU cannot tell which is in front, and the winner changes from pixel to pixel and frame to frame. That is **z-fighting**.

You can see it with [artifacts_demo.gd](code/godot/cameras/artifacts_demo.gd): a red board 1 cm in front of a blue board, both scaled so they stay about 31 px wide, at increasing distance. The table shows how much of the board came out red (red is correct):

| near | far | 50 m | 100 m | 200 m | 400 m | 600 m | 800 m |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 0.01 | 5000 | 100 % | **0 %** | 100 % | 100 % | **0 %** | **0 %** |
| 0.05 | 2000 | 100 % | **0 %** | 100 % | **0 %** | **0 %** | **0 %** |
| 0.5 | 2000 | 100 % | 100 % | 100 % | **0 %** | **0 %** | **0 %** |
| 1.0 | 1000 | 100 % | 100 % | 100 % | 100 % | 100 % | **0 %** |
| 0.05 | 900 | 100 % | **0 %** | 100 % | **0 %** | **0 %** | **0 %** |

Measured with Godot 4.7.2's Compatibility renderer on Mesa llvmpipe. On a GPU with the Forward+ renderer the exact pattern will differ; run the demo and fill in your own table.

What to read from it:

- The results are not a smooth decline. They jump between 0 % and 100 %. That is the signature of z-fighting: whether the two depths land in the same bucket is close to chance.
- **`near` matters far more than `far`.** Changing far from 2000 to 900 m with near = 0.05 changed nothing. Raising near from 0.05 to 1.0 m pushed the first failure from 100 m to 800 m.
- A 1 cm gap is small, but real scenes have gaps like that: a road mesh lying on terrain, a decal on a wall, a landing pad on the ground.

What to do:

1. Set `near` as large as your scene allows. Each camera has its own.
2. Do not lay flat meshes exactly on other meshes. Lift road and pad meshes a few centimetres, or carve them into the terrain mesh.
3. If you need far views and close-ups at once (a plane landing), use two cameras or adjust `near` with altitude.
4. For a depth *sensor*, do not read the depth buffer at all: cast rays (Module 8), which are exact.

## Try it

- In the lab scene, set the FPV camera's `near` to 3 m and render the board at 5 m and at 2 m. What happens at 2 m?
- Run `artifacts_demo.tscn` on your machine. Compare your depth table with the one above. Is your renderer Forward+, Mobile or Compatibility? (*Project → Project Settings → Rendering → Renderer*.)
- Use `project_ray_normal(Vector2(320, 180))` on a 640×360 camera. Which direction is it, in the camera frame? Then try pixel (0, 180): the angle to the optical axis should be `fov_h / 2`.

## References

- Godot docs: [Camera3D](https://docs.godotengine.org/en/4.7/classes/class_camera3d.html) (`unproject_position`, `project_ray_normal`, `near`, `far`)
- Nathan Reed, [Depth precision visualized](https://developer.nvidia.com/content/depth-precision-visualized) (why near dominates, and reversed-Z)
