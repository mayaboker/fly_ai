# Lab 6: Camera rigs and the 1 m board check (2.25 h)

You will give the quad three cameras, export their intrinsics, and then test the camera model the way you would test a real camera: put a target of known size at known distances, predict its size in pixels, measure it in the image, and compare.

## Files

| robosim path | Status | From |
|---|---|---|
| `godot/cameras/camera_intrinsics.gd` | new | [code/godot/cameras/](code/godot/cameras/camera_intrinsics.gd) |
| `godot/cameras/camera_rig.gd` | new | [code/godot/cameras/](code/godot/cameras/camera_rig.gd) |
| `godot/cameras/target_box.gd` | new | [code/godot/cameras/](code/godot/cameras/target_box.gd) |
| `godot/cameras/camera_lab.gd`, `camera_lab.tscn` | new (test scene) | [code/godot/cameras/](code/godot/cameras/camera_lab.gd) |
| `godot/cameras/target_box_test.gd` | new (headless test) | [code/godot/cameras/](code/godot/cameras/target_box_test.gd) |
| `godot/cameras/artifacts_demo.gd`, `artifacts_demo.tscn` | new (sub-topics 03, 05) | [code/godot/cameras/](code/godot/cameras/artifacts_demo.gd) |
| `tools/measure_target.py`, `tools/camera_model.py` | new | [code/tools/](code/tools/measure_target.py) |
| `godot/main.gd` | changed: rigs added under the quad's mount markers | step 8 |

Try writing `camera_rig.gd` yourself from sub-topics 01 and 04 before you copy it. The other files are mostly bookkeeping.

## Step 1: Copy and import

From the `robosim/` folder:

```bash
mkdir -p godot/cameras tools
cp <course>/m06_cameras/code/godot/cameras/* godot/cameras/
cp <course>/m06_cameras/code/tools/*.py tools/
godot --headless --path godot --import        # registers CameraRig, CameraIntrinsics, TargetBox
```

## Step 2: Run the headless projection test

This needs no GPU. It checks the box math against brute force:

```bash
godot --headless --path godot -s res://cameras/target_box_test.gd
```

Expected: five lines and `PASS (worst 0.000 px)`.

## Step 3: Predict before you render

Fill in this table by hand, with `fy = (H/2) / tan(fov_v/2)` and `w = fy · 1 m / d`:

| Image | fov_v | d | fy (px) | Predicted width (px) |
|---|---:|---:|---:|---:|
| 640×360 | 60° | 5 m | | |
| 640×360 | 60° | 10 m | | |
| 1280×720 | 60° | 5 m | | |
| 1280×720 | 60° | 10 m | | |
| 640×360 | 90° | 5 m | | |
| 640×360 | 90° | 10 m | | |

Also predict, before running, what doubling the resolution does to the width at 10 m, and what going from 60° to 90° does.

## Step 4: Look at the test scene

Open `godot/cameras/camera_lab.gd`. It builds everything in code, so it does not depend on how you built your Module 2 scenes:

- a 200 m checkerboard ground (1 m squares), a sky colour and a sun with shadows;
- a stand-in quad body at 2 m height, nose toward −Z;
- four rigs on it: `fpv` (RIGID, 25 cm in front of the centre), `gimbal` (GIMBAL_LEVEL, same place), `down` (RIGID, rotated −90° about x, `fov` 70°) and `chase` (CHASE);
- a 1 m × 1 m × 2 cm board with an **unshaded** pure red material.

`_run()` does the experiment. For each case it resizes the FPV viewport, sets the FOV, places the board so its front face is exactly d metres ahead (optionally shifted sideways), waits for the frame to be drawn, saves the PNG, and records three numbers: the pinhole prediction, `TargetBox.compute()` and `TargetBox.compute_unproject()`. Two off-axis cases check the projection away from the image centre.

## Step 5: Render

```bash
godot --path godot res://cameras/camera_lab.tscn
```

A window opens for a few seconds and closes. On a server without a display, use the software renderer through a virtual X server (this is how the reference numbers were made):

```bash
xvfb-run -a -s "-screen 0 1280x720x24" godot --path godot --rendering-driver opengl3 res://cameras/camera_lab.tscn
```

Expected console output (identical on any renderer, because these are computed, not measured):

```
fpv_640x360_fov60_d5_x0_y0.png     fy= 311.77 pred= 62.35 box= 62.35x 62.35 unproject= 62.35x 62.35
fpv_640x360_fov60_d10_x0_y0.png    fy= 311.77 pred= 31.18 box= 31.18x 31.18 unproject= 31.18x 31.18
fpv_1280x720_fov60_d5_x0_y0.png    fy= 623.54 pred=124.71 box=124.71x124.71 unproject=124.71x124.71
fpv_1280x720_fov60_d10_x0_y0.png   fy= 623.54 pred= 62.35 box= 62.35x 62.35 unproject= 62.35x 62.35
fpv_640x360_fov90_d5_x0_y0.png     fy= 180.00 pred= 36.00 box= 36.00x 36.00 unproject= 36.00x 36.00
fpv_640x360_fov90_d10_x0_y0.png    fy= 180.00 pred= 18.00 box= 18.00x 18.00 unproject= 18.00x 18.00
fpv_640x360_fov60_d5_x3_y1.png     fy= 311.77 pred= 62.35 box= 62.97x 62.48 unproject= 62.97x 62.48
fpv_1280x720_fov60_d10_x-4_y-1.png fy= 623.54 pred= 62.35 box= 62.79x 62.42 unproject= 62.79x 62.42
wrote .../robosim/logs/camera_check
```

The off-axis boxes are slightly larger than the prediction because you now also see the 2 cm side of the board.

## Step 6: Measure the pixels

```bash
python tools/measure_target.py logs/camera_check
python tools/camera_model.py logs/camera_check
```

`measure_target.py` finds every pixel with R > 200, G < 80, B < 80, takes their bounding box, and compares its width, height and centre with the prediction. Reference output:

```
image                                   fy    pred     box  unproj  meas w  meas h    err  ctr err
fpv_640x360_fov60_d5_x0_y0.png      311.77   62.35   62.35   62.35      62      62   0.35     0.00
fpv_640x360_fov60_d10_x0_y0.png     311.77   31.18   31.18   31.18      32      32   0.82     0.00
fpv_1280x720_fov60_d5_x0_y0.png     623.54  124.71  124.71  124.71     124     124   0.71     0.00
fpv_1280x720_fov60_d10_x0_y0.png    623.54   62.35   62.35   62.35      62      62   0.35     0.00
fpv_640x360_fov90_d5_x0_y0.png      180.00   36.00   36.00   36.00      36      36   0.00     0.00
fpv_640x360_fov90_d10_x0_y0.png     180.00   18.00   18.00   18.00      18      18   0.00     0.00
fpv_640x360_fov60_d5_x3_y1.png      311.77   62.35   62.97   62.97      63      63   0.65     0.25
fpv_1280x720_fov60_d10_x-4_y-1.png  623.54   62.35   62.79   62.79      63      63   0.65     0.30
worst error (size or centre) = 0.82 px  (tolerance 1.5 px)  ->  PASS
```

`camera_model.py` re-projects the same boards in Python (numpy and `cv2.projectPoints`) and must print `PASS`.

**Why the tolerance is 1.5 px.** A pixel is filled when its centre is inside the board, so a counted width can be off by up to 1 px from the true width (sub-topic 03 explains the 32 vs 31.18 case). The extra 0.5 px covers the board's thickness in the off-axis cases. If your error is several pixels, something is wrong: usually horizontal vs vertical FOV, or the wrong image size in the intrinsics.

## Step 7: Look at the camera images

Open the PNGs in `logs/camera_check/`:

| Image | What you should see |
|---|---|
| `fpv.png` | the board 8 m ahead, centred, with the horizon at mid-height |
| `down.png` | 1 m checker squares; the camera is 1.94 m above the ground and fy = 257 px, so one square is about 257 / 1.94 ≈ 132 px wide |
| `chase.png` | the quad from behind and above, the board ahead of it |
| `fpv_tilted.png` | quad pitched 15° down and rolled 10°: horizon tilted about 10° and about 84 px higher (fy · tan 15°) |
| `gimbal_tilted.png` | same quad attitude: horizon level, at mid-height |
| `intrinsics_<name>.json` | K, FOVs, near/far, `T_body_cam_godot`, `T_body_cam_cv` |

Check the down camera's JSON: the third column of `T_body_cam_godot` must be (0, 1, 0).

## Step 8: Put the rigs on your quad

The lab scene uses a stand-in. Now add the same rigs to your real quad from Module 2. `quad.tscn` is **generated** by `build_vehicles.gd` (Module 2, sub-topic 05), so do not edit it in the editor: the next run of the generator would delete your rigs. Add them from `main.gd` instead, under the quad instance's mounts:

1. In `main.gd`, add a helper and call it at the end of `_ready()`:
   ```gdscript
   func _add_camera_rigs() -> void:
   	var quad: Vehicle = $Vehicles/Quad
   	var logs := ProjectSettings.globalize_path("res://").path_join("../logs").simplify_path()
   	for spec in [["fpv", "fpv_cam", 60.0, CameraRig.Mode.RIGID],
   			["down", "down_cam", 70.0, CameraRig.Mode.RIGID],
   			["chase", "", 60.0, CameraRig.Mode.CHASE]]:
   		var rig := CameraRig.new()
   		rig.camera_name = spec[0]
   		rig.image_size = Vector2i(640, 360)
   		rig.fov_v_deg = spec[2]
   		rig.mode = spec[3]
   		# fpv and down sit on the Module 2 mounts (identity transform); chase on the quad root
   		(quad.mount(spec[1]) if spec[1] != "" else quad).add_child(rig)
   		rig.save_intrinsics(logs.path_join("intrinsics_%s.json" % rig.camera_name))
   ```
   Module 2's `down_cam` mount is already pitched −90°, so the down rig needs no rotation of its own.
2. Run `main.tscn` (with a physics script from Module 4/5 if you want the quad to move) and show the three viewports in `TextureRect`s (sub-topic 01).

If you prefer the editor: select the `Quad` instance in `main.tscn`, right-click → *Editable Children*, and add a `CameraRig` under `Mounts/fpv_cam` with *Add Child Node* (it appears there after `--import`, because it has a `class_name`). The rig is then saved in `main.tscn`, not in the generated `quad.tscn`.

If your vehicle node is moved in `_process` by the bridge code, the rigs follow it in the same frame (`process_priority = 1000`). If you move the vehicle in `_physics_process` instead, the rig still runs afterwards, because rendering happens after both.

## Step 9: Write the resolution vs FOV note

In 3–5 sentences, using your own measured numbers, explain:

- what happened to the board's pixel width when you doubled the resolution at the same FOV, and why the image *content* did not change;
- what happened when you widened the FOV at the same resolution;
- which one you would change to detect a 1 m target at 30 m with at least 20 px, and what it costs (pixels to transport in Module 7, field of view).

## Check

- [ ] `target_box_test.gd` prints `PASS`.
- [ ] `measure_target.py` prints `PASS`: for the 1 m board at 5 m and 10 m, at 640×360 and 1280×720, the red-pixel box differs from `fy · 1 m / d` by at most 1.5 px in width, height and centre. The reference worst case was 0.82 px.
- [ ] `camera_model.py` prints `PASS` (Godot boxes = numpy = OpenCV within 0.001 px).
- [ ] Every rig wrote an `intrinsics_<name>.json`, and for 640×360 / 60° it says `fx = fy = 311.77`, `cx = 320`, `cy = 180`.
- [ ] `gimbal_tilted.png` has a level horizon; `fpv_tilted.png` does not.
- [ ] Your resolution vs FOV note exists and uses your numbers.

## Stretch goals

- Add a fourth case at 20 m and at 50 m. At what distance does the measured error first exceed 1.5 px, and why (hint: the board becomes a few pixels wide)?
- Turn on `msaa = MSAA_4X` for the FPV rig and fit the board edges with sub-pixel accuracy (for example, sum the red fraction per column). How close to 31.18 px can you get at 10 m?
- Add lens distortion in Python: apply `k1 = −0.2` with `cv2.initUndistortRectifyMap`/`cv2.remap` in reverse, then undistort again with the same coefficients and re-run the size check.
- Make the gimbal realistic: limit its pitch to ±30° and give it a first-order lag of 0.1 s.
