# 01 Camera3D and SubViewport

A robot camera is not the camera you look through in the editor. It must have a fixed image size, render whether or not anyone looks at it, and hand its pixels to code. In Godot that means one `Camera3D` inside its own `SubViewport`. This page explains why, and how the two fit together.

## Why a SubViewport

The main window is a `Viewport`. It has exactly one active camera and its size is whatever the window is. That is fine for a human operator, and wrong for a sensor:

| Need of a robot camera | Main window | SubViewport |
|---|---|---|
| Fixed image size (e.g. 640×360) | changes when the user resizes the window | `size` property, fixed |
| Several cameras at once (FPV, down, chase) | one active camera | one camera per SubViewport |
| Renders when nobody watches | yes | only if you set the update mode |
| Pixels available to code | `get_viewport().get_texture()` | `sub.get_texture()` |

A `SubViewport` is a *render target*: an off-screen image that Godot draws a 3D view into. By default it shares the scene's `World3D` with the main window (`own_world_3d = false`), so every camera sees the same terrain and vehicles. You do not duplicate the scene.

## How a camera finds its viewport

A `Camera3D` renders into the **nearest `Viewport` above it in the tree**. So the camera must be a child (or grandchild) of the `SubViewport`:

```
Quad (Node3D, moved by the bridge)
└── Mounts/fpv_cam (Marker3D, from Module 2)
    └── Rig_fpv (CameraRig: Node3D, this module)
        └── View_fpv (SubViewport, 640×360)
            └── Cam_fpv (Camera3D)        ← renders into View_fpv
```

There is a catch. `SubViewport` is a `Node`, not a `Node3D`. A `Node3D` whose parent is not a `Node3D` does not inherit any transform: its `transform` **is** its world transform. So `Cam_fpv` does not follow the quad by itself. Something must copy the mount's world transform onto the camera every frame. That is the job of `CameraRig` (sub-topic 04), and it is also an advantage: the rig decides *how* the camera follows (rigid, gimbal-level, chase).

## The properties that matter

| Node | Property | Default | Set it to | Why |
|---|---|---|---|---|
| SubViewport | `size` | 512×512 | your sensor size, e.g. 640×360 | defines the image and the intrinsics |
| SubViewport | `render_target_update_mode` | `UPDATE_WHEN_VISIBLE` | `UPDATE_ALWAYS` (or `UPDATE_ONCE` on demand) | an off-screen viewport is never "visible", so it would never render |
| SubViewport | `msaa_3d` | disabled | disabled for tests, 2×–4× for realism | see sub-topic 05 |
| Camera3D | `fov` | 75° | your lens | **vertical** angle by default (sub-topic 02) |
| Camera3D | `keep_aspect` | `KEEP_HEIGHT` | leave it | it makes `fov` vertical |
| Camera3D | `near` / `far` | 0.05 m / 4000 m | as large / small as the scene allows | depth precision (sub-topic 03) |
| Camera3D | `current` | false | true | the active camera of *its* viewport |

The defaults in the table were printed by Godot 4.7.2 itself.

### Update modes

| Mode | Renders | Use it for |
|---|---|---|
| `UPDATE_DISABLED` | never | a camera that is off |
| `UPDATE_ONCE` | the next frame, then switches itself to `DISABLED` | capture on demand at a camera rate (Module 7) |
| `UPDATE_WHEN_VISIBLE` | when its texture is drawn on screen | a picture-in-picture display |
| `UPDATE_WHEN_PARENT_VISIBLE` | when its parent `CanvasItem` is visible | UI panels |
| `UPDATE_ALWAYS` | every frame | a sensor that streams continuously |

Each rendering SubViewport costs about as much GPU time as rendering the window again at that size. Three cameras at 640×360 cost roughly what one 1280×720 view costs (an estimate; Module 7 shows how to measure it). Turn off the ones you do not need.

## Code: a SubViewport camera in a few lines

This is the core of `camera_rig.gd` (full file in [code/godot/cameras/camera_rig.gd](code/godot/cameras/camera_rig.gd)):

```gdscript
func _ready() -> void:
	process_priority = 1000          # run after whatever moves the vehicle this frame
	viewport = SubViewport.new()
	viewport.size = image_size                       # e.g. Vector2i(640, 360)
	viewport.render_target_update_mode = update_mode # UPDATE_ALWAYS by default
	add_child(viewport)              # shares the main World3D
	camera = Camera3D.new()
	camera.keep_aspect = Camera3D.KEEP_HEIGHT
	camera.fov = fov_v_deg
	camera.near = near
	camera.far = far
	viewport.add_child(camera)
	camera.current = true


func _process(_delta: float) -> void:
	camera.global_transform = global_transform       # RIGID mode: copy the mount
```

`process_priority = 1000` matters. Godot calls `_process` in priority order (lower first). `SimBridge` reads the packets at priority −100, your viewer script moves the vehicle at the default priority 0, and the rig runs after both, so the camera uses **this** frame's vehicle pose, not the last one.

## Showing a camera on screen

To watch a robot camera, draw its texture in a `TextureRect`. The texture is live: it updates whenever the viewport renders.

```gdscript
var tr := TextureRect.new()
tr.texture = rig.viewport.get_texture()        # a ViewportTexture
tr.custom_minimum_size = Vector2(320, 180)
tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
add_child(tr)
```

Displaying it is cheap, because the texture never leaves the GPU. Reading its pixels back to the CPU (`get_texture().get_image()`) is a different story, and is the subject of [Module 7](../m07_frame_transport/README.md).

## Getting one image (for tests)

```gdscript
await RenderingServer.frame_post_draw          # wait until this frame has been drawn
var img: Image = rig.viewport.get_texture().get_image()
img.save_png("user://test.png")            # user:// = the per-project user data folder
```

Two details from testing:

- `get_image()` returned `FORMAT_RGBA8` (4 bytes per pixel) even with `transparent_bg = false`. Module 7 converts it to RGB8.
- Reading in `_process` gives you the image drawn in the **previous** frame. Reading after `RenderingServer.frame_post_draw` gives you this frame's image. Module 7 measures this.

## Try it

- Add a second `CameraRig` to the quad with `image_size = Vector2i(320, 240)` and show both in `TextureRect`s. Resize the window: the robot images must not change size.
- Set the rig's `update_mode` to `UPDATE_WHEN_VISIBLE` and remove its `TextureRect`. Save an image after 10 frames. What do you get? (Expect an empty or stale image.)
- Print `Engine.get_frames_per_second()` with 1, 2 and 3 cameras at `UPDATE_ALWAYS`. Write down the numbers for your GPU.

## References

- Godot docs: [Using Viewports](https://docs.godotengine.org/en/4.7/tutorials/rendering/viewports.html)
- Godot docs: [SubViewport](https://docs.godotengine.org/en/4.7/classes/class_subviewport.html), [Camera3D](https://docs.godotengine.org/en/4.7/classes/class_camera3d.html), [ViewportTexture](https://docs.godotengine.org/en/4.7/classes/class_viewporttexture.html)
