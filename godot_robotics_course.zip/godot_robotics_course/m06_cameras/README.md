# Module 6: Cameras and image formation (8 h)

## What you will build

Three robot cameras on the quadcopter: a forward FPV camera, a downward optical-flow camera and a chase camera. Each one renders into its own image and exports its pinhole intrinsics and its mount as JSON. You then prove the model is right: you predict how many pixels a 1 m board covers, render it, count the red pixels and compare.

## Prerequisites

- Modules 1–5 done. You need the test range scene, the quad model with its mount `Marker3D`s (Module 2/3), and the bridge (Module 4/5).
- [Frames cheat sheet](../reference/frames.md): cameras look along their own −Z.
- A machine that renders (a GPU, or the software renderer on a headless server, see [code/README.md](code/README.md)). `--headless` does **not** render images.
- Python with `numpy`, `pillow` and `opencv-python` (from [00_setup](../00_setup/README.md)).

## Sub-topics

| File | Topic | Time |
|---|---|---:|
| [01_camera_and_subviewport.md](01_camera_and_subviewport.md) | Camera3D, SubViewport, render targets, update modes, image size | 1 h |
| [02_fov_and_intrinsics.md](02_fov_and_intrinsics.md) | Vertical FOV, keep_aspect, H↔V conversion, pinhole model, fx fy cx cy, JSON export | 1.25 h |
| [03_projection_and_depth.md](03_projection_and_depth.md) | Checking projection with `unproject_position`, near/far, depth precision | 0.75 h |
| [04_camera_mounts.md](04_camera_mounts.md) | Extrinsics from Marker3D mounts; rigid FPV, gimbal-level, downward, chase | 1 h |
| [05_lighting_and_artifacts.md](05_lighting_and_artifacts.md) | Aliasing, MSAA, shadows, exposure, and what they do to vision code | 1 h |
| [06_ground_truth_boxes.md](06_ground_truth_boxes.md) | Ideal target detection: 8 corners → bounding box | 0.75 h |
| [lab.md](lab.md) | Camera rigs + the 1 m board size check | 2.25 h |

## Deliverables

- `godot/cameras/camera_rig.gd`, `camera_intrinsics.gd`, `target_box.gd` in `robosim/`.
- FPV, downward and chase rigs on the quad, each writing `intrinsics_<name>.json`.
- `logs/camera_check/`: rendered PNGs, `results.json` and the output of `tools/measure_target.py`.
- A short note (3–5 sentences, in your lab notebook or the run folder) explaining what changes when you change resolution and what changes when you change FOV.

## Check

All numbers below were measured with the reference code (Godot 4.7.2, Compatibility renderer on Mesa llvmpipe). Your GPU renders the same geometry, so you should get the same pixel counts within the tolerance.

1. **Intrinsics.** For 640×360 and `fov = 60°` the exported JSON says `fy = fx = 311.77`, `cx = 320`, `cy = 180`, `fov_h_deg = 91.49`.
2. **Predicted vs rendered size.** For the 1 m board at 5 m and 10 m, at 640×360 and at 1280×720, the width and height of the red pixel box differ from `fy · 1 m / d` by **at most 1.5 px**, and the box centre differs from the projected centre by at most 1.5 px. Reference run: worst error 0.82 px over 8 cases.
3. **unproject_position agrees.** `TargetBox.compute()` (pinhole math) and Godot's `Camera3D.unproject_position()` give the same box to within 0.001 px (reference run: 3·10⁻⁵ px). `tools/camera_model.py` (numpy and `cv2.projectPoints`) also agrees to within 0.001 px.
4. **Mounts.** `intrinsics_down.json` has a `T_body_cam_godot` whose third column is (0, 1, 0): the camera's +Z is body up, so it looks down. With the quad pitched 15° and rolled 10°, the gimbal image shows a level horizon and the rigid FPV image does not.

## Common mistakes

- **Treating `fov` as horizontal.** Godot's default `keep_aspect = KEEP_HEIGHT` makes `fov` the vertical angle. At 16:9, `fov = 60` is 91.5° horizontally.
- **Forgetting that a SubViewport is 512×512 and renders only "when visible" by default.** An off-screen camera then never updates. Set `size` and `render_target_update_mode` yourself.
- **Mixing pixel conventions.** Godot and OpenCV both put (0, 0) at the top-left *corner* of the image, with the centre of pixel *i* at *i* + 0.5. That is why `cx = W/2`, not `(W−1)/2`.
- **Shading the target.** A lit material's colour depends on the sun angle (measured: 255 → 130 in the red channel). Use an unshaded material for anything you segment by colour in a test.
- **`near = 0.001` "to be safe".** Depth precision depends on near far more than on far. A tiny near makes distant surfaces flicker (z-fighting).
- **Expecting the ideal box to know about walls.** The 8-corner box ignores occlusion: a board half-buried in the ground still gets its full box (we hit exactly this in testing).
