# 2. Godot's conventions: +Y up, −Z forward, Transform3D

Godot is the frame everything ends up in. Before you convert anything into it, you need to know exactly what its axes mean, how a node stores its pose, and how its Euler angles are ordered. Everything here was checked with Godot 4.7.2.

## Axes

| Axis | Godot meaning | Course meaning in the world |
|---|---|---|
| +X | right | East |
| +Y | up | Up |
| −Z | forward (`Vector3.FORWARD = (0, 0, -1)`) | North |
| +Z | back | South |

Godot is right-handed and **Y-up**. Cameras, lights and `Node3D.look_at()` all treat **−Z as forward**. A `Camera3D` with no rotation looks along −Z, with +X to the right of the image and +Y toward its top.

There is one trap. Since 4.3, Godot also defines `Vector3.MODEL_FRONT = (0, 0, 1)`, because glTF assets face **+Z**. So Godot has two "fronts": −Z for cameras and nodes, and +Z for imported models. The course picks one: **every vehicle model faces −Z, with its top toward +Y** (Module 2 builds them that way). The payoff is that a camera mounted on a vehicle with an identity rotation looks straight ahead. If an imported mesh faces +Z, don't rotate the vehicle root. Put the mesh under a child node and rotate that child 180° about Y.

The body frame this gives is called **MODEL** in `frames.py`: x = right, y = up, z = back.

```
          +Y up
           │   −Z forward (nose, camera view)
           │  ╱
           │ ╱
           └──────── +X right
          ╱
         ╱
       +Z back
```

## Transform3D = Basis + origin

Every `Node3D` stores its pose as a `Transform3D`:

```gdscript
var t: Transform3D = node.transform     # relative to the PARENT
t.basis      # Basis: 3x3 rotation (and scale), columns = the node's local axes in parent coordinates
t.origin     # Vector3: the node's position in parent coordinates
```

In the course notation, `node.transform` is `(R_parent_node, t_parent_node)`. Applying it to a point gives `t * p = basis * p + origin`, which is exactly `p_parent = R_parent_node · p_node + t_parent_node`.

`Basis` columns are the axes, the same as the "columns are b's axes in a" rule from [sub-topic 1](01_why_frames.md):

```gdscript
var b := Basis(Vector3(1, 0, 0), Vector3(0, 0, -1), Vector3(0, 1, 0))   # constructor takes COLUMNS
print(b.y)          # (0, 0, -1): the node's local +Y points toward world -Z
print(b[1])         # same column, by index
print(b.transposed().is_equal_approx(b.inverse()))   # true for a pure rotation
```

When Godot prints a `Basis` it shows `[X: (…), Y: (…), Z: (…)]`, which are the three **columns**. In numpy, `R[:, 0]` is the same thing as `basis.x`. You can move a numpy matrix into Godot column by column without transposing.

## Local vs global

| Property | Frame | Use it when |
|---|---|---|
| `position`, `rotation`, `basis`, `quaternion`, `transform` | relative to the parent | building a rig: mounts, wheels, rotors |
| `global_position`, `global_rotation`, `global_basis`, `global_transform` | relative to the world | applying a pose from physics, measuring where something points |

A pose from the bridge is a **world** pose, so set `global_transform`. A camera mount is a **body-relative** pose, so set its `transform` once and never touch it again. Godot composes the two for you:

```gdscript
# body pose in the world, mount pose in the body
body.global_transform = Transform3D(Basis(q_from_wire), p_from_wire)
# $Body/FpvMount.transform was set in the editor: 0.85 m ahead, 0.1 m up
var cam_world: Transform3D = $Body/FpvMount.global_transform      # = body.global_transform * mount.transform
var nose_world: Vector3 = body.to_global(Vector3(0, 0, -1))       # a body point, in world coordinates
var back_in_body: Vector3 = body.to_local(nose_world)             # and back again
```

We ran this pattern on a body at (10, 2, 0) with pitch 20°, yaw 30° and roll 10°. `body.to_global(Vector3(0,0,-1))`, `child.global_position` (a child at local (0,0,−1)) and `body.global_transform * Vector3(0,0,-1)` all gave the same point, (9.53, 2.34, −0.81).

Global properties work only when the node is inside the scene tree. If you read `global_transform` from a node that hasn't been added yet, Godot prints `Condition "!is_inside_tree()" is true` and returns the identity transform.

## Euler angles: order YXZ

`Node3D.rotation` is a `Vector3` of angles in **radians** (`rotation_degrees` uses degrees), applied in the order given by `rotation_order`. The default is `EULER_ORDER_YXZ`, and `Basis.from_euler(v)` uses the same default. Verified in 4.7.2:

```
Basis.from_euler(Vector3(x, y, z))  ==  Ry(y) · Rx(x) · Rz(z)
```

Read the product right to left, as rotations about the body's own axes: first **roll** about Z, then **pitch** about X, then **yaw** about Y. Equivalently, yaw is the outermost rotation. That is the aerospace yaw-pitch-roll order with Godot's axis names, and it is why `rotation.y` alone is the heading:

| Component | Axis | Positive means | Checked with |
|---|---|---|---|
| `rotation.y` | Y (up) | turn **left** (counter-clockwise seen from above) | `Ry(+90°) · FORWARD = (−1, 0, 0)` |
| `rotation.x` | X (right) | nose **up** | `Rx(+90°) · FORWARD = (0, 1, 0)` |
| `rotation.z` | Z (back) | right side **up** (roll left) | `Rz(+90°) · RIGHT = (0, 1, 0)` |

Compare this with aerospace angles, where +ψ turns right and +φ rolls right. The signs of yaw and roll are flipped and pitch keeps its sign. That is the whole content of the JSBSim shortcut `Basis.from_euler(Vector3(θ, −ψ, −φ))`, which [sub-topic 4](04_jsbsim_geodetic.md) proves.

## Rules for applying external poses

1. **Set a quaternion or basis, not Euler angles.** Euler angles from another library use another order and another sign convention. A quaternion on the wire has no order to get wrong, apart from the element order (see [sub-topic 5](05_quaternions.md)).
2. **Set `global_transform` once per frame.** If you set `global_position` and then `global_basis` separately, you pay for two updates, and the result is easy to get wrong when the parent moves.
3. **Keep scale out of vehicle roots.** `Quaternion(basis)` fails on a scaled basis. Godot 4.7.2 prints `must be normalized in order to be casted to a Quaternion` and returns identity. Scale the mesh child, not the node that receives poses.

```gdscript
func apply_wire_pose(node: Node3D, pos: Vector3, quat_xyzw: Quaternion) -> void:
	node.global_transform = Transform3D(Basis(quat_xyzw.normalized()), pos)
```

## Try it

- In a new scene, add a `Node3D` with a child `MeshInstance3D` (a `BoxMesh` stretched along Z) and a child `Marker3D` at (0, 0, −1). Rotate the parent with `rotation_degrees = Vector3(0, 90, 0)` and print `$Marker3D.global_position`. Predict the answer before running.
- Set `rotation_degrees = Vector3(30, 0, 0)` and then `Vector3(0, 0, 30)`. Which one raises the nose, and which one lifts the right side?
- Print `Basis.from_euler(Vector3(0.3, 0.5, 0.7))` and `Basis(Vector3.UP, 0.5) * Basis(Vector3.RIGHT, 0.3) * Basis(Vector3.BACK, 0.7)`. Confirm with `is_equal_approx` that they are equal. Then swap the order of the factors and confirm they are not.
- Set `rotation_order` to `EULER_ORDER_XYZ` on a node and repeat the first exercise with all three angles non-zero. Explain the difference.

## References

- Godot docs, *Using 3D transforms*: <https://docs.godotengine.org/en/stable/tutorials/3d/using_transforms.html>
- `Transform3D`: <https://docs.godotengine.org/en/stable/classes/class_transform3d.html>
- `Basis` (`from_euler`, columns, `looking_at`): <https://docs.godotengine.org/en/stable/classes/class_basis.html>
- `Node3D` (`rotation_order`, `global_transform`, `to_global`): <https://docs.godotengine.org/en/stable/classes/class_node3d.html>
- `Vector3` constants (`FORWARD`, `MODEL_FRONT`): <https://docs.godotengine.org/en/stable/classes/class_vector3.html>
