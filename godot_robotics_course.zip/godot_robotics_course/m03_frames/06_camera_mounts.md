# 6. Camera mounts and the optical frame

A camera is a sensor frame bolted to a body frame. Its world pose is always **body pose × mount transform**. The body pose changes every frame. The mount is fixed, unless it is a gimbal. In this sub-topic you put that product into the scene tree with a `Marker3D`. You then learn the two standard mounts (FPV and downward), cross from Godot's camera frame to the OpenCV optical frame that vision code expects, and choose between a rigid mount and a levelled gimbal.

## A mount is a fixed child transform

```
Body (Node3D)                      ← global_transform set from the wire every frame
├── Hull, Nose, …                  ← meshes (MODEL frame: x right, y up, −z forward)
├── FpvMount (Marker3D)            ← transform = T_model_fpv, set ONCE in the editor
│   └── Camera3D  (or a RemoteTransform3D that drives one)
└── DownMount (Marker3D)           ← transform = T_model_down
```

`Marker3D` is a plain `Node3D` that draws a cross in the editor, so you can see the mount point while you place it. It costs nothing at runtime. The mount's `transform` is expressed in the body's MODEL frame, so "0.85 m ahead and 0.1 m up" is `position = Vector3(0, 0.1, -0.85)`. Godot composes the poses for you: `mount.global_transform == body.global_transform * mount.transform`.

Put a `Camera3D` directly under the mount when the camera renders into the main window. When it renders into a `SubViewport` (a picture-in-picture or an image you will capture), the camera node must live **inside** the `SubViewport`. In that case, give the mount a `RemoteTransform3D` child whose `remote_path` points at that camera. It copies the mount's global transform to the camera every time the mount moves. This is what the lab does:

```
Body/FpvMount (Marker3D)
└── ToFpvCamera (RemoteTransform3D)   remote_path = ../../../UI/FpvBox/FpvViewport/FpvCamera
UI/FpvBox (SubViewportContainer, stretch) / FpvViewport (SubViewport 320×240) / FpvCamera (Camera3D)
```

The vehicle's own debug arrows should not appear in its FPV image. Put them on render layer 2 (the lab's `AxisTriad.layers = 2`) and set `FpvCamera.cull_mask = 1`. Debug visuals that only the chase camera sees are a pattern you will reuse for every sensor.

## FPV vs downward

| Mount | `transform.basis` in MODEL | Looks along | Image top points to | Typical use |
|---|---|---|---|---|
| FPV, level | identity | body forward (−Z) | body up | driving, piloting, object detection |
| FPV, tilted up α | `Basis(Vector3.RIGHT, deg_to_rad(α))` | forward, raised α | mostly up | racing quads fly nose-down, so the camera tilts up 20–40° |
| Down | `Basis(Vector3.RIGHT, -PI / 2)` | body down (−Y) | body forward | optical flow, landing pad detection, mapping |

Check the down mount by reasoning. Rotating −90° about +X takes the camera's view direction −Z to −Y (down), and its image-up +Y to −Z (forward). We verified this in 4.7.2. On a body pitched 20°, yawed 30° and rolled 10°, the rigid down camera looked along (−0.02, −0.93, −0.38). That is not straight down, because a rigid mount tilts with the body.

## Godot camera frame vs OpenCV optical frame

Vision code (OpenCV, ROS `*_optical_frame`, most calibration tools) uses a different camera frame from Godot:

| Frame | x | y | z |
|---|---|---|---|
| Godot camera | right | **up** | **back** (view along −z) |
| OpenCV optical | right | **down** | **forward** (view along +z) |

They differ by 180° about x:

```
R_opt_cam = diag(1, -1, -1)              # its own inverse; frames_extra.R_OPT_CAM
p_opt     = R_opt_cam · T_cam_world · p_world        (T_cam_world = camera.global_transform.affine_inverse())
u = fx · x/z + cx,   v = fy · y/z + cy                (z > 0 means in front of the camera)
fy = (H/2) / tan(fov_v/2),  fx = fy,  cx = W/2,  cy = H/2   # course convention: Camera3D.fov is VERTICAL
```

In GDScript, as used in the lab:

```gdscript
var p_cam := fpv_mount.global_transform.affine_inverse() * p_world   # Godot camera frame
var p_opt := Vector3(p_cam.x, -p_cam.y, -p_cam.z)                    # OpenCV optical frame
var uv := Vector2(fx * p_opt.x / p_opt.z + W / 2.0, fy * p_opt.y / p_opt.z + H / 2.0)
# compare with Godot's own projection:
var godot_uv := fpv_cam.unproject_position(p_world)
```

In the lab run (320 × 240, `fov = 70`), every visible pillar top projected to the same pixel both ways. For example, at the identity hold the pinhole gave (160.0, 110.4) and `unproject_position` gave (160.0, 110.4). Godot's camera agrees with the pinhole model and the vertical-fov convention. The same check also confirms that the `RemoteTransform3D` camera sits exactly on the mount.

### Extrinsics in the robot's body frame

A vision pipeline often wants the camera pose in the **robot's** body frame (FLU or FRD), in optical axes. Chain it:

```
R_flu_opt = C_FLU_MODEL · R_model_cam · R_opt_camᵀ          t_flu = C_FLU_MODEL · t_model
```

For the lab's level FPV mount (`R_model_cam = I`, `t_model = (0, 0.1, −0.85)`):

```
R_flu_opt columns: optical x → (0,−1,0) right,  optical y → (0,0,−1) down,  optical z → (1,0,0) forward
t_flu = (0.85, 0, 0.10)            # 0.85 m forward, 0.10 m up
```

This is the usual ROS relation between `base_link` and `camera_optical_frame`, and `test_camera_extrinsics_in_flu` checks it. In FRD the same camera is a pure permutation: `R_frd_opt = [[0,0,1],[1,0,0],[0,1,0]]`. Optical x is body right, y is body down, z is body forward, with no sign flips. That is one reason aerospace people like FRD.

## Gimbal (level) vs rigid mount

| | Rigid | Level gimbal |
|---|---|---|
| Camera follows body roll/pitch | yes | no (heading only) |
| Horizon in the image | tilts with the vehicle | stays level |
| Extrinsics | constant, so easy for VIO/SLAM | change every frame, so you must log them |
| Real-world equivalent | FPV racing camera, VIO stereo rig | 2–3-axis brushless gimbal on a mapping drone |

A perfect level gimbal is one line, because of Godot's YXZ order. `global_rotation.y` is the heading, so a basis built from it alone throws away pitch and roll:

```gdscript
func _update_gimbals() -> void:      # call AFTER the body pose is set this frame
	var heading := Basis(Vector3.UP, body.global_rotation.y)
	$Body/GimbalFpv.global_basis = heading                                    # level, looks along heading
	$Body/GimbalDown.global_basis = heading * Basis(Vector3.RIGHT, -PI / 2)   # straight down, image top = heading
```

Verified on the same 20°/30°/10° body: the levelled FPV looked along (−0.5, 0, −0.866), which is horizontal, along the body's 30° yaw (Godot `rotation.y` = +30°, so compass heading 330°). The levelled down camera looked along (0, −1, 0) with image-up (−0.5, 0, −0.866). Two practical notes:

- **Update order.** Set the gimbal in the same function, right after the body pose. If you do it in a separate `_process` that runs first, the gimbal lags one frame and the image shakes.
- **Near ±90° pitch** the heading is undefined (gimbal lock in the Euler sense). Real gimbals have limits too. Clamp, or keep the last good heading.

Only orientation is levelled. The gimbal's position still follows the body through the parent, which is how a real gimbal works.

## Try it

- Add a `DownMount` (`Marker3D`, rotated −90° about X, 0.1 m below the hull) to the lab body with its own `SubViewport` camera. During the roll +90° hold, what does it see?
- Change the FPV mount to a 30° up-tilt. Predict how the pillar's v pixel moves at the identity hold, then check the `fpv sees pillar` line.
- Turn the FPV mount into a level gimbal with the code above. Run the PyBullet sequence and describe the FPV image during the pitch hold.
- Compute `R_frd_opt` for the down camera by hand and check it in numpy.

## References

- `Marker3D`: <https://docs.godotengine.org/en/stable/classes/class_marker3d.html>
- `RemoteTransform3D`: <https://docs.godotengine.org/en/stable/classes/class_remotetransform3d.html>
- `Camera3D` (`fov`, `keep_aspect`, `unproject_position`, `cull_mask`): <https://docs.godotengine.org/en/stable/classes/class_camera3d.html>
- `SubViewport`: <https://docs.godotengine.org/en/stable/classes/class_subviewport.html>
- OpenCV camera model: <https://docs.opencv.org/4.x/d9/d0c/group__calib3d.html>
- REP 103, "Suffix frames" (`_optical`): <https://www.ros.org/reps/rep-0103.html>
- Module 6 builds full camera rigs and exports these intrinsics: [m06_cameras](../m06_cameras/README.md)
