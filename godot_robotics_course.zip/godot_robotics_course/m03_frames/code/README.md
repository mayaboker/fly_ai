# Module 3 reference code

These are the finished files for [lab.md](../lab.md). Paths mirror `robosim/`.

| File | Copy to |
|---|---|
| `physics/robosim/frames_extra.py` | `robosim/physics/robosim/` |
| `physics/tests/test_frames_known.py`, `test_geo_error.py` | `robosim/physics/tests/` |
| `physics/sims/frames_demo.py` | `robosim/physics/sims/` |
| `godot/frames_lab/{frames_lab.tscn, frames_lab.gd, axis_triad.gd}` | `robosim/godot/frames_lab/` |
| `godot/tests/test_yxz_shortcut.gd` | `robosim/godot/tests/` |
| `frames_lab_flu_roll.png`, `frames_lab_frd_pitch.png` | screenshots from our test run (for comparison only) |

You also need `robosim/physics/aircraft/quad_rpy/` (from `reference/code/aircraft/`) for the JSBSim parts. The Godot project needs `bridge/` from `reference/code/godot/bridge/` (copied in 00_setup).

## Run

```bash
cd ~/robosim/physics
python tests/test_frames_known.py          # 8 tests; also writes tests/out/yxz_cases.json
python tests/test_geo_error.py             # flat-earth error table; --lat <deg> for your site
cd ~/robosim/godot
godot --headless --import                  # once, registers class_name AxisTriad
godot --headless --script res://tests/test_yxz_shortcut.gd

# the lab: two terminals
godot --path ~/robosim/godot res://frames_lab/frames_lab.tscn -- --source=flu     # or frd
cd ~/robosim/physics && python sims/frames_demo.py --source pybullet               # or jsbsim
```

Scene options after `--`: `--source=flu|frd`, `--listen-port=`, `--physics-port=`, `--quit-after-holds=N`, `--screenshot=PATH --screenshot-hold=N` (this also writes `PATH_fpv.png`).
Script options: `--source`, `--ramp`, `--hold`, `--once`, `--viewer-port`, `--listen-port`.

## What was verified (Godot 4.7.2, Python 3.11, PyBullet 3.2.x, JSBSim 1.3.1, Linux)

All tests ran in a throwaway copy of `robosim/`, built the way 00_setup describes, with ports 9130/9131 so they would not collide with other tests.

| Test | Result |
|---|---|
| `test_frames_known.py` as a script and with `pytest` | 8/8 pass |
| `test_geo_error.py` | pass. 32° N table: `GeoOrigin` 3.90 / 19.53 / 78.39 m, `GeoOriginLocal` 0.057 / 1.417 / 22.705 m at 1 / 5 / 20 km. JSBSim ECEF vs WGS84 formula: < 0.01 m |
| `test_yxz_shortcut.gd` (headless) | PASS, 54 cases, worst column error 1.3e-7. A deliberately wrong sign variant FAILs (error 2.0) |
| `frames_demo.py --source pybullet` + `frames_lab.tscn --source=flu` (headless) | 4/4 holds: measured vectors equal the expected table |
| `frames_demo.py --source jsbsim` + `frames_lab.tscn --source=frd` (headless) | 4/4 holds: measured vectors equal the expected table |
| FPV pinhole vs `Camera3D.unproject_position` (320×240, fov 70) | identical to the printed 0.1 px in every hold |
| Rendered run under `xvfb-run` with `--rendering-driver opengl3` | screenshots above checked by eye: arrows, labels, FPV inset (horizon vertical at the roll hold, sky at the JSBSim pitch hold). Software rendering ran at about 6–7 fps |
| Snippets in sub-topics 2, 5, 6 (local/global, quaternion behavior, gimbal and down-mount bases) | run in a scratch Godot project; the printed values in the text come from those runs |

Not tested here: the editor GUI workflow itself (opening the scene and pressing F6), and running on a GPU (we only used software OpenGL). Nothing in the scene depends on either.

## Notes for maintainers

- `frames_demo.py` calls `wait_for_viewer()` without `send_idle_pose`, so the sequence starts only once a viewer is listening. With the current reference `SimBridge` (HELLO at start-up, every 0.5 s until the first pose, and again on the first pose of each physics session), it works in both start orders, with or without idle poses. Rechecked after the bridge change: 4/4 holds for both sources, physics-first and viewer-first.
- The tests insert their parent `physics/` folder into `sys.path`, and so does the reference `test_frames.py`, so `python tests/test_frames.py` works from `robosim/physics` in the 00_setup layout.
