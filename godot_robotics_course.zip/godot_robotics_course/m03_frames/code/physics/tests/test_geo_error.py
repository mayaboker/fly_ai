"""
test_geo_error.py - how wrong is a flat-earth origin? (Module 3, sub-topic 4)

Run from robosim/physics:   python tests/test_geo_error.py

Reference = exact WGS84 geodetic -> ECEF -> local ENU (frames_extra.enu_exact).
Compared:   frames.GeoOrigin        (equatorial radius for both axes)
            frames_extra.GeoOriginLocal (meridian radius M and prime-vertical radius N at lat0)
Points are placed at a TRUE ground distance d from the origin, at the origin's height,
on 72 bearings; the table reports the worst horizontal error and the curvature drop
(how far below the tangent plane the point is, which a flat Godot world ignores on purpose).

The last test checks that JSBSim itself uses the same WGS84 ellipsoid (skipped when the
quad_rpy model is not in physics/aircraft/).
"""
import math
import os
import sys

import numpy as np

PHYSICS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PHYSICS_DIR)

from robosim.frames import GeoOrigin, FT  # noqa: E402
from robosim.frames_extra import GeoOriginLocal, enu_exact, geodetic_to_ecef  # noqa: E402

LAT0, LON0, H0 = math.radians(32.0), math.radians(35.0), 0.0


def point_at(d, bearing, local):
    """lat, lon whose EXACT ENU is (d sin b, d cos b, ~drop). Newton iteration on the local radii."""
    e_t, n_t = d * math.sin(bearing), d * math.cos(bearing)
    lat, lon, _ = local.to_geodetic(e_t, n_t, 0.0)
    for _ in range(20):
        e, n, _ = enu_exact(lat, lon, local.h0, local.lat0, local.lon0, local.h0)
        lat += (n_t - n) / local.m_radius
        lon += (e_t - e) / (local.n_radius * math.cos(local.lat0))
    return lat, lon


def error_table(lat0=LAT0, distances=(1000.0, 5000.0, 20000.0), n_bearings=72):
    ref, loc = GeoOrigin(lat0, LON0, H0), GeoOriginLocal(lat0, LON0, H0)
    rows = []
    for d in distances:
        worst_ref = worst_loc = drop = 0.0
        for b in np.linspace(0.0, 2 * math.pi, n_bearings, endpoint=False):
            lat, lon = point_at(d, b, loc)
            t = np.array(enu_exact(lat, lon, H0, lat0, LON0, H0))
            worst_ref = max(worst_ref, float(np.hypot(*(np.array(ref.to_enu(lat, lon, H0)) - t)[:2])))
            worst_loc = max(worst_loc, float(np.hypot(*(np.array(loc.to_enu(lat, lon, H0)) - t)[:2])))
            drop = max(drop, -t[2])
        rows.append((d, worst_ref, worst_loc, drop))
    return rows


def test_error_bounds():
    rows = {int(d): r for d, *r in error_table()}
    ref1, loc1, drop1 = rows[1000]
    assert 3.5 < ref1 < 4.5            # equatorial radius: ~0.39 % too long north-south at 32 N
    assert loc1 < 0.1                  # local radii: centimeters at 1 km
    assert rows[5000][1] < 2.0         # local radii: below 2 m at 5 km
    assert 0.07 < drop1 < 0.09         # curvature drop d^2 / 2R at 1 km


def test_jsbsim_uses_wgs84():
    if not os.path.exists(os.path.join(PHYSICS_DIR, "aircraft", "quad_rpy", "quad_rpy.xml")):
        print("  (skipped: aircraft/quad_rpy not found)")
        return
    import jsbsim
    fdm = jsbsim.FGFDMExec(PHYSICS_DIR, None)
    fdm.set_debug_level(0)
    fdm.load_model("quad_rpy")
    for lat_deg, lon_deg, h in ((32.0, 35.0, 0.0), (32.05, 35.1, 500.0)):
        fdm["ic/lat-geod-deg"], fdm["ic/long-gc-deg"], fdm["ic/h-sl-ft"] = lat_deg, lon_deg, h / FT
        fdm.run_ic()
        r = fdm["position/radius-to-vehicle-ft"] * FT
        lat_gc, lon = fdm["position/lat-gc-rad"], fdm["position/long-gc-rad"]
        jsb = np.array([r * math.cos(lat_gc) * math.cos(lon), r * math.cos(lat_gc) * math.sin(lon), r * math.sin(lat_gc)])
        ours = geodetic_to_ecef(math.radians(lat_deg), math.radians(lon_deg), h)
        assert np.linalg.norm(jsb - ours) < 0.01, (jsb - ours)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--lat", type=float, default=32.0, help="origin latitude for the printed table, deg")
    lat_deg = ap.parse_args().lat
    test_error_bounds()
    print("  ok  test_error_bounds")
    test_jsbsim_uses_wgs84()
    print("  ok  test_jsbsim_uses_wgs84")
    print("geo_error: all tests pass\n")
    print(f"Origin {lat_deg:g} N 35 E, h0 = 0. Worst horizontal error over 72 bearings, and curvature drop:")
    print("  distance | GeoOrigin (equatorial R) | GeoOriginLocal (M, N) | drop below tangent plane")
    for d, a, b, c in error_table(math.radians(lat_deg)):
        print(f"  {d/1000:5.0f} km | {a:20.2f} m   | {b:17.3f} m   | {c:10.2f} m")
