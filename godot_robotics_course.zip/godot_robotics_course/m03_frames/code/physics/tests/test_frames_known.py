"""
test_frames_known.py - known rotations with hand-derived Godot vectors (Module 3).

Run from robosim/physics:   python tests/test_frames_known.py
(pytest also works:          python -m pytest tests/test_frames_known.py)

Every expected vector below was derived by hand (see m03_frames/lab.md, step 1).
The test pushes the same rotation through frames.py and checks that the body axes
land on those vectors in the Godot world (x = East, y = Up, z = South).
It also writes tests/out/yxz_cases.json for the Godot-side test of the YXZ shortcut.
"""
import json
import math
import os
import sys

import numpy as np

PHYSICS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PHYSICS_DIR)

from robosim.frames import (C_FLU_MODEL, M_GODOT_ENU, enu_flu_to_godot, enu_to_godot_pos,  # noqa: E402
                            jsbsim_state_to_godot, matrix_to_quat, ned_frd_euler_to_enu_flu,
                            quat_to_matrix, GeoOrigin, FT)
from robosim.frames_extra import (R_OPT_CAM, pinhole_from_fov, project_optical,  # noqa: E402
                                  quat_angle_deg, quat_slerp)

# Godot world directions, by name
E, W = (1, 0, 0), (-1, 0, 0)
UP, DOWN = (0, 1, 0), (0, -1, 0)
N, S = (0, 0, -1), (0, 0, 1)

# Body axes expressed in Godot MODEL coordinates (model: x right, y up, z back)
FLU_IN_MODEL = {"x": (0, 0, -1), "y": (-1, 0, 0), "z": (0, 1, 0)}   # forward, left, up
FRD_IN_MODEL = {"x": (0, 0, -1), "y": (1, 0, 0), "z": (0, -1, 0)}   # forward, right, down

H = math.sqrt(0.5)
# PyBullet: (label, quaternion x,y,z,w in ENU/FLU, expected Godot vectors of body x, y, z)
PYBULLET_CASES = [
    ("identity",  (0, 0, 0, 1), {"x": E, "y": N, "z": UP}),
    ("roll +90",  (H, 0, 0, H), {"x": E, "y": UP, "z": S}),       # left side rises
    ("pitch +90", (0, H, 0, H), {"x": DOWN, "y": N, "z": E}),     # FLU: +pitch = nose DOWN
    ("yaw +90",   (0, 0, H, H), {"x": N, "y": W, "z": UP}),       # CCW seen from above
]
# JSBSim: (label, (phi, theta, psi) degrees, expected Godot vectors of body x, y, z)
JSBSIM_CASES = [
    ("identity",  (0, 0, 0),  {"x": N, "y": E, "z": DOWN}),
    ("roll +90",  (90, 0, 0), {"x": N, "y": DOWN, "z": W}),       # right wing down
    ("pitch +90", (0, 90, 0), {"x": UP, "y": E, "z": N}),         # FRD: +theta = nose UP
    ("yaw +90",   (0, 0, 90), {"x": E, "y": S, "z": DOWN}),       # heading east
]


def body_axes_in_godot(R_godot_model, axes_in_model):
    return {k: R_godot_model @ np.array(v, float) for k, v in axes_in_model.items()}


def wire_round_trip(R):
    """What the viewer really gets: a float32 quaternion turned back into a matrix."""
    q = np.array(matrix_to_quat(R), dtype=np.float32)
    return quat_to_matrix(q.astype(float))


def check(got, expected, label):
    for k in ("x", "y", "z"):
        assert np.allclose(got[k], expected[k], atol=1e-6), f"{label}: body {k} -> {got[k].round(3)}, expected {expected[k]}"


# ------------------------------------------------------------------ tests
def test_positions():
    assert np.allclose(enu_to_godot_pos((1, 2, 3)), (1, 3, -2))               # E, U, -N
    origin = GeoOrigin(math.radians(32.0), math.radians(35.0), 0.0)
    fdm = {"position/lat-geod-rad": math.radians(32.0), "position/long-gc-rad": math.radians(35.0),
           "position/h-sl-ft": 100.0 / FT,
           "attitude/phi-rad": 0.0, "attitude/theta-rad": 0.0, "attitude/psi-rad": 0.0}
    p, q = jsbsim_state_to_godot(fdm, origin)
    assert np.allclose(p, (0, 100, 0)), p                                       # feet became meters
    assert np.allclose(q, (0, 0, 0, 1))                                         # north-facing = Godot identity


def test_pybullet_known_rotations():
    for label, q_enu_flu, expected in PYBULLET_CASES:
        _, q_godot = enu_flu_to_godot((0, 0, 0), q_enu_flu)
        got = body_axes_in_godot(wire_round_trip(quat_to_matrix(q_godot)), FLU_IN_MODEL)
        check(got, expected, "PyBullet " + label)


def test_jsbsim_known_rotations():
    for label, (phi, th, psi), expected in JSBSIM_CASES:
        R = M_GODOT_ENU @ ned_frd_euler_to_enu_flu(math.radians(phi), math.radians(th), math.radians(psi)) @ C_FLU_MODEL
        got = body_axes_in_godot(wire_round_trip(R), FRD_IN_MODEL)
        check(got, expected, "JSBSim " + label)


def Rx(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])


def Ry(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])


def Rz(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def test_jsbsim_yxz_shortcut():
    """Basis.from_euler(Vector3(theta, -psi, -phi)) with Godot's YXZ order = Ry * Rx * Rz."""
    for _, (phi, th, psi), expected in JSBSIM_CASES:
        phi, th, psi = map(math.radians, (phi, th, psi))
        B = Ry(-psi) @ Rx(th) @ Rz(-phi)
        check(body_axes_in_godot(B, FRD_IN_MODEL), expected, "YXZ shortcut")


def test_quaternion_traps():
    q_xyzw = (0, 0, H, H)                       # yaw +90 in (x, y, z, w)
    q_wxyz = (H, 0, 0, H)                       # the same rotation written (w, x, y, z)
    R_good = quat_to_matrix(q_xyzw)
    R_bad = quat_to_matrix(q_wxyz)              # read with the wrong order: a 90 deg ROLL
    assert np.allclose(R_good @ [1, 0, 0], [0, 1, 0])
    assert np.allclose(R_bad @ [1, 0, 0], [1, 0, 0]) and not np.allclose(R_bad, R_good)
    assert np.allclose(quat_to_matrix(-np.array(q_xyzw)), R_good)              # q and -q: same rotation
    assert np.allclose(quat_to_matrix(3.0 * np.array(q_xyzw)), R_good)         # frames.py normalizes
    # slerp must take the short arc even when the second quaternion has the "other" sign
    q170 = (0, 0, math.sin(math.radians(85)), math.cos(math.radians(85)))     # yaw 170 deg
    mid = quat_slerp((0, 0, 0, 1), -np.array(q170), 0.5)
    assert math.isclose(quat_angle_deg((0, 0, 0, 1), mid), 85.0, abs_tol=1e-6)


def test_camera_optical_frame():
    """A point straight ahead of a Godot camera lands on the principal point;
    a point above it lands in the upper half (smaller v)."""
    fx, fy, cx, cy = pinhole_from_fov(320, 240, 70.0)
    assert math.isclose(fy, 120.0 / math.tan(math.radians(35.0)))
    ahead = R_OPT_CAM @ np.array([0.0, 0.0, -5.0])                             # Godot cam looks along -z
    assert np.allclose(ahead, (0, 0, 5))
    assert np.allclose(project_optical(ahead, fx, fy, cx, cy), (160, 120))
    u, v = project_optical(R_OPT_CAM @ np.array([0.0, 1.0, -5.0]), fx, fy, cx, cy)
    assert math.isclose(u, 160) and v < 120


def test_camera_extrinsics_in_flu():
    """FPV camera mounted with identity rotation (looks along body forward).
    Its OpenCV optical axes, written in the FLU body frame: x right, y down, z forward."""
    R_model_cam = np.eye(3)                                   # Marker3D with no rotation
    R_flu_opt = C_FLU_MODEL @ R_model_cam @ R_OPT_CAM.T
    assert np.allclose(R_flu_opt[:, 0], (0, -1, 0))           # optical x = body right = -left
    assert np.allclose(R_flu_opt[:, 1], (0, 0, -1))           # optical y = body down
    assert np.allclose(R_flu_opt[:, 2], (1, 0, 0))            # optical z = body forward


def write_godot_cases(path=None):
    """Random JSBSim attitudes and the matrices the FULL chain gives, for the Godot test."""
    path = path or os.path.join(PHYSICS_DIR, "tests", "out", "yxz_cases.json")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    rng = np.random.default_rng(3)
    cases = [[math.radians(a) for a in c[1]] for c in JSBSIM_CASES]
    cases += [list(rng.uniform(-1.5, 1.5, 3)) for _ in range(50)]
    out = []
    for phi, th, psi in cases:
        R = M_GODOT_ENU @ ned_frd_euler_to_enu_flu(phi, th, psi) @ C_FLU_MODEL
        out.append({"phi": phi, "theta": th, "psi": psi,
                    "cols": [list(R[:, 0]), list(R[:, 1]), list(R[:, 2])]})   # Basis columns x, y, z
    with open(path, "w") as f:
        json.dump(out, f)
    return path, len(out)


def test_write_godot_cases():
    path, n = write_godot_cases()
    assert os.path.exists(path) and n == 54


def fmt(v):
    return "(" + ", ".join(f"{c:+.0f}" for c in v) + ")"


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for t in tests:
        t()
        print(f"  ok  {t.__name__}")
    print(f"frames_known: all {len(tests)} tests pass")
    print("\nExpected Godot world vectors (x = East, y = Up, z = South):")
    for src, cases in (("PyBullet FLU", PYBULLET_CASES), ("JSBSim FRD", JSBSIM_CASES)):
        for label, _, exp in cases:
            print(f"  {src:13s} {label:10s} body x {fmt(exp['x'])}  body y {fmt(exp['y'])}  body z {fmt(exp['z'])}")
    print("wrote %s (%d cases)" % write_godot_cases())
