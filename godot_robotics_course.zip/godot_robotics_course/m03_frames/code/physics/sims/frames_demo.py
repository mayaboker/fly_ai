"""
frames_demo.py - stream a test body that rotates +90 deg about each body axis in turn (Module 3).

Run from robosim/physics:
    python sims/frames_demo.py --source pybullet      # ENU world, FLU body, quaternion (x,y,z,w)
    python sims/frames_demo.py --source jsbsim        # lat/lon/ft, NED world, FRD body, phi/theta/psi

Sequence (repeats unless --once): hold identity, then for roll, pitch, yaw:
ramp 0 -> +90 deg, HOLD, ramp back to 0. At the start of every HOLD the script prints the
Godot-world vectors of the body x, y, z axes that frames.py predicts. The Godot scene
frames_lab.tscn prints the vectors it MEASURES on the drawn arrows. They must match.

The body is posed, not simulated: PyBullet bodies are teleported with
resetBasePositionAndOrientation and read back; JSBSim is posed through its initial-condition
properties and run_ic(). Dynamics start in Module 4.
"""
import argparse
import math
import os
import sys
import time

import numpy as np

PHYSICS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PHYSICS_DIR)

from robosim.bridge import PhysicsBridge  # noqa: E402
from robosim.frames import FT, GeoOrigin, enu_flu_to_godot, jsbsim_state_to_godot, quat_to_matrix  # noqa: E402

POSE_HZ = 60.0
VEHICLE_ID = 10                 # test body
HEIGHT_M = 1.5                  # body center above the ground
LAT0_DEG, LON0_DEG, H0_M = 32.0, 35.0, 0.0      # JSBSim local origin (documented, see lab step 3)

# Body axes in Godot MODEL coordinates (x right, y up, z back)
AXES = {"pybullet": (("x fwd", (0, 0, -1)), ("y left", (-1, 0, 0)), ("z up", (0, 1, 0))),
        "jsbsim": (("x fwd", (0, 0, -1)), ("y right", (1, 0, 0)), ("z down", (0, -1, 0)))}


def schedule(ramp_s, hold_s):
    """List of (name, axis_index or None, start_deg, end_deg, duration_s, is_hold)."""
    segs = [("identity", None, 0, 0, hold_s, True)]
    for i, name in enumerate(("roll +90", "pitch +90", "yaw +90")):
        segs += [(name, i, 0, 90, ramp_s, False), (name, i, 90, 90, hold_s, True),
                 (name, i, 90, 0, ramp_s, False)]
    return segs


class PyBulletSource:
    def __init__(self):
        import pybullet as p
        self.p = p
        p.connect(p.DIRECT)
        shape = p.createCollisionShape(p.GEOM_BOX, halfExtents=[0.6, 0.3, 0.1])   # FLU: long along x
        self.body = p.createMultiBody(1.0, shape, basePosition=[0, 0, HEIGHT_M])

    def describe(self):
        return "PyBullet: ENU world (x E, y N, z U), FLU body, quaternion (x,y,z,w), meters"

    def pose(self, rpy_rad):
        q_cmd = self.p.getQuaternionFromEuler(rpy_rad)            # only one angle is non-zero
        self.p.resetBasePositionAndOrientation(self.body, [0, 0, HEIGHT_M], q_cmd)
        pos_enu, q_enu_flu = self.p.getBasePositionAndOrientation(self.body)   # (x, y, z, w)
        return enu_flu_to_godot(pos_enu, q_enu_flu)


class JSBSimSource:
    def __init__(self):
        import jsbsim
        self.fdm = jsbsim.FGFDMExec(PHYSICS_DIR, None)       # finds aircraft/quad_rpy/quad_rpy.xml
        self.fdm.set_debug_level(0)
        if not self.fdm.load_model("quad_rpy"):
            sys.exit("cannot load aircraft/quad_rpy (copy it from reference/code/aircraft)")
        self.fdm["ic/lat-geod-deg"], self.fdm["ic/long-gc-deg"] = LAT0_DEG, LON0_DEG
        self.fdm["ic/h-sl-ft"] = (H0_M + HEIGHT_M) / FT         # JSBSim wants feet
        self.origin = GeoOrigin(math.radians(LAT0_DEG), math.radians(LON0_DEG), H0_M)

    def describe(self):
        return (f"JSBSim: origin lat0={LAT0_DEG:.6f} deg N, lon0={LON0_DEG:.6f} deg E, h0={H0_M:.1f} m "
                f"(flat earth, GeoOrigin); NED world, FRD body, phi/theta/psi rad; ft x {FT} -> m")

    def pose(self, rpy_rad):
        self.fdm["ic/phi-rad"], self.fdm["ic/theta-rad"], self.fdm["ic/psi-true-rad"] = rpy_rad
        self.fdm.run_ic()
        return jsbsim_state_to_godot(self.fdm, self.origin)


def fmt(v):
    return "(" + ", ".join(f"{c:+.2f}" for c in v) + ")"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", choices=("pybullet", "jsbsim"), default="pybullet")
    ap.add_argument("--ramp", type=float, default=2.0, help="seconds per 0->90 deg ramp")
    ap.add_argument("--hold", type=float, default=3.0, help="seconds to hold each pose")
    ap.add_argument("--once", action="store_true", help="stop after one sequence")
    ap.add_argument("--viewer-port", type=int, default=9001)
    ap.add_argument("--listen-port", type=int, default=9002)
    args = ap.parse_args()

    src = PyBulletSource() if args.source == "pybullet" else JSBSimSource()
    print("[frames_demo]", src.describe(), flush=True)
    br = PhysicsBridge(viewer_port=args.viewer_port, listen_port=args.listen_port)
    # Wait for the viewer's HELLO, so the sequence starts when someone is watching. This works
    # in either start order (SimBridge keeps saying HELLO until it gets a pose).
    print(f"[frames_demo] waiting for the viewer on UDP {args.listen_port} ...", flush=True)
    br.wait_for_viewer()
    print("[frames_demo] viewer connected", flush=True)

    dt, t_sim, n_tick = 1.0 / POSE_HZ, 0.0, 0
    wall0 = time.monotonic()
    while True:
        for name, axis, a0, a1, dur, is_hold in schedule(args.ramp, args.hold):
            n = max(1, round(dur * POSE_HZ))
            for k in range(n):
                ang = math.radians(a0 + (a1 - a0) * (k + 1) / n)
                rpy = [0.0, 0.0, 0.0]
                if axis is not None:
                    rpy[axis] = ang
                pos, quat = src.pose(tuple(rpy))
                br.send_pose(t_sim, VEHICLE_ID, pos, quat)
                br.poll(t_sim)                                       # answers HELLO / commands
                if is_hold and k == 0:
                    R = quat_to_matrix(quat)
                    vecs = "  ".join(f"{lab} -> {fmt(R @ np.array(v, float))}" for lab, v in AXES[args.source])
                    print(f"[frames_demo] HOLD {name:10s} t={t_sim:6.2f}  expect  {vecs}", flush=True)
                t_sim += dt
                n_tick += 1
                sleep = wall0 + n_tick * dt - time.monotonic()      # pace to wall clock
                if sleep > 0:
                    time.sleep(sleep)
        if args.once:
            print("[frames_demo] sequence done", flush=True)
            return


if __name__ == "__main__":
    main()
