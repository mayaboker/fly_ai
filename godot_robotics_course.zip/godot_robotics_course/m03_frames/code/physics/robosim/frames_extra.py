"""
frames_extra.py - Module 3 additions that frames.py does not have.

  * exact geodetic -> local ENU (WGS84 ellipsoid, through ECEF), to measure errors
  * GeoOriginLocal: a flat-earth origin that uses the local radii of curvature
  * the Godot-camera -> OpenCV-optical rotation and pinhole intrinsics

frames.py stays the single place for the PyBullet and JSBSim pose chains.
"""
import math
import numpy as np

# ---- WGS84 ellipsoid (JSBSim 1.3.1 uses the same one; Module 3 checks this)
WGS84_A = 6378137.0                    # equatorial radius, m
WGS84_F = 1.0 / 298.257223563          # flattening
WGS84_E2 = WGS84_F * (2.0 - WGS84_F)   # first eccentricity squared


def geodetic_to_ecef(lat_rad, lon_rad, h_m):
    """Geodetic latitude, longitude, height above the ellipsoid -> ECEF (m)."""
    s = math.sin(lat_rad)
    n = WGS84_A / math.sqrt(1.0 - WGS84_E2 * s * s)
    return np.array([(n + h_m) * math.cos(lat_rad) * math.cos(lon_rad),
                     (n + h_m) * math.cos(lat_rad) * math.sin(lon_rad),
                     (n * (1.0 - WGS84_E2) + h_m) * s])


def enu_exact(lat_rad, lon_rad, h_m, lat0_rad, lon0_rad, h0_m=0.0):
    """Exact local-tangent-plane ENU of a point relative to an origin (m)."""
    d = geodetic_to_ecef(lat_rad, lon_rad, h_m) - geodetic_to_ecef(lat0_rad, lon0_rad, h0_m)
    sl, cl = math.sin(lat0_rad), math.cos(lat0_rad)
    so, co = math.sin(lon0_rad), math.cos(lon0_rad)
    R = np.array([[-so, co, 0.0],
                  [-sl * co, -sl * so, cl],
                  [cl * co, cl * so, sl]])
    return tuple(float(v) for v in R @ d)


class GeoOriginLocal:
    """Flat-earth local frame like frames.GeoOrigin, but with the ellipsoid's local radii:
    M (north-south, meridian) and N (east-west, prime vertical) at lat0.
    'up' is height difference (h - h0), not tangent-plane z: terrain stays flat in Godot."""

    def __init__(self, lat0_rad, lon0_rad, h0_m=0.0):
        self.lat0, self.lon0, self.h0 = lat0_rad, lon0_rad, h0_m
        w = 1.0 - WGS84_E2 * math.sin(lat0_rad) ** 2
        self.m_radius = WGS84_A * (1.0 - WGS84_E2) / w ** 1.5
        self.n_radius = WGS84_A / math.sqrt(w)

    def to_enu(self, lat_rad, lon_rad, h_m):
        e = (lon_rad - self.lon0) * (self.n_radius + self.h0) * math.cos(self.lat0)
        n = (lat_rad - self.lat0) * (self.m_radius + self.h0)
        return (e, n, h_m - self.h0)

    def to_geodetic(self, e, n, u):
        """Inverse of to_enu (handy for placing JSBSim initial conditions)."""
        return (self.lat0 + n / (self.m_radius + self.h0),
                self.lon0 + e / ((self.n_radius + self.h0) * math.cos(self.lat0)),
                self.h0 + u)


# ---- quaternions (x, y, z, w), like PyBullet, Godot and the wire
def quat_slerp(q0, q1, t):
    """Spherical interpolation along the SHORT arc (flips q1 when q0 . q1 < 0)."""
    q0, q1 = np.asarray(q0, float), np.asarray(q1, float)
    q0, q1 = q0 / np.linalg.norm(q0), q1 / np.linalg.norm(q1)
    d = float(np.dot(q0, q1))
    if d < 0.0:                       # q and -q are the same rotation: take the closer one
        q1, d = -q1, -d
    if d > 0.9995:                    # nearly equal: lerp + normalize is accurate and safe
        q = q0 + t * (q1 - q0)
        return q / np.linalg.norm(q)
    th = math.acos(d)
    return (math.sin((1 - t) * th) * q0 + math.sin(t * th) * q1) / math.sin(th)


def quat_angle_deg(q0, q1):
    """Rotation angle between two orientations, 0..180 deg (sign-safe)."""
    d = abs(float(np.dot(q0, q1))) / (np.linalg.norm(q0) * np.linalg.norm(q1))
    return math.degrees(2.0 * math.acos(min(1.0, d)))


# ---- cameras
# Godot camera frame: x right, y up, looks along -z.
# OpenCV optical frame: x right, y down, z forward (into the image).
R_OPT_CAM = np.diag([1.0, -1.0, -1.0])   # v_optical = R_OPT_CAM @ v_godot_cam (its own inverse)


def pinhole_from_fov(width, height, fov_v_deg):
    """Course convention: Camera3D.fov is VERTICAL (keep_aspect = KEEP_HEIGHT), square pixels."""
    fy = (height / 2.0) / math.tan(math.radians(fov_v_deg) / 2.0)
    return fy, fy, width / 2.0, height / 2.0          # fx, fy, cx, cy


def project_optical(p_opt, fx, fy, cx, cy):
    """Point in the optical frame -> pixel (u, v), or None when behind the camera."""
    x, y, z = p_opt
    if z <= 0:
        return None
    return (fx * x / z + cx, fy * y / z + cy)
