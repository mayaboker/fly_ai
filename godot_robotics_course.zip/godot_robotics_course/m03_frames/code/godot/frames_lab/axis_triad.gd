class_name AxisTriad
extends Node3D
## Draws three labelled arrows from this node's origin.
## Each arrow points along a direction given in THIS node's local coordinates, so a triad
## that is a child of a vehicle shows the vehicle's body axes in any convention you like.
## Colors follow the usual rule: x red, y green, z blue.

const COLORS: Array[Color] = [Color(0.9, 0.15, 0.15), Color(0.15, 0.75, 0.2), Color(0.2, 0.4, 1.0)]

@export var length := 1.0
@export var shaft_radius := 0.025
## Render layer of the arrows. Layer 2 by default, so on-board cameras can hide them
## (the FPV camera's cull_mask contains layer 1 only).
@export_flags_3d_render var layers := 2

var _arrows: Array[Node3D] = []


## dirs: local directions of axis x, y, z. names: label text for each arrow.
func build(dirs: Array[Vector3], names: PackedStringArray) -> void:
	for a in _arrows:
		a.queue_free()
	_arrows.clear()
	for i in 3:
		var arrow := _make_arrow(COLORS[i], names[i])
		add_child(arrow)
		# The arrow mesh points along its own +Y. Rotate +Y onto the requested direction.
		arrow.basis = Basis(Quaternion(Vector3.UP, dirs[i].normalized()))
		_arrows.append(arrow)


## World-space unit vector of arrow i, measured from the scene tree (what you SEE).
func world_dir(i: int) -> Vector3:
	return (_arrows[i].global_basis * Vector3.UP).normalized()


func _make_arrow(color: Color, text: String) -> Node3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.no_depth_test = true          # arrows stay visible inside the hull
	mat.render_priority = 1

	var root := Node3D.new()
	var shaft := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = shaft_radius
	cyl.bottom_radius = shaft_radius
	cyl.height = length * 0.8
	shaft.mesh = cyl
	shaft.material_override = mat
	shaft.layers = layers
	shaft.position = Vector3(0, length * 0.4, 0)
	root.add_child(shaft)

	var head := MeshInstance3D.new()
	var cone := CylinderMesh.new()
	cone.top_radius = 0.0
	cone.bottom_radius = shaft_radius * 3.0
	cone.height = length * 0.2
	head.mesh = cone
	head.material_override = mat
	head.layers = layers
	head.position = Vector3(0, length * 0.9, 0)
	root.add_child(head)

	var label := Label3D.new()
	label.text = text
	label.modulate = color
	label.outline_size = 8
	label.font_size = 40
	label.pixel_size = 0.004
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	label.layers = layers
	label.position = Vector3(0, length * 1.12, 0)
	root.add_child(label)
	return root
