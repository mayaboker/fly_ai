extends Node3D
## Module 3 lab: show a streamed test body with its body axes drawn in the SOURCE convention,
## print the world vectors measured on those arrows whenever the body holds still, and
## carry an FPV camera on a fixed body-to-camera mount.
##
## Command-line options (after "--"), all optional:
##   --source=flu|frd          body convention of the physics side (PyBullet = flu, JSBSim = frd)
##   --listen-port=9001 --physics-port=9002
##   --quit-after-holds=N      quit after N holds were measured (for automated runs)
##   --screenshot=PATH --screenshot-hold=N   save the window image at hold N

enum Convention { FLU, FRD }

const VEHICLE_ID := 10
const STILL_S := 0.4                 ## wall seconds without change that count as a hold

## Physics-side body convention. PyBullet = FLU, JSBSim = FRD.
@export var source_convention := Convention.FLU
@export var listen_port := RsProtocol.PORT_TO_VIEWER
@export var physics_port := RsProtocol.PORT_TO_PHYSICS

# Body axes of each convention, written in Godot MODEL coordinates (x right, y up, z back).
const AXES := {
	Convention.FLU: [Vector3(0, 0, -1), Vector3(-1, 0, 0), Vector3(0, 1, 0)],
	Convention.FRD: [Vector3(0, 0, -1), Vector3(1, 0, 0), Vector3(0, -1, 0)],
}
const NAMES := {
	Convention.FLU: ["x fwd", "y left", "z up"],
	Convention.FRD: ["x fwd", "y right", "z down"],
}

@onready var body: Node3D = $Body
@onready var body_axes: AxisTriad = $Body/BodyAxes
@onready var fpv_mount: Marker3D = $Body/FpvMount
@onready var fpv_cam: Camera3D = $UI/FpvBox/FpvViewport/FpvCamera
@onready var hud: Label = $UI/Hud

var bridge: SimBridge
var _last_quat := Quaternion(0, 0, 0, 0)   # 'no pose yet': the first pose always counts as a move
var _still_since := 0.0
var _reported := false
var _holds := 0
var _quit_after := 0
var _shot_path := ""
var _shot_hold := 1
var _pillars := {}                   # name -> world position of the pillar top


func _ready() -> void:
	Engine.max_fps = 60
	_parse_args()
	# The bridge is created in code so the ports from the command line apply before it binds.
	bridge = SimBridge.new()
	bridge.listen_port = listen_port
	bridge.physics_port = physics_port
	add_child(bridge)

	var dirs: Array[Vector3] = []
	dirs.assign(AXES[source_convention])
	body_axes.build(dirs, PackedStringArray(NAMES[source_convention]))
	var world_dirs: Array[Vector3] = [Vector3.RIGHT, Vector3.UP, Vector3.BACK]
	$WorldAxes.build(world_dirs, PackedStringArray(["+X east", "+Y up", "+Z south"]))
	$ChaseCam.look_at_from_position(Vector3(2.5, 3.0, 6.5), Vector3(0, 1.2, 0))   # from the south-east
	_build_compass()
	_build_grid()
	print("[frames_lab] source=%s  listening on %d" % [Convention.keys()[source_convention], listen_port])


func _process(_delta: float) -> void:
	if not bridge.has_vehicle(VEHICLE_ID):
		return
	body.global_transform = bridge.latest_transform(VEHICLE_ID)   # raw pose; Module 5 interpolates
	var q := body.global_basis.get_rotation_quaternion()
	var now := Time.get_ticks_msec() / 1000.0
	if absf(q.dot(_last_quat)) < 0.999999:                        # moved (q and -q count as equal)
		_last_quat = q
		_still_since = now
		_reported = false
	elif not _reported and now - _still_since > STILL_S:
		_reported = true
		_holds += 1
		_report_hold()
	_update_hud()


func _report_hold() -> void:
	var names: Array = NAMES[source_convention]
	var parts := PackedStringArray()
	for i in 3:
		parts.append("%s -> %s" % [names[i], _fmt(body_axes.world_dir(i))])
	print("[frames_lab] HOLD %d t=%6.2f  measured  %s" % [_holds, bridge.latest_t_sim, "  ".join(parts)])
	_check_projection()
	if _shot_path != "" and _holds == _shot_hold:
		await RenderingServer.frame_post_draw
		var img := get_viewport().get_texture().get_image()
		var fpv_img := fpv_cam.get_viewport().get_texture().get_image()
		if img and fpv_img:
			img.save_png(_shot_path)
			fpv_img.save_png(_shot_path.get_basename() + "_fpv.png")
			print("[frames_lab] saved screenshots ", _shot_path, " and *_fpv.png")
	if _quit_after > 0 and _holds >= _quit_after:
		get_tree().quit()


## Project the pillar tops with Godot's camera and with our own pinhole model in the
## OpenCV optical frame. The two pixel positions must agree.
func _check_projection() -> void:
	var size := Vector2(fpv_cam.get_viewport().get_visible_rect().size)
	var fy := (size.y / 2.0) / tan(deg_to_rad(fpv_cam.fov) / 2.0)   # fov is vertical
	var fx := fy
	var inv := fpv_mount.global_transform.affine_inverse()           # world -> Godot camera frame
	for pillar_name in _pillars:
		var p_world: Vector3 = _pillars[pillar_name]
		var p_cam := inv * p_world                                   # x right, y up, -z forward
		var p_opt := Vector3(p_cam.x, -p_cam.y, -p_cam.z)            # x right, y down, z forward
		if p_opt.z < 0.1:
			continue
		var uv := Vector2(fx * p_opt.x / p_opt.z + size.x / 2.0, fy * p_opt.y / p_opt.z + size.y / 2.0)
		if uv.x < 0 or uv.y < 0 or uv.x > size.x or uv.y > size.y:
			continue
		var godot_uv := fpv_cam.unproject_position(p_world)
		print("[frames_lab]   fpv sees pillar %s: pinhole (%.1f, %.1f)  godot (%.1f, %.1f)" % [
				pillar_name, uv.x, uv.y, godot_uv.x, godot_uv.y])


func _update_hud() -> void:
	var names: Array = NAMES[source_convention]
	var lines := PackedStringArray()
	lines.append("source %s   t_sim %.2f   %s   holds %d   %d fps" % [Convention.keys()[source_convention],
			bridge.latest_t_sim, "STALE" if bridge.is_stale() else "live", _holds,
			Engine.get_frames_per_second()])
	for i in 3:
		lines.append("body %-7s -> world %s" % [names[i], _fmt(body_axes.world_dir(i))])
	lines.append("world: +X east, +Y up, +Z south (north = -Z)")
	hud.text = "\n".join(lines)


func _fmt(v: Vector3) -> String:
	return "(%+.2f, %+.2f, %+.2f)" % [v.x, v.y, v.z]


func _parse_args() -> void:
	for arg in OS.get_cmdline_user_args():
		var kv := arg.trim_prefix("--").split("=", true, 1)
		if kv.size() != 2:
			continue
		match kv[0]:
			"source":
				source_convention = Convention.FRD if kv[1].to_lower() == "frd" else Convention.FLU
			"listen-port":
				listen_port = int(kv[1])
			"physics-port":
				physics_port = int(kv[1])
			"quit-after-holds":
				_quit_after = int(kv[1])
			"screenshot":
				_shot_path = kv[1]
			"screenshot-hold":
				_shot_hold = int(kv[1])


## Four colored pillars, 8 m away in each compass direction, so you always know where north is.
func _build_compass() -> void:
	var spots := {"N": [Vector3(0, 0, -8), Color(0.2, 0.4, 1.0)], "E": [Vector3(8, 0, 0), Color(0.9, 0.15, 0.15)],
			"S": [Vector3(0, 0, 8), Color(0.95, 0.85, 0.2)], "W": [Vector3(-8, 0, 0), Color(0.95, 0.95, 0.95)]}
	for key in spots:
		var pos: Vector3 = spots[key][0]
		var mat := StandardMaterial3D.new()
		mat.albedo_color = spots[key][1]
		var cyl := CylinderMesh.new()
		cyl.top_radius = 0.2
		cyl.bottom_radius = 0.2
		cyl.height = 2.0
		cyl.material = mat
		var m := MeshInstance3D.new()
		m.mesh = cyl
		m.position = pos + Vector3(0, 1.0, 0)
		add_child(m)
		var label := Label3D.new()
		label.text = key
		label.font_size = 96
		label.pixel_size = 0.01
		label.outline_size = 12
		label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		label.position = pos + Vector3(0, 2.6, 0)
		add_child(label)
		_pillars[key] = pos + Vector3(0, 2.0, 0)


## 1 m grid lines on the ground for scale.
func _build_grid() -> void:
	var im := ImmediateMesh.new()
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(0.3, 0.32, 0.3)
	im.surface_begin(Mesh.PRIMITIVE_LINES, mat)
	for i in range(-12, 13):
		im.surface_add_vertex(Vector3(i, 0.005, -12))
		im.surface_add_vertex(Vector3(i, 0.005, 12))
		im.surface_add_vertex(Vector3(-12, 0.005, i))
		im.surface_add_vertex(Vector3(12, 0.005, i))
	im.surface_end()
	var grid := MeshInstance3D.new()
	grid.mesh = im
	add_child(grid)
