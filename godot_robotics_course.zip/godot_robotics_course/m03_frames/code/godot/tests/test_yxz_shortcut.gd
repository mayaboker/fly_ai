extends SceneTree
## Proves on the Godot side that the JSBSim shortcut
##     Basis.from_euler(Vector3(theta, -psi, -phi))      (default order YXZ)
## gives the same basis as the full Python chain  M_GODOT_ENU . T_ENU_NED . R_zyx . D_FRD_FLU . C_FLU_MODEL.
##
## 1. cd robosim/physics && python tests/test_frames_known.py      (writes tests/out/yxz_cases.json)
## 2. cd robosim/godot   && godot --headless --script res://tests/test_yxz_shortcut.gd
## Optional: pass another JSON path after "--".


func _init() -> void:
	var path := ProjectSettings.globalize_path("res://").path_join("../physics/tests/out/yxz_cases.json")
	var user_args := OS.get_cmdline_user_args()
	if user_args.size() > 0:
		path = user_args[0]
	var text := FileAccess.get_file_as_string(path)
	if text.is_empty():
		push_error("cannot read %s (run python tests/test_frames_known.py first)" % path)
		quit(2)
		return
	var cases: Array = JSON.parse_string(text)
	var worst := 0.0
	for c: Dictionary in cases:
		var b := Basis.from_euler(Vector3(c.theta, -c.psi, -c.phi))   # order defaults to YXZ
		for i in 3:
			var col: Array = c.cols[i]
			worst = maxf(worst, (b[i] - Vector3(col[0], col[1], col[2])).length())
	var ok := worst < 1e-5
	print("yxz_shortcut: %d cases, worst column error %.9f -> %s" % [cases.size(), worst, "PASS" if ok else "FAIL"])
	quit(0 if ok else 1)
