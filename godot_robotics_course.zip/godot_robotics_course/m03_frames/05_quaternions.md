# 5. Quaternions in practice

The course sends orientation as a quaternion because it has no Euler order to get wrong, no gimbal lock, and it interpolates smoothly. It still has four practical traps: **element order**, **normalization**, **interpolation path**, and **sign**. Each trap below comes with the measured behavior of the tools you use.

## Just enough theory

A unit quaternion for a rotation by angle α about the unit axis **n** is

```
q = (x, y, z, w) = (n·sin(α/2), cos(α/2))          # course order: vector part first, w last
```

- Identity is (0, 0, 0, 1).
- Yaw +90° about z is (0, 0, sin 45°, cos 45°) = (0, 0, 0.7071, 0.7071).
- The angle between two orientations is `2·acos(|q1 · q2|)`.

`frames.quat_to_matrix` and `frames.matrix_to_quat` convert both ways. `matrix_to_quat` always returns w ≥ 0.

## Trap 1: element order

| Library / format | Order | Note |
|---|---|---|
| robosim wire, `frames.py` | (x, y, z, w) | |
| PyBullet | (x, y, z, w) | `getBasePositionAndOrientation`, `getQuaternionFromEuler` |
| Godot `Quaternion(x, y, z, w)` | (x, y, z, w) | properties `.x .y .z .w` |
| ROS `geometry_msgs/Quaternion` | x, y, z, w fields | |
| SciPy `Rotation.from_quat` | (x, y, z, w) by default | `scalar_first=True` switches |
| Eigen `Quaterniond(w, x, y, z)` | constructor (w, x, y, z) | but `.coeffs()` returns (x, y, z, w) |
| `transforms3d`, MuJoCo, many papers | (w, x, y, z) | |

A wrong order doesn't crash. It gives you a different, valid rotation. `test_frames_known.py::test_quaternion_traps` shows the classic case. Yaw +90° written in (w, x, y, z) order is `(0.7071, 0, 0, 0.7071)`. Read as (x, y, z, w), the same four numbers are a **90° roll**: forward stays forward, and the vehicle lies on its side.

Defenses:

1. Put the order in the name: `q_xyzw`, `q_wxyz`.
2. Convert at the library boundary, in one function, and test it with yaw +90°. That is the cheapest test that catches an order swap, because it moves forward to left.
3. Never index a quaternion by position in GDScript. Use `q.w`, not `q[3]`.

## Trap 2: normalization

Rotations need unit quaternions. They drift from unit length in three ways: float32 on the wire (6–7 significant digits), repeated multiplication, and hand-typed values like 0.7071. The libraries react differently, and only some of them complain:

| Operation (Godot 4.7.2) | With a non-unit quaternion |
|---|---|
| `Basis(q)` | works: the result is a proper rotation, built as if q were normalized |
| `q * v` (rotate a vector) | prints `ERROR: The quaternion … must be normalized` and returns `v` unrotated |
| `a.slerp(b, t)` | prints `ERROR: The end quaternion … must be normalized` and returns identity |
| `Quaternion(basis)` of a scaled basis | prints `must be normalized in order to be casted to a Quaternion` and returns identity; use `basis.get_rotation_quaternion()` |

`frames.quat_to_matrix` normalizes internally, and `SimBridge` calls `msg.quat.normalized()` on every received pose. Do the same in any code you write that receives quaternions. It is one call, and it costs almost nothing.

```gdscript
var q: Quaternion = msg.quat.normalized()
assert(q.is_normalized())
```

## Trap 3: q and −q are the same rotation

Negating all four elements changes α/2 to α/2 + 180°, which is a full extra turn, so the rotation is unchanged. Consequences, all checked in Godot 4.7.2:

```gdscript
var q := Quaternion(0, 0, 0.7071068, 0.7071068)
print(q == -q)                                   # false
print(q.is_equal_approx(-q))                      # false
print(Basis(q).is_equal_approx(Basis(-q)))        # true  (same rotation)
print(q.dot(-q))                                  # -1.0
```

- **Comparisons:** test `absf(q1.dot(q2)) > 1.0 - 1e-6`, or compare bases. The lab's hold detector uses `absf(q.dot(_last_quat))` for exactly this reason.
- **Logging and plots:** a quaternion component that suddenly flips sign is usually the same orientation written the other way. Plot Euler angles or rotation angles, not raw components. `matrix_to_quat` picks w ≥ 0 so its output is stable.
- **Interpolation:** see the next trap.

## Trap 4: interpolation takes the long way round

Slerp (spherical linear interpolation) moves at a constant angular rate between two orientations. With q and −q both available for the end pose, there are two arcs: a short one and a long one. Measured in Godot 4.7.2, interpolating halfway from identity to a 170° yaw:

| Call | End given as | Halfway angle |
|---|---|---|
| `Quaternion.IDENTITY.slerp(qb, 0.5)` | qb | 85° |
| `Quaternion.IDENTITY.slerp(-qb, 0.5)` | −qb | 85° (Godot's `slerp` flips to the short arc) |
| `Quaternion.IDENTITY.slerpni(-qb, 0.5)` | −qb | **95°** (`slerpni` = no invert, takes the arc it was given) |

Godot's `slerp` takes the short arc for you, and `SimBridge.sample()` uses it. A hand-written slerp in Python or C++ often doesn't, and you then see a vehicle spin the long way round when its heading crosses the ±180° seam. The lab's `frames_extra.quat_slerp` flips the sign when the dot product is negative. The test checks that the halfway point to −q(170°) is 85°:

```python
def quat_slerp(q0, q1, t):
    q0, q1 = q0 / np.linalg.norm(q0), q1 / np.linalg.norm(q1)
    d = float(np.dot(q0, q1))
    if d < 0.0:                       # take the short arc
        q1, d = -q1, -d
    if d > 0.9995:                    # nearly equal: normalized lerp
        q = q0 + t * (q1 - q0)
        return q / np.linalg.norm(q)
    th = math.acos(d)
    return (math.sin((1 - t) * th) * q0 + math.sin(t * th) * q1) / math.sin(th)
```

Never interpolate Euler angles for display. Interpolating heading from 179° to −179° goes the long way through 0°.

## Converting between Godot `Quaternion`, `Basis` and numpy

| From → to | GDScript | Python (`frames.py`) |
|---|---|---|
| quaternion → matrix | `Basis(q)` | `quat_to_matrix(q_xyzw)` |
| matrix → quaternion | `basis.get_rotation_quaternion()` (safe with scale) or `Quaternion(basis)` (pure rotation only) | `matrix_to_quat(R)` → (x,y,z,w), w ≥ 0 |
| Euler → quaternion | `Quaternion.from_euler(Vector3(x, y, z))` (YXZ) | `matrix_to_quat(euler_zyx_to_matrix(r, p, y))` (aerospace ZYX) |
| axis-angle → quaternion | `Quaternion(axis_unit, angle)` | `(*(n * sin(a/2)), cos(a/2))` |
| vector rotation | `q * v` or `basis * v` | `quat_to_matrix(q) @ v` |

A numpy matrix and a Godot `Basis` agree element by element: `R[:, 0]` is `basis.x`. We checked that `Quaternion.from_euler(e)` and `Quaternion(Basis.from_euler(e))` give the same four numbers in 4.7.2.

Composition order is the same in both: `q_a_c = q_a_b * q_b_c` in Godot matches `R_a_c = R_a_b @ R_b_c` in numpy. Godot's `*` on quaternions is the Hamilton product, the same convention as the matrix chain.

## Try it

- In Python, build the yaw +90° quaternion in (w, x, y, z) order, pass it to `quat_to_matrix` (which expects x, y, z, w), and print where (1, 0, 0) goes. Name the rotation you actually got.
- In Godot, rotate `Vector3.FORWARD` by `Quaternion(0, 0, 1.4142, 1.4142)` with `*` and read the error message. Fix it with `.normalized()`.
- Make a heading sweep from 170° to −170° in 10 steps. Interpolate it once with your own slerp without the sign flip and once with `quat_slerp`. Plot the yaw. Which version crosses through 0°?
- Send the same pose twice over the wire, once as q and once as −q. Does the Godot body move? Does the hold detector in the lab report a move?

## References

- Godot `Quaternion` (`slerp`, `slerpni`, `is_normalized`, `from_euler`): <https://docs.godotengine.org/en/stable/classes/class_quaternion.html>
- Godot `Basis.get_rotation_quaternion`: <https://docs.godotengine.org/en/stable/classes/class_basis.html>
- K. Shoemake, *Animating Rotation with Quaternion Curves*, SIGGRAPH 1985 (slerp)
- J. Solà, *Quaternion kinematics for the error-state Kalman filter* (2017), section 1–2: conventions and the Hamilton vs JPL product
