# Module 3: Frames, units, quaternions and camera mounts (9 h)

## What you will build

You will build a PyBullet→Godot adapter and a JSBSim→Godot adapter, and prove both with tests. A test body streams from Python and rotates +90° about each of its axes in turn. Godot draws the body's x, y and z axes in the source convention and prints the world vectors it measures, so you can compare them with the vectors you worked out by hand. The body carries an FPV camera on a fixed mount, and you will check its projection against the OpenCV pinhole model.

## Prerequisites

- [Module 1](../m01_editor_gdscript/README.md) (editor, GDScript, running a scene) and [Module 2](../m02_scene_assets/README.md) (vehicle models built nose toward −Z, top toward +Y).
- [00_setup](../00_setup/README.md) done: `robosim/physics/robosim` and `robosim/godot/bridge` copied from the reference.
- Linear algebra you already know: rotation matrices, dot products, and that the transpose of a rotation is its inverse.
- JSBSim: lessons 1–3 of the companion JSBSim course (see the [course README](../README.md#jsbsim-parallel-track)).
- Keep the [frames cheat sheet](../reference/frames.md) open. This module derives everything on it.

## Sub-topics

| File | Topic | Time |
|---|---|---:|
| [01_why_frames.md](01_why_frames.md) | World, body and sensor frames. The `R_a_b` notation. Active vs passive rotations | 1 h |
| [02_godot_conventions.md](02_godot_conventions.md) | +Y up, −Z forward, `Transform3D`/`Basis`, local vs global, Euler order YXZ | 1 h 15 |
| [03_pybullet_conventions.md](03_pybullet_conventions.md) | ENU world, FLU body, (x,y,z,w). Deriving `M_GODOT_ENU` and `C_FLU_MODEL` | 1 h |
| [04_jsbsim_geodetic.md](04_jsbsim_geodetic.md) | lat/lon/alt, NED, FRD, φ θ ψ, feet. Flat-earth error. The YXZ shortcut | 1 h 30 |
| [05_quaternions.md](05_quaternions.md) | Order traps, normalization, slerp, q vs −q, Godot `Quaternion`/`Basis` | 1 h |
| [06_camera_mounts.md](06_camera_mounts.md) | Fixed mounts with `Marker3D`, FPV vs down camera, optical frame, gimbal vs rigid | 1 h 15 |
| [lab.md](lab.md) | Known-rotation tests, streaming test body, axis arrows, FPV mount, cheat sheet | 2 h |

## Deliverables

1. `physics/tests/test_frames_known.py` passes. It covers identity and 90° roll, pitch and yaw for both PyBullet and JSBSim inputs, with hand-derived Godot vectors.
2. `physics/tests/test_geo_error.py` passes, and you have written down the flat-earth error of your chosen origin.
3. `physics/sims/frames_demo.py` streams the rotating test body from PyBullet and from JSBSim.
4. `godot/frames_lab/frames_lab.tscn` shows labelled body-axis arrows and an FPV camera on a fixed `Marker3D` mount, and it prints the measured world vectors.
5. `godot/tests/test_yxz_shortcut.gd` passes.
6. **Your own one-page frame cheat sheet** (`robosim/FRAMES.md`), filled in from the template in [lab.md](lab.md#9-deliverable-your-frame-cheat-sheet).

## Check

The module is done when all of the following are true:

1. `python tests/test_frames_known.py` prints `frames_known: all 8 tests pass`, and `python tests/test_geo_error.py` prints `geo_error: all tests pass`.
2. `godot --headless --script res://tests/test_yxz_shortcut.gd` prints `PASS` (54 cases, worst column error below 1e-5).
3. **Before any JSBSim pose is wired**, `FRAMES.md` states the local origin (lat0, lon0, h0), the flat-earth method, its error at your largest operating distance, and the unit conversions (ft → m, and which angles are radians).
4. With `frames_demo.py` streaming, each of the 8 holds below appears in Godot's `HOLD` lines. Every component matches the table to within ±0.01.

| Source | Pose | body x → Godot | body y → Godot | body z → Godot |
|---|---|---|---|---|
| PyBullet (FLU) | identity | (1, 0, 0) east | (0, 0, −1) north | (0, 1, 0) up |
| PyBullet (FLU) | roll +90° | (1, 0, 0) east | (0, 1, 0) up | (0, 0, 1) south |
| PyBullet (FLU) | pitch +90° | (0, −1, 0) down | (0, 0, −1) north | (1, 0, 0) east |
| PyBullet (FLU) | yaw +90° | (0, 0, −1) north | (−1, 0, 0) west | (0, 1, 0) up |
| JSBSim (FRD) | identity | (0, 0, −1) north | (1, 0, 0) east | (0, −1, 0) down |
| JSBSim (FRD) | φ = +90° | (0, 0, −1) north | (0, −1, 0) down | (−1, 0, 0) west |
| JSBSim (FRD) | θ = +90° | (0, 1, 0) up | (1, 0, 0) east | (0, 0, −1) north |
| JSBSim (FRD) | ψ = +90° | (1, 0, 0) east | (0, 0, 1) south | (0, −1, 0) down |

5. The FPV check lines (`fpv sees pillar …`) show the pinhole pixel equal to Godot's `unproject_position` pixel, to within 0.5 px.

## Common mistakes

- **Reading a quaternion in the wrong order.** If you read (x, y, z, w) as (w, x, y, z), a 90° yaw turns into a 90° roll. The test `test_quaternion_traps` shows exactly this. Name the order in every variable (`q_xyzw`).
- **Converting in two places.** If Godot also "fixes" the axes, the fixes cancel or double. Convert once, in Python. The viewer applies the wire quaternion and nothing else.
- **Forgetting that +pitch has opposite meanings.** In FLU (PyBullet), +pitch about +y (left) puts the nose **down**. In FRD (JSBSim), +θ puts the nose **up**.
- **Feet on the wire.** JSBSim's `h-sl-ft` sent as meters puts a 100 m hover at 328 m. Convert at the property read, and keep the unit in the variable name.
- **Trusting "flat earth is fine" without a number.** At 32° N, an origin that uses the equatorial radius for both axes is already 3.9 m off at 1 km north. Measure your own error with `test_geo_error.py`.
- **Comparing quaternions with `==`.** q and −q are the same rotation, but `q == -q` is `false` in Godot and in numpy. Compare `abs(q1.dot(q2))` with 1, or compare matrices.
