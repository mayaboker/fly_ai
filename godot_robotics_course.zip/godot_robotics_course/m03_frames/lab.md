# Lab 3: Verified frame adapters, a rotating test body, and an FPV mount (about 2 h)

You will prove, three times over, that the PyBullet→Godot and JSBSim→Godot conversions are right:

1. on paper, with a table you fill in by hand,
2. in Python, with tests that check that table,
3. in Godot, by measuring the arrows on a streamed body and comparing them with what Python predicted.

Then you will put an FPV camera on a fixed mount and check its projection against the OpenCV pinhole model.

## Files added or changed

| File in `robosim/` | Status | Purpose |
|---|---|---|
| `physics/robosim/frames_extra.py` | **new** | exact geodetic→ENU, `GeoOriginLocal`, slerp, optical frame, pinhole |
| `physics/tests/test_frames_known.py` | **new** | known rotations, PyBullet and JSBSim inputs, hand-derived Godot vectors |
| `physics/tests/test_geo_error.py` | **new** | flat-earth error vs exact WGS84, and JSBSim's Earth model check |
| `physics/sims/frames_demo.py` | **new** | streams the test body (vehicle id 10) rotating about each axis |
| `godot/frames_lab/axis_triad.gd` | **new** | `AxisTriad`: three labelled arrows in any convention |
| `godot/frames_lab/frames_lab.gd`, `frames_lab.tscn` | **new** | the lab scene |
| `godot/tests/test_yxz_shortcut.gd` | **new** | Godot-side proof of `from_euler(θ, −ψ, −φ)` |
| `physics/aircraft/quad_rpy/` | copy if missing | from `reference/code/aircraft/quad_rpy` (used only as a JSBSim state holder) |
| `FRAMES.md` | **new** | your cheat sheet (step 9) |

`frames.py`, `bridge.py` and `godot/bridge/` are **not** changed. This module adds one file to the shared package (`frames_extra.py`) and nothing else.

The finished files are in [code/](code/README.md). Try each step before you look.

> **Running scripts from `physics/`.** Every script in this lab adds its parent `physics/` folder to `sys.path`, so `python tests/…` and `python sims/…` work from `robosim/physics`. If an older script fails with `No module named 'robosim'`, run it as `PYTHONPATH=. python tests/<script>.py`.

## 1. Derive the expected table by hand (20 min)

Do this on paper **before** running anything. It is the part that builds intuition, and the tests are only worth something if you derived the numbers independently.

The Godot world is x = East, y = Up, z = South. For each case, write where the body's x, y and z axes point.

- **PyBullet (FLU).** Start from identity: forward = east, left = north, up = up. Rotate +90° about one body axis with the right-hand rule. Example for roll (about x = forward): y → z and z → −y.
- **JSBSim (FRD).** Start from φ = θ = ψ = 0: forward = north, right = east, down = down. Use the right-hand rule again: +θ about the right axis puts the nose up, and +ψ about down turns it clockwise, toward east.

Fill in this table, then compare with the [Check table in the README](README.md#check):

| Source | Pose | body x | body y | body z |
|---|---|---|---|---|
| PyBullet | identity | | | |
| PyBullet | roll +90 | | | |
| PyBullet | pitch +90 | | | |
| PyBullet | yaw +90 | | | |
| JSBSim | identity | | | |
| JSBSim | φ +90 | | | |
| JSBSim | θ +90 | | | |
| JSBSim | ψ +90 | | | |

The two entries most people get wrong are PyBullet pitch (the nose goes **down**) and JSBSim roll (body z, which is down, ends up pointing **west**).

## 2. Known-rotation tests (20 min)

Copy `code/physics/tests/test_frames_known.py` and `code/physics/robosim/frames_extra.py` into your project. Better still, write the test yourself from the table, then compare. Its structure:

```python
FLU_IN_MODEL = {"x": (0, 0, -1), "y": (-1, 0, 0), "z": (0, 1, 0)}   # body axes in Godot MODEL coords
FRD_IN_MODEL = {"x": (0, 0, -1), "y": (1, 0, 0), "z": (0, -1, 0)}
PYBULLET_CASES = [("roll +90", (H, 0, 0, H), {"x": E, "y": UP, "z": S}), ...]    # quaternion (x,y,z,w)
JSBSIM_CASES   = [("roll +90", (90, 0, 0),   {"x": N, "y": DOWN, "z": W}), ...]  # phi, theta, psi deg

def test_pybullet_known_rotations():
    for label, q_enu_flu, expected in PYBULLET_CASES:
        _, q_godot = enu_flu_to_godot((0, 0, 0), q_enu_flu)
        got = body_axes_in_godot(wire_round_trip(quat_to_matrix(q_godot)), FLU_IN_MODEL)
        check(got, expected, "PyBullet " + label)
```

`wire_round_trip` rounds the quaternion to float32, as the bridge does, so the test checks exactly what Godot receives. The file also tests positions (ENU→Godot, and feet→meters through `jsbsim_state_to_godot` with a dict standing in for a JSBSim instance), the YXZ shortcut, the quaternion traps, the optical frame, and the FPV extrinsics in FLU. Run it:

```bash
cd ~/robosim/physics
python tests/test_frames_known.py
```

Expected output:

```
  ok  test_camera_extrinsics_in_flu
  ok  test_camera_optical_frame
  ok  test_jsbsim_known_rotations
  ok  test_jsbsim_yxz_shortcut
  ok  test_positions
  ok  test_pybullet_known_rotations
  ok  test_quaternion_traps
  ok  test_write_godot_cases
frames_known: all 8 tests pass

Expected Godot world vectors (x = East, y = Up, z = South):
  PyBullet FLU  identity   body x (+1, +0, +0)  body y (+0, +0, -1)  body z (+0, +1, +0)
  ...
wrote /home/you/robosim/physics/tests/out/yxz_cases.json (54 cases)
```

`python -m pytest tests/test_frames_known.py` works too (8 passed).

## 3. Choose and document the JSBSim origin, before wiring poses (15 min)

Copy `code/physics/tests/test_geo_error.py` and run it:

```bash
python tests/test_geo_error.py
```

```
  ok  test_error_bounds
  ok  test_jsbsim_uses_wgs84
geo_error: all tests pass

Origin 32 N 35 E, h0 = 0. Worst horizontal error over 72 bearings, and curvature drop:
  distance | GeoOrigin (equatorial R) | GeoOriginLocal (M, N) | drop below tangent plane
      1 km |                 3.90 m   |             0.057 m   |       0.08 m
      5 km |                19.53 m   |             1.417 m   |       1.97 m
     20 km |                78.39 m   |            22.705 m   |      31.48 m
```

(JSBSim prints its startup banner in between. That is normal.) [Sub-topic 4](04_jsbsim_geodetic.md#measured-error-at-32-n) explains the numbers. Now **write the origin block of your cheat sheet** (step 9) before you go on. Use your own site's latitude with `--lat`. This is part of the Check: the origin, the method, the error at your largest distance, and the unit conversions are on paper before any JSBSim pose reaches Godot.

## 4. The streaming script (20 min)

`physics/sims/frames_demo.py` poses a test body and streams it as vehicle id 10. It is short, so read all of it. The key parts:

```python
class PyBulletSource:
    def pose(self, rpy_rad):
        q_cmd = self.p.getQuaternionFromEuler(rpy_rad)
        self.p.resetBasePositionAndOrientation(self.body, [0, 0, HEIGHT_M], q_cmd)
        pos_enu, q_enu_flu = self.p.getBasePositionAndOrientation(self.body)   # read back, (x,y,z,w)
        return enu_flu_to_godot(pos_enu, q_enu_flu)

class JSBSimSource:
    def pose(self, rpy_rad):
        self.fdm["ic/phi-rad"], self.fdm["ic/theta-rad"], self.fdm["ic/psi-true-rad"] = rpy_rad
        self.fdm.run_ic()                                   # JSBSim recomputes its full state
        return jsbsim_state_to_godot(self.fdm, self.origin) # reads lat/lon/h-sl-ft and phi/theta/psi
```

Neither source runs dynamics. PyBullet teleports the body, and JSBSim is re-initialized at each step. So the only thing under test is the frame chain. The sequence is: identity hold, then for roll, pitch and yaw, a ramp to +90°, a hold, and a ramp back. At the start of each hold, Python prints the vectors **it** predicts:

```
[frames_demo] HOLD roll +90   t=  5.00  expect  x fwd -> (+1.00, -0.00, +0.00)  y left -> (+0.00, +1.00, -0.00)  z up -> (-0.00, +0.00, +1.00)
```

The script waits for the viewer's HELLO before it streams, so you can start either side first.

## 5. The Godot scene (30 min)

Copy `code/godot/frames_lab/` into `robosim/godot/frames_lab/` and `code/godot/tests/` into `robosim/godot/tests/`. Then run `godot --headless --path ~/robosim/godot --import` once (it registers the new `class_name AxisTriad`). Open `frames_lab.tscn` and look at the tree:

| Node | Type | Notes |
|---|---|---|
| `FramesLab` | Node3D | `frames_lab.gd`; creates the `SimBridge` in code so command-line ports apply before it binds |
| `WorldAxes` | Node3D + `axis_triad.gd` | Godot world axes, labelled "+X east", "+Y up", "+Z south" |
| `Body` | Node3D | receives `global_transform` from the wire |
| `Body/Hull`, `Nose`, `Fin` | MeshInstance3D | orange nose at −Z, fin on top (+Y): MODEL frame |
| `Body/BodyAxes` | Node3D + `axis_triad.gd` | body x, y, z **in the source convention** |
| `Body/FpvMount` | Marker3D | (0, 0.1, −0.85), no rotation: the fixed body→camera transform |
| `Body/FpvMount/ToFpvCamera` | RemoteTransform3D | drives `UI/FpvBox/FpvViewport/FpvCamera` |
| `ChaseCam` | Camera3D | fixed observer south-east of the body |
| `UI/Hud`, `UI/FpvBox` | Label, SubViewportContainer | live vectors; 320×240 FPV picture-in-picture |

The two ideas that matter:

**Arrows in the source convention.** `AxisTriad.build(dirs, names)` draws one arrow per direction, given in the parent's local (MODEL) coordinates. For PyBullet the body axes are FLU, which in MODEL coordinates are forward (0,0,−1), left (−1,0,0) and up (0,1,0). For JSBSim they are FRD: forward (0,0,−1), right (1,0,0) and down (0,−1,0). The arrows are children of `Body`, so Godot rotates them with the received quaternion. Nothing in GDScript knows about ENU or NED.

```gdscript
const AXES := {
	Convention.FLU: [Vector3(0, 0, -1), Vector3(-1, 0, 0), Vector3(0, 1, 0)],
	Convention.FRD: [Vector3(0, 0, -1), Vector3(1, 0, 0), Vector3(0, -1, 0)],
}
```

**Measure what you see.** When the body has been still for 0.4 s, the scene prints the world direction of each **drawn** arrow (`arrow.global_basis * Vector3.UP`), so the measurement includes everything between the wire and the screen:

```gdscript
func _process(_delta: float) -> void:
	...
	body.global_transform = bridge.latest_transform(VEHICLE_ID)   # raw pose; Module 5 interpolates
	var q := body.global_basis.get_rotation_quaternion()
	if absf(q.dot(_last_quat)) < 0.999999:                        # moved (q and -q count as equal)
		...
	elif not _reported and now - _still_since > STILL_S:
		_report_hold()
```

Set the convention with the `source_convention` export in the Inspector, or on the command line with `-- --source=frd`.

## 6. Run it and compare (20 min)

Two terminals. The course ports are 9001/9002 (the defaults):

```bash
# terminal 1 (or open frames_lab.tscn in the editor and press F6)
cd ~/robosim/godot && godot --path . res://frames_lab/frames_lab.tscn -- --source=flu
# terminal 2
cd ~/robosim/physics && python sims/frames_demo.py --source pybullet
```

Watch the body roll, pitch and yaw. Compare each `[frames_lab] HOLD` line with the `[frames_demo] HOLD` line and with your hand table. Then stop Python, restart Godot with `--source=frd`, and run `python sims/frames_demo.py --source jsbsim`.

The output below is from our run with Python and headless Godot, using shorter ramps and holds (`--ramp 0.5 --hold 1.0 --once`) and test ports. Your `t=` values will differ.

```
[frames_demo] JSBSim: origin lat0=32.000000 deg N, lon0=35.000000 deg E, h0=0.0 m (flat earth, GeoOrigin); NED world, FRD body, phi/theta/psi rad; ft x 0.3048 -> m
[frames_demo] HOLD pitch +90  t=  3.50  expect  x fwd -> (-0.00, +1.00, -0.00)  y right -> (+1.00, +0.00, -0.00)  z down -> (-0.00, -0.00, -1.00)

[frames_lab] source=FRD  listening on 9130
[frames_lab] HOLD 1 t=  0.40  measured  x fwd -> (+0.00, +0.00, -1.00)  y right -> (+1.00, +0.00, +0.00)  z down -> (+0.00, -1.00, +0.00)
[frames_lab]   fpv sees pillar N: pinhole (160.0, 110.4)  godot (160.0, 110.4)
[frames_lab] HOLD 2 t=  1.88  measured  x fwd -> (+0.00, -0.00, -1.00)  y right -> (+0.00, -1.00, +0.00)  z down -> (-1.00, +0.00, -0.00)
[frames_lab]   fpv sees pillar N: pinhole (148.0, 122.4)  godot (148.0, 122.4)
[frames_lab] HOLD 3 t=  3.88  measured  x fwd -> (-0.00, +1.00, +0.00)  y right -> (+1.00, +0.00, -0.00)  z down -> (-0.00, +0.00, -1.00)
[frames_lab] HOLD 4 t=  5.90  measured  x fwd -> (+1.00, +0.00, +0.00)  y right -> (+0.00, -0.00, +1.00)  z down -> (+0.00, -1.00, -0.00)
[frames_lab]   fpv sees pillar E: pinhole (160.0, 110.4)  godot (160.0, 110.4)
```

All 8 holds (4 PyBullet + 4 JSBSim) matched the table exactly, to the printed two decimals. "−0.00" is a tiny negative rounding residue, and it counts as zero.

For an automated run without a window:

```bash
cd ~/robosim/godot
godot --headless --path . res://frames_lab/frames_lab.tscn -- --source=flu --quit-after-holds=4 &
cd ../physics && python sims/frames_demo.py --source pybullet --once
```

On a slow machine (software rendering), the first identity hold can be missed while shaders compile. Without `--once` the sequence repeats, so just wait for the next round.

## 7. The FPV camera on a fixed mount (15 min)

The FPV camera never gets a pose from the network. It inherits the body pose through `FpvMount`, the fixed body→camera transform. Check three things in the picture-in-picture:

- At the identity hold it looks at the pillar the nose points to: E for PyBullet, N for JSBSim.
- At the roll hold the horizon is **vertical**, with the ground on the right, because the right side went down.
- At the JSBSim pitch +90° hold it sees only sky.

The `fpv sees pillar` lines are the numeric version. For every pillar top in view, the scene projects the point twice: once through the OpenCV optical frame with `fy = (H/2)/tan(fov/2)`, and once with Godot's `Camera3D.unproject_position`. They agreed to 0.1 px in every hold we ran. The body's arrows are on render layer 2, and the FPV camera's `cull_mask` is 1, so the vehicle's debug arrows don't block its own camera.

![Lab scene, PyBullet roll +90° hold](code/frames_lab_flu_roll.png)

*Our xvfb render (software OpenGL, about 6–7 fps) at the PyBullet roll +90° hold. Body y (left) points up and body z (up) points south. The FPV inset shows the horizon vertical, with the E pillar in view. The JSBSim pitch +90° hold is in [code/frames_lab_frd_pitch.png](code/frames_lab_frd_pitch.png).*

## 8. Prove the YXZ shortcut inside Godot (5 min)

```bash
cd ~/robosim/godot
godot --headless --script res://tests/test_yxz_shortcut.gd
# yxz_shortcut: 54 cases, worst column error 0.000000133 -> PASS
```

It reads `physics/tests/out/yxz_cases.json` (written in step 2) and compares Godot's `Basis.from_euler(Vector3(θ, −ψ, −φ))` with the full Python chain. Break it on purpose: change the signs to `(θ, ψ, φ)` and confirm it prints `FAIL` with an error of about 2.0.

## 9. Deliverable: your frame cheat sheet

Write `robosim/FRAMES.md`, one page, in your own words. Copying the course's page teaches nothing. Template:

```markdown
# FRAMES.md: <your name>, <date>

## Wire rule
Everything on the wire is: ______ world frame, unit ______, quaternion order ______, model forward = ______

## Frames I use
| Frame | x | y | z | Where it comes from |
|---|---|---|---|---|
| Godot world | | | | |
| PyBullet world | | | | |
| JSBSim local | | | | |
| Body (PyBullet) | | | | |
| Body (JSBSim) | | | | |
| Godot model | | | | |
| Camera (optical) | | | | |

## Chains (with R_a_b = "a from b")
PyBullet: R_godot_model = ______
JSBSim:   R_godot_model = ______        GDScript shortcut: Basis.from_euler(Vector3(___, ___, ___))
Camera:   p_opt = ______ · p_world

## JSBSim origin (fill in BEFORE wiring poses)
lat0 = ______ deg   lon0 = ______ deg   h0 = ______ m   (what is it? runway threshold / pad / terrain center)
Method: GeoOrigin / GeoOriginLocal / exact     Error at my largest distance (____ km): ______ m
Units: length ft x 0.3048, speed ft/s x 0.3048, kt x 0.514444, angles: ______ on the wire, ______ in the UI

## Signs I must remember
+pitch FLU = ______   +theta FRD = ______   +yaw FLU = ______   +psi = ______   Godot rotation.y + = ______

## Quaternion orders in my stack
| Library | Order |
|---|---|

## Symptom → cause (add one every time you hit a bug)
| Symptom | Cause | Fix |
|---|---|---|
| identity PyBullet pose looks rotated 90° in Godot | (it is correct: PyBullet identity faces east) | none |
| | | |

## My sanity tests
- command: ______   expected output: ______
```

## Check

- [ ] `python tests/test_frames_known.py` → `frames_known: all 8 tests pass`
- [ ] `python tests/test_geo_error.py` → `geo_error: all tests pass`
- [ ] `godot --headless --script res://tests/test_yxz_shortcut.gd` → `PASS`
- [ ] `FRAMES.md` has the JSBSim origin, method, error and units filled in **before** step 6's JSBSim run
- [ ] For all 8 holds, the measured vectors match the [README table](README.md#check) to within ±0.01
- [ ] Every `fpv sees pillar` line has pinhole and Godot pixels within 0.5 px

## Stretch goals

1. **Replace the test body with your Module 2 vehicles.** Instance `vehicles/quad.tscn` (or the plane) under `Body` instead of the hull meshes. If a vehicle's nose is not on the −Z arrow, its model breaks the course convention. Fix it in the vehicle scene, never in the converter.
2. **Down camera and gimbal.** Add a `DownMount` and a level-gimbal variant (see [sub-topic 6](06_camera_mounts.md#gimbal-level-vs-rigid-mount)). During the roll hold, show rigid and gimbal images side by side.
3. **Use `GeoOriginLocal` in the JSBSim source** and fly the body 1 km north by setting `ic/lat-geod-rad` with `origin.to_geodetic(0, 1000, 1.5)`. Read Godot's z. How far off would `GeoOrigin` have been?
4. **Combined rotations.** Add a hold at φ = 30°, θ = 20°, ψ = 120° and derive the expected vectors with `euler_zyx_to_matrix`. Compare with `Basis.from_euler(Vector3(θ, −ψ, −φ))` in the Godot debugger.
5. **Velocity.** Send the JSBSim NED velocity converted to Godot, and draw it as a fourth arrow, in world space rather than as a body child.
