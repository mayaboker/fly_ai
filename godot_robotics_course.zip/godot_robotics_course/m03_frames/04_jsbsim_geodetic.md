# 4. JSBSim: geodetic position, NED, FRD, feet

JSBSim is an aerospace tool, and it reports state the aerospace way. Position is latitude, longitude and altitude on the WGS84 ellipsoid. Attitude is Euler angles φ, θ, ψ relative to local North-East-Down. Body axes are Forward-Right-Down. Lengths are in **feet**. Each of these is a separate conversion, and each has failed in somebody's project. This sub-topic takes them one at a time. It ends with a measured answer to "how far from the origin can I use flat earth?" and a proof of the one-line GDScript shortcut.

## The properties you read

| Property | Meaning | Unit | Course conversion |
|---|---|---|---|
| `position/lat-geod-rad` | geodetic latitude | rad | → local north (see below) |
| `position/long-gc-rad` | longitude (same in geodetic and geocentric) | rad | → local east |
| `position/h-sl-ft` | height above sea level (the ellipsoid in JSBSim) | **ft** | × 0.3048 → up |
| `attitude/phi-rad`, `theta-rad`, `psi-rad` | roll φ, pitch θ, heading ψ, relative to local NED | rad | → `R_ned_frd` |
| `velocities/v-north-fps`, `v-east-fps`, `v-down-fps` | velocity in local NED | **ft/s** | Godot vel = 0.3048 · (v_e, −v_d, −v_n) |
| `velocities/p-rad_sec`, `q-rad_sec`, `r-rad_sec` | body rates about FRD x, y, z | rad/s | stay in FRD for the IMU (Module 8) |

**Latitude in initialize files.** In an `<initialize>` XML file, JSBSim reads `<latitude>` as **geocentric** unless you write `<latitude type="geod">`. At 32° N the two differ by about 0.17° (about 19 km north–south), so a missing `type="geod"` puts the aircraft far from your origin. From Python, set `ic/lat-geod-deg` (as `frames_demo.py` does) or `ic/lat-geod-rad`, and always read back `position/lat-geod-rad`.

Most properties come in several units. Pick the `-rad`, `-ft` or `-fps` suffix explicitly, and convert at the line where you read. `h_m = fdm["position/h-sl-ft"] * FT` is safe. `alt = fdm["position/h-sl-ft"]` is a bug waiting for the next module.

## Attitude: NED world, FRD body, Euler ZYX

```
R_ned_frd = Rz(ψ) · Ry(θ) · Rx(φ)          # frames.euler_zyx_to_matrix(phi, theta, psi)
```

Apply heading ψ about Down first, then pitch θ about the new Right axis, then roll φ about the new Forward axis. Each angle is a right-hand rotation in FRD/NED, so:

| Angle | Positive means | At ψ = 0 |
|---|---|---|
| φ (roll) | **right wing down** | |
| θ (pitch) | **nose up** | |
| ψ (heading) | **clockwise seen from above**: 0 = north, 90° = east | |

FRD's z axis points down, so rotations "about +z" turn clockwise when seen from above. FLU's z points up, so +yaw there turns counter-clockwise. Both obey the right-hand rule.

The full chain to Godot goes through ENU and FLU, so it reuses the PyBullet constants:

```
R_godot_model = M_GODOT_ENU · T_ENU_NED · R_ned_frd · D_FRD_FLU · C_FLU_MODEL
                (enu→godot)   (ned→enu)  (JSBSim)   (flu→frd)   (model→flu)
T_ENU_NED = [[0,1,0],[1,0,0],[0,0,-1]]      D_FRD_FLU = diag(1, -1, -1)
```

## Position: from lat/lon/alt to local meters

Godot needs meters around a local origin. You choose the origin (lat0, lon0, h0): usually the runway threshold, the takeoff pad, or the terrain's center. Then you write it down. The Module 3 check requires this **before** you wire any JSBSim pose. The lab's `frames_demo.py` uses lat0 = 32.000000° N, lon0 = 35.000000° E, h0 = 0 m, and prints them at startup.

`frames.GeoOrigin` is the course's flat-earth converter:

```python
n = (lat - lat0) * EARTH_R                      # EARTH_R = 6 378 137 m (equatorial radius)
e = (lon - lon0) * EARTH_R * cos(lat0)
u = h - h0
```

That is an equirectangular projection on a sphere. The Earth is an ellipsoid, and a degree of latitude is shorter near the equator than near the poles. The correct local radii at latitude φ0 are:

```
M = a(1 − e²) / (1 − e² sin²φ0)^1.5      meridian radius   (north–south)   6 353 346 m at 32° N
N = a / (1 − e² sin²φ0)^0.5             prime vertical    (east–west)     6 384 141 m at 32° N
```

Using `a` (6 378 137 m) for north–south makes every north distance 0.39 % too long at 32° N. Using `a` for east–west makes east distances 0.09 % too short. The lab adds `frames_extra.GeoOriginLocal`, which uses M and N. It is still flat earth and still three lines of math.

### Measured error at 32° N

`tests/test_geo_error.py` places points at a true ground distance d from an origin at 32° N, 35° E, on 72 bearings. It converts them with each method and compares against the **exact** conversion: WGS84 geodetic → ECEF → local tangent-plane ENU (`frames_extra.enu_exact`). These are the numbers it printed:

| Distance from origin | `GeoOrigin` (equatorial R), worst horizontal error | `GeoOriginLocal` (M, N), worst horizontal error | Curvature drop below the tangent plane |
|---:|---:|---:|---:|
| 1 km | **3.90 m** | 0.057 m | 0.08 m |
| 5 km | **19.53 m** | 1.42 m | 1.97 m |
| 20 km | **78.39 m** | 22.7 m | 31.5 m |

How to read this:

- The `GeoOrigin` error is almost all **scale**: 3.9 m per km of northing. It grows linearly, so it is already visible at airfield size. A plane landing 2 km north of the origin would touch down about 8 m past the painted threshold on your terrain. "Flat earth is fine within a few km" does not hold at this latitude, which is why the [frames cheat sheet](../reference/frames.md#the-chains) and the `GeoOrigin` docstring quote these numbers. Use `GeoOriginLocal` (or `enu_exact`) whenever poses must line up with georeferenced terrain.
- The `GeoOriginLocal` error grows with d². That is the projection's own limit: lines of constant latitude curve on the ellipsoid. It stays below 6 cm within 1 km and below 1.5 m within 5 km. For the course's 257 m × 257 m terrain it is a few millimeters.
- The **curvature drop** (d²/2R) is how far the exact tangent-plane "up" coordinate falls below zero for a point at the origin's altitude. Flat-earth methods ignore it **on purpose**. They use u = h − h0, so a plane flying at constant altitude stays at constant Godot y over flat Godot terrain. If you used tangent-plane ENU instead, a plane in level flight 20 km out would appear 31 m too **low**, below a flat runway at its own altitude. Keep u = h − h0 unless your terrain itself is curved.

**Is JSBSim's Earth the same WGS84?** The same test builds ECEF from JSBSim's own `position/radius-to-vehicle-ft`, `lat-gc-rad` and `long-gc-rad` after `run_ic()`. That ECEF matches our WGS84 formula to under 1 cm (measured: 0.000 m and 0.002 m at two test points). So `enu_exact` really is "what JSBSim thinks", and the errors above are errors of the shortcut, not of JSBSim.

What to do, by situation:

| Situation | Use |
|---|---|
| Everything within ~1 km, terrain only roughly georeferenced | either; write down which one |
| Terrain or a runway placed from real coordinates | `GeoOriginLocal`, or move the origin to the area of interest |
| Long flights (> 5–10 km) | `enu_exact` for horizontal position, and re-center the origin (a floating origin) for float32 rendering |

## The YXZ shortcut, and why it is exact

In GDScript you will see:

```gdscript
body.basis = Basis.from_euler(Vector3(theta, -psi, -phi))      # default order YXZ, radians
```

Here is why it equals the full five-matrix chain. Combine the constants on each side of `R_ned_frd`:

```
P = M_GODOT_ENU · T_ENU_NED = [[ 0, 1,  0],     # Godot from NED: x = E, y = −D, z = −N
                               [ 0, 0, -1],
                               [-1, 0,  0]]
D_FRD_FLU · C_FLU_MODEL = [[0,0,-1],[1,0,0],[0,-1,0]] = Pᵀ
```

So `R_godot_model = P · Rz(ψ) Ry(θ) Rx(φ) · Pᵀ = (P Rz(ψ) Pᵀ)(P Ry(θ) Pᵀ)(P Rx(φ) Pᵀ)`. Conjugating by P turns a rotation about an NED axis into the same rotation about where P sends that axis:

| NED axis | P sends it to | So |
|---|---|---|
| z (down) | (0, −1, 0) = −Y | `P Rz(ψ) Pᵀ = Ry(−ψ)` |
| y (east) | (1, 0, 0) = +X | `P Ry(θ) Pᵀ = Rx(θ)` |
| x (north) | (0, 0, −1) = −Z | `P Rx(φ) Pᵀ = Rz(−φ)` |

That gives `R_godot_model = Ry(−ψ) · Rx(θ) · Rz(−φ)`, which is exactly Godot's `from_euler` with order YXZ applied to the vector (θ, −ψ, −φ). The order matches, and the signs flip where the axis flips (down vs up, north vs −Z).

**Proof by test.** The algebra could hide a sign slip, so the lab tests it twice. `test_frames_known.py::test_jsbsim_yxz_shortcut` checks it in numpy for the 90° cases. `godot/tests/test_yxz_shortcut.gd` runs inside Godot 4.7.2 and compares `Basis.from_euler(Vector3(θ, −ψ, −φ))` with the Python full-chain matrix for 54 attitudes (the 4 named cases plus 50 random ones up to ±86°). The measured worst column error was 1.3e-7. When the test is deliberately broken by using `(θ, ψ, φ)`, it reports an error of 2.0 and fails, so it can catch a sign mistake.

Use the shortcut for quick viewers and debugging. The course wire still carries the quaternion from the full chain, because Godot should not have to know which simulator produced a pose.

## Putting it together

```python
from robosim.frames import GeoOrigin, jsbsim_state_to_godot, FT
import math

origin = GeoOrigin(math.radians(32.0), math.radians(35.0), 0.0)      # DOCUMENTED in FRAMES.md
pos_g, q_g = jsbsim_state_to_godot(fdm, origin)                     # meters + Godot-model quaternion
vel_g = (fdm["velocities/v-east-fps"] * FT, -fdm["velocities/v-down-fps"] * FT,
         -fdm["velocities/v-north-fps"] * FT)
bridge.send_pose(fdm.get_sim_time(), vehicle_id, pos_g, q_g, vel_g)
```

`jsbsim_state_to_godot` builds its position with the origin object you pass in. To use the local radii, give it a `GeoOriginLocal` instead, because both classes have the same `to_enu()` method.

## Try it

- Set `ic/psi-true-deg = 90` and `run_ic()`. Predict where the nose (model −Z) points in Godot, then compute it.
- Run `python tests/test_geo_error.py --lat 0` and then `--lat 60` (the table only; the bounds test stays at 32°). Explain why the `GeoOrigin` error changes size, and why at 60° north distances come out too **short**. Hint: compare `a` with M and N at each latitude.
- Write the inverse of `GeoOrigin.to_enu` yourself, then compare it with `GeoOrigin.from_enu` in `frames.py`. Check that a round trip of 3 km returns to within 1 mm.
- Start JSBSim at 100 m altitude and send `h-sl-ft` to Godot **without** converting. Where does the body appear? Leave this mistake in your cheat sheet as "symptom → cause".

## References

- JSBSim Reference Manual, frames and Euler angles: <https://jsbsim-team.github.io/jsbsim-reference-manual/>
- JSBSim property catalog (run `fdm.print_property_catalog()` or see the docs): <https://jsbsim-team.github.io/jsbsim/>
- NGA, *WGS 84 definition* (a, f, e², radii of curvature): <https://earth-info.nga.mil/>
- [Frames cheat sheet](../reference/frames.md#the-chains), `frames.py` and the lab's `frames_extra.py`
