# 1. Why frames matter, and how to write them down

A pose is only a set of numbers until you say which frame it is in. `(0, 0, 0.707, 0.707)` means a 90° turn. It does not tell you whether that is about "up" or about "forward", whether "up" is z or y, or whether the turn is left or right. Most simulator integration bugs are frame bugs: a quadcopter that yaws the wrong way, a camera that looks at the sky, a plane that flies backwards at 3.28 times its speed. They are hard to see because the numbers look reasonable.

This module removes the guessing. Every vector gets a frame, every rotation gets two frame names, and every conversion gets a test with a known answer.

## Three kinds of frame

```
             world frame (fixed to the ground)
             ┌───────────────────────────────────────────┐
             │   y                                        │
             │   ▲      body frame (moves with vehicle)   │
             │   │        ┌────────────┐                  │
             │   │        │  x fwd ──▶ │──┐ sensor frame  │
             │   └──▶ x   └────────────┘  └▶ (camera, IMU, │
             │                              lidar mount)  │
             └───────────────────────────────────────────┘
```

| Kind | Fixed to | Examples in this course | Who defines it |
|---|---|---|---|
| **World** | the ground | ENU (PyBullet, logs), NED (JSBSim), Godot world | the simulator or the scene |
| **Body** | the vehicle's reference point | FLU (PyBullet, ROS), FRD (JSBSim), MODEL (Godot mesh) | the vehicle model |
| **Sensor** | a mount on the body | FPV camera, down camera, IMU, OpenCV optical frame | you, when you place the mount |

A vehicle pose is the body frame's position and orientation **in** the world frame. A sensor pose is a fixed transform **in** the body frame, so it has to be chained with the vehicle pose.

The course uses three world frames and three body frames. The [frames cheat sheet](../reference/frames.md) lists them. They exist because each tool chose a different convention, and none of the choices is wrong.

| | x | y | z |
|---|---|---|---|
| ENU | East | North | Up |
| NED | North | East | Down |
| Godot world | East | Up | South |
| FLU | Forward | Left | Up |
| FRD | Forward | Right | Down |
| MODEL | Right | Up | Back |

All six are **right-handed**: x × y = z. Check one: in Godot, East × Up = South. Point your right hand's fingers east, curl them up, and your thumb points south. Because every frame is right-handed, every change between them is a proper rotation with determinant +1. A determinant of −1 means you have swapped one axis too many. It is a mirror, and no physical rotation can produce it.

## The notation: `R_a_b`

The course writes rotation matrices as `R_a_b`, read "**a from b**":

```
v_a = R_a_b · v_b          # the same vector, b coordinates in, a coordinates out
```

This one rule has three useful consequences.

1. **Chains cancel like fractions.** The inner names must match, and they disappear:
   ```
   R_godot_model = R_godot_enu · R_enu_flu · R_flu_model
                         └─enu─┘     └─flu─┘
   ```
   If the inner names don't match, the chain is wrong before you run anything.
2. **The columns of `R_a_b` are b's axes written in a.** Column 0 is where b's x axis points, expressed in frame a. This is how you build a matrix by hand. It is also how you read one: `R_enu_flu[:, 0]` is the vehicle's forward direction in ENU.
3. **The inverse is the transpose and swaps the names:** `R_b_a = R_a_bᵀ`.

`frames.py` uses this notation, with two names kept for history: `M_GODOT_ENU` is `R_godot_enu`, and `C_FLU_MODEL` is `R_flu_model`. A pose adds a translation: `p_a = R_a_b · p_b + t_a_b`, where `t_a_b` is b's origin expressed in a. In Godot this is exactly what a `Transform3D` stores (see [sub-topic 2](02_godot_conventions.md)).

## Active vs passive: one matrix, two readings

Take the yaw matrix for +90° about z:

```
Rz(90°) = [[0, -1, 0],
           [1,  0, 0],
           [0,  0, 1]]
```

- **Active reading.** There is one frame. The matrix moves a vector inside it: `Rz · (1,0,0) = (0,1,0)`. The vector that pointed along x now points along y.
- **Passive reading.** There are two frames and one fixed vector. If body frame b is yawed +90° relative to world frame a, then `R_a_b = Rz(90°)`. The body's x axis, which is (1,0,0) in b, is `R_a_b · (1,0,0) = (0,1,0)` in a. Nothing moved. We only changed which axes we measure along.

Both readings use the same numbers. Trouble starts when one library documents "the rotation from A to B" and means the active rotation that carries A's axes onto B's, while the next library means the passive map that turns B coordinates into A coordinates. These are the same matrix. A third library might mean its transpose. **Don't trust prose. Test with a known case:** identity, then 90° about one axis, and check where one axis lands. Every test in this module works that way.

In this course `R_a_b` is always:

- the **orientation of b in a**: active, it carries a's axes onto b's axes, and
- the **coordinate change b → a**: passive, it turns b coordinates into a coordinates.

Those two statements describe the same matrix. Keep both in mind and the ambiguity disappears.

## Seeing it in code

```python
# start `python` inside robosim/physics, then paste
import numpy as np
from robosim.frames import M_GODOT_ENU, C_FLU_MODEL

# Columns of R_godot_enu = ENU axes written in Godot coordinates
east, north, up = M_GODOT_ENU[:, 0], M_GODOT_ENU[:, 1], M_GODOT_ENU[:, 2]
print(east, north, up)            # (1,0,0) (0,0,-1) (0,1,0): north is Godot -Z

# Columns of R_flu_model = Godot model axes written in FLU
right, up_m, back = C_FLU_MODEL[:, 0], C_FLU_MODEL[:, 1], C_FLU_MODEL[:, 2]
print(right, up_m, back)          # (0,-1,0) (0,0,1) (-1,0,0): right = -left, back = -forward

# Both are proper rotations
print(np.linalg.det(M_GODOT_ENU), np.linalg.det(C_FLU_MODEL))   # 1.0 1.0
print(np.allclose(M_GODOT_ENU @ M_GODOT_ENU.T, np.eye(3)))     # True
```

## Why "convert once, on the physics side"

You could send ENU poses and convert in GDScript, or send FLU and convert in a shader. Each extra conversion point is one more place where a sign can flip and one more place a later module must remember. The course rule ([frames](../reference/frames.md#the-rule)) is: **the wire carries Godot-world meters and a Godot-model quaternion.** The physics side owns `frames.py`, and Godot only applies what it receives. Module 4 builds the bridge on that promise, and Module 8 sends sensor data back in the same Godot frame.

## Try it

- Write `R_ned_enu` by hand using the "columns are b's axes in a" rule. Compare it with `frames.T_ENU_NED.T`. Why is `T_ENU_NED` its own transpose?
- Compute `np.linalg.det(np.diag([1, 1, -1]))`. Which frame pair from the table would need that matrix, and why does none of ours?
- Pick a chain with wrong names, for example `R_godot_enu · R_ned_frd`. Explain in one sentence what the product would compute if you used it anyway.
- Write the active and the passive meaning of `C_FLU_MODEL` in one sentence each.

## References

- [Frames cheat sheet](../reference/frames.md) and [`frames.py`](../reference/code/python/robosim/frames.py)
- REP 103, *Standard Units of Measure and Coordinate Conventions* (ROS): <https://www.ros.org/reps/rep-0103.html>
- J. Diebel, *Representing Attitude: Euler Angles, Unit Quaternions, and Rotation Vectors* (2006): a careful treatment of active vs passive conventions
