# 3. PyBullet conventions: Z-up ENU world, FLU body

PyBullet itself only says "Z is up". The rest is a course convention that matches ROS and URDF: the world is **ENU** (x = East, y = North, z = Up), and every body is **FLU** (x = Forward, y = Left, z = Up). In this sub-topic you derive the two constant matrices that take a PyBullet pose into Godot. Then you learn the four PyBullet calls you will use every day, and the one sign that surprises everybody.

## What PyBullet gives you

| Call | Returns | Frame / order |
|---|---|---|
| `p.getBasePositionAndOrientation(body)` | `pos (x,y,z)`, `quat (x,y,z,w)` | world ENU, body FLU; position of the base's **center of mass** frame |
| `p.getBaseVelocity(body)` | `lin (vx,vy,vz)`, `ang (wx,wy,wz)` | both in **world** coordinates, not body |
| `p.getQuaternionFromEuler([roll, pitch, yaw])` | `(x,y,z,w)` | `Rz(yaw)·Ry(pitch)·Rx(roll)` |
| `p.getMatrixFromQuaternion(q)` | 9 floats | **row-major** 3×3: reshape with `np.reshape(m, (3, 3))` |
| `p.resetBasePositionAndOrientation(body, pos, quat)` | none | teleports the body (no dynamics) |

We checked these against `frames.py` in PyBullet 3.2: `getMatrixFromQuaternion(getQuaternionFromEuler(e))` equals `euler_zyx_to_matrix(*e)` and `quat_to_matrix(q)` for random angles. PyBullet's quaternion order is **(x, y, z, w)**, the same as Godot and the robosim wire, so it passes through unchanged. Only the frame changes.

A body loaded from URDF has its link frame where the URDF says. PyBullet reports the base's *inertial* frame, so if the URDF's `<inertial><origin>` is offset or rotated, the reported pose is offset or rotated by the same amount. Keep the inertial origin at zero rotation. If your vehicle's URDF puts x forward, y left and z up (REP 103), its base frame is FLU and everything below applies. If someone built it with y forward, fix it in the URDF, not in the converter. One converter per simulator is the point.

## Deriving `M_GODOT_ENU` (= `R_godot_enu`)

Use the column rule: the columns of `R_godot_enu` are the ENU axes written in Godot coordinates.

| ENU axis | Points | In Godot coordinates | Column |
|---|---|---|---|
| x | East | +X | (1, 0, 0) |
| y | North | −Z | (0, 0, −1) |
| z | Up | +Y | (0, 1, 0) |

```
M_GODOT_ENU = [[1, 0,  0],
               [0, 0,  1],
               [0, -1, 0]]
```

Check the rows as well: row 1 says "Godot y = ENU z", which means up is up. Row 2 says "Godot z = −ENU y", which means south is minus north. The determinant is +1. The matrix is `Rx(−90°)`, a quarter turn about the east axis that tips the Z-up world onto its back so that up becomes +Y. Positions convert with the same matrix: `p_godot = (E, U, −N)`.

## Deriving `C_FLU_MODEL` (= `R_flu_model`)

The Godot mesh has its own body frame, MODEL (x right, y up, z back). The PyBullet body frame is FLU. We need the MODEL axes written in FLU:

| MODEL axis | Points | In FLU | Column |
|---|---|---|---|
| x | right | −left | (0, −1, 0) |
| y | up | up | (0, 0, 1) |
| z | back | −forward | (−1, 0, 0) |

```
C_FLU_MODEL = [[ 0, 0, -1],
               [-1, 0,  0],
               [ 0, 1,  0]]
```

## The chain

```
R_godot_model = R_godot_enu · R_enu_flu · R_flu_model
              = M_GODOT_ENU · quat_to_matrix(q_pybullet) · C_FLU_MODEL
```

Read it right to left. A vector in the Godot mesh's coordinates becomes FLU, then PyBullet's attitude takes it to ENU, then `M_GODOT_ENU` takes it to the Godot world. The result is the `global_basis` that the Godot node must have. `frames.enu_flu_to_godot()` does all of this and returns a Godot position and a Godot quaternion (x,y,z,w):

```python
import pybullet as p
from robosim.frames import enu_flu_to_godot, M_GODOT_ENU

pos_enu, q_enu_flu = p.getBasePositionAndOrientation(body)          # (x,y,z), (x,y,z,w)
lin_enu, ang_enu = p.getBaseVelocity(body)                           # world frame
pos_g, q_g = enu_flu_to_godot(pos_enu, q_enu_flu)
vel_g = tuple(M_GODOT_ENU @ lin_enu)                                 # velocities: world rotation only
bridge.send_pose(t_sim, vehicle_id, pos_g, q_g, vel_g)
```

Velocities and angular rates in the world frame need only `M_GODOT_ENU`. The body-frame correction `C_FLU_MODEL` belongs to orientations alone.

**Sanity check (identity).** A PyBullet body with `q = (0,0,0,1)` faces +x, which is east. In Godot its nose, model −Z, must point to Godot +X:

```
R = M_GODOT_ENU · I · C_FLU_MODEL = [[0,0,-1],[0,1,0],[1,0,0]]
R · (0,0,-1) = (1, 0, 0)  ✓ east
```

That is a −90° turn about Godot Y, because the Godot model's default heading is north and the PyBullet body's is east. This surprises people the first time they see an "identity" PyBullet pose turn up rotated in Godot. It is correct.

## The signs of roll, pitch and yaw in FLU

A positive angle is a right-hand rotation about the positive axis. In FLU that gives:

| Angle | Axis | Positive means | Godot result (from identity, facing east) |
|---|---|---|---|
| roll | +x forward | **left side up**, right side down | body y (left) → (0, 1, 0) |
| pitch | +y left | **nose DOWN** | body x (forward) → (0, −1, 0) |
| yaw | +z up | **turn left** (counter-clockwise from above) | body x → (0, 0, −1) north |

The pitch sign is the trap. Rotating +90° about the left axis takes forward (x) to −z, which is down. In JSBSim's FRD frame, +θ is nose **up**, because there the axis is +y **right**. The two are the same physical rule (right-hand rotation) about opposite axes. So when you send a pitch command to a PyBullet quad, decide once whether the command is FLU or aerospace, and write it in the variable name.

We confirmed this in PyBullet. After `resetBasePositionAndOrientation(body, pos, getQuaternionFromEuler([0, π/2, 0]))`, the forward column of `getMatrixFromQuaternion` is (0, 0, −1) in ENU, pointing straight down.

## Teleporting vs simulating

The Module 3 lab poses the body with `resetBasePositionAndOrientation` and reads it back with `getBasePositionAndOrientation`, without calling `stepSimulation`. That keeps gravity out of a test about frames. From Module 4 on, the same read-back call follows `stepSimulation`, and nothing in the conversion changes.

## Try it

- Create a box with `halfExtents=[0.6, 0.3, 0.1]` (long along x). Set the yaw to +30° and print the first column of `getMatrixFromQuaternion`. In which compass direction does the nose point? Convert with `enu_flu_to_godot` and compute `R · (0, 0, −1)` in Godot coordinates.
- Use `p.getEulerFromQuaternion` on the pitch +90° quaternion. Then try pitch 91°. What happens to roll and yaw, and why should you never send Euler angles over the wire?
- Write `R_godot_flu = M_GODOT_ENU · R_enu_flu` for the identity pose and read off its columns. Where do FLU forward, left and up land in Godot?
- Spawn a second body at ENU (3, 4, 0). Where should it appear in Godot? Check with `enu_to_godot_pos`.

## References

- PyBullet Quickstart Guide (base state, velocities, Euler/quaternion helpers): <https://docs.google.com/document/d/10sXEhzFRSnvFcl3XxNGhnD4N2SedqwdAvK3dsihxVUA>
- REP 103 (FLU body, ENU world): <https://www.ros.org/reps/rep-0103.html>
- [Frames cheat sheet](../reference/frames.md#the-chains)
