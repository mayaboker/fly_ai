# Frames cheat sheet

Use this page as the single source of truth for frames. Module 3 derives everything on it. Every later module refers back here instead of re-deriving. The code is in [`code/python/robosim/frames.py`](code/python/robosim/frames.py). It is tested, including a check that it matches Godot's own `Basis.from_euler`.

## The rule

> **Convert once, on the physics side.** Every pose on the wire is already in the Godot world frame, in meters, with a Godot-model quaternion. The viewer never sees feet, lat/lon, NED or Z-up.

## World frames

| Frame | x | y | z | Used by |
|---|---|---|---|---|
| **ENU** (course world) | East | North | Up | PyBullet worlds, logs, plots |
| **NED** | North | East | Down | JSBSim local frame |
| **Godot world** | East | Up | South (= −North) | Godot scene, the wire |

A position converts as `godot = (E, U, −N)`. As a matrix (rows = Godot axes):

```
M_GODOT_ENU = [[1, 0, 0],
               [0, 0, 1],
               [0,-1, 0]]      det = +1, so it is a pure rotation
```

## Body frames

| Frame | x | y | z | Used by |
|---|---|---|---|---|
| **FLU** | Forward | Left | Up | PyBullet bodies, ROS |
| **FRD** | Forward | Right | Down | JSBSim body axes, `p q r` rates |
| **MODEL** | Right | Up | Back | Godot meshes: a Godot model **looks along −Z** |

Build every vehicle mesh in Godot with its nose toward **−Z** and its top toward **+Y**. Attach every camera so that it looks along its own −Z. That is Godot's default.

## The chains

**PyBullet (ENU world, FLU body):**

```
R_godot_model = M_GODOT_ENU · R_enu_flu · C_FLU_MODEL
C_FLU_MODEL   = [[0,0,-1], [-1,0,0], [0,1,0]]
```

**JSBSim (lat/lon/alt, NED world, FRD body, Euler φ θ ψ):**

```
p_enu  = GeoOrigin(lat0, lon0, h0).to_enu(lat, lon, h)      # flat earth; see the note below
R_enu_flu = T_ENU_NED · R_zyx(φ, θ, ψ) · D_FRD_FLU
T_ENU_NED = [[0,1,0], [1,0,0], [0,0,-1]],   D_FRD_FLU = diag(1, -1, -1)
```

**Flat-earth note.** `GeoOrigin` uses one radius for both axes. That is consistent inside the simulation, because physics and viewer share the conversion. Compared with true WGS84 at 32° N, it is off by about **3.9 m at 1 km and 20 m at 5 km** (measured in [Module 3](../m03_frames/README.md)). Use Module 3's `GeoOriginLocal` (about 6 cm at 1 km) whenever you compare against real GPS or maps. Also note that JSBSim reads `<latitude>` in an initialize file as **geocentric** unless you write `type="geod"`.

**Shortcut for JSBSim in GDScript.** This is tested to be identical to the full chain:

```gdscript
basis = Basis.from_euler(Vector3(theta, -psi, -phi))   # default order YXZ, radians
```

## Quaternion order: the most common bug

| Library | Order |
|---|---|
| PyBullet `getBasePositionAndOrientation` | (x, y, z, w) |
| Godot `Quaternion(x, y, z, w)` | (x, y, z, w) |
| robosim wire format | (x, y, z, w) |
| Eigen, many papers, `transforms3d` | (w, x, y, z) |

## Units

| Quantity | Course unit | JSBSim gives | Convert |
|---|---|---|---|
| length | m | ft (`-ft`) | × 0.3048 |
| speed | m/s | ft/s (`-fps`), kt (`-kts`) | × 0.3048, × 0.514444 |
| angle | rad on the wire, deg in UIs | rad (`-rad`) or deg (`-deg`) | |
| force | N | lbf | × 4.44822 |
| time | s, sim time | s | |

## Sanity tests (run them after any change)

| Test | Expected in Godot |
|---|---|
| PyBullet identity orientation | model −Z points to Godot +X (east) |
| JSBSim φ = θ = ψ = 0 | model −Z points to Godot −Z (north) |
| JSBSim ψ = 90° | nose points to Godot +X (east) |
| JSBSim θ = +30° | nose rises (forward vector has +Y) |
| JSBSim φ = +30° | right wing (model +X) goes down |

## Where gravity points

The stationary accelerometer convention is **specific force**. An IMU at rest reads **+g upward**, which is +9.81 m/s² on body z in FLU and −9.81 on body z in FRD. JSBSim's `accelerations/a-pilot-z-ft_sec2` follows FRD, so it reads about −32.2 ft/s² at rest.
