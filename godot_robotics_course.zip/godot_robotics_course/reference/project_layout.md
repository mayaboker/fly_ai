# The `robosim/` project

Every lab adds to this one project. By Module 12 it looks like this:

```
robosim/
├── godot/                         ← Godot 4.7 project (open this folder in the editor)
│   ├── project.godot
│   ├── main.tscn / main.gd        ← the test range scene (Module 1–2)
│   ├── bridge/                    ← protocol.gd, sim_bridge.gd   (Module 4–5)
│   ├── vehicles/                  ← rover, quad, plane, quadplane scenes (Module 2)
│   ├── cameras/                   ← camera rigs, capture, intrinsics   (Module 6–7)
│   ├── sensors/                   ← range, lidar, contact, target box  (Module 8)
│   ├── ui/                        ← HUD, status, stale indicator
│   └── terrain/                   ← Terrain3D data or generated mesh   (Module 2)
├── physics/                       ← Python side (run with the venv's python)
│   ├── robosim/                   ← shared package: frames, protocol, bridge, logger, telemetry
│   │                                 + terrain.py (M2), frames_extra.py (M3), sensors.py (M8),
│   │                                   pybullet_world.py (M9), jsbsim_vehicle.py (M11)
│   ├── sims/                      ← one entry script per scenario
│   │   ├── spin_bodies.py         (Module 4)
│   │   ├── ugv_pybullet.py        (Module 9)
│   │   ├── quad_pybullet.py       (Module 10)
│   │   ├── quad_jsbsim.py         (Module 10, JSBSim option)
│   │   └── plane_jsbsim.py        (Module 11)
│   ├── aircraft/                  ← JSBSim models (copied from the JSBSim course)
│   └── tests/                     ← test_frames.py, test_protocol.py, ...
├── data/
│   └── terrain/                   ← heightmap.png (16-bit) + heightmap.json + range.json (Module 2)
├── tools/                         ← plotting, frame reader, latency analysis
└── logs/                          ← one folder per run (see logging.md)
```

## Rules

- The shared package `physics/robosim/` starts as a copy of [`reference/code/python/robosim`](code/python/robosim). Change it only through a module that says so.
- `godot/bridge/` starts as a copy of [`reference/code/godot/bridge`](code/godot/bridge).
- One scenario = one script in `sims/`. Run it from the `physics/` folder: `python sims/ugv_pybullet.py`.
- `logs/` and `godot/.godot/` are never committed to git.
