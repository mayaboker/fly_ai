# robosim bridge protocol, version 1

Every module that moves data between the physics process and Godot uses this protocol. Module 4 builds it step by step. This page is the finished specification.

- Python: [`code/python/robosim/protocol.py`](code/python/robosim/protocol.py) and [`bridge.py`](code/python/robosim/bridge.py)
- Godot: [`code/godot/bridge/protocol.gd`](code/godot/bridge/protocol.gd) and [`sim_bridge.gd`](code/godot/bridge/sim_bridge.gd)
- Extension: [`telemetry.py`](code/python/robosim/telemetry.py) and [`telemetry_bridge.gd`](code/godot/bridge/telemetry_bridge.gd) (TELEMETRY, below)

Both sides were tested against each other with Godot 4.7.2 (headless) and Python 3, including physics-first and viewer-first start orders, a viewer restart, and packet loss.

Put the `SimBridge` node anywhere in the scene: it sets `process_priority = -100` itself, so it reads packets before any other script runs that frame.

## Ownership

```
 physics process (Python)                         viewer (Godot)
 ─────────────────────────                        ─────────────────────────
 owns sim time + dynamics      ── POSE ────────▶  places nodes, renders
 owns vehicle-state sensors    ── ACK  ────────▶  stops resending a command
 applies commands, contacts    ◀─ COMMAND ──────  input, UI buttons
                               ◀─ SENSOR ───────  ray/contact/camera-derived data
                               ◀─ HELLO / BYE ──  handshake
        UDP 127.0.0.1:9002 (to physics)     UDP 127.0.0.1:9001 (to viewer)
```

## Header (16 bytes, little-endian, every packet)

| Field | Type | Meaning |
|---|---|---|
| magic | 2 bytes | `"RS"` |
| version | u8 | `1`. Drop any packet with another version. |
| type | u8 | message type (below) |
| seq | u32 | per-sender counter, +1 every packet, wraps at 2³² |
| t_sim | f64 | simulation seconds. On viewer → physics packets it is the sim time **of the pose the data was computed from**. |

Python `struct` format: `"<2sBBId"`.

## Messages

| Type | Id | Direction | Body | Total |
|---|---|---|---|---|
| HELLO | 1 | viewer → physics | none. Sent at start-up, every 0.5 s until the first pose, and again on the first pose of every physics session. | 16 B |
| BYE | 2 | either | none | 16 B |
| POSE | 3 | physics → viewer | `vehicle_id u16, flags u16, pos 3×f32, quat 4×f32 (x,y,z,w), vel 3×f32` | 60 B |
| COMMAND | 4 | viewer → physics | `vehicle_id u16, cmd u16, args 8×f32` | 52 B |
| ACK | 5 | physics → viewer | `acked_seq u32` | 20 B |
| SENSOR | 6 | viewer → physics | `vehicle_id u16, sensor u16, count u16, reserved u16, count×f32` | 24 + 4n B |

Every position, velocity and normal is **already in the Godot world frame, in meters** (see [frames](frames.md)).

**POSE flags:** `1 = RESET` (first pose after a reset; the viewer clears its buffers), `2 = PAUSED`.

**Commands:**

| cmd | Name | args |
|---|---|---|
| 0 | HEARTBEAT | none |
| 1 / 2 / 3 / 4 | PAUSE / RESUME / STEP / RESET | none |
| 10 | ATTITUDE | roll_deg, pitch_deg, yawrate_dps, throttle 0–1 |
| 11 | DIFF_DRIVE | v m/s, ω rad/s |

Use command ids 100–199 for your own experiments, so they never collide with the course's.

**Sensors (viewer side):**

| sensor | Name | values |
|---|---|---|
| 1 | CONTACT | hit 0/1, nx, ny, nz, depth m |
| 2 | RANGE | one distance per ray, m (`inf` = no hit) |
| 3 | TARGET_BOX | visible 0/1, cx, cy, w_px, h_px. cx, cy are in −1…1 with **+cx = right, +cy = down** (image convention) |

`SENSOR` has no instance id, so two sensors of the same type on one vehicle are told apart by their value count (Module 8). A future v2 would use the `reserved` u16 as an instance id.

## Extension: TELEMETRY (type 100, physics → viewer)

This is a new message type, so no existing layout changes. Message types 100–199 are reserved for extensions like this one. Its body has the same layout as SENSOR: `vehicle_id u16, code u16, count u16, reserved u16, count×f32`. It is unreliable and latest-wins. Viewers that don't know type 100 ignore it.

| code | Name | values | First used |
|---|---|---|---|
| 1 | FLIGHT | airspeed m/s, alpha deg, AGL m, terrain m, crashed 0/1, phase, reserved | Module 11 |
| 2 | MOTORS | four motor outputs 0–1, order 1..4 | Module 10 |
| 3 | TTC | state, tau_est, forward speed, true distance, true tau | Module 12 |
| 100–199 | yours | free | |

## Other ports

| Port | Use |
|---|---|
| 9001 / 9002 | this protocol |
| 9005 | Module 7's UDP frame fallback (camera images when `/dev/shm` is not available) |

## Reliability

| Stream | Transport rule |
|---|---|
| POSE | unreliable, **latest wins**. Never queue old poses. |
| Stick-style input (50 Hz) | unreliable (`send_command_unreliable`) |
| Discrete commands (pause, reset, mode change) | **reliable**: resent every 100 ms until ACKed. The physics side de-duplicates by `seq`. |
| SENSOR | unreliable, tagged with the pose's `t_sim` |

## Failure behavior (Module 4 tests these)

| Event | Viewer | Physics |
|---|---|---|
| Physics stops | `is_stale()` becomes true after 0.25 s. Show it and keep the last pose. | — |
| Physics restarts | the pose has the RESET flag, or `t_sim` goes backwards, so the viewer clears its buffers and answers with HELLO | sends RESET on the first pose |
| Viewer restarts | sends HELLO; its `seq` restarts at 1 | gets a HELLO whose `seq` went backwards, so it forgets the old session's command ids (otherwise new commands would be dropped as duplicates). Only HELLO counts: a resent COMMAND legitimately carries an old `seq`. |
| Packet loss | interpolation hides it, extrapolating ≤ 50 ms | resends nothing |

## Changing the protocol

Add fields only by making a **new message type** or a **new version**. Never change an existing layout in place: old logs and recordings must stay readable.
