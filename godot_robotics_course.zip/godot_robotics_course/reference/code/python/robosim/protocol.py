"""
protocol.py - robosim bridge protocol, version 1 (little-endian, fixed layouts).

Every packet starts with the same 16-byte header:
    magic  2s   b"RS"
    ver    u8   1
    type   u8   see MSG_*
    seq    u32  per-sender counter, +1 every packet
    t_sim  f64  simulation time in seconds (for viewer->physics packets:
                the sim time of the POSE the data was computed from)

Ports (localhost):  physics -> viewer 9001,  viewer -> physics 9002
All positions/vectors on the wire are already in GODOT world frame, meters.
"""
import struct

MAGIC, VERSION = b"RS", 1
HEADER = struct.Struct("<2sBBId")                     # 16 bytes
PORT_TO_VIEWER, PORT_TO_PHYSICS = 9001, 9002

MSG_HELLO, MSG_BYE, MSG_POSE, MSG_COMMAND, MSG_ACK, MSG_SENSOR = 1, 2, 3, 4, 5, 6

# POSE: vehicle_id u16, flags u16, pos 3f, quat 4f (x,y,z,w), vel 3f      -> 60 bytes total
POSE = struct.Struct("<HH3f4f3f")
POSE_FLAG_RESET = 1          # set on the first pose after a reset (viewer clears buffers)
POSE_FLAG_PAUSED = 2

# COMMAND: vehicle_id u16, cmd u16, args 8f                               -> 52 bytes total
COMMAND = struct.Struct("<HH8f")
CMD_HEARTBEAT, CMD_PAUSE, CMD_RESUME, CMD_STEP, CMD_RESET = 0, 1, 2, 3, 4
CMD_ATTITUDE = 10            # args: roll_deg, pitch_deg, yawrate_dps, throttle_0_1
CMD_DIFF_DRIVE = 11          # args: v_mps, omega_radps

# ACK: acked_seq u32                                                      -> 20 bytes total
ACK = struct.Struct("<I")

# SENSOR: vehicle_id u16, sensor u16, count u16, reserved u16, count x f32 (variable)
SENSOR_HEAD = struct.Struct("<HHHH")
SENSOR_CONTACT = 1           # values: hit(0/1), nx, ny, nz, depth_m   (normal in Godot frame)
SENSOR_RANGE = 2             # values: one distance per ray, m (inf = no hit)
SENSOR_TARGET_BOX = 3        # values: visible, cx, cy, w_px, h_px


def _header(msg_type, seq, t_sim):
    return HEADER.pack(MAGIC, VERSION, msg_type, seq & 0xFFFFFFFF, t_sim)


def pack_pose(seq, t_sim, vehicle_id, pos, quat, vel=(0, 0, 0), flags=0):
    return _header(MSG_POSE, seq, t_sim) + POSE.pack(vehicle_id, flags, *pos, *quat, *vel)


def pack_command(seq, t_sim, vehicle_id, cmd, args=()):
    a = list(args) + [0.0] * (8 - len(args))
    return _header(MSG_COMMAND, seq, t_sim) + COMMAND.pack(vehicle_id, cmd, *a[:8])


def pack_ack(seq, t_sim, acked_seq):
    return _header(MSG_ACK, seq, t_sim) + ACK.pack(acked_seq)


def pack_sensor(seq, t_sim, vehicle_id, sensor, values):
    return (_header(MSG_SENSOR, seq, t_sim) + SENSOR_HEAD.pack(vehicle_id, sensor, len(values), 0)
            + struct.pack(f"<{len(values)}f", *values))


def pack_simple(msg_type, seq, t_sim):
    """HELLO or BYE: header only."""
    return _header(msg_type, seq, t_sim)


def unpack(data):
    """bytes -> dict, or None if the packet is not a valid v1 packet."""
    if len(data) < HEADER.size:
        return None
    magic, ver, typ, seq, t = HEADER.unpack_from(data)
    if magic != MAGIC or ver != VERSION:
        return None
    msg = {"type": typ, "seq": seq, "t_sim": t}
    body = data[HEADER.size:]
    try:
        if typ == MSG_POSE:
            v = POSE.unpack(body)
            msg.update(vehicle_id=v[0], flags=v[1], pos=v[2:5], quat=v[5:9], vel=v[9:12])
        elif typ == MSG_COMMAND:
            v = COMMAND.unpack(body)
            msg.update(vehicle_id=v[0], cmd=v[1], args=v[2:10])
        elif typ == MSG_ACK:
            msg.update(acked_seq=ACK.unpack(body)[0])
        elif typ == MSG_SENSOR:
            vid, sensor, n, _ = SENSOR_HEAD.unpack_from(body)
            msg.update(vehicle_id=vid, sensor=sensor,
                       values=struct.unpack_from(f"<{n}f", body, SENSOR_HEAD.size))
    except struct.error:
        return None
    return msg
