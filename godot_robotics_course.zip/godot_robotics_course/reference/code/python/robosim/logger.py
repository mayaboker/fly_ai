"""
logger.py - the course log format: one CSV per stream + run.json sidecar.

    log = RunLogger("logs", run_name="hover", seed=42, meta={"physics": "jsbsim", "rate_hz": 120})
    log.write("pose", t_sim=..., x=..., y=...)
    log.close()

Every row gets t_sim (simulation seconds) and t_wall (seconds since the run started).
run.json records versions, seed, frame convention and anything in meta.
"""
import csv, json, os, platform, sys, time
from datetime import datetime, timezone


class RunLogger:
    def __init__(self, root="logs", run_name="run", seed=None, meta=None):
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        base = os.path.join(root, f"{stamp}_{run_name}")
        self.dir, n = base, 1
        while True:                       # two runs in the same second get _2, _3, ...
            try:
                os.makedirs(self.dir)
                break
            except FileExistsError:
                n += 1
                self.dir = f"{base}_{n}"
        self._t0 = time.monotonic()
        self._files, self._writers = {}, {}
        info = {"run": run_name, "started_utc": stamp, "seed": seed,
                "frames": "world=ENU (x E, y N, z U); wire=Godot (x E, y U, z S); body=FLU",
                "python": sys.version.split()[0], "platform": platform.platform()}
        for mod in ("jsbsim", "pybullet", "numpy"):
            try:
                m = __import__(mod)
                info[mod] = getattr(m, "__version__", "installed")
            except ImportError:
                pass
        info.update(meta or {})
        with open(os.path.join(self.dir, "run.json"), "w") as f:
            json.dump(info, f, indent=2)

    def write(self, stream, t_sim, **values):
        row = {"t_sim": round(t_sim, 6), "t_wall": round(time.monotonic() - self._t0, 6), **values}
        if stream not in self._writers:
            f = open(os.path.join(self.dir, f"{stream}.csv"), "w", newline="")
            w = csv.DictWriter(f, fieldnames=list(row.keys()))
            w.writeheader()
            self._files[stream], self._writers[stream] = f, w
        self._writers[stream].writerow(row)

    def close(self):
        for f in self._files.values():
            f.close()
