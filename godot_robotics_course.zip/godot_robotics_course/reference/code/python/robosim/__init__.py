"""robosim - shared helpers for the Godot robotics course (frames, protocol, logging)."""
