"""
frames.py - the course's ONE place for frame conversions.

World frames
  ENU    physics world: x = East, y = North, z = Up (meters). PyBullet uses this.
  NED    JSBSim local:  x = North, y = East, z = Down.
  GODOT  Godot world:   x = East, y = Up, z = South (= -North).

Body frames
  FLU    robotics body (PyBullet, ROS): x = Forward, y = Left, z = Up
  FRD    aerospace body (JSBSim):       x = Forward, y = Right, z = Down
  MODEL  Godot model:   x = Right, y = Up, z = Back (Godot looks along -Z)

Rotation matrices map vectors FROM the right frame TO the left frame:
  R_enu_flu @ v_flu = v_enu
"""
import math
import numpy as np

# ---- constant frame changes (all proper rotations, det = +1)
M_GODOT_ENU = np.array([[1, 0, 0],      # godot x = east
                        [0, 0, 1],      # godot y = up
                        [0, -1, 0]],    # godot z = -north
                       dtype=float)
T_ENU_NED = np.array([[0, 1, 0],        # east  = ned y
                      [1, 0, 0],        # north = ned x
                      [0, 0, -1]],      # up    = -ned z
                     dtype=float)
D_FRD_FLU = np.diag([1.0, -1.0, -1.0])  # FLU <-> FRD (its own inverse)
C_FLU_MODEL = np.array([[0, 0, -1],     # forward = -model z
                        [-1, 0, 0],     # left    = -model x
                        [0, 1, 0]],     # up      =  model y
                       dtype=float)

EARTH_R = 6378137.0  # m, WGS84 equatorial radius (flat-earth approximation)
FT = 0.3048


# ---- quaternions, stored (x, y, z, w) like PyBullet and Godot
def quat_to_matrix(q):
    x, y, z, w = q
    n = math.sqrt(x * x + y * y + z * z + w * w)
    x, y, z, w = x / n, y / n, z / n, w / n
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


def matrix_to_quat(R):
    """Rotation matrix -> (x, y, z, w), w >= 0."""
    t = R[0, 0] + R[1, 1] + R[2, 2]
    if t > 0:
        s = math.sqrt(t + 1.0) * 2
        w, x, y, z = 0.25 * s, (R[2, 1] - R[1, 2]) / s, (R[0, 2] - R[2, 0]) / s, (R[1, 0] - R[0, 1]) / s
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = math.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2]) * 2
        w, x, y, z = (R[2, 1] - R[1, 2]) / s, 0.25 * s, (R[0, 1] + R[1, 0]) / s, (R[0, 2] + R[2, 0]) / s
    elif R[1, 1] > R[2, 2]:
        s = math.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2]) * 2
        w, x, y, z = (R[0, 2] - R[2, 0]) / s, (R[0, 1] + R[1, 0]) / s, 0.25 * s, (R[1, 2] + R[2, 1]) / s
    else:
        s = math.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1]) * 2
        w, x, y, z = (R[1, 0] - R[0, 1]) / s, (R[0, 2] + R[2, 0]) / s, (R[1, 2] + R[2, 1]) / s, 0.25 * s
    q = np.array([x, y, z, w])
    return tuple(float(v) for v in (-q if w < 0 else q))


def euler_zyx_to_matrix(roll, pitch, yaw):
    """Aerospace Euler angles (yaw, then pitch, then roll), radians -> R_parent_body."""
    cr, sr, cp, sp, cy, sy = math.cos(roll), math.sin(roll), math.cos(pitch), math.sin(pitch), math.cos(yaw), math.sin(yaw)
    return np.array([
        [cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
        [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
        [-sp, cp * sr, cp * cr]])


# ---- PyBullet (ENU world, FLU body) -> Godot
def enu_to_godot_pos(p_enu):
    return tuple(float(v) for v in M_GODOT_ENU @ np.asarray(p_enu, float))


def enu_flu_to_godot(p_enu, q_enu_flu):
    """Position + orientation of a FLU body in ENU -> Godot position + quaternion (x,y,z,w)
    for a Godot model whose forward is -Z."""
    R = M_GODOT_ENU @ quat_to_matrix(q_enu_flu) @ C_FLU_MODEL
    return enu_to_godot_pos(p_enu), matrix_to_quat(R)


# ---- JSBSim (lat/lon/alt, NED, FRD body) -> ENU and Godot
class GeoOrigin:
    """Simple flat-earth local frame around (lat0, lon0, h0).

    It uses the equatorial radius for both axes. That is CONSISTENT inside the
    simulation (physics and viewer use the same conversion), but at 32 deg N it
    stretches north-south distances by ~0.4 %: about 3.9 m at 1 km and 20 m at 5 km
    compared with true WGS84 (measured in Module 3). When you compare against real
    GPS or maps, use GeoOriginLocal from Module 3 (local radii, ~6 cm at 1 km).

    Note: JSBSim's <latitude> in an initialize file is GEOCENTRIC unless you write
    type="geod"; position/lat-geod-rad reports the geodetic value.
    """
    def __init__(self, lat0_rad, lon0_rad, h0_m=0.0):
        self.lat0, self.lon0, self.h0 = lat0_rad, lon0_rad, h0_m

    def to_enu(self, lat_rad, lon_rad, h_m):
        n = (lat_rad - self.lat0) * EARTH_R
        e = (lon_rad - self.lon0) * EARTH_R * math.cos(self.lat0)
        return (e, n, h_m - self.h0)

    def from_enu(self, e, n, u):
        """Inverse of to_enu: ENU meters -> (lat_rad, lon_rad, h_m)."""
        return (self.lat0 + n / EARTH_R,
                self.lon0 + e / (EARTH_R * math.cos(self.lat0)),
                self.h0 + u)


def ned_frd_euler_to_enu_flu(roll, pitch, yaw):
    """JSBSim attitude (phi, theta, psi, radians) -> R_enu_flu."""
    return T_ENU_NED @ euler_zyx_to_matrix(roll, pitch, yaw) @ D_FRD_FLU


def jsbsim_state_to_godot(fdm, origin):
    """Read a JSBSim FGFDMExec and return Godot position + quaternion."""
    p_enu = origin.to_enu(fdm["position/lat-geod-rad"], fdm["position/long-gc-rad"],
                          fdm["position/h-sl-ft"] * FT)
    R_enu_flu = ned_frd_euler_to_enu_flu(fdm["attitude/phi-rad"], fdm["attitude/theta-rad"],
                                         fdm["attitude/psi-rad"])
    return enu_to_godot_pos(p_enu), matrix_to_quat(M_GODOT_ENU @ R_enu_flu @ C_FLU_MODEL)
