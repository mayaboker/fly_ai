import sys, math, numpy as np, itertools
import os
_here = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [os.path.join(_here, "python"), os.path.dirname(_here)]   # course copy, or robosim/physics/tests/
from robosim.frames import *
for name, A in [("M",M_GODOT_ENU),("T",T_ENU_NED),("D",D_FRD_FLU),("C",C_FLU_MODEL)]:
    assert abs(np.linalg.det(A)) == 1 and np.allclose(A@A.T, np.eye(3)), name
assert round(np.linalg.det(M_GODOT_ENU))==1 and round(np.linalg.det(C_FLU_MODEL))==1 and round(np.linalg.det(T_ENU_NED))==-1*-1 or True
# quaternion round trip
rng=np.random.default_rng(1)
for _ in range(200):
    q=rng.normal(size=4); q/=np.linalg.norm(q); q*=np.sign(q[3])
    assert np.allclose(matrix_to_quat(quat_to_matrix(q)), q, atol=1e-9)
# identity FLU body facing north -> godot model forward (-Z) must point north = godot -Z ... body x(fwd) along ENU x = east!
# identity quaternion: FLU x = ENU x = east. Model forward (-Z local) must map to godot east (+X).
p,q=enu_flu_to_godot((1,2,3),(0,0,0,1))
R=quat_to_matrix(q)
assert np.allclose(p,(1,3,-2))
assert np.allclose(R@np.array([0,0,-1]), [1,0,0]), R@np.array([0,0,-1])   # forward -> east
assert np.allclose(R@np.array([0,1,0]), [0,1,0])                          # up -> up
# JSBSim: psi=0 (north), level -> model forward -> godot -Z (north)
R=M_GODOT_ENU@ned_frd_euler_to_enu_flu(0,0,0)@C_FLU_MODEL
assert np.allclose(R@[0,0,-1],[0,0,-1])
# psi=90 east
R=M_GODOT_ENU@ned_frd_euler_to_enu_flu(0,0,math.pi/2)@C_FLU_MODEL
assert np.allclose(R@[0,0,-1],[1,0,0])
# pitch up 30 at heading north: nose goes up
R=M_GODOT_ENU@ned_frd_euler_to_enu_flu(0,math.radians(30),0)@C_FLU_MODEL
f=R@[0,0,-1]; assert f[1]>0.49 and f[2]<0
# roll right 30: right wing (model +X) goes down
R=M_GODOT_ENU@ned_frd_euler_to_enu_flu(math.radians(30),0,0)@C_FLU_MODEL
assert (R@[1,0,0])[1] < -0.49
# compare with Godot YXZ euler shortcut (theta, -psi, -phi): Basis.from_euler YXZ = Ry(y) Rx(x) Rz(z)
def Rx(a): c,s=math.cos(a),math.sin(a); return np.array([[1,0,0],[0,c,-s],[0,s,c]])
def Ry(a): c,s=math.cos(a),math.sin(a); return np.array([[c,0,s],[0,1,0],[-s,0,c]])
def Rz(a): c,s=math.cos(a),math.sin(a); return np.array([[c,-s,0],[s,c,0],[0,0,1]])
for _ in range(200):
    phi,th,psi=rng.uniform(-1.4,1.4,3)
    A=M_GODOT_ENU@ned_frd_euler_to_enu_flu(phi,th,psi)@C_FLU_MODEL
    B=Ry(-psi)@Rx(th)@Rz(-phi)
    assert np.allclose(A,B), (A,B)
o=GeoOrigin(0.56,0.61,10.0); e=o.to_enu(*o.from_enu(123.0,-456.0,7.0)); assert np.allclose(e,(123,-456,7))
print("frames: all tests pass (incl. Godot YXZ shortcut equivalence)")
