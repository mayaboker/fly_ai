class_name RsProtocol
extends RefCounted
## robosim bridge protocol v1 - GDScript side. Mirrors robosim/protocol.py exactly.
## Header (16 B): "RS", ver u8, type u8, seq u32, t_sim f64. Little-endian.

const VERSION := 1
const HEADER_SIZE := 16
const PORT_TO_VIEWER := 9001
const PORT_TO_PHYSICS := 9002

const MSG_HELLO := 1
const MSG_BYE := 2
const MSG_POSE := 3
const MSG_COMMAND := 4
const MSG_ACK := 5
const MSG_SENSOR := 6

const POSE_FLAG_RESET := 1
const POSE_FLAG_PAUSED := 2

const CMD_HEARTBEAT := 0
const CMD_PAUSE := 1
const CMD_RESUME := 2
const CMD_STEP := 3
const CMD_RESET := 4
const CMD_ATTITUDE := 10
const CMD_DIFF_DRIVE := 11

const SENSOR_CONTACT := 1
const SENSOR_RANGE := 2
const SENSOR_TARGET_BOX := 3


static func _header(msg_type: int, seq: int, t_sim: float, body_size: int) -> PackedByteArray:
	var b := PackedByteArray()
	b.resize(HEADER_SIZE + body_size)
	b.encode_u8(0, 0x52)          # 'R'
	b.encode_u8(1, 0x53)          # 'S'
	b.encode_u8(2, VERSION)
	b.encode_u8(3, msg_type)
	b.encode_u32(4, seq & 0xFFFFFFFF)
	b.encode_double(8, t_sim)
	return b


## Returns {} when the packet is not a valid v1 packet.
static func unpack(data: PackedByteArray) -> Dictionary:
	if data.size() < HEADER_SIZE or data.decode_u8(0) != 0x52 or data.decode_u8(1) != 0x53:
		return {}
	if data.decode_u8(2) != VERSION:
		return {}
	var msg := {"type": data.decode_u8(3), "seq": data.decode_u32(4), "t_sim": data.decode_double(8)}
	var o := HEADER_SIZE
	match msg.type:
		MSG_POSE:
			if data.size() < o + 44:
				return {}
			msg.vehicle_id = data.decode_u16(o)
			msg.flags = data.decode_u16(o + 2)
			msg.pos = Vector3(data.decode_float(o + 4), data.decode_float(o + 8), data.decode_float(o + 12))
			msg.quat = Quaternion(data.decode_float(o + 16), data.decode_float(o + 20),
					data.decode_float(o + 24), data.decode_float(o + 28))
			msg.vel = Vector3(data.decode_float(o + 32), data.decode_float(o + 36), data.decode_float(o + 40))
		MSG_ACK:
			if data.size() < o + 4:
				return {}
			msg.acked_seq = data.decode_u32(o)
	return msg


static func pack_command(seq: int, t_sim: float, vehicle_id: int, cmd: int, args: Array = []) -> PackedByteArray:
	var b := _header(MSG_COMMAND, seq, t_sim, 36)
	b.encode_u16(HEADER_SIZE, vehicle_id)
	b.encode_u16(HEADER_SIZE + 2, cmd)
	for i in 8:
		b.encode_float(HEADER_SIZE + 4 + i * 4, float(args[i]) if i < args.size() else 0.0)
	return b


static func pack_sensor(seq: int, t_sim: float, vehicle_id: int, sensor: int, values: PackedFloat32Array) -> PackedByteArray:
	var b := _header(MSG_SENSOR, seq, t_sim, 8 + values.size() * 4)
	b.encode_u16(HEADER_SIZE, vehicle_id)
	b.encode_u16(HEADER_SIZE + 2, sensor)
	b.encode_u16(HEADER_SIZE + 4, values.size())
	b.encode_u16(HEADER_SIZE + 6, 0)
	for i in values.size():
		b.encode_float(HEADER_SIZE + 8 + i * 4, values[i])
	return b


static func pack_simple(msg_type: int, seq: int, t_sim: float) -> PackedByteArray:
	return _header(msg_type, seq, t_sim, 0)
