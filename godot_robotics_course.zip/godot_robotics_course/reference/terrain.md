# Shared terrain contract

The physics process and Godot read **the same heightmap file** with **the same origin**. Module 2 creates it. Modules 9–11 use it for contact (PyBullet) or for terrain elevation (JSBSim).

## Files

```
data/terrain/heightmap.png    16-bit grayscale PNG, N×N pixels, N = 2^k + 1 (default 257)
data/terrain/heightmap.json   the numbers needed to turn pixels into meters
```

```json
{
  "size_px": 257,
  "meters_per_px": 1.0,
  "min_height_m": 0.0,
  "height_range_m": 20.0,
  "seed": 42,
  "origin": "center"
}
```

## Mapping (memorize this)

| Quantity | Rule |
|---|---|
| height of a pixel | `h = min_height_m + value / 65535 · height_range_m` |
| world size | `(size_px − 1) · meters_per_px`, 256 m by default |
| origin | the **center pixel** is ENU (0, 0); +x East = increasing column, +y North = **decreasing** row (row 0 is the north edge) |
| ENU → pixel | `col = (N−1)/2 + E / mpp`, `row = (N−1)/2 − N_north / mpp` |
| between pixels | bilinear interpolation, both engines |

In Godot the same point is at `(E, h, −N)` (see [frames](frames.md)).

## Who uses it

| Consumer | How |
|---|---|
| Godot visuals | Terrain3D import, **or** the fallback: a mesh plus `HeightMapShape3D` generated from the PNG (Module 2) |
| Godot sensors | raycasts against that shape (Module 8) |
| PyBullet contact | `createCollisionShape(GEOM_HEIGHTFIELD, heightfieldData=...)` (Module 9) |
| JSBSim | each step, Python samples the height under the aircraft and writes `position/terrain-elevation-asl-ft` (Module 11) |

## Two traps (measured in Module 2)

- **Godot's `Image.load_from_file` reduces a 16-bit PNG to 8 bits**, so heights are off by up to 3.9 cm with the default 20 m range. Read the PNG with Module 2's `Png16` reader (`godot/terrain/png16.gd`); it matches Python exactly.
- **Raycasts hit triangles, not the bilinear surface.** `HeightMapShape3D` splits each cell along one diagonal. On gentle ground this differs from bilinear interpolation by millimeters, but on the steep border hills by up to 13 cm. Choose check points away from steep slopes, or use a looser tolerance there.

## The range layout

Module 2 also writes `data/terrain/range.json` (ENU meters): road centerlines, landing pad, apron, parking spots for vehicles 1–4, gates and obstacles. Every later module reads positions from it instead of hard-coding them. The Python side loads the heightmap with `physics/robosim/terrain.py` (`Heightmap.load()`, `height_at(e, n)`, `height_at_godot()`, `normal_at()`).

## Validation (Module 9 Check)

Sample height at three world points in both engines. They must agree within one height step of the heightmap's resolution, plus the bilinear interpolation error.
