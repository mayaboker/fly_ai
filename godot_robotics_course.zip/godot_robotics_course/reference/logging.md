# Log format

Use one format for every module, from Module 5 on. Code: [`code/python/robosim/logger.py`](code/python/robosim/logger.py).

```
logs/
└── 20261001T090000Z_hover/
    ├── run.json        ← seed, versions, rates, origin, frame convention, anything else in meta
    ├── pose.csv        ← one CSV per stream
    ├── imu.csv
    ├── command.csv
    └── frames/         ← images (Module 7), named <frame_id>.png, zero-padded to 6 digits (000042.png)
        └── frames.csv  ← frame_id, t_sim, pose_seq, t_capture_wall, width, height
```

## Rules

1. **Every row has `t_sim` and `t_wall`.** Join streams on `t_sim`. Use `t_wall` only to measure latency. `t_wall` is seconds since the run started. The one exception is `t_capture_wall` in `frames.csv`, which is Unix time, because Godot and Python must agree on it across processes.
2. **Truth and measurement are separate columns**, for example `alt_true, alt_meas`. Never overwrite truth with noise.
3. **Seed everything** that is random, and write the seed to `run.json`.
4. **Units in column names** when they are not SI base units, for example `roll_deg` or `speed_kts`.
5. **One run = one folder.** Never append to an old run. Two runs started in the same second get `_2`, `_3` … suffixes automatically.

## Minimal example

```python
from robosim.logger import RunLogger
log = RunLogger("logs", run_name="hover", seed=42,
                meta={"physics": "pybullet", "physics_hz": 240, "pose_hz": 60})
log.write("pose", t_sim=t, x=x, y=y, z=z, qx=qx, qy=qy, qz=qz, qw=qw)
log.close()
```

## Why not ROS bags or MCAP?

CSV is readable by anything, from Excel to pandas to plain eyes, and it is enough for this course. If you move to ROS 2 later, convert to MCAP. The `t_sim` / `t_wall` / `run.json` structure maps directly onto it.
