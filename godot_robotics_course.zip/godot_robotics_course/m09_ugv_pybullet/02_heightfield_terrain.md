# 02 The shared heightmap as a PyBullet heightfield

The rover must touch the **same ground that Godot draws**. If the two disagree by 10 cm, the wheels sink into the visible road or hover above it. If they are mirrored, the rover climbs a hill that Godot shows as a valley. This page loads Module 2's `data/terrain/heightmap.png` into PyBullet and proves that the two engines agree. Module 2 already compared Godot with Python. The PyBullet leg of that comparison was deferred to this module, because you need a PyBullet world to run it.

## The contract (from [terrain.md](../reference/terrain.md))

| Quantity | Rule |
|---|---|
| file | 16-bit grayscale PNG, N×N, N = 257 by default, plus `heightmap.json` next to it |
| height | `h = min_height_m + value / 65535 · height_range_m` |
| spacing | `meters_per_px` (1 m), so 256 m × 256 m |
| origin | center pixel = ENU (0, 0); column grows **east**; row 0 is the **north** edge |
| between samples | bilinear |

Module 2's `physics/robosim/terrain.py` implements exactly this:

```python
from robosim.terrain import Heightmap
hm = Heightmap.load("../data/terrain/heightmap.png")   # json next to the png; refuses 8-bit
hm.height_at(37.3, -12.6)                              # bilinear height in m at ENU (east, north)
hm.h                                                   # numpy array [row, col], row 0 = north, meters
```

## What PyBullet actually does with heightfield data

The PyBullet documentation is thin here, so we measured it. We built a tiny 4 × 5 heightfield with two spikes and fired rays at it (the probe is in "Try it" below). Results for PyBullet 3.2.7:

| Question | Answer (measured) |
|---|---|
| Which axis does `numHeightfieldRows` run along? | **local X**: "rows" is the number of samples along X |
| Index of sample (i along X, j along Y)? | `heightfieldData[i + j * numHeightfieldRows]` |
| Does j grow toward +Y? | yes |
| Is the shape centered in X and Y? | yes: X spans ±(rows − 1)/2 · scale_x |
| Is it centered in **Z**? | **yes**: the local origin is at (min + max)/2 of the data |
| `meshScale` | `[scale_x, scale_y, scale_z]` multiplies the grid spacing and the heights |

Now map that onto the image. X = east = increasing column. So `numHeightfieldRows` = number of **columns**, and the column index must vary fastest. Y = north must grow with j, but image rows grow **southward**, so flip the rows. Z is centered, so lift the body by (min + max)/2. The new shared helper `physics/robosim/pybullet_world.py` does all three:

```python
def add_heightfield(p, hm, friction=1.0):
    """Static heightfield body for a robosim.terrain.Heightmap. Returns the body id."""
    data = hm.h[::-1, :]                          # flip rows: index j must grow northward
    shape = p.createCollisionShape(
        p.GEOM_HEIGHTFIELD,
        meshScale=[hm.mpp, hm.mpp, 1.0],          # heights are already in meters
        heightfieldData=data.ravel().tolist(),    # row-major: column (east) index fastest
        numHeightfieldRows=hm.size_px,            # samples along X
        numHeightfieldColumns=hm.size_px)         # samples along Y
    z_center = (float(hm.h.min()) + float(hm.h.max())) / 2.0
    body = p.createMultiBody(0, shape, basePosition=[0, 0, z_center])
    p.changeDynamics(body, -1, lateralFriction=friction)
    return body
```

The heightmap is square, so rows and columns are both 257. That is exactly why a swap goes unnoticed until you test with real points.

The same file also places Module 2's obstacles and gates as static PyBullet bodies (`add_range_objects`). It uses the rule from `RangeBuilder`: each object sits on the lowest terrain point under its footprint, and `range.json`'s `yaw_deg` is a clockwise turn seen from above (Godot `rotation.y = −yaw`), which is a rotation of −yaw about ENU +z.

## The three-point cross-check

Use the three ENU points from Module 2's `tools/compare_heights.py`. None of them is on a grid vertex, which would hide interpolation and flip errors. Fire a vertical ray at each one in PyBullet and compare the hit height with `hm.height_at()`.

```python
for e, n in [(37.3, -12.6), (-55.5, 41.2), (101.7, -88.3)]:
    hit = p.rayTest([e, n, 1000.0], [e, n, -1000.0])[0]
    h_pb, h_py = hit[3][2], hm.height_at(e, n)
    tol = step + W.cell_twist(hm, e, n) + 1e-3
    print(e, n, h_py, h_pb, abs(h_pb - h_py) <= tol)
```

### What tolerance is fair?

[terrain.md](../reference/terrain.md) says: within one height step, plus the bilinear interpolation error. Here is the precise version:

| Term | Size | Why |
|---|---|---|
| one height step | `height_range / 65535` = 0.31 mm | quantization of the 16-bit PNG |
| triangle vs bilinear | `|h00 + h11 − h01 − h10| / 4` of that cell | PyBullet (and Godot) split each cell into **two flat triangles**. Bilinear is a curved patch. They agree on the edges and differ most in the middle, by at most a quarter of the cell's "twist". `pybullet_world.cell_twist()` computes it. |
| float32 + ray precision | 1 mm | single-precision heights and ray math inside Bullet |

### Measured result (Module 2 terrain, seed 42)

```
terrain AABB x -128.0..128.0  y -128.0..128.0  z -0.00..18.96
   east   north  python_m pybullet_m  diff_mm  tol_mm
  37.30  -12.60    0.6476     0.6473     0.29    1.92  OK
 -55.50   41.20    2.7400     2.7396     0.40    2.30  OK
 101.70  -88.30    3.3864     3.3865     0.14    1.69  OK
2000 random points: median 0.15 mm, 99th pct 2.48 mm, max 105.16 mm; outside their own tolerance: 0
heightfield check: PASS
```

The random-point statistic shows why the tolerance has a per-cell term. The worst point, 105 mm, lies in the steep border hills, in a cell whose triangle-vs-bilinear bound is 132 mm. That is real geometry, not a bug. All 2000 points are within their own cell's tolerance.

### All three engines at the same points

We also ran Module 2's `tools/compare_heights.py` (Godot headless) on the same terrain:

| E, N (m) | Python bilinear | PyBullet ray | Godot lookup | Godot ray |
|---|---:|---:|---:|---:|
| 37.3, −12.6 | 0.6476 | 0.6473 | 0.6476 | 0.6479 |
| −55.5, 41.2 | 2.7400 | 2.7396 | 2.7400 | 2.7403 |
| 101.7, −88.3 | 3.3864 | 3.3865 | 3.3864 | 3.3860 |

PyBullet and Godot each triangulate the cells their own way, so their rays differ from each other by up to 0.7 mm. The rover cannot feel that.

## What the classic mistakes look like

We ran the three points with each mistake on purpose. Differences (PyBullet − Python, m):

| Mistake | Point 1 | Point 2 | Point 3 | Signature |
|---|---:|---:|---:|---|
| none | 0.000 | 0.000 | 0.000 | |
| rows not flipped (north–south mirror) | +0.615 | −1.097 | +1.656 | varies, can be small near the flat center |
| body at z = 0 (forgot vertical centering) | −9.479 | −9.479 | −9.479 | constant = −(min + max)/2 |
| transposed (column/row swapped) | +0.277 | −1.384 | −0.361 | varies |

A constant offset means a Z placement error. Varying errors mean an indexing error. Small errors that grow with slope are just triangles vs bilinear. The Module 2 map is almost flat near the center (the apron is exactly 0 m), so a mirror error can stay invisible on the apron. That is one more reason to test points with relief.

## Try it

- Run `python tests/test_heightfield.py`. Then break `add_heightfield()` in each of the three ways above and confirm the signatures.
- Run this probe. Work out where the two spikes appear, and explain the AABB z range (−3 … +3) it prints.

  ```python
  import pybullet as p
  p.connect(p.DIRECT)
  data = [0.0] * 20; data[1] = 3.0; data[4 * 2 + 3] = 6.0       # rows=4 (X), cols=5 (Y)
  s = p.createCollisionShape(p.GEOM_HEIGHTFIELD, meshScale=[2, 1, 1], heightfieldData=data,
                             numHeightfieldRows=4, numHeightfieldColumns=5)
  b = p.createMultiBody(0, s); print(p.getAABB(b))
  ```
- Add a fourth test point at (0, 0). Why does it prove nothing on this map?
- Spawn `box_1` from `range.json` with `add_range_objects()`, and compare its PyBullet AABB with the box Godot draws (select it in the remote scene tree while the game runs).

## References

- [Shared terrain contract](../reference/terrain.md), and [Module 2](../m02_scene_assets/README.md) pages 04 and 05
- Godot `HeightMapShape3D`: <https://docs.godotengine.org/en/stable/classes/class_heightmapshape3d.html>
- PyBullet Quickstart Guide, `createCollisionShape` with `GEOM_HEIGHTFIELD`: <https://docs.google.com/document/d/10sXEhzFRSnvFcl3XxNGhnD4N2SedqwdAvK3dsihxVUA>
