"""
test_heightfield.py - Module 9 Check: PyBullet's heightfield agrees with the Python
bilinear sampler (robosim.terrain) at three ENU points.

    cd robosim/physics && python tests/test_heightfield.py

The three points are the ones Module 2 used for Godot (tools/compare_heights.py).
Tolerance per point = one height step (height_range / 65535)
                    + the cell's two-triangle vs bilinear bound (pybullet_world.cell_twist)
                    + 1 mm for single-precision heights and ray math inside Bullet.
"""
import os, sys
import numpy as np
import pybullet as p

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from robosim.terrain import Heightmap
from robosim import pybullet_world as W

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
POINTS = [(37.3, -12.6), (-55.5, 41.2), (101.7, -88.3)]      # ENU (east, north), meters


def ray_height(body, e, n):
    hit = p.rayTest([e, n, 1000.0], [e, n, -1000.0])[0]
    assert hit[0] == body, f"ray at ({e}, {n}) missed the terrain"
    return hit[3][2]


def main():
    hm = Heightmap.load(os.path.join(ROOT, "data", "terrain", "heightmap.png"))
    step = hm.meta["height_range_m"] / 65535.0
    p.connect(p.DIRECT)
    terrain = W.add_heightfield(p, hm)
    lo, hi = p.getAABB(terrain)
    print(f"terrain AABB x {lo[0]:.1f}..{hi[0]:.1f}  y {lo[1]:.1f}..{hi[1]:.1f}  z {lo[2]:.2f}..{hi[2]:.2f}")

    ok = True
    print(f"{'east':>7} {'north':>7} {'python_m':>9} {'pybullet_m':>10} {'diff_mm':>8} {'tol_mm':>7}")
    for e, n in POINTS:
        h_py = hm.height_at(e, n)
        h_pb = ray_height(terrain, e, n)
        tol = step + W.cell_twist(hm, e, n) + 1e-3
        diff = abs(h_pb - h_py)
        ok &= diff <= tol
        print(f"{e:7.2f} {n:7.2f} {h_py:9.4f} {h_pb:10.4f} {diff * 1000:8.2f} {tol * 1000:7.2f}"
              f"  {'OK' if diff <= tol else 'FAIL'}")

    # the same comparison at 2000 random points, as a statistic
    rng = np.random.default_rng(0)
    d, outside = [], 0
    for e, n in rng.uniform(-120, 120, (2000, 2)):
        d.append(abs(ray_height(terrain, e, n) - hm.height_at(e, n)))
        outside += d[-1] > step + W.cell_twist(hm, e, n) + 1e-3
    d = np.array(d) * 1000
    print(f"2000 random points: median {np.median(d):.2f} mm, 99th pct {np.percentile(d, 99):.2f} mm, "
          f"max {d.max():.2f} mm; outside their own tolerance: {outside}")
    print("heightfield check:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
