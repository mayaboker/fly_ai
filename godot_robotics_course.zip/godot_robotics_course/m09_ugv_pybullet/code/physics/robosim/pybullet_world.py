"""
pybullet_world.py - the Module 2 test range inside PyBullet (Module 9; Module 10 reuses it).

    from robosim.terrain import Heightmap
    from robosim import pybullet_world as W
    hm = Heightmap.load("../data/terrain/heightmap.png")
    layout = W.load_range("../data/terrain/range.json")
    terrain = W.add_heightfield(p, hm)                 # the shared heightmap as GEOM_HEIGHTFIELD
    names = W.add_range_objects(p, hm, layout, gates=True)   # obstacles (+ gates), as Godot builds them

PyBullet's heightfield conventions (measured with PyBullet 3.2.7 in Module 9):
  * numHeightfieldRows = number of samples along local X (here: East = image columns)
  * heightfieldData[i + j * numHeightfieldRows]: i along X, j along +Y (North)
  * the shape is centered in X and Y, and ALSO in Z: its origin sits at (min + max) / 2
"""
import json
import math


def add_heightfield(p, hm, friction=1.0):
    """Static heightfield body for a robosim.terrain.Heightmap. Returns the body id."""
    data = hm.h[::-1, :]                          # flip rows: index j must grow northward
    shape = p.createCollisionShape(
        p.GEOM_HEIGHTFIELD,
        meshScale=[hm.mpp, hm.mpp, 1.0],          # heights are already in meters
        heightfieldData=data.ravel().tolist(),    # row-major: column (east) index fastest
        numHeightfieldRows=hm.size_px,            # samples along X
        numHeightfieldColumns=hm.size_px)         # samples along Y
    z_center = (float(hm.h.min()) + float(hm.h.max())) / 2.0
    body = p.createMultiBody(0, shape, basePosition=[0, 0, z_center])
    p.changeDynamics(body, -1, lateralFriction=friction)
    return body


def cell_twist(hm, e, n):
    """|h00 + h11 - h01 - h10| / 4 of the cell under ENU (e, n): the most a two-triangle
    surface (PyBullet, Godot HeightMapShape3D) can differ from bilinear inside that cell."""
    col, row = hm.enu_to_pixel(e, n)
    c0 = int(min(max(math.floor(col), 0), hm.size_px - 2))
    r0 = int(min(max(math.floor(row), 0), hm.size_px - 2))
    h = hm.h
    return abs(h[r0, c0] + h[r0 + 1, c0 + 1] - h[r0, c0 + 1] - h[r0 + 1, c0]) / 4.0


def load_range(path):
    with open(path) as f:
        return json.load(f)


def _lowest_ground(hm, e, n, footprint):
    """Same rule as Module 2's RangeBuilder: sit on the lowest terrain point under the footprint."""
    low = hm.height_at(e, n)
    for de, dn in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
        low = min(low, hm.height_at(e + de * footprint, n + dn * footprint))
    return low


def add_range_objects(p, hm, layout, gates=False):
    """Static bodies for range.json obstacles (and optionally the drone gates), placed exactly
    like Module 2's RangeBuilder places them in Godot. Returns {body_id: name}."""
    names = {}
    for o in layout.get("obstacles", []):
        e, n = o["e"], o["n"]
        if o["type"] == "box":
            sx, sy, sz = o["size_m"]                                   # [east, north, up]
            shape = p.createCollisionShape(p.GEOM_BOX, halfExtents=[sx / 2, sy / 2, sz / 2])
            height, footprint = sz, math.hypot(sx, sy) / 2
        else:
            r, height = o["radius_m"], o["height_m"]
            shape = p.createCollisionShape(p.GEOM_CYLINDER, radius=r, height=height)  # axis = local z
            footprint = r
        z0 = _lowest_ground(hm, e, n, footprint)
        # range.json yaw_deg: Godot rotation.y = -yaw_deg, i.e. a CLOCKWISE turn seen from above.
        # In ENU (z up) that is a rotation of -yaw_deg about +z.
        q = p.getQuaternionFromEuler([0, 0, -math.radians(o.get("yaw_deg", 0.0))])
        names[p.createMultiBody(0, shape, basePosition=[e, n, z0 + height / 2], baseOrientation=q)] = o["name"]
    if gates:
        for g in layout.get("gates", []):
            names.update(_add_gate(p, hm, g))
    return names


def _add_gate(p, hm, g):
    """Two posts and a top bar, as Module 2 builds them (heading_deg = compass direction of flight)."""
    w, h = g["width_m"], g["height_m"]
    z0 = hm.height_at(g["e"], g["n"])
    psi = math.radians(g["heading_deg"])
    right = (math.cos(psi), -math.sin(psi))                           # ENU unit vector to the gate's right
    q = p.getQuaternionFromEuler([0, 0, -psi])                         # gate local x = its right
    parts = {}
    for side in (-1, 1):
        off = side * (w / 2 + 0.1)
        shape = p.createCollisionShape(p.GEOM_BOX, halfExtents=[0.1, 0.1, (h + 0.2) / 2])
        pos = [g["e"] + off * right[0], g["n"] + off * right[1], z0 + (h + 0.2) / 2]
        parts[p.createMultiBody(0, shape, basePosition=pos, baseOrientation=q)] = g["name"] + "_post"
    shape = p.createCollisionShape(p.GEOM_BOX, halfExtents=[(w + 0.4) / 2, 0.1, 0.1])
    parts[p.createMultiBody(0, shape, basePosition=[g["e"], g["n"], z0 + h + 0.1],
                            baseOrientation=q)] = g["name"] + "_bar"
    return parts
