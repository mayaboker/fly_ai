"""
ugv_pybullet.py - Module 9: differential-drive rover on the shared terrain, road following.

    cd robosim/physics
    python sims/ugv_pybullet.py                      # real time, streams to Godot (port 9001)
    python sims/ugv_pybullet.py --fast --friction 0.3 --run-name ugv_low_mu   # as fast as possible

Vehicle id 1. World ENU, body FLU (x forward). Rates: physics 240 Hz, control + pose + log 60 Hz.
Auto mode: pure pursuit along the Module 2 roads in data/terrain/range.json: from the rover's
lineup spot onto the spur, down to the loop, one lap counter-clockwise, back to the junction.
Manual mode: any DIFF_DRIVE (cmd 11) received in the last 0.3 s of sim time overrides the
controller (a dead-man timeout).
"""
import argparse, json, math, os, sys, time
import numpy as np
import pybullet as p

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
from robosim import protocol as P
from robosim.bridge import PhysicsBridge
from robosim.frames import enu_flu_to_godot, enu_to_godot_pos, quat_to_matrix
from robosim.logger import RunLogger
from robosim.terrain import Heightmap
from robosim import pybullet_world as W

ROOT = os.path.join(HERE, "..", "..")
VEHICLE_ID = 1
WHEEL_R, TRACK = 0.15, 0.72          # m, must match assets/rover.urdf
REST_HEIGHT = 0.25                   # base origin above the ground when resting (Module 2 rest_height_m)
LEFT, RIGHT, CASTER = 0, 1, 2        # joint / link indices in the URDF
MANUAL_TIMEOUT_S = 0.3
A_MAX, ALPHA_MAX = 1.0, 3.0         # m/s^2, rad/s^2 command rate limits
STUCK_S = 30.0                      # auto mode: < 1 m of progress in this time = stuck, stop


# ---------------------------------------------------------------- path geometry
class Path2D:
    """Polyline in ENU with arc length, closest point and look-ahead point."""
    def __init__(self, pts):
        self.p = np.asarray(pts, float)
        seg = np.diff(self.p, axis=0)
        self.seg_len = np.hypot(seg[:, 0], seg[:, 1])
        self.s = np.r_[0.0, np.cumsum(self.seg_len)]
        self.length = self.s[-1]

    def project(self, xy, i_min=0, i_max=None):
        """Closest point on segments i_min..i_max: (arc length s, signed cross-track, index).
        Cross-track is + when the point is LEFT of the path direction."""
        i_max = len(self.seg_len) if i_max is None else min(i_max, len(self.seg_len))
        best = (1e18, 0.0, 0.0, i_min)
        for i in range(i_min, i_max):
            a, d, L = self.p[i], self.p[i + 1] - self.p[i], self.seg_len[i]
            t = min(max(np.dot(xy - a, d) / (L * L), 0.0), 1.0)
            q = a + t * d
            dist2 = float(np.sum((xy - q) ** 2))
            if dist2 < best[0]:
                cross = d[0] * (xy[1] - a[1]) - d[1] * (xy[0] - a[0])
                best = (dist2, self.s[i] + t * L, math.copysign(math.sqrt(dist2), cross), i)
        return best[1], best[2], best[3]

    def point_at(self, s):
        s = min(max(s, 0.0), self.length)
        i = min(int(np.searchsorted(self.s, s, side="right")) - 1, len(self.seg_len) - 1)
        t = (s - self.s[i]) / self.seg_len[i]
        return self.p[i] + t * (self.p[i + 1] - self.p[i])


def build_route(layout, start_en):
    """Start point -> spur (north to south) -> junction on the loop -> one counter-clockwise lap
    -> junction. The loop in range.json is closed (last point = first point)."""
    roads = {r["name"]: r["points"] for r in layout["roads"]}
    spur = [tuple(pt) for pt in roads["spur"]]
    loop = [tuple(pt) for pt in roads["loop"]][:-1]            # drop the repeated closing point
    q = np.array(spur[-1], float)                              # junction = end of the spur
    best = (1e18, 0)
    for i in range(len(loop)):                                 # which loop segment holds it?
        a, b = np.array(loop[i]), np.array(loop[(i + 1) % len(loop)])
        t = np.clip(np.dot(q - a, b - a) / np.dot(b - a, b - a), 0, 1)
        d = np.linalg.norm(a + t * (b - a) - q)
        if d < best[0]:
            best = (d, i)
    i = best[1]
    lap = loop[i + 1:] + loop[:i + 1]                          # starts after the junction, CCW
    pts = [tuple(start_en)] + spur + lap + [spur[-1]]
    out = [pts[0]]
    for pt in pts[1:]:                                         # drop duplicate points
        if np.hypot(pt[0] - out[-1][0], pt[1] - out[-1][1]) > 1e-6:
            out.append(pt)
    return out


class PurePursuit:
    """Steer toward the path point one look-ahead distance ahead. kappa = 2 y / Ld^2."""
    def __init__(self, path, v_max=2.0, a_lat_max=1.0, ld_min=1.5, ld_gain=0.6):
        self.path, self.v_max, self.a_lat = path, v_max, a_lat_max
        self.ld_min, self.ld_gain = ld_min, ld_gain
        self.i = None                               # progress index; None = search widely
        self.floor = 0                              # a wide search never goes back before this

    def lost(self):
        """Back from manual driving: search the rest of the route (from just before where we were)."""
        if self.i is not None:
            self.floor = max(self.i - 4, 0)
        self.i = None

    def update(self, xy, yaw, v_now):
        if self.i is None:                          # start, reset, or back from manual driving
            s, cte, self.i = self.path.project(xy, self.floor)
        else:                                       # then only look a little back and ahead
            s, cte, self.i = self.path.project(xy, max(self.i - 2, 0), self.i + 8)
        ld = max(self.ld_min, self.ld_min + self.ld_gain * v_now)
        target = self.path.point_at(s + ld)
        dx, dy = target - xy
        x_body = math.cos(yaw) * dx + math.sin(yaw) * dy      # target in the body frame
        y_body = -math.sin(yaw) * dx + math.cos(yaw) * dy
        done = self.path.length - s < 0.5
        if done:
            return 0.0, 0.0, s, cte, True
        alpha = math.atan2(y_body, x_body)                      # bearing to the target
        if abs(alpha) > math.radians(60):                       # target behind or far to the side:
            return 0.3, math.copysign(1.0, alpha), s, cte, False  # crawl and turn toward it
        kappa = 2.0 * y_body / max(dx * dx + dy * dy, 1e-6)     # pure pursuit: kappa = 2 y / L^2
        v = min(self.v_max, math.sqrt(self.a_lat / max(abs(kappa), 1e-6)))
        v = min(v, 0.8 * (self.path.length - s) + 0.1)          # slow down at the end
        return v, v * kappa, s, cte, False


# ---------------------------------------------------------------- the simulation
def wheel_speeds(v, w):
    """Unicycle (v m/s, w rad/s) -> wheel joint speeds (rad/s)."""
    return (v - w * TRACK / 2) / WHEEL_R, (v + w * TRACK / 2) / WHEEL_R


class UgvSim:
    def __init__(self, a):
        self.a = a
        self.dt = 1.0 / a.physics_hz
        self.hm = Heightmap.load(os.path.join(ROOT, "data", "terrain", "heightmap.png"))
        self.layout = W.load_range(os.path.join(ROOT, "data", "terrain", "range.json"))
        spot = next(v for v in self.layout["lineup"] if v["id"] == VEHICLE_ID)
        self.lineup = (spot["e"], spot["n"])
        self.path = Path2D(build_route(self.layout, self.lineup))

        p.connect(p.DIRECT)
        p.setGravity(0, 0, -9.81)
        p.setTimeStep(self.dt)
        p.setPhysicsEngineParameter(numSolverIterations=50)
        self.terrain = W.add_heightfield(p, self.hm, friction=1.0)
        self.obstacles = W.add_range_objects(p, self.hm, self.layout, gates=True)   # as Godot builds them

        self.rover = p.loadURDF(os.path.join(HERE, "..", "assets", "rover.urdf"),
                                flags=p.URDF_USE_INERTIA_FROM_FILE)
        # Bullet multiplies the two bodies' coefficients: terrain 1.0 x wheel mu = mu.
        for j in (LEFT, RIGHT):
            p.changeDynamics(self.rover, j, lateralFriction=a.friction,
                             rollingFriction=0.0, spinningFriction=0.0)
        p.changeDynamics(self.rover, CASTER, lateralFriction=0.0)        # a frictionless ball
        p.changeDynamics(self.rover, -1, lateralFriction=0.3)            # chassis, only if it scrapes
        self.reset()

        self.br = PhysicsBridge(viewer_port=a.viewer_port, listen_port=a.listen_port)
        self.log = RunLogger(os.path.join(ROOT, "logs"), run_name=a.run_name, seed=0, meta={
            "physics": "pybullet", "physics_hz": a.physics_hz, "control_hz": a.physics_hz / a.decim,
            "pose_hz": a.physics_hz / a.decim, "vehicle_id": VEHICLE_ID, "wheel_friction": a.friction,
            "max_wheel_torque_nm": a.max_torque, "v_max": a.speed, "nav": a.nav,
            "wheel_r_m": WHEEL_R, "track_m": TRACK, "road_length_m": round(self.path.length, 2)})

    def start_pose(self):
        if self.a.start:
            e, n, yaw_deg = (float(v) for v in self.a.start.split(","))
            return e, n, math.radians(yaw_deg)
        (e, n), (e1, n1) = self.path.p[0], self.path.p[1]           # lineup spot, facing the spur
        return e, n, math.atan2(n1 - n, e1 - e)

    def reset(self):
        e, n, yaw = self.start_pose()
        z = self.hm.height_at(e, n) + REST_HEIGHT + 0.02  # wheel bottoms 2 cm above the ground
        p.resetBasePositionAndOrientation(self.rover, [e, n, z], p.getQuaternionFromEuler([0, 0, yaw]))
        p.resetBaseVelocity(self.rover, [0, 0, 0], [0, 0, 0])
        for j in (LEFT, RIGHT):
            p.resetJointState(self.rover, j, 0.0, 0.0)
        self.t = 0.0
        self.k = 0
        self.odom = np.array([e, n, yaw])                # starts at the true pose, then drifts
        self.v_cmd = self.w_cmd = 0.0
        self.manual_until = -1.0
        self.manual = (0.0, 0.0)
        self.bump_until = -1.0
        self.paused = False
        self.steps_left = 0
        self.pp = None
        self.prog_s, self.prog_t, self.stuck = 0.0, 0.0, False
        self.wall0 = time.monotonic()                    # pacing reference: sim t=0 <-> this wall time

    # ---- one physics step
    def step_physics(self):
        wl, wr = wheel_speeds(self.v_cmd, self.w_cmd)
        for j, w in ((LEFT, wl), (RIGHT, wr)):
            p.setJointMotorControl2(self.rover, j, p.VELOCITY_CONTROL, targetVelocity=w,
                                    force=self.a.max_torque)       # 'force' = max torque, N m
        p.stepSimulation()
        self.t += self.dt
        self.k += 1
        # wheel odometry: integrate what the encoders see (joint speeds), in 2D
        wl_m = p.getJointState(self.rover, LEFT)[1]
        wr_m = p.getJointState(self.rover, RIGHT)[1]
        v = WHEEL_R * (wl_m + wr_m) / 2
        w = WHEEL_R * (wr_m - wl_m) / TRACK
        th = self.odom[2] + 0.5 * w * self.dt                       # midpoint heading
        self.odom += [v * math.cos(th) * self.dt, v * math.sin(th) * self.dt, w * self.dt]
        self.enc = (wl_m, wr_m)

    # ---- 60 Hz: commands, control, contacts, pose, log
    def control_tick(self, frozen=False):
        """frozen=True (paused, or waiting for the viewer): answer commands and resend the same pose."""
        pos, q = p.getBasePositionAndOrientation(self.rover)
        lin, ang = p.getBaseVelocity(self.rover)
        R = quat_to_matrix(q)
        yaw = math.atan2(R[1, 0], R[0, 0])
        v_fwd = float(np.dot(R[:, 0], lin))                         # true forward speed
        xy_true = np.array(pos[:2])

        for msg in self.br.poll(self.t):
            if msg["type"] != P.MSG_COMMAND or msg["vehicle_id"] not in (VEHICLE_ID, 0):
                continue
            c = msg["cmd"]
            if c == P.CMD_DIFF_DRIVE:
                self.manual = (msg["args"][0], msg["args"][1])
                self.manual_until = self.t + MANUAL_TIMEOUT_S
            elif c == P.CMD_PAUSE:
                self.paused = True
            elif c == P.CMD_RESUME:
                self.paused, self.steps_left = False, 0
            elif c == P.CMD_STEP:
                self.steps_left += 1
            elif c == P.CMD_RESET:
                self.reset()
                self.br.mark_reset()
                return False
        if frozen:
            pos_g, q_g = enu_flu_to_godot(pos, q)
            self.br.send_pose(self.t, VEHICLE_ID, pos_g, q_g, (0, 0, 0), paused=self.paused)
            return False

        # navigation source: ground truth (like RTK GPS) or our own drifting odometry
        nav_xy, nav_yaw = (xy_true, yaw) if self.a.nav == "truth" else (self.odom[:2], self.odom[2])
        if self.pp is None:
            self.pp = PurePursuit(self.path, v_max=self.a.speed)
        v, w, s, _, done = self.pp.update(nav_xy, nav_yaw, max(v_fwd, 0.0))
        s_true, cte, _ = self.path.project(xy_true, max(self.pp.i - 4, 0), self.pp.i + 8)
        mode = "auto"
        if self.t < self.manual_until:
            v, w = self.manual
            mode = "manual"
            self.pp.lost()                          # re-find the road when auto resumes

        # collision feedback: contacts on the CHASSIS (link -1). Wheels/caster touch the ground all the time.
        f_obst = f_scrape = 0.0
        for c in p.getContactPoints(bodyA=self.rover, linkIndexA=-1):
            other, normal_on_b, f = c[2], c[7], c[9]
            if f <= 0.0:
                continue                                            # touching, but no force
            if other in self.obstacles:
                f_obst += f
                self.log.write("contact", t_sim=self.t, other=self.obstacles[other], normal_force_n=round(f, 2),
                               nx=round(normal_on_b[0], 3), ny=round(normal_on_b[1], 3), nz=round(normal_on_b[2], 3))
            elif other == self.terrain:
                f_scrape += f
        if f_obst > 1.0:
            self.bump_until = self.t + 0.5                          # bumper: no forward motion for 0.5 s
        if self.t < self.bump_until:
            v = min(v, 0.0)
            self.v_cmd = min(self.v_cmd, 0.0)                       # a bumper stops NOW, no ramp
        # acceleration limits: a step from 0 to 2 m/s spins the wheels and kicks the heading
        dt_c = self.dt * self.a.decim
        self.v_cmd += min(max(v - self.v_cmd, -A_MAX * dt_c), A_MAX * dt_c)
        self.w_cmd += min(max(w - self.w_cmd, -ALPHA_MAX * dt_c), ALPHA_MAX * dt_c)

        # pose to Godot (converted once, here)
        pos_g, q_g = enu_flu_to_godot(pos, q)
        self.br.send_pose(self.t, VEHICLE_ID, pos_g, q_g, enu_to_godot_pos(lin), paused=self.paused)

        # logs: truth and measurement in separate columns
        rpy = p.getEulerFromQuaternion(q)
        self.log.write("pose", t_sim=self.t, x=pos[0], y=pos[1], z=pos[2],
                       roll_deg=math.degrees(rpy[0]), pitch_deg=math.degrees(rpy[1]),
                       yaw_deg=math.degrees(yaw), v_fwd=v_fwd, wz=ang[2])
        err = float(np.hypot(*(self.odom[:2] - xy_true)))
        self.log.write("odom", t_sim=self.t, x_true=pos[0], y_true=pos[1], yaw_true_deg=math.degrees(yaw),
                       x_odom=self.odom[0], y_odom=self.odom[1], yaw_odom_deg=math.degrees(self.odom[2]),
                       pos_err=err, wl_enc=self.enc[0], wr_enc=self.enc[1])
        self.log.write("control", t_sim=self.t, mode=mode, v_cmd=self.v_cmd, w_cmd=self.w_cmd,
                       s=s_true, cte=cte, f_obstacle_n=f_obst, f_scrape_n=f_scrape)
        if mode == "auto" and self.t - self.prog_t > STUCK_S:     # no progress along the road
            if s_true - self.prog_s < 1.0:
                self.stuck = True
            self.prog_s, self.prog_t = s_true, self.t
        if mode == "auto":
            self.cte_sq += cte * cte
            self.cte_max = max(self.cte_max, abs(cte))
            self.n_ticks += 1
        return (done and mode == "auto") or self.stuck

    def run(self):
        a = self.a
        print(f"ugv: vehicle {VEHICLE_ID}, friction {a.friction}, nav {a.nav}, road {self.path.length:.1f} m, "
              f"log {self.log.dir}")
        self.cte_sq, self.cte_max, self.n_ticks = 0.0, 0.0, 0
        if not (a.fast or a.no_wait):
            print("waiting for the Godot viewer (HELLO)... use --no-wait to start anyway")
            self.br.wait_for_viewer()      # HELLO (or any packet) from the viewer; works in either start order
            self.reset()                                             # start the clock now
        t_start = time.monotonic()
        end_reason = "duration"
        try:
            while a.duration <= 0 or self.t < a.duration:
                if self.paused and self.steps_left == 0:
                    w0 = time.monotonic()
                    self.control_tick(frozen=True)                    # keeps poses + commands alive
                    time.sleep(1.0 / 60)
                    self.wall0 += time.monotonic() - w0              # paused time does not count
                    continue
                for _ in range(a.decim):
                    self.step_physics()
                if self.paused:
                    self.steps_left -= 1
                if self.control_tick() and (self.stuck or not a.keep_running):
                    end_reason = "stuck" if self.stuck else "road end"
                    break
                if not a.fast:                                       # pace to wall clock
                    lag = self.t - (time.monotonic() - self.wall0)
                    if lag > 0:
                        time.sleep(lag)
        except KeyboardInterrupt:
            end_reason = "ctrl-c"
        wall = time.monotonic() - t_start
        pos, _ = p.getBasePositionAndOrientation(self.rover)
        odo_err = float(np.hypot(self.odom[0] - pos[0], self.odom[1] - pos[1]))
        rms = math.sqrt(self.cte_sq / max(self.n_ticks, 1))
        summary = {"end": end_reason, "t_sim": round(self.t, 2), "wall_s": round(wall, 2),
                   "cte_rms_m": round(rms, 3), "cte_max_m": round(self.cte_max, 3),
                   "odom_err_end_m": round(odo_err, 2)}
        with open(os.path.join(self.log.dir, "summary.json"), "w") as f:
            json.dump(summary, f, indent=2)
        print("ugv summary:", summary)
        self.log.close()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--friction", type=float, default=1.0, help="wheel lateralFriction (terrain is 1.0)")
    ap.add_argument("--speed", type=float, default=2.0, help="max speed, m/s")
    ap.add_argument("--max-torque", type=float, default=8.0, help="per-wheel motor torque limit, N m")
    ap.add_argument("--nav", choices=["truth", "odom"], default="truth", help="pose used by the controller")
    ap.add_argument("--physics-hz", type=float, default=240.0)
    ap.add_argument("--decim", type=int, default=4, help="physics steps per control/pose tick (240/4 = 60 Hz)")
    ap.add_argument("--duration", type=float, default=0.0, help="sim seconds, 0 = until the road ends")
    ap.add_argument("--keep-running", action="store_true", help="stay up after the road ends (manual driving)")
    ap.add_argument("--start", default="", help="'east,north,yaw_deg' instead of the road start")
    ap.add_argument("--fast", action="store_true", help="do not pace to the wall clock, do not wait for Godot")
    ap.add_argument("--no-wait", action="store_true", help="start without waiting for the viewer's HELLO")
    ap.add_argument("--run-name", default="ugv")
    ap.add_argument("--viewer-port", type=int, default=P.PORT_TO_VIEWER)
    ap.add_argument("--listen-port", type=int, default=P.PORT_TO_PHYSICS)
    UgvSim(ap.parse_args()).run()


if __name__ == "__main__":
    main()
