# Module 9 reference code

These files mirror their paths in `robosim/`. Copy them over your project as [lab.md](../lab.md) describes. They build on Module 2 (terrain, `range.json`, `terrain.py`, `HeightmapTerrain`, `RangeBuilder`, `rover.tscn`), Module 4 (bridge), Module 5 (`RenderClock`) and Module 6 (`CameraRig`). Nothing from those modules is changed.

```
physics/robosim/pybullet_world.py   NEW shared helper: add_heightfield(), cell_twist(), load_range(),
                                    add_range_objects() (obstacles + gates, placed like RangeBuilder)
physics/assets/rover.urdf           2 driven rear wheels (sphere collision) + front caster; Module 2 dimensions
physics/sims/ugv_pybullet.py        the simulation (vehicle id 1): route, pure pursuit, odometry, bumper, logs
physics/tests/test_heightfield.py   Check 1: PyBullet vs Python at Module 2's three points
tools/plot_cross_track.py           cross-track + odometry plot and table, up to 4 runs
godot/scenes/ugv_lab.tscn/.gd       the viewer: Module 2 range + rover, chase/onboard view,
                                    FPV picture-in-picture, DIFF_DRIVE, test options
```

## How to run

```bash
cd ~/robosim/physics
python tests/test_heightfield.py
python sims/ugv_pybullet.py --fast --run-name ugv_mu1.0
python sims/ugv_pybullet.py --fast --friction 0.15 --run-name ugv_mu0.15
cd .. && python tools/plot_cross_track.py logs/*_ugv_mu1.0 logs/*_ugv_mu0.15 -o cross_track.png

godot --headless --path godot --import
python physics/sims/ugv_pybullet.py --keep-running     # then run godot/scenes/ugv_lab.tscn
```

`ugv_lab.gd` test options (after `--`): `--ports=L,P`, `--autotest`, `--shot=DIR@T`, `--quit-after=S`.

## What was verified, and how

Tested on Linux (2 CPU cores) with Python 3.11, PyBullet 3.2.7, numpy 2.4, matplotlib 3.10, Pillow 12.2 and Godot 4.7.2-stable, in a scratch copy of `robosim/` assembled from the Module 2, 4, 5 and 6 reference code. The terrain is Module 2's `make_heightmap.py --seed 42`; we regenerated it and it was byte-identical to Module 2's files. The bridge used test ports 9190/9191; the defaults in the code are 9001/9002.

| What | How | Result |
|---|---|---|
| heightfield conventions (axis, index order, Z centering) | 4 × 5 probe heightfield + rays | rows = X, `data[i + j·rows]`, centered in X, Y **and** Z |
| `test_heightfield.py` | Module 2 terrain | PASS; 0.29 / 0.40 / 0.14 mm vs tolerance 1.92 / 2.30 / 1.69 mm; 2000 random points all within their own cell tolerance |
| Godot at the same points | Module 2's `tools/compare_heights.py`, headless | raycast 0.6479 / 2.7403 / 3.3860 m (PyBullet 0.6473 / 2.7396 / 3.3865) |
| rover at rest | URDF on a plane, 1 s | base origin at 0.250 m = Module 2 `rest_height_m` |
| kinematics | v = 1, ω = 0.5 on a plane | 1.011 m/s, 0.4999 rad/s |
| route runs | `--fast`, full 529 m route | μ 1.0 / 0.3 / 0.15: RMS 0.046 / 0.045 / 0.207 m; max 0.661 / 0.638 / 1.101 m; odometry 1.68 / 3.10 / 143.3 m |
| other runs in the docs | `--speed 3`, `--nav odom`, cylinder wheels, no acceleration limits | see [03](../03_differential_drive.md), [04](../04_friction_and_slip.md), [05](../05_road_following.md) |
| off-road start | `--start=-10,-35,90` | rejoined the spur, cross-track −10 m → 0.06 m in 10 s |
| real-time pacing | `wall_s` vs `t_sim` in `summary.json` | 14.02 s wall for 14.02 s sim |
| fast mode speed | full route, `--fast` | 265 s of sim in 11.4 s of wall time |
| Godot ↔ Python end to end | `ugv_lab.tscn --autotest`, headless, sim started at (−40, −58) facing south | ~60 poses/s, not stale; manual `DIFF_DRIVE` into `box_2`; `contact.csv` first row at t = 6.07 s, normal (0, 1, 0); force < 5 N after 0.2 s; auto mode rejoined the road |
| pause / step / resume / reset | a Python stand-in viewer sending reliable commands | all ACKed; time frozen while paused; one STEP = +1/60 s; RESET flag on the next pose |
| rendering | `xvfb-run ... --rendering-driver opengl3`, `--shot=DIR@26` | `../img/ugv_chase.png`, `../img/ugv_fpv.png` |

## Not tested here

- Keyboard input by a human. The autotest calls `set_drive()` directly; the key mapping was read, not pressed.
- Windows and macOS.
