"""
plot_cross_track.py - Module 9: compare UGV runs (cross-track error and odometry drift).

    cd robosim
    python tools/plot_cross_track.py logs/*_ugv_mu1.0 logs/*_ugv_mu0.3 -o cross_track.png

For every run folder it reads run.json, control.csv and odom.csv, prints a table
(RMS / 95th percentile / max cross-track error, odometry error at the end) and draws:
  top    - cross-track error vs distance along the road
  bottom - odometry position error vs distance along the road
"""
import argparse, csv, json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

COLORS = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]       # fixed order: run 1, 2, 3, 4


def read_csv(path):
    with open(path) as f:
        rows = list(csv.DictReader(f))
    return {k: np.array([float(r[k]) if k != "mode" else 0.0 for r in rows]) for k in rows[0]}


def label_for(meta):
    return f"mu {meta.get('wheel_friction')}, nav {meta.get('nav')}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("runs", nargs="+", help="run folders under logs/")
    ap.add_argument("-o", "--out", default="cross_track.png")
    a = ap.parse_args()

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(9, 6.5), sharex=True)
    print(f"{'run':<34} {'label':<20} {'rms_m':>6} {'p95_m':>6} {'max_m':>6} {'odom_end_m':>10}")
    for i, run in enumerate(a.runs[:len(COLORS)]):
        meta = json.load(open(os.path.join(run, "run.json")))
        c = read_csv(os.path.join(run, "control.csv"))
        o = read_csv(os.path.join(run, "odom.csv"))
        auto = c["s"] > 1.0                                    # skip the first metre (initial alignment)
        cte = c["cte"][auto]
        lab = label_for(meta)
        print(f"{os.path.basename(run.rstrip('/')):<34} {lab:<20} {np.sqrt(np.mean(cte ** 2)):6.3f} "
              f"{np.percentile(np.abs(cte), 95):6.3f} {np.max(np.abs(cte)):6.3f} {o['pos_err'][-1]:10.2f}")
        ax1.plot(c["s"], c["cte"], color=COLORS[i], lw=1.5, label=lab)
        n = min(len(c["s"]), len(o["pos_err"]))              # a killed run may have uneven files
        ax2.plot(c["s"][:n], o["pos_err"][:n], color=COLORS[i], lw=1.5, label=lab)
    ax1.axhline(0, color="#9a9994", lw=0.8)
    ax1.set_ylabel("cross-track error (m)\n+ = left of road")
    ax2.set_ylabel("odometry position error (m)")
    ax2.set_xlabel("distance along road (m)")
    ax1.set_title("UGV road following: cross-track error and odometry drift", loc="left", fontsize=11)
    for ax in (ax1, ax2):
        ax.grid(True, color="#e4e3df", lw=0.6)
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
        ax.legend(frameon=False, fontsize=9)
    fig.tight_layout()
    fig.savefig(a.out, dpi=120)
    print("wrote", a.out)


if __name__ == "__main__":
    main()
