extends Node3D
## Module 9 viewer: the PyBullet rover (vehicle 1) on the Module 2 range.
##   - places Module 2's rover.tscn from POSE with the Module 5 render clock + SimBridge.sample()
##   - main view: chase or onboard (camera_next, C); FPV picture-in-picture from a Module 6
##     CameraRig on the rover's fpv_cam mount
##   - manual driving: M toggles; W/A/S/D or the arrow keys stream DIFF_DRIVE (cmd 11) at 50 Hz
##   - pause_toggle (P), N single step, reset (R): reliable commands, resent until ACKed
## Test options (after "--"):  --ports=9190,9191   --autotest   --shot=DIR@T   --quit-after=S

const VID := 1
const V_MAX := 2.0              ## m/s at full key
const W_MAX := 1.0              ## rad/s at full key; + = counter-clockwise (left)
const SEND_HZ := 50.0

@onready var bridge: SimBridge = $SimBridge
@onready var terrain: HeightmapTerrain = $Terrain
@onready var rover: Vehicle = $Rover
@onready var view_cam: Camera3D = $ViewCam
@onready var hud: Label = $UI/Hud
@onready var pip: TextureRect = $UI/Pip

var clock := RenderClock.new()
var onboard: CameraRig
var manual := false
var use_keys := true            ## the autotest switches this off and calls set_drive()
var drive := Vector2.ZERO       ## (v m/s, w rad/s) that manual mode streams
var paused := false             ## from the PAUSED flag of the newest pose
var poses_rx := 0
var _send_acc := 0.0
var _onboard_main := false
var _wheels: Array[Node3D] = []
var _spin := 0.0
var _last_pos := Vector3.INF
var _args := {}
var _t_wall := 0.0
var _shot_done := false


func _enter_tree() -> void:
	for a in OS.get_cmdline_user_args():
		var kv := a.trim_prefix("--").split("=", true, 1)
		_args[kv[0]] = kv[1] if kv.size() > 1 else ""
	if _args.has("ports"):                          # before SimBridge._ready binds the socket
		var p: PackedStringArray = _args.ports.split(",")
		$SimBridge.listen_port = int(p[0])
		$SimBridge.physics_port = int(p[1])


func _ready() -> void:
	onboard = CameraRig.new()                       # Module 6: own SubViewport + Camera3D
	onboard.camera_name = "fpv"
	onboard.mode = CameraRig.Mode.RIGID
	onboard.image_size = Vector2i(640, 360)
	onboard.fov_v_deg = 60.0
	rover.mount("fpv_cam").add_child(onboard)
	pip.texture = onboard.viewport.get_texture()
	for w in rover.get_node("Visual").get_children():
		if w.name.begins_with("Wheel_"):
			_wheels.append(w)
	bridge.pose_received.connect(func(_vid: int, msg: Dictionary) -> void:
		poses_rx += 1
		paused = (msg.flags & RsProtocol.POSE_FLAG_PAUSED) != 0
		clock.observe(msg.t_sim, Time.get_ticks_usec() / 1e6))
	bridge.physics_reset.connect(func() -> void: clock.reset())
	if _args.has("autotest") or _args.has("quit-after"):
		Engine.max_fps = 60
	if _args.has("autotest"):
		use_keys = false


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("camera_next"):
		_onboard_main = not _onboard_main
	elif event.is_action_pressed("pause_toggle"):
		bridge.send_command(VID, RsProtocol.CMD_RESUME if paused else RsProtocol.CMD_PAUSE)
	elif event.is_action_pressed("reset"):
		bridge.send_command(VID, RsProtocol.CMD_RESET)
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_M:
			manual = not manual
		elif event.keycode == KEY_N:
			bridge.send_command(VID, RsProtocol.CMD_STEP)


## The command manual mode streams. Also the hook for tests.
func set_drive(v: float, w: float) -> void:
	drive = Vector2(v, w)


func _process(delta: float) -> void:
	_t_wall += delta
	if manual and use_keys:
		var fwd := clampf(Input.get_axis("move_back", "move_forward") + Input.get_axis("ui_down", "ui_up"), -1, 1)
		var turn := clampf(Input.get_axis("move_right", "move_left") + Input.get_axis("ui_right", "ui_left"), -1, 1)
		set_drive(fwd * V_MAX, turn * W_MAX)      # left key = +w = counter-clockwise
	_send_acc += delta
	if manual and _send_acc >= 1.0 / SEND_HZ:
		_send_acc = 0.0
		bridge.send_command_unreliable(VID, RsProtocol.CMD_DIFF_DRIVE, [drive.x, drive.y])
	if bridge.has_vehicle(VID):
		var t := clock.advance(delta, bridge.latest_t_sim, paused)
		rover.global_transform = bridge.sample(VID, t)
		_spin_wheels()
		_update_view_cam(delta)
		onboard.sync_now()
	_update_hud()
	_test_hooks()


## Module 2's rover has four drawn wheels; spin them from the body's own motion
## (wheel speeds are not on the wire, and physics drives only the rear pair).
func _spin_wheels() -> void:
	var p := rover.global_position
	if _last_pos != Vector3.INF:
		_spin += (p - _last_pos).dot(-rover.global_basis.z) / 0.15     # wheel radius 0.15 m
	_last_pos = p
	for w in _wheels:
		w.rotation = Vector3(-_spin, 0.0, PI / 2)    # Rz turns the cylinder axis to X, Rx spins it


func _update_view_cam(delta: float) -> void:
	if _onboard_main:
		view_cam.global_transform = rover.mount("fpv_cam").global_transform
		return
	var t := rover.global_transform
	var back := t.basis.z
	back.y = 0.0
	var want := t.origin + back.normalized() * 5.0 + Vector3.UP * 2.2
	view_cam.global_position = view_cam.global_position.lerp(want, minf(1.0, delta * 3.0))
	view_cam.look_at(t.origin + Vector3.UP * 0.3, Vector3.UP)


func _update_hud() -> void:
	var s := "NO DATA FROM PHYSICS" if bridge.is_stale() else "t_sim %.2f s" % bridge.latest_t_sim
	if bridge.has_vehicle(VID):
		var p := rover.global_position
		var v: Vector3 = bridge.latest_transform(VID).origin
		s += "   ENU E %.1f N %.1f U %.1f   ground %.2f m" % [p.x, -p.z, p.y, terrain.height_at_world(v.x, v.z)]
	s += "\n%s%s   manual cmd v %.1f m/s  w %.2f rad/s" % ["MANUAL" if manual else "auto (road following)",
			"  PAUSED" if paused else "", drive.x, drive.y]
	s += "\n[M] manual  [WASD/arrows] drive  [C] camera  [P] pause  [N] step  [R] reset"
	hud.text = s


func _test_hooks() -> void:
	if _args.has("autotest"):                     # drive into whatever is ahead, then hand back
		manual = _t_wall < 8.0
		set_drive(1.0 if manual else 0.0, 0.0)
		if _t_wall > 14.0:
			var p := rover.global_position
			print("ugv_autotest: poses %d, stale %s, t_sim %.2f, rover ENU (%.2f, %.2f, %.2f)"
					% [poses_rx, bridge.is_stale(), bridge.latest_t_sim, p.x, -p.z, p.y])
			get_tree().quit()
	if _args.has("shot") and not _shot_done:
		var spec: PackedStringArray = _args.shot.split("@")
		if bridge.latest_t_sim >= float(spec[1]):
			_shot_done = true
			_save_shots(spec[0])
	if _args.has("quit-after") and _t_wall > float(_args["quit-after"]):
		get_tree().quit()


func _save_shots(dir: String) -> void:
	DirAccess.make_dir_recursive_absolute(dir)
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(dir.path_join("ugv_chase.png"))
	onboard.viewport.get_texture().get_image().save_png(dir.path_join("ugv_fpv.png"))
	print("saved shots at t_sim %.2f" % bridge.latest_t_sim)
