# 03 Differential drive: kinematics and wheel motors

A differential-drive rover has two driven wheels on one axle and one or more passive supports (casters). It steers by driving the wheels at different speeds. It is the simplest ground robot that can still follow any smooth path. Most indoor robots and many small field rovers work this way.

## The course rover

The physics model must match what Godot draws. So the URDF takes its dimensions from Module 2's `rover.tscn`: a 0.9 m × 0.6 m × 0.2 m chassis, wheels of radius 0.15 m, and the origin 0.25 m above the ground (`rest_height_m`). Module 2 drew four wheels. Physics drives the **rear pair** and replaces the front pair with one frictionless caster at the front axle. The front wheels in Godot are visual only.

```
          top view (FLU body frame)                     side view
                 +x forward
                   ▲                             chassis 0.90 x 0.60 x 0.20 m, origin at its center
          ┌────────┼────────┐                   ┌──────────────────┐
          │        ●        │  caster r 0.10     │        ·         │
          │                 │  at (0.30, 0)      └─○──────────────●─┘
   +y ◀───┤                 │                     caster          wheel r 0.15
   left   │█               █│  wheels at x = -0.30   all contact points 0.25 m below the origin
          └─────────────────┘  y = ±0.36 (track 0.72)
```

| Part | Value | URDF |
|---|---|---|
| chassis | 10 kg, 0.90 × 0.60 × 0.20 m | `base_link` box |
| wheels | 0.8 kg each, r = 0.15 m, at (−0.30, ±0.36, −0.10) | `continuous` joints, axis (0, 1, 0) |
| caster | frictionless ball, r = 0.10 m, at (0.30, 0, −0.15) | `fixed` joint; friction set to 0 in Python |

Three contact points (two wheels and one caster) always touch the ground. Four points could rock on uneven terrain and leave a drive wheel in the air. The caster is a separate link, not part of `base_link`, so a contact on link −1 can only mean "the chassis hit something" (page 06). With the center of mass halfway between the axle and the caster, the drive wheels carry about half the weight. That matters for traction (page 04).

## Kinematics: (v, ω) ↔ wheel speeds

Treat the rover as a **unicycle**: forward speed v (m/s) along body x, and yaw rate ω (rad/s, positive counter-clockwise seen from above, i.e. about +z in ENU/FLU). With wheel radius r and track b (the distance between the wheel contact points):

```
 inverse (what we command)            forward (what odometry uses)
 ω_L = (v − ω·b/2) / r                v = r (ω_R + ω_L) / 2
 ω_R = (v + ω·b/2) / r                ω = r (ω_R − ω_L) / b
```

The left wheel is on the inside of a left turn, so it slows down. This comes straight from rigid-body motion: a point at lateral offset y moves at v − ω·y, and the left wheel has y = +b/2.

```python
WHEEL_R, TRACK = 0.15, 0.72

def wheel_speeds(v, w):
    """Unicycle (v m/s, w rad/s) -> wheel joint speeds (rad/s)."""
    return (v - w * TRACK / 2) / WHEEL_R, (v + w * TRACK / 2) / WHEEL_R
```

### Check the sign of the wheel axis

Both wheel joints rotate about +y (left). Does a **positive** joint speed roll the rover **forward**? Use the right-hand rule. Rotating about +y carries +z (the top of the wheel) toward +x, and the bottom toward −x. The contact point pushes the ground backward, so the rover goes forward. Yes. If a URDF from elsewhere has its axis along −y, flip the sign of that wheel's command. Do **not** flip the kinematics.

Verified on a flat plane, v = 1 m/s and ω = 0.5 rad/s commanded for 6 s: measured 1.011 m/s and 0.4999 rad/s. The wheel speeds were 5.467 and 7.866 rad/s, against 5.467 and 7.867 from the formulas.

## Wheel motors: `VELOCITY_CONTROL`

PyBullet joint motors are **constraints**. You give a target and a limit, and the solver finds the torque:

```python
for j, w in ((LEFT, wl), (RIGHT, wr)):
    p.setJointMotorControl2(rover, j, p.VELOCITY_CONTROL,
                            targetVelocity=w,         # rad/s
                            force=MAX_TORQUE)         # N m: the MOST the motor may use
```

| Mode | You set | PyBullet solves for | Use it for |
|---|---|---|---|
| `VELOCITY_CONTROL` | target ω, max torque | the torque (up to the max) that reaches ω this step | wheels, like an ESC in speed mode |
| `POSITION_CONTROL` | target angle, gains, max torque | torque from a PD law | arms, steering servos |
| `TORQUE_CONTROL` | torque | nothing; you apply it | your own motor model. Disable the default motor first with VELOCITY_CONTROL and force 0. |

`force=` is a **limit**, not an applied value. The motor uses only what it needs: on flat ground at a steady 1 m/s, the joint reported 0.09 N·m of applied torque with an 8 N·m limit. When the limit is too low, the rover just accelerates slowly. With 0.5 N·m it reached 0.51 m/s after 1 s, instead of 1.0 m/s.

### Sizing the torque limit

The steepest 5 m of the route has an 8.4 % grade (where the spur leaves the flat apron). Climbing it at constant speed needs

```
F = m g sin(atan 0.084) = 11.8 kg · 9.81 · 0.084 ≈ 9.7 N    →    τ_total = F r ≈ 1.5 N m
```

Accelerating at 1 m/s² on that slope adds another 11.8 N, for about 3.2 N·m in total. The lab uses 8 N·m **per wheel**. That is generous on purpose: in this lab the motor limit should never be what stops the rover. Page 04 shows that **friction** is the real limit.

## Acceleration limits: give the command a slew rate

A velocity motor reaches its target almost in one step if torque allows. Commanding 0 → 2 m/s at once asks for an acceleration that only friction can refuse. Real motor drivers have a "ramp" or "acceleration limit" parameter for this. The lab rate-limits the command at 60 Hz:

```python
A_MAX, ALPHA_MAX = 1.0, 3.0          # m/s^2, rad/s^2
dt_c = 1 / 60                        # control period
v_cmd += clamp(v_target - v_cmd, -A_MAX * dt_c, A_MAX * dt_c)
w_cmd += clamp(w_target - w_cmd, -ALPHA_MAX * dt_c, ALPHA_MAX * dt_c)
```

Does it matter here? We measured it, and on this route the answer is: hardly. Without the limits, the end-of-route odometry error was 1.85 m instead of 1.68 m at μ = 1.0, and 2.96 m instead of 3.10 m at μ = 0.3. The start is on the flat apron, and 1 m/s² is well inside the grip. The limit starts to matter when the requested acceleration exceeds what the tires can transmit, roughly μ·g·(the drive wheels' share of the weight). Keep it anyway: it is cheap and it protects the hardware you will drive later.

## Try it

- On a flat plane, command v = 0, ω = 1 rad/s (turn in place) for 3 s. Compare the yaw rate from `getBaseVelocity` with r(ω_R − ω_L)/b. Where does the caster go?
- Set the torque limit to 0.5 N·m and run the route (`--max-torque 0.5 --fast`). Where does the rover fall behind, and does it finish?
- Compute the traction limit μ·g·0.5 for μ = 1.0, 0.3 and 0.15. Which of them is below `A_MAX`? Check your prediction against page 04.
- Derive v and ω from two given wheel speeds by hand, for ω_L = 5 and ω_R = 10 rad/s, and check with the formulas.

## References

- K. M. Lynch and F. C. Park, *Modern Robotics*, section 13.3 (wheeled mobile robots): <http://hades.mech.northwestern.edu/index.php/Modern_Robotics>
- PyBullet Quickstart Guide, `setJointMotorControl2`: <https://docs.google.com/document/d/10sXEhzFRSnvFcl3XxNGhnD4N2SedqwdAvK3dsihxVUA>
- [Module 2](../m02_scene_assets/README.md), page 05 (the rover model and its `rest_height_m`)
