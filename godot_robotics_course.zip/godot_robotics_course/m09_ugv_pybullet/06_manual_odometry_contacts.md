# 06 Manual driving, wheel odometry, collision feedback

Three small features turn the road follower into a usable test vehicle. You can drive it by hand from Godot. It has a realistic **drifting** position sensor next to the ground truth. And it notices when it hits something. Each one raises an ownership question, and this page answers those too.

## Manual mode: `DIFF_DRIVE` (cmd 11) from Godot

The protocol has a command for this ([protocol](../reference/protocol.md)): `DIFF_DRIVE`, args `v m/s, ω rad/s`. Keyboard input is **stick-style**: it is sent continuously and the newest value wins. So it uses the unreliable path at 50 Hz, never the resend-until-ACK path.

The UGV scene reuses Module 2's input actions (`move_forward` = W, `move_back` = S, `move_left` = A, `move_right` = D) and adds the arrow keys:

```gdscript
# scenes/ugv_lab.gd (excerpt)
const V_MAX := 2.0              ## m/s at full key
const W_MAX := 1.0              ## rad/s at full key; + = counter-clockwise (left)
const SEND_HZ := 50.0

func _process(delta: float) -> void:
	if manual and use_keys:
		var fwd := clampf(Input.get_axis("move_back", "move_forward") + Input.get_axis("ui_down", "ui_up"), -1, 1)
		var turn := clampf(Input.get_axis("move_right", "move_left") + Input.get_axis("ui_right", "ui_left"), -1, 1)
		set_drive(fwd * V_MAX, turn * W_MAX)      # left key = +w = counter-clockwise
	_send_acc += delta
	if manual and _send_acc >= 1.0 / SEND_HZ:
		_send_acc = 0.0
		bridge.send_command_unreliable(VID, RsProtocol.CMD_DIFF_DRIVE, [drive.x, drive.y])
```

Note the sign: **left = positive ω**. ω is a counter-clockwise yaw rate about +z (ENU up = Godot +Y). If your rover turns the wrong way, fix it here, at the input mapping. Never flip it inside the kinematics.

On the physics side there is no "mode" command. The rule is:

> Any `DIFF_DRIVE` received in the last **0.3 s of sim time** overrides the road controller. When the stream stops, the controller takes over again.

```python
if c == P.CMD_DIFF_DRIVE:
    self.manual = (msg["args"][0], msg["args"][1])
    self.manual_until = self.t + MANUAL_TIMEOUT_S        # 0.3 s dead-man timeout
...
if self.t < self.manual_until:
    v, w = self.manual
    mode = "manual"
    self.pp.lost()                                       # re-find the road when auto resumes
```

| Design question | Answer | Why |
|---|---|---|
| reliable or unreliable? | unreliable, 50 Hz | a resent old stick value is worse than a lost one |
| what if Godot freezes? | the rover stops obeying after 0.3 s and drives on by itself | a dead-man timeout, the same idea as a radio failsafe |
| timeout in sim or wall time? | sim time | consistent with pause and step; in real-time mode they are the same |
| do the acceleration limits apply? | yes | a keyboard is a step input; the ramp protects grip and odometry |

## Wheel odometry: a sensor that drifts

Wheel odometry integrates the wheel encoders. It needs no outside reference, so it never jumps, but its error grows without bound. In this lab it runs on the physics side at the full 240 Hz from the joint velocities. By the sensor ownership rule ("would the reading change if I moved a wall?" No.) it belongs to physics.

```python
wl_m = p.getJointState(rover, LEFT)[1]          # rad/s: the "encoder"
wr_m = p.getJointState(rover, RIGHT)[1]
v = WHEEL_R * (wl_m + wr_m) / 2
w = WHEEL_R * (wr_m - wl_m) / TRACK
th = odom[2] + 0.5 * w * dt                      # midpoint heading: second-order accurate
odom += [v * cos(th) * dt, v * sin(th) * dt, w * dt]
```

It starts at the true pose and is never corrected. The logs keep truth and measurement in **separate columns** ([logging rule 2](../reference/logging.md)):

```
odom.csv: t_sim, t_wall, x_true, y_true, yaw_true_deg, x_odom, y_odom, yaw_odom_deg, pos_err, wl_enc, wr_enc
```

### Where the drift comes from

| Source | Effect | Present in the lab? |
|---|---|---|
| longitudinal slip (spin, skid) | distance error | yes, at low μ |
| lateral slip (sliding in turns) | heading error | yes: the dominant term at μ = 0.15 |
| heading error | grows into a position error ∝ distance | yes |
| 2D model on 3D terrain | overestimates horizontal distance by 1 − cos(slope): 0.35 % on an 8.4 % grade | yes, small on these roads |
| wrong wheel radius or track in the model | scale and turn-rate error | no (exact here; add it as an exercise) |
| encoder noise and quantization | random walk | no (add it with [Module 8](../m08_sensors/README.md)) |

Measured end-of-route position error on the 529 m route: **1.7 m** at μ = 1.0 (0.3 % of the distance), **3.1 m** at μ = 0.3 and **143 m** at μ = 0.15. The low-friction number comes from the slide in the first turn (page 04).

## Collision feedback

Contacts are part of the dynamics, so PyBullet computes them and they belong to the physics owner. `pybullet_world.add_range_objects()` puts Module 2's boxes, poles and gates into the PyBullet world, exactly where Godot draws them. Every control tick, the sim asks for contacts on the **chassis** only. The wheels and the caster touch the ground all the time, and they are separate links:

```python
for c in p.getContactPoints(bodyA=rover, linkIndexA=-1):     # -1 = base link = chassis
    other, normal_on_b, f = c[2], c[7], c[9]
    if f <= 0.0:
        continue                                             # touching, but no force
    if other in obstacles:
        log.write("contact", t_sim=t, other=obstacles[other], normal_force_n=f,
                  nx=normal_on_b[0], ny=normal_on_b[1], nz=normal_on_b[2])
```

| Field | Index | Meaning |
|---|---|---|
| `bodyUniqueIdB` | 2 | what we hit |
| `positionOnA/B` | 5, 6 | contact points, world frame |
| `contactNormalOnB` | 7 | unit normal, world frame (ENU), pointing from B toward A |
| `contactDistance` | 8 | negative = penetration (m) |
| `normalForce` | 9 | N, over the last step |

**What the rover does with it:** a bumper. If the obstacle force is above 1 N, forward speed is clamped to ≤ 0 for 0.5 s, **bypassing** the acceleration ramp. A bumper that ramps down at 1 m/s² keeps pushing for a whole second. Our first version did exactly that and logged about 90 N of steady push after the impact.

Reference test: drive south into `box_2` at 1 m/s (start `--start=-40,-58,-90`). First contact came at t = 6.07 s, with normal (0, 1, 0): the box's north face, pointing back at the rover. In the impact step, the contact points summed to 1.8–2.8 kN, depending on the run. That is a one-step impulse spike (11.8 kg stopped from 1 m/s within a few steps), not a sustained force. Within 0.2 s the force fell below 5 N. When manual input ended, the controller turned the rover around in a tight arc (the behind-target fallback of page 05) and drove back to the road.

### Does Godot need to know?

The bridge has no physics → viewer contact message. You have three honest options:

| Option | Fits the rules? | Note |
|---|---|---|
| keep contacts in the physics log only | yes | what the lab does; plots and tests read `contact.csv` |
| show a hit in Godot with its own `Area3D` around the rover | yes, as a **visual** cue | that is Module 8's contact *sensor*. It sees only what Godot draws, and it can disagree with physics by a frame. |
| send contacts as a new physics → viewer message | yes, by adding a message type ([protocol](../reference/protocol.md), "Changing the protocol") | Module 10 uses the TELEMETRY extension (type 100) for motor outputs; a contact code would fit there too |

The ownership rule decides who owns the **response**: physics, always. A Godot `Area3D` overlap must never push the rover.

## Try it

- Drive into `box_1` at 0.5, 1 and 2 m/s. Plot the peak summed `normal_force_n` against speed. Why does a 240 Hz step make the peak so large?
- Add a 2 % wheel-radius error to the odometry model only (use 0.153 in the odometry formula). How much does the end error grow at μ = 1.0?
- Add Gaussian noise (σ = 0.05 rad/s) to `wl_m` and `wr_m`. Seed it, and record the seed in `run.json` by passing `seed=` to `RunLogger`.
- Make manual mode reliable on purpose: send `DIFF_DRIVE` with `send_command` (ACKed and resent). Hold a key and watch `bridge.pending_commands()`. Why is this a bad idea?

## References

- [Protocol](../reference/protocol.md) (commands, reliability), [logging](../reference/logging.md)
- Godot `Input.get_axis`: <https://docs.godotengine.org/en/stable/classes/class_input.html>
- PyBullet Quickstart Guide, `getContactPoints`: <https://docs.google.com/document/d/10sXEhzFRSnvFcl3XxNGhnD4N2SedqwdAvK3dsihxVUA>
- S. Thrun, W. Burgard, D. Fox, *Probabilistic Robotics*, ch. 5.4 (odometry motion model)
