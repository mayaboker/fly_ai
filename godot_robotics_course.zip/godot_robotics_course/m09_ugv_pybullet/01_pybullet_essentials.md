# 01 PyBullet essentials for this course

PyBullet is a Python wrapper around the Bullet physics engine. In this course it is the **physics owner** for ground robots and, in Module 10, for one of the two quadcopter options. Godot never simulates the rover. It only draws the poses that PyBullet sends. This page covers the small part of PyBullet you need, and the defaults that cause most beginner bugs.

## Why DIRECT mode

PyBullet can open its own OpenGL window (`p.GUI`) or run without one (`p.DIRECT`).

| Mode | Window | Use it for |
|---|---|---|
| `p.DIRECT` | none | everything in this course: Godot is the viewer |
| `p.GUI` | PyBullet's debug viewer | a quick look while debugging a URDF |
| `p.SHARED_MEMORY` / `p.GUI_SERVER` | shared | not needed here |

We always use DIRECT. Two windows that both claim to show "the" robot only cause confusion. DIRECT also runs headless on a server or in CI. When you need to see a URDF quickly, switch to GUI for one run, then switch back.

```python
import pybullet as p
p.connect(p.DIRECT)          # returns a client id; one physics world per connection
```

## Fixed time step, stepped by you

PyBullet has no clock of its own. The world advances exactly `timeStep` seconds each time you call `stepSimulation()`. That is what we want: **the physics process owns simulation time** (Module 5).

```python
PHYSICS_HZ = 240.0
p.setTimeStep(1.0 / PHYSICS_HZ)          # 240 Hz is PyBullet's default and a good choice
p.setGravity(0, 0, -9.81)                # ENU: z is up, so gravity is -z
t = 0.0
for k in range(N):
    apply_commands()                     # motor targets, external forces...
    p.stepSimulation()
    t += 1.0 / PHYSICS_HZ                # count sim time yourself
```

Never call `p.setRealTimeSimulation(1)`. It steps the world on PyBullet's own wall-clock thread. Then you cannot log exact sim times, pause, single-step or replay.

**Rates in the UGV lab:**

| Loop | Rate | Why |
|---|---|---|
| physics step | 240 Hz | contact stability with 0.15 m wheels on a 1 m terrain grid |
| controller, pose to Godot, logs | 60 Hz (every 4th step) | the road controller needs nothing faster; 60 Hz matches the pose stream |
| Godot render | whatever the screen does | decoupled by interpolation (Module 5) |

Real-time pacing is optional. In `--fast` mode the script never sleeps. On the 2-core test machine, the 265 s route took 11.3 s of wall time, about 23× real time. With Godot attached, the script sleeps so that sim time tracks wall time.

## Bodies: URDF or `createMultiBody`

| | URDF (`p.loadURDF`) | `p.createMultiBody` |
|---|---|---|
| Good for | articulated robots: wheels, arms, joints | single rigid bodies: terrain, boxes, a quad frame |
| Joints | yes, named, with axes and limits | possible, but clumsy (link arrays) |
| Readable by other tools | yes (ROS, RViz, Gazebo) | no |
| Used in this course for | the rover (`physics/assets/rover.urdf`) | the heightfield, obstacles, the Module 10 quad |

A minimal rigid body:

```python
col = p.createCollisionShape(p.GEOM_BOX, halfExtents=[0.45, 0.3, 0.1])     # HALF sizes
body = p.createMultiBody(baseMass=10.0, baseCollisionShapeIndex=col,
                         basePosition=[0, 0, 1.0])                         # mass 0 = static
```

Note `halfExtents`. A 0.9 m box has half-extent 0.45. This is a classic factor-of-two bug.

## Units and frames

PyBullet itself has no units. It is consistent if *you* are consistent. The course uses SI throughout: m, kg, s, N, N·m, rad. PyBullet's world in this course is **ENU** (x east, y north, z up). Its bodies are **FLU** (x forward, y left, z up), as in ROS. The conversion to Godot happens once, in Python, with `robosim.frames.enu_flu_to_godot` ([frames](../reference/frames.md)).

| Call | Returns | Watch out |
|---|---|---|
| `getBasePositionAndOrientation(b)` | position, quaternion **(x, y, z, w)** | the base frame is the URDF base link origin, not the center of mass, unless they coincide |
| `getBaseVelocity(b)` | linear, angular velocity, **world frame** | rotate the angular velocity with Rᵀ to get body rates |
| `getEulerFromQuaternion(q)` | roll, pitch, yaw about fixed x, y, z | fine for logs; never send Euler angles over the wire |
| `getJointState(b, j)` | position, **velocity**, reaction forces, applied torque | velocity is the "encoder" we use for odometry |

## Defaults that bite

| Default | Effect | What we do |
|---|---|---|
| `loadURDF` recomputes inertia from the collision shapes | your `<inertia>` tags are ignored | pass `flags=p.URDF_USE_INERTIA_FROM_FILE` |
| bodies get `linearDamping` = `angularDamping` = 0.04 | a free body slowly loses speed by itself | set them to 0 when you model drag yourself (Module 10 measured the difference) |
| revolute joints start with a weak velocity motor | an unpowered wheel acts like a brake | always call `setJointMotorControl2` on every driven joint |
| external forces are cleared after each `stepSimulation()` | a force applied once acts for one step only | re-apply every step (Module 10) |
| friction is combined by multiplying the two bodies' coefficients | μ_wheel = 0.3 on μ_ground = 1.0 → 0.3; on μ_ground = 0.5 → 0.15 | set the terrain to 1.0 and vary the wheel only |

## Code: the smallest useful PyBullet world

```python
import pybullet as p

p.connect(p.DIRECT)
p.setGravity(0, 0, -9.81)
p.setTimeStep(1 / 240)
plane = p.createMultiBody(0, p.createCollisionShape(p.GEOM_PLANE))
rover = p.loadURDF("physics/assets/rover.urdf", [0, 0, 0.27],
                   flags=p.URDF_USE_INERTIA_FROM_FILE)
for j in range(p.getNumJoints(rover)):
    info = p.getJointInfo(rover, j)
    print(j, info[1].decode(), "type", info[2], "axis", info[13])
for _ in range(240):                     # one second
    p.stepSimulation()
print(p.getBasePositionAndOrientation(rover))
```

Expected joint list for the course rover:

```
0 left_wheel_joint type 0 axis (0.0, 1.0, 0.0)
1 right_wheel_joint type 0 axis (0.0, 1.0, 0.0)
2 caster_joint type 4 axis (0.0, 0.0, 0.0)
```

Type 0 is `JOINT_REVOLUTE` (URDF `continuous` becomes revolute without limits). Type 4 is `JOINT_FIXED`. The link index of a joint's child equals the joint index. So `changeDynamics(rover, 0, ...)` changes the left wheel, and `-1` means the base.

## Try it

- Run the snippet above and print the base height after one second. Explain why it is 0.25 m: the wheel and caster bottoms sit 0.25 m below the base origin, exactly like Module 2's `rest_height_m` for the rover.
- Load the URDF with and without `URDF_USE_INERTIA_FROM_FILE` and print `p.getDynamicsInfo(rover, -1)[2]` (the local inertia diagonal) both times. The course URDF uses the solid-box formula, so the two agree (0.333 vs 0.3333). Now change `ixx` in the URDF to 1.0 and repeat. Only the flag makes PyBullet use your number.
- Check the friction rule. Put a box with μ = 0.6 on a 20° slope with μ = 0.5. Product (0.30 < tan 20° = 0.36): it slides. Minimum (0.5): it would stick. In our test it slid at about 0.55 m/s².
- Replace `p.DIRECT` with `p.GUI` once, look at the rover, then switch back.
- Time 10 000 `stepSimulation()` calls with `time.perf_counter()` on a plane, and later on the heightfield (next page). Write down your steps per second.

## References

- PyBullet Quickstart Guide (official): <https://docs.google.com/document/d/10sXEhzFRSnvFcl3XxNGhnD4N2SedqwdAvK3dsihxVUA>
- URDF XML specification: <https://wiki.ros.org/urdf/XML>
- [Frames cheat sheet](../reference/frames.md), [Module 5: time and rates](../m05_time_rates/README.md)
