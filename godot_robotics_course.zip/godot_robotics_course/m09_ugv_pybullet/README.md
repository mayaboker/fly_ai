# Module 9: PyBullet UGV lab (9 h)

## What you will build

A two-wheel differential-drive rover (vehicle id 1) in PyBullet. It drives on the same heightmap that Godot draws and follows the Module 2 road from its parking spot, down the spur and once around the loop. Godot shows Module 2's rover model with a chase view and an FPV picture-in-picture. You can take over from the keyboard with `DIFF_DRIVE` commands. Every run is logged, so you can compare high- and low-friction runs, and wheel odometry against ground truth.

## Prerequisites

- Modules 1–8, in particular:
  - [Module 2](../m02_scene_assets/README.md): `heightmap.png`, `range.json`, `robosim/terrain.py`, `HeightmapTerrain`, `RangeBuilder`, `rover.tscn`
  - [Module 3](../m03_frames/README.md): frame adapters
  - [Module 4](../m04_bridge/README.md): the bridge
  - [Module 5](../m05_time_rates/README.md): `RenderClock` and the log format
  - [Module 6](../m06_cameras/README.md): `CameraRig`
- Python: PyBullet 3.2.x, numpy, matplotlib (Pillow comes with matplotlib).
- Reference pages: [frames](../reference/frames.md), [protocol](../reference/protocol.md), [logging](../reference/logging.md), [terrain](../reference/terrain.md).

## Sub-topics

| File | Topic | Time |
|---|---|---:|
| [01_pybullet_essentials.md](01_pybullet_essentials.md) | DIRECT mode, fixed time step, URDF vs `createMultiBody`, units, the defaults that bite | 1 h |
| [02_heightfield_terrain.md](02_heightfield_terrain.md) | The shared heightmap as `GEOM_HEIGHTFIELD`: centering, `meshScale`, row order, and the three-point cross-check | 1.25 h |
| [03_differential_drive.md](03_differential_drive.md) | Unicycle kinematics, wheel joints with `VELOCITY_CONTROL`, torque and acceleration limits | 1 h |
| [04_friction_and_slip.md](04_friction_and_slip.md) | `lateralFriction`, rolling friction, how Bullet combines friction, wheel shape, slip | 1 h |
| [05_road_following.md](05_road_following.md) | The road from `range.json` as a route, cross-track error, pure pursuit (and Stanley for comparison) | 1.25 h |
| [06_manual_odometry_contacts.md](06_manual_odometry_contacts.md) | `DIFF_DRIVE` from Godot, wheel odometry as a drifting sensor, collision feedback | 1 h |
| [lab.md](lab.md) | Build it: `ugv_pybullet.py`, the Godot UGV scene, logs, `plot_cross_track.py` | 2.5 h |

## Deliverables

- `physics/robosim/pybullet_world.py`: the Module 2 range in PyBullet: heightfield, obstacles and gates. Module 10 reuses it.
- `physics/tests/test_heightfield.py`: PyBullet heightfield vs the Python sampler at Module 2's three points.
- `physics/assets/rover.urdf` and `physics/sims/ugv_pybullet.py`.
- `godot/scenes/ugv_lab.tscn`: terrain, range, rover, chase and FPV views, manual driving.
- `tools/plot_cross_track.py` and one plot comparing high- and low-friction runs.

## Check

All numbers below come from the reference code on Module 2's terrain (seed 42).

1. **Heightfield agreement.** `python tests/test_heightfield.py` prints PASS. At each of Module 2's three points, |PyBullet ray − Python bilinear| must be ≤ one height step (20 m / 65535 = 0.3 mm), plus that cell's two-triangle bound, plus 1 mm. Reference: 0.29, 0.40 and 0.14 mm against tolerances of 1.92, 2.30 and 1.69 mm. With Module 2's Godot result, the three engines agree: Python 0.6476 / 2.7400 / 3.3864 m, PyBullet 0.6473 / 2.7396 / 3.3865 m, Godot raycast 0.6479 / 2.7403 / 3.3860 m.
2. **Road following, high friction (μ = 1.0).** The rover finishes the 529 m route. Cross-track RMS ≤ 0.10 m and max ≤ 1.0 m. Reference: RMS 0.046 m, max 0.661 m (at the T-junction), 265 s of sim time.
3. **Low friction, same plot.** Run μ = 0.15. It must also finish. Report RMS, max and the end-of-route odometry error for both runs in one plot. Reference: μ = 0.15 gave RMS 0.207 m and max 1.10 m. Odometry error at the end was 1.7 m at μ = 1.0 and 143 m at μ = 0.15. (μ = 0.3 is almost indistinguishable from μ = 1.0 on these gentle roads: RMS 0.045 m, odometry 3.1 m.)
4. **Manual mode and contact.** In Godot, press M and drive into an obstacle. The physics log `contact.csv` records the hit with a normal force above 1 N, and the rover stops pushing (bumper). Press M again, and auto mode finds the road. Reference: driving south into `box_2` at 1 m/s, first contact at t = 6.07 s, with normal (0, 1, 0), i.e. the box's north face.
5. **Rates.** Godot receives poses at 60 Hz and never reports "NO DATA FROM PHYSICS" while physics runs in real time. Reference: 833 poses in about 14 s, not stale.

## Common mistakes

- Placing the heightfield body at z = 0. PyBullet centers the shape vertically on (min + max)/2. On the Module 2 map every height comes out 9.48 m low.
- Feeding PNG rows straight into `heightfieldData`. Row 0 of the PNG is **north**, but PyBullet's second index grows toward **+y = north**. Without the flip, the map is mirrored north–south. On Module 2's three points the error was 0.6–1.7 m. The flat center hides most of it, so test points with relief.
- Using cylinder collision shapes for wheels on a heightfield. The contacts jitter, the wheels slip and odometry becomes useless: 69.5 m of error on the route, against 1.7 m with sphere wheels.
- Forgetting that `force=` in `setJointMotorControl2(..., VELOCITY_CONTROL)` is the **maximum** motor torque. It is not a force you apply.
- Testing pure pursuit only from a pose on the road. With the target behind the rover, κ = 2y/L² is almost zero, and the rover drives away from the road.
- Treating the physics contact as a Godot sensor. The contact *response* belongs to the physics owner. A Godot contact sensor (Module 8) only sees what Godot draws.
