# Module 9 lab: a PyBullet rover on the Module 2 range

You will add a differential-drive rover to `robosim/`. PyBullet owns its dynamics on the shared terrain and follows the Module 2 road. Godot shows Module 2's rover model on Module 2's range, lets you drive it, and records nothing it does not own. At the end you measure the Check: heightfield agreement, and cross-track error at high and low friction.

Time: about 2.5 h after the sub-topics.

## Files added or changed

| Path in `robosim/` | New / changed | From |
|---|---|---|
| `physics/robosim/pybullet_world.py` | **new** shared helper: heightfield, range obstacles and gates in PyBullet (Module 10 reuses it) | [code/physics/robosim/pybullet_world.py](code/physics/robosim/pybullet_world.py) |
| `physics/tests/test_heightfield.py` | new | [code/physics/tests/test_heightfield.py](code/physics/tests/test_heightfield.py) |
| `physics/assets/rover.urdf` | new folder + file | [code/physics/assets/rover.urdf](code/physics/assets/rover.urdf) |
| `physics/sims/ugv_pybullet.py` | new | [code/physics/sims/ugv_pybullet.py](code/physics/sims/ugv_pybullet.py) |
| `tools/plot_cross_track.py` | new | [code/tools/plot_cross_track.py](code/tools/plot_cross_track.py) |
| `godot/scenes/ugv_lab.tscn`, `ugv_lab.gd` | new | [code/godot/scenes/](code/godot/scenes/ugv_lab.gd) |

Everything else comes from earlier modules and does not change:

| Used | From |
|---|---|
| `data/terrain/heightmap.png`, `heightmap.json`, `range.json`; `physics/robosim/terrain.py`; `godot/terrain/heightmap_terrain.gd`, `png16.gd`; `godot/world/range_builder.gd`; `godot/vehicles/rover.tscn`, `vehicle.gd`; the input actions in `project.godot` | Module 2 |
| `physics/robosim/bridge.py`, `godot/bridge/sim_bridge.gd` | Module 4 |
| `godot/bridge/render_clock.gd` | Module 5 |
| `godot/cameras/camera_rig.gd` | Module 6 |

## Step 0: the range exists

```bash
cd ~/robosim
ls data/terrain/                    # heightmap.json  heightmap.png  range.json   (Module 2)
python -c "import json; print([r['name'] for r in json.load(open('data/terrain/range.json'))['roads']])"
# ['loop', 'spur']
```

If they are missing, run Module 2's generator: `python tools/make_heightmap.py` (seed 42). All numbers in this lab come from that seed.

## Step 1: the PyBullet heightfield and its check

1. Copy `pybullet_world.py` into `physics/robosim/` and `test_heightfield.py` into `physics/tests/`.
2. Run the check:

   ```bash
   cd physics
   python tests/test_heightfield.py
   ```

   Expected:

   ```
   terrain AABB x -128.0..128.0  y -128.0..128.0  z -0.00..18.96
      east   north  python_m pybullet_m  diff_mm  tol_mm
     37.30  -12.60    0.6476     0.6473     0.29    1.92  OK
    -55.50   41.20    2.7400     2.7396     0.40    2.30  OK
    101.70  -88.30    3.3864     3.3865     0.14    1.69  OK
   2000 random points: median 0.15 mm, 99th pct 2.48 mm, max 105.16 mm; outside their own tolerance: 0
   heightfield check: PASS
   ```

3. Compare with your Module 2 result from `tools/compare_heights.py`. On the same three points, Godot's raycast gave 0.6479 / 2.7403 / 3.3860 m. If PyBullet fails, compare your errors with the "classic mistakes" table in [02](02_heightfield_terrain.md).

## Step 2: the rover URDF

Copy `rover.urdf` to `physics/assets/`. Read it against [03](03_differential_drive.md) and check:

- chassis 0.90 × 0.60 × 0.20 m, origin 0.25 m above the wheel bottoms (Module 2's `rest_height_m`)
- wheel joints `continuous` with axis `0 1 0`, at x = −0.30 (the rear pair), r = 0.15 m
- wheel collision shapes are **spheres** ([04](04_friction_and_slip.md) explains why)
- the caster is its own link on a `fixed` joint, at the front axle

## Step 3: the simulation script

Copy `ugv_pybullet.py` to `physics/sims/`. Its structure:

```
UgvSim.__init__   connect DIRECT, 240 Hz, gravity; heightfield + range objects (pybullet_world);
                  route from range.json (lineup -> spur -> loop lap -> junction); rover URDF;
                  friction per link; PhysicsBridge; RunLogger with all parameters in run.json
step_physics()    240 Hz: wheel VELOCITY_CONTROL -> stepSimulation -> wheel odometry
control_tick()    60 Hz: poll commands (DIFF_DRIVE, PAUSE/RESUME/STEP/RESET)
                         -> pure pursuit (or manual) -> bumper -> acceleration limits
                         -> send_pose (ENU/FLU converted ONCE with enu_flu_to_godot)
                         -> log pose.csv, odom.csv, control.csv (+ contact.csv on hits)
run()             wait for HELLO (unless --fast/--no-wait), pace to the wall clock (unless --fast),
                  stop at the route end, or when stuck for 30 s; write summary.json
```

Run it once without Godot:

```bash
python sims/ugv_pybullet.py --fast --run-name ugv_mu1.0
# ugv summary: {'end': 'road end', 't_sim': 265.43, 'wall_s': 11.39, 'cte_rms_m': 0.046,
#               'cte_max_m': 0.661, 'odom_err_end_m': 1.68}
```

| Option | Default | Meaning |
|---|---|---|
| `--friction` | 1.0 | wheel `lateralFriction` (the terrain is 1.0, so this is the effective μ) |
| `--speed` | 2.0 | speed limit, m/s |
| `--max-torque` | 8.0 | per-wheel motor torque limit, N·m |
| `--nav` | truth | pose the controller steers on: `truth` or `odom` |
| `--physics-hz`, `--decim` | 240, 4 | physics rate; steps per control/pose tick (60 Hz) |
| `--duration` | 0 | sim seconds; 0 = until the route ends |
| `--start=E,N,YAW` | lineup spot, facing the spur | start pose; use `=` because the value may begin with `-` |
| `--fast` | off | no wall-clock pacing, no waiting for Godot |
| `--no-wait` | off | real time, but do not wait for the viewer's HELLO |
| `--keep-running` | off | stay up after the route end, for manual driving |
| `--viewer-port`, `--listen-port` | 9001, 9002 | bridge ports |

## Step 4: the Godot scene

1. Copy `ugv_lab.tscn` and `ugv_lab.gd` to `godot/scenes/`. Run `godot --headless --path godot --import` once.
2. The scene tree. Every node except the script is a Module 2–6 part:

   ```
   UgvLab (Node3D, ugv_lab.gd)          RenderClock, keys, HUD, chase/onboard view, DIFF_DRIVE at 50 Hz
   ├── SimBridge (sim_bridge.gd)        Module 4; ports 9001/9002
   ├── WorldEnvironment, Sun
   ├── Terrain (HeightmapTerrain)       Module 2
   ├── Range (RangeBuilder)             Module 2: roads, pad, gates, obstacles from range.json
   ├── Rover (rover.tscn instance)      Module 2; ugv_lab.gd sets its transform every frame
   │                                    (+ a CameraRig on Mounts/fpv_cam, added in _ready)
   ├── ViewCam (Camera3D)               chase or onboard
   └── UI/Hud, UI/Pip                   status text; FPV picture-in-picture
   ```

3. In `_process`, the rover is placed exactly as in Module 5: `t = clock.advance(delta, bridge.latest_t_sim, paused)`, then `rover.global_transform = bridge.sample(VID, t)`. Module 2's four wheels spin from the body's motion: wheel speeds are not on the wire, and physics drives only the rear pair.
4. Start physics, then run `scenes/ugv_lab.tscn` from the editor (F6 with the scene open). Either order works:

   ```bash
   cd ~/robosim/physics && python sims/ugv_pybullet.py --keep-running
   # waiting for the Godot viewer (HELLO)...
   ```

You should see the rover leave its parking spot, take the spur south and turn east onto the loop. In our offscreen render it had just turned onto the loop, with `box_1` ahead on the left. The picture-in-picture showed the same road from the FPV mount.

![chase view with FPV picture-in-picture](img/ugv_chase.png)

**The handshake.** The script calls `wait_for_viewer()` without idle poses, so the rover appears only when the run starts. `SimBridge` says HELLO at start-up, every 0.5 s until its first pose, and again on the first pose of each physics session, and any packet from the viewer counts as "alive", so either start order works. (Passing `send_idle_pose=...` would also work, as Modules 8 and 11 do.)

## Step 5: manual driving and an obstacle

1. Restart with `--keep-running`. In Godot press **M** (manual), then W/A/S/D or the arrow keys.
2. `box_2` stands 9.5 m south of the loop's bottom edge, at (−40, −64.5). Drive into it.
3. Check `logs/<run>/contact.csv`:

   ```
   t_sim,t_wall,other,normal_force_n,nx,ny,nz
   6.066667,7.962065,box_2,1468.33,0.0,1.0,0.0
   ```

   The first-step force differs from run to run (1468 N and 1636 N in two of ours), because it depends on exactly when the DIFF_DRIVE stream starts relative to the physics clock. The time and the normal should be close to these.

4. Press **M** again. After 0.3 s the controller finds the road and continues the route from there.
5. Try P (pause), N (single step) and R (reset). The pose's PAUSED and RESET flags drive the render clock (Module 5).

To repeat the obstacle test automatically:

```bash
python sims/ugv_pybullet.py --start=-40,-58,-90 --duration 14 &
godot --headless --path godot res://scenes/ugv_lab.tscn -- --autotest
# ugv_autotest: poses 829, stale false, t_sim 13.82, rover ENU (-36.17, -58.83, 2.08)
```

Start Python first here: the autotest's 8 s of driving are timed on Godot's wall clock from its own start, so a Godot that starts several seconds early stops pushing before it reaches the box.

`--autotest` drives forward at 1 m/s for 8 s, then hands back to auto. Other test options: `--ports=L,P`, `--shot=DIR@T` (save the main view and the FPV image once sim time reaches T), `--quit-after=S`.

## Step 6: high vs low friction, and the plot

```bash
cd ~/robosim/physics
python sims/ugv_pybullet.py --fast --friction 1.0  --run-name ugv_mu1.0
python sims/ugv_pybullet.py --fast --friction 0.3  --run-name ugv_mu0.3
python sims/ugv_pybullet.py --fast --friction 0.15 --run-name ugv_mu0.15
cd .. && python tools/plot_cross_track.py logs/*_ugv_mu1.0 logs/*_ugv_mu0.3 logs/*_ugv_mu0.15 -o cross_track.png
```

Expected table:

```
run                                label                 rms_m  p95_m  max_m odom_end_m
20261001T072836Z_ugv_mu1.0         mu 1.0, nav truth     0.046  0.049  0.661       1.68
20261001T072853Z_ugv_mu0.3         mu 0.3, nav truth     0.045  0.048  0.638       3.10
20261001T072906Z_ugv_mu0.15        mu 0.15, nav truth    0.207  0.552  1.101     143.31
```

![cross-track and odometry error](img/cross_track.png)

Read the plot:

- **Cross-track (top).** μ = 1.0 and 0.3 overlap almost everywhere. The spike at s = 46 m is the T-junction, and the small steps are the four 22 m arcs (0.035 m inside each one). At μ = 0.15 the rover slides in the first turn (1.1 m) and in the corners.
- **Odometry (bottom).** At μ = 1.0 the error grows slowly to 1.7 m. At μ = 0.15 the slide in the first turn gives odometry a heading error of more than 200°, and the position error then wanders up to 210 m.

## Check

| # | Test | Pass if | Reference result |
|---|---|---|---|
| 1 | `tests/test_heightfield.py` | PASS: each of the 3 points within its tolerance | 0.29 / 0.40 / 0.14 mm vs 1.92 / 2.30 / 1.69 mm |
| 2 | μ = 1.0 route | finishes; cross-track RMS ≤ 0.10 m, max ≤ 1.0 m | 0.046 m, 0.661 m, 265 s |
| 3 | μ = 0.15 route + plot | finishes; both runs in one plot; RMS, max and odometry error reported for both | 0.207 m, 1.10 m; odometry 1.7 m vs 143 m |
| 4 | obstacle | `contact.csv` has a row with > 1 N; rover stops pushing within 0.5 s | `box_2` at t = 6.07 s; force < 5 N after 0.2 s |
| 5 | viewer | no "NO DATA FROM PHYSICS" while physics runs in real time; ~60 poses/s | `stale false`, 829 poses in 13.8 s |

## Stretch goals

1. Implement Stanley ([05](05_road_following.md)) and compare it with pure pursuit at 2 and 3 m/s.
2. Round the T-junction in `build_route()` and measure the new maximum cross-track error.
3. Add encoder noise and a wheel-radius error to odometry. Fuse odometry with a 1 Hz noisy GPS from Module 8 using a simple complementary filter, and plot the fused error.
4. Show contacts in Godot without breaking ownership: add Module 8's contact sensor around the rover model and flash the HUD. Compare its timestamps with `contact.csv`.
5. Detect wheel slip at μ = 0.15 (heading rate from the wheels vs from a gyro, Module 8) and slow down before the turn.
6. Stream the FPV picture-in-picture with your Module 7 transport and log frame timestamps next to `pose.csv`.
