# 05 Road following: route, cross-track error, pure pursuit

The rover's job in this lab is to drive along a road. That breaks into three small problems. You need to describe the road, measure how far off it you are, and turn that error into a steering command. All three live in ENU on the physics side. Godot draws the same road from the same file (Module 2's `RangeBuilder`) but takes no part in the control.

## The road as data

Module 2 wrote the road centerlines into `data/terrain/range.json`, next to the heightmap:

```json
"road_width_m": 5.0,
"roads": [
  {"name": "loop", "closed": true,  "points": [[48.0, -55.0], [49.917, -54.916], ...]},
  {"name": "spur", "closed": false, "points": [[0.0, -20.0], [0.0, -36.0], [0.0, -55.0]]}
],
"lineup": [{"id": 1, "name": "rover", "e": -9.0, "n": -12.0}, ...]
```

| Feature | Value | Consequence for the controller |
|---|---|---|
| loop | rounded rectangle E −70…70, N −55…65, 22 m corner radius, points every ~2 m on the arcs | gentle curves; long straights are a single segment (up to 96 m) |
| spur | from the apron (0, −20) south to the loop at (0, −55) | meets the loop at a **T-junction**: a 90° corner with no radius |
| closed loop | the last point repeats the first | drop the repeat before you rotate the list |
| frame | ENU, meters, heights not stored | heights come from the terrain, one source of truth |

## From roads to one route

The controller follows one open polyline. `build_route()` makes it: the rover's lineup spot, then the spur, then one counter-clockwise lap of the loop starting at the junction, and back to the junction.

```python
def build_route(layout, start_en):
    roads = {r["name"]: r["points"] for r in layout["roads"]}
    spur = [tuple(pt) for pt in roads["spur"]]
    loop = [tuple(pt) for pt in roads["loop"]][:-1]            # drop the repeated closing point
    q = np.array(spur[-1], float)                              # junction = end of the spur
    # find the loop segment that contains q (closest segment), call its index i
    ...
    lap = loop[i + 1:] + loop[:i + 1]                          # starts after the junction, CCW
    return [tuple(start_en)] + spur + lap + [spur[-1]]
```

The result has 81 points and is 529.2 m long. The junction (0, −55) lies inside the loop's closing segment, from (−48, −55) to (48, −55). So the lap starts at (48, −55) and ends at (−48, −55), and the final point brings the rover back to the junction. The loop's points run counter-clockwise, and leaving the spur toward the east is a left turn, so a CCW lap needs no U-turn.

## Projection and cross-track error

For each segment from **a** to **b**, project the rover position **p** onto the segment and keep the closest point:

```
t   = clamp( (p − a)·(b − a) / |b − a|² , 0, 1 )
q   = a + t (b − a)                       closest point on the segment
s   = arc length of a + t |b − a|          progress along the route
cte = ± |p − q|,   sign = sign of the 2D cross product (b − a) × (p − a)
```

With this sign, **cte > 0 means the rover is left of the road** (counter-clockwise from the direction of travel). Write the convention into the plot's axis label. Half of all sign bugs in path following come from two people using opposite conventions.

The route passes the junction twice, and the loop's bottom edge appears at both ends of the lap. A global "closest point" search could therefore jump between the start and the end of the route. The controller keeps a **progress index** and normally searches only from 2 segments behind to 8 ahead. At the start (and after a reset) it searches the whole route. When auto mode resumes after manual driving, it searches from just before the last progress point to the end. So it may skip ahead, but it never jumps back to the start of the lap.

## Pure pursuit

Pure pursuit (Coulter, 1992) chases a point on the path one **look-ahead distance** L ahead of the closest point. It then picks the circular arc through the rover and that target:

```
                 target (on the road, L ahead)
                    ●
                  ╱ |  y = lateral offset of the target in the BODY frame
                ╱   |
   rover ●───────────►  x (forward)
         radius R = L² / (2y),   curvature κ = 1/R = 2y / L²,   ω = v κ
```

A circle through the origin, tangent to the body x axis, that passes through (x, y), has radius R = (x² + y²)/(2y). With L² = x² + y² this gives κ = 2y/L².

```python
def update(self, xy, yaw, v_now):
    ...                                                  # s, cte, progress index (above)
    ld = self.ld_min + self.ld_gain * v_now             # 1.5 m + 0.6 s · v
    dx, dy = self.path.point_at(s + ld) - xy
    x_b =  math.cos(yaw) * dx + math.sin(yaw) * dy      # target in the body frame
    y_b = -math.sin(yaw) * dx + math.cos(yaw) * dy
    if abs(math.atan2(y_b, x_b)) > math.radians(60):    # target behind or far to the side
        return 0.3, math.copysign(1.0, y_b), ...        # crawl and turn toward it
    kappa = 2.0 * y_b / (dx * dx + dy * dy)
    v = min(self.v_max, math.sqrt(self.a_lat / abs(kappa)))   # limit lateral acceleration
    return v, v * kappa, ...
```

| Design choice | Value | Effect |
|---|---|---|
| look-ahead L | 1.5 m + 0.6 s · v (2.7 m at 2 m/s) | shorter: tighter tracking but oscillation; longer: smooth but cuts corners |
| lateral acceleration limit | 1.0 m/s² | at κ = 0.4 the speed drops to 1.6 m/s, which keeps the wheels inside their grip |
| behind-target fallback | crawl at 0.3 m/s, turn at 1 rad/s | pure pursuit alone fails when the target is behind (y ≈ 0, so κ ≈ 0, so it drives away) |
| end of route | v ≤ 0.8 · (distance left) + 0.1 | stops smoothly 0.5 m before the end |

The fallback was not in the first version of the lab code. A rover started 9 m off the road, facing away, simply drove off into the hills, because κ = 2y/L² is tiny when the target is behind. Test your controller from bad starting poses, not only from the road.

### Result on the route (μ = 1.0, 2 m/s, steering on the true pose)

Cross-track RMS 0.046 m, 95th percentile 0.049 m, max 0.661 m. The maximum is at s = 46 m, the **T-junction**. A 90° corner with zero radius cannot be driven exactly by anything with momentum. Pure pursuit starts turning L before the corner, so it cuts it. On the four 22 m arcs of the loop, the rover runs a steady 0.035 m to the left, inside the curve. Pure pursuit aims at a point ahead, and on a curve that point lies inside the bend. On the straights the error is below 5 mm.

![cross-track error, three friction values](img/cross_track.png)

## Stanley, for comparison

The Stanley controller (from Stanford's 2005 DARPA Grand Challenge car) steers on the error **at the axle**, not at a point ahead:

```
δ = ψ_e − atan( k · cte / v )      ψ_e = road heading − rover heading, δ > 0 = turn left
```

The minus sign comes from this page's convention (cte > 0 = rover **left** of the road, so it must steer right). Many write-ups print `+ atan(...)` because they measure the cross-track error with the opposite sign; check the convention before you copy a formula.

It is written for a car's steering angle δ. For a diff-drive robot, turn it into a yaw rate, for example ω = k_ψ · δ.

| | Pure pursuit | Stanley |
|---|---|---|
| tuning knob | look-ahead L | gain k |
| needs road heading | no | yes |
| corner cutting | yes (∝ L) | little |
| low-speed behavior | fine | atan(k·cte/v) saturates as v → 0; add a softening term |
| typical use | robots, low speed | cars at speed |

The lab uses pure pursuit. Implementing Stanley is a stretch goal. Compare it with the same `plot_cross_track.py`.

## Steering on odometry instead of truth

The controller can also steer on the drifting wheel-odometry pose (`--nav odom`). Cross-track error is still measured from the **true** pose, but the controller now believes its own estimate. At μ = 1.0 the rover finished the route with cross-track RMS 1.65 m and max 3.36 m, because the odometry was off by up to 4.9 m. It stayed on the 5 m wide road only because the drift was small. In a real robot, this is why you fuse odometry with GPS or visual landmarks.

## Try it

- Halve and double `ld_min` and `ld_gain`. Plot cross-track error for each, and find where oscillation starts on the straights and how the junction error changes.
- Replace the T-junction with a rounded one: insert points on a 6 m radius arc between the spur and the loop in `build_route()`. How much does the maximum error drop?
- Start the rover off the road and facing away: `--start=-10,-35,90` (note the `=`: the value starts with a minus sign). Watch the fallback turn it around and bring it to the spur in Godot (in our run, cross-track went from −10 m to 0.06 m in 10 s). Then try `--start=-20,-40,90`. The closest road point is now on the loop's bottom edge, which is the **end** of the route, so the rover drives to the junction and stops. Explain why, and decide what the right behavior would be.
- Implement Stanley as a second class with the same `update()` signature, and compare RMS and max.

## References

- R. C. Coulter, *Implementation of the Pure Pursuit Path Tracking Algorithm*, CMU-RI-TR-92-01, 1992: <https://www.ri.cmu.edu/publications/implementation-of-the-pure-pursuit-path-tracking-algorithm/>
- S. Thrun et al., "Stanley: The robot that won the DARPA Grand Challenge", J. Field Robotics, 2006
- J. Snider, *Automatic Steering Methods for Autonomous Automobile Path Tracking*, CMU-RI-TR-09-08, 2009
- [Module 2](../m02_scene_assets/README.md), page 05 (`range.json`)
