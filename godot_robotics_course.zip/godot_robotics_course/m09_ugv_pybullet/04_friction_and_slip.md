# 04 Friction and slip

A wheel can only push as hard as friction allows. On a dry road you rarely notice. On wet grass, gravel or ice, the wheels slip, the controller's commands stop meaning what they say, and odometry drifts. This page explains PyBullet's friction parameters and shows, with measured runs, what low friction does to the rover.

## The Coulomb model, in one table

The contact force splits into a normal part N (pressing the surfaces together) and a tangential part F (along the surface). Coulomb friction says:

| Situation | Tangential force |
|---|---|
| no sliding (grip) | any F with \|F\| ≤ μN, whatever is needed to prevent sliding |
| sliding (slip) | \|F\| = μN, opposite to the sliding velocity |

A driven wheel uses the **same** friction budget for traction (along the wheel) and for cornering (sideways). If it spins for traction, it has little left to hold the rover sideways. And if the rover asks for a turn, the wheels must push sideways too.

## PyBullet's friction parameters

All of them are set per link with `p.changeDynamics(body, link, ...)`:

| Parameter | Unit | What it does | Lab value |
|---|---|---|---|
| `lateralFriction` | – | Coulomb μ for sliding in the contact plane | wheels 1.0, 0.3 or 0.15; terrain 1.0; caster 0; chassis 0.3 |
| `rollingFriction` | m | resistance torque against rolling (≈ a contact patch length) | 0 (wheels should roll freely) |
| `spinningFriction` | m | resistance against spinning about the contact normal | 0 |
| `restitution` | – | bounciness | default 0 |
| `contactStiffness`, `contactDamping` | N/m, N·s/m | soft contacts instead of hard ones | not used |

**Combination rule.** Bullet multiplies the coefficients of the two touching bodies: μ = μ_A · μ_B. With the terrain at 1.0, the wheel's value is the effective μ. With the terrain at 0.5, a "μ = 0.3" wheel would really have 0.15. Page 01 has the inclined-box test that confirms the product rule.

```python
terrain = W.add_heightfield(p, hm, friction=1.0)          # keep the ground neutral
for j in (LEFT, RIGHT):
    p.changeDynamics(rover, j, lateralFriction=mu, rollingFriction=0.0, spinningFriction=0.0)
p.changeDynamics(rover, CASTER, lateralFriction=0.0)       # an ideal swivel caster
```

Why a frictionless caster? A real swivel caster turns to follow the motion and offers almost no resistance in any direction. A ball with μ = 0 is the simplest model of that. A caster *with* friction would scrub sideways in every turn and fight the drive wheels.

## Wheel shape matters more than you think

URDF wheels are naturally cylinders. On a triangle-mesh heightfield, Bullet's cylinder contacts jitter: the contact points jump between the cylinder's rim and its face. We measured it on the full 529 m route, μ = 1.0, same controller:

| Wheel collision shape | Cross-track RMS | Odometry error at the end |
|---|---:|---:|
| cylinder r = 0.15, width 0.10 | 0.045 m | **69.5 m** |
| sphere r = 0.15 | 0.046 m | **1.7 m** |

The controller hides the problem, because it steers on the true pose. Odometry exposes it: cylinder wheels slip all the time. So the course URDF uses **sphere** collision shapes for the wheels, while Godot still draws cylinders. Physics and visuals do not need the same shape, only the same contact point, and a sphere touches the ground directly below the axle, like a narrow wheel. Many PyBullet vehicle models do the same.

## High vs low friction on the route

We ran the full route with the same controller and a 2 m/s speed limit, changing only the wheel μ. All numbers come from `summary.json` and `tools/plot_cross_track.py`:

| Wheel μ | Speed limit | Finished | Cross-track RMS | Cross-track max | Odometry error at end |
|---:|---:|---|---:|---:|---:|
| 1.0 | 2 m/s | yes, 265.4 s | 0.046 m | 0.661 m | 1.7 m |
| 0.3 | 2 m/s | yes, 265.6 s | 0.045 m | 0.638 m | 3.1 m |
| 0.15 | 2 m/s | yes, 270.0 s | 0.207 m | 1.101 m | 143 m |
| 1.0 | 3 m/s | yes, 178.4 s | 0.060 m | 0.681 m | 4.0 m |
| 0.3 | 3 m/s | yes, 179.4 s | 0.093 m | 0.783 m | 49.1 m |

![cross-track error and odometry, three friction values](img/cross_track.png)

**μ = 0.3 barely matters at 2 m/s.** The Module 2 roads are gentle (8.4 % at worst), and the controller limits lateral acceleration to 1 m/s². The tires are rarely near their limit.

**μ = 0.15 is where it shows.** The drive wheels carry about half of the 11.8 kg, so the grip limit is about 0.15 · 0.5 · g ≈ 0.74 m/s², along *or* across the wheels. The first problem is the right turn from the lineup onto the spur, 10–20 m into the route. The controller asks for −0.4 to −0.66 rad/s. The wheel speeds show that differential, but the rover's true heading stalls at about −85° while it slides sideways. Odometry integrates the wheel speeds, so it believes the rover kept turning. By 30 m it is off by more than 200° of heading, and it never recovers: 143 m of error at the end. Road following still works, because it steers on the true pose. But every sharp corner now produces a visible slide, 0.85 m off the line at the loop's north-west corner (s = 349 m).

**Speed makes it worse.** At 3 m/s even μ = 0.3 starts to slide in the corners: 49 m of odometry error.

## Measuring slip

Longitudinal slip compares the wheel's surface speed with the ground speed:

```
slip = (r·ω_wheel − v_ground) / max(|r·ω_wheel|, ε)     0 = pure rolling, 1 = spinning in place
```

Both numbers are in the logs: `odom.csv` has the encoder speeds `wl_enc` and `wr_enc`, and `pose.csv` has the true forward speed `v_fwd`. Compute slip from **averaged** values (over 0.1 s or more). Single-step contact noise makes per-sample slip useless near zero speed. Lateral slip (the slide in the turns) is the angle between the body x axis and the velocity vector, `atan2(v_left, v_fwd)`.

## Try it

- Run `python sims/ugv_pybullet.py --fast --friction 0.15` and plot the true and odometry headings for the first 40 m (`odom.csv`: `yaw_true_deg`, `yaw_odom_deg`). Find the moment they separate.
- Lower `--speed` to 1.0 at μ = 0.15. Does the rover still slide in the first turn?
- Set the terrain's friction to 0.5 without changing the wheels (μ = 0.3). Predict the new effective μ, then confirm with one run.
- Swap the wheel collision back to cylinders (`<cylinder radius="0.15" length="0.10"/>` with `rpy="1.5708 0 0"`) and reproduce the wheel-shape table.

## References

- PyBullet Quickstart Guide, `changeDynamics`: <https://docs.google.com/document/d/10sXEhzFRSnvFcl3XxNGhnD4N2SedqwdAvK3dsihxVUA>
- H. Pacejka, *Tire and Vehicle Dynamics*, chapter 1 (slip definitions)
- [Module 8](../m08_sensors/README.md), for adding noise to the encoder readings
