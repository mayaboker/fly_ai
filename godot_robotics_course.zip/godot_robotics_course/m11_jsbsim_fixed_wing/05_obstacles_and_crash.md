# 05 Obstacles only Godot knows: contact and the crash decision

JSBSim knows exactly one obstacle: the ground. It has no buildings, masts, trees or gates. Godot has all of them, because they are part of the scene. So who notices when the plane flies into a radio mast?

Apply the course's sensor ownership rule: *would the reading change if I moved a wall?* Yes. So the **contact sensor belongs to Godot**. But the **consequence** belongs to the physics process, because it owns the vehicle's state: Godot reports, Python decides.

```
 Godot                                             Python
 ─────────────────────────────                     ──────────────────────────────────
 Area3D overlap + shape sweep   ── SENSOR_CONTACT ─▶ latch crash flag, log the event,
 (vehicle 3, hit, normal)          (t_sim of pose)   stop the dynamics, mark poses PAUSED
 HUD shows CONTACT / CRASH      ◀─ TELEMETRY ──────  crashed = 1
```

## The obstacles

The plane lab adds two red-and-white radio masts to Module 2's range. Their positions are exported in the scene, in ENU meters, and nowhere in Python:

```gdscript
## Radio masts, ENU meters: Vector4(east, north, height, radius). Only Godot knows them.
@export var masts: Array[Vector4] = [Vector4(-40, 0, 45, 0.6), Vector4(60, 60, 30, 0.6)]
```

Each one is a `StaticBody3D` on physics layer 2, which Module 2 named `obstacles`. The range's boxes and poles are on layer 2 as well, the terrain is on layer 1.

## The hull: an Area3D with the vehicle's own box

Module 2's `plane.tscn` already has a `Body/Shape` box (1.6 × 0.3 × 1.45 m) on layer 3, so that Godot rays can hit the plane. The lab builds an `Area3D` that reuses that box and watches layer 2 only:

```gdscript
func _build_hull() -> void:
	var body_shape: CollisionShape3D = plane.get_node("Body/Shape")
	hull = Area3D.new()
	hull.collision_layer = 0                      # nothing needs to detect the hull
	hull.collision_mask = 1 << (OBSTACLE_LAYER - 1)   # obstacles only, NOT the terrain
	hull.monitorable = false
	hull_shape = CollisionShape3D.new()
	hull_shape.shape = body_shape.shape           # same box, same offset
	hull_shape.transform = body_shape.transform
	hull.add_child(hull_shape)
	plane.add_child(hull)
```

The terrain is deliberately not in the mask. JSBSim owns the ground (sub-topic 04). If Godot also reported terrain contact, you would have two judges for one event, and they would disagree by the 6 cm one-step lag.

## Why an overlap test is not enough

`hull.get_overlapping_bodies()` answers "am I inside something **now**?". The plane moves 16 m/s. At 60 FPS that is 0.27 m per frame, at 20 FPS 0.8 m, at 2 FPS 8 m. The mast is 1.2 m thick. Between two frames, the hull can be in front of the mast and then behind it, never inside. This is called tunnelling.

We saw it happen. Our first version used the overlap only. Under software rendering (about 2 FPS), the plane in the `crash` scenario flew straight through the mast, and Python never heard of it.

The fix is a **sweep**: move the hull's shape from last frame's pose to this frame's pose and ask the physics server where it first touches something:

```gdscript
var hit := not hull.get_overlapping_bodies().is_empty()
var xf := hull_shape.global_transform
if _prev_hull_xf != Transform3D() and not hit:
	var q := PhysicsShapeQueryParameters3D.new()
	q.shape = hull_shape.shape
	q.transform = _prev_hull_xf
	q.motion = xf.origin - _prev_hull_xf.origin
	q.collision_mask = hull.collision_mask
	var frac := get_world_3d().direct_space_state.cast_motion(q)   # [safe, unsafe] in 0..1
	hit = frac.size() == 2 and frac[1] < 1.0
	if hit:
		hit_xf = _prev_hull_xf.translated(q.motion * frac[1])        # where it touched
_prev_hull_xf = xf
```

`cast_motion` sweeps a translation only. The plane also rotates between frames, but a few degrees of rotation of a 1.6 m box matter much less than meters of translation. After a reset, `_prev_hull_xf` is cleared so the plane does not "sweep" from its old position to the new start.

The sweep is also why the contact still works in a slow viewer: with it, all three of our slow runs (1–2 FPS) detected the mast.

## The message

`SENSOR_CONTACT` is defined in protocol v1: `hit 0/1, nx, ny, nz, depth`, normal in the Godot frame. The normal comes from `get_rest_info()` at the touching position (with a 2 m margin so it finds the nearest surface). The depth is not measured and sent as 0.

```gdscript
bridge.send_sensor(t_render, vehicle_id, RsProtocol.SENSOR_CONTACT,
		PackedFloat32Array([1.0 if hit else 0.0, n.x, n.y, n.z, 0.0]))
```

Two details:

- The header's `t_sim` is **the sim time of the pose that was drawn** (`t_render`), not the newest pose and not the wall clock. Python logs it next to its own time. The difference is the detection delay.
- The lab sends a contact message every frame while touching, and a "no contact" message at 5 Hz otherwise. The 5 Hz heartbeat lets Python tell "no contact" from "viewer gone". Unreliable is fine: the next frame repeats it.

## Python decides

```python
elif (m["type"] == P.MSG_SENSOR and m["vehicle_id"] == VEHICLE_ID
      and m["sensor"] == P.SENSOR_CONTACT and m["values"][0] > 0.5 and not crashed):
    crashed, crash_reason = True, "obstacle"          # Python decides, Godot only reports
    log.write("event", plane.t, event="crash", reason="obstacle", pose_t_sim=m["t_sim"],
              nx=m["values"][1], ny=m["values"][2], nz=m["values"][3])
```

After a crash, `plane_jsbsim.py` stops stepping JSBSim, sends every pose with the PAUSED flag, sets `crashed = 1` in TELEMETRY, keeps that up for 3 s so the viewer shows it, and exits. A RESET command restarts the scenario instead. What a crash *means* is a modelling choice: you could instead apply a large drag force, or hand the wreck to PyBullet. The point is that the choice lives in the physics process.

The ground is handled the same way, but JSBSim detects it itself: if `h-agl` drops below 0.3 m, Python sets the crash flag with reason `terrain`.

## Measured

`crash` scenario: north at 30 m ASL, straight at the 45 m mast at ENU (−40, 0).

| Viewer | Contact reported for the pose at | Python decided at | Event normal (Godot frame) |
|---|---|---|---|
| headless, 60 FPS | t = 5.54 s | t = 5.57 s | (0.00, −0.02, 1.00): +Z = south, back toward the plane |
| software renderer, about 1 FPS | t = 6.18 s | t = 7.15 s | (0.00, −0.02, 1.00) |

From the logged track, the hull's front reaches the mast at about t = 5.55 s, so the 60 FPS run is right to within a frame. The slow run is still *correct* (the sweep found the touch) but *late*: Python flew on for a second of sim time, about 16 m past the mast. If the consequence matters, the physics process must rewind to `pose_t_sim` or at least log it, which is why the event row carries both times. A slow viewer is part of the control loop as soon as it produces sensor data. The capstone measures this.

![Crash scenario, the moment of contact: the HUD shows CONTACT](img/mast_crash.png)

## Try it

- Disable the sweep and run the `crash` scenario with `Engine.max_fps = 10`. Does the plane still crash? Now at 60 FPS?
- Change the reaction: instead of freezing, cut the pusher and let JSBSim fly on with a large drag (`fcs/pusher-cmd = 0`, and add an external drag force). Where does the plane hit the ground?
- Log the event and compute the distance flown between `pose_t_sim` and the decision time for both viewer rates.
- Put a third mast on the `lap` route and make the autopilot avoid it. What would Python need to know, and who should provide it? (Hint: Module 8's range sensor.)

## References

- `PhysicsDirectSpaceState3D.cast_motion`, `get_rest_info`: <https://docs.godotengine.org/en/stable/classes/class_physicsdirectspacestate3d.html>
- `Area3D`: <https://docs.godotengine.org/en/stable/classes/class_area3d.html>
- [Module 8: Godot-side range, lidar and contact](../m08_sensors/04_godot_range_lidar_contact.md), [protocol](../reference/protocol.md)
