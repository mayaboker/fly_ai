"""
compare_hud.py - Module 11 Check: does the Godot HUD show JSBSim's numbers?

    python tools/compare_hud.py logs/<run>/pose.csv hud_log.csv

pose.csv  written by sims/plane_jsbsim.py --scenario check (JSBSim truth, 120 Hz... logged per pose)
hud.csv   written by the Godot plane_lab scene with  -- --hud-log=<path>  (one row per frame,
          computed from the rendered node transform, stamped with the sim time it was drawn for)

For every HUD row the truth is interpolated at the HUD's t_sim. Errors are reported for the
settled window of each steady state (Check.windows in plane_jsbsim.py).
"""
import csv
import sys

import numpy as np

WINDOWS = {"LEVEL": (7, 12), "TURN": (26, 32), "CLIMB": (39, 44)}
PAIRS = [("heading_deg", "heading_deg", "deg"), ("pitch_deg", "pitch_deg", "deg"),
         ("roll_deg", "roll_deg", "deg"), ("alt_m", "h_asl", "m"), ("agl_m", "agl", "m"),
         ("speed_mps", "airspeed", "m/s")]
LIMITS = {"deg": 0.5, "m": 0.2, "m/s": 0.2}     # pass/fail thresholds of the Check


def load(path):
    with open(path) as f:
        rows = list(csv.DictReader(f))
    out = {}
    for k in rows[0]:
        try:
            out[k] = np.array([float(r[k]) for r in rows])
        except ValueError:
            pass
    return out


def interp(t_truth, y, t, angle=False):
    if angle:                                  # unwrap headings before interpolating
        y = np.degrees(np.unwrap(np.radians(y)))
        return np.interp(t, t_truth, y) % 360.0
    return np.interp(t, t_truth, y)


def main(pose_csv, hud_csv):
    truth, hud = load(pose_csv), load(hud_csv)
    print(f"{'state':6s} {'quantity':12s} {'JSBSim':>9s} {'Godot HUD':>10s} {'mean err':>9s} {'max |err|':>9s}")
    ok = True
    for name, (a, b) in WINDOWS.items():
        m = (hud["t_sim"] >= a) & (hud["t_sim"] <= b)
        t = hud["t_sim"][m]
        for hk, tk, unit in PAIRS:
            ref = interp(truth["t_sim"], truth[tk], t, angle=(hk == "heading_deg"))
            err = hud[hk][m] - ref
            if hk == "heading_deg":
                err = (err + 180) % 360 - 180
            worst = np.abs(err).max()
            ok &= worst < LIMITS[unit]
            print(f"{name:6s} {hk:12s} {ref.mean():9.3f} {hud[hk][m].mean():10.3f} {err.mean():+9.4f} "
                  f"{worst:9.4f} {unit}{'' if worst < LIMITS[unit] else '  FAIL'}")
        print(f"{'':6s} ({m.sum()} HUD frames in t = {a}-{b} s)")
    print("Check:", "PASS" if ok else "FAIL", f"(limits {LIMITS})")
    return ok


if __name__ == "__main__":
    sys.exit(0 if main(sys.argv[1], sys.argv[2]) else 1)
