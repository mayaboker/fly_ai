"""
plot_plane_run.py - plot one plane_jsbsim.py run (Module 11).

    python tools/plot_plane_run.py logs/<run>          # writes <run>/plane_run.png

Panels: track over the heightmap (top view, north up), altitude ASL with the terrain
under the aircraft, airspeed and bank angle.
"""
import csv
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                     # noqa: E402
import numpy as np                                                  # noqa: E402

BLUE, ORANGE, GREY, INK = "#2a78d6", "#eb6834", "#8a897f", "#3d3d3a"


def read(path):
    with open(path) as f:
        rows = list(csv.DictReader(f))
    return {k: np.array([float(r[k]) if k != "segment" else 0 for r in rows]) for k in rows[0]}


def main(run):
    p = read(os.path.join(run, "pose.csv"))
    here = os.path.dirname(os.path.abspath(__file__))
    png = os.path.join(here, "..", "data", "terrain", "heightmap.png")
    fig = plt.figure(figsize=(11, 7))
    ax0 = fig.add_subplot(1, 2, 1)
    try:
        from PIL import Image
        import json
        meta = json.load(open(png[:-4] + ".json"))
        h = meta["min_height_m"] + np.array(Image.open(png), dtype=float) / 65535 * meta["height_range_m"]
        half = (h.shape[0] - 1) / 2 * meta["meters_per_px"]
        im = ax0.imshow(h, cmap="Greys", extent=(-half, half, -half, half), origin="upper")
        fig.colorbar(im, ax=ax0, shrink=0.6, label="terrain height (m)")
    except Exception as exc:                       # the plot still works without the terrain image
        print("no terrain background:", exc)
    ax0.plot(p["e"], p["n"], color=BLUE, lw=2)
    ax0.plot(p["e"][0], p["n"][0], "o", color=BLUE, ms=8)
    ax0.text(p["e"][0] + 4, p["n"][0], "start", color=INK, fontsize=9)
    ax0.set_xlabel("east (m)")
    ax0.set_ylabel("north (m)")
    ax0.set_title("track (top view)", color=INK, loc="left")
    ax0.set_aspect("equal")

    ax1 = fig.add_subplot(3, 2, 2)
    ax1.fill_between(p["t_sim"], 0, p["terrain"], color=GREY, alpha=0.5, lw=0)
    ax1.plot(p["t_sim"], p["h_asl"], color=BLUE, lw=2)
    ax1.text(p["t_sim"][-1], p["h_asl"][-1], " aircraft", color=INK, fontsize=8, va="center")
    ax1.text(p["t_sim"][-1], p["terrain"][-1], " terrain", color=INK, fontsize=8, va="center")
    ax1.set_ylabel("height ASL (m)")
    ax2 = fig.add_subplot(3, 2, 4, sharex=ax1)
    ax2.plot(p["t_sim"], p["airspeed"], color=BLUE, lw=2)
    ax2.set_ylabel("airspeed (m/s)")
    ax3 = fig.add_subplot(3, 2, 6, sharex=ax1)
    ax3.plot(p["t_sim"], p["roll_deg"], color=BLUE, lw=2)
    ax3.set_ylabel("bank (deg)")
    ax3.set_xlabel("sim time (s)")
    for a in (ax0, ax1, ax2, ax3):
        a.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    out = os.path.join(run, "plane_run.png")
    fig.savefig(out, dpi=100)
    print("saved", out)
    print(f"min AGL {p['agl'].min():.1f} m, altitude {p['h_asl'].min():.1f}-{p['h_asl'].max():.1f} m ASL, "
          f"airspeed {p['airspeed'].min():.1f}-{p['airspeed'].max():.1f} m/s")


if __name__ == "__main__":
    main(sys.argv[1])
