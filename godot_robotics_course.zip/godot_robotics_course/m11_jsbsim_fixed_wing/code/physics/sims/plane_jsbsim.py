"""
plane_jsbsim.py - Module 11: the JSBSim "trainer" over the shared terrain, viewed in Godot.

  JSBSim trainer, 120 Hz          -- POSE 60 Hz (vehicle 3) -->       Godot plane_lab scene
  Python autopilot                -- TELEMETRY 10 Hz (type 100) -->   HUD: airspeed, alpha, AGL, crash
  terrain feed from heightmap     <-- SENSOR_CONTACT (vehicle 3) --   Area3D hits an obstacle
  crash decision                  <-- COMMAND pause/resume/reset --   keys P / R

Autopilot (lesson 7 of the JSBSim course, unchanged gains):
  altitude -> pitch angle -> elevator,  heading -> bank angle -> aileron,  airspeed -> pusher

Scenarios:
  lap    (default) waypoint circuit: climb over the west hills, turn, descend toward them again
  check  three steady states for the Module 11 Check: level, steady climb, steady 25 deg turn
  crash  fly north into the radio mast that only Godot knows about

Run from robosim/physics:   python sims/plane_jsbsim.py [--scenario lap|check|crash]
"""
import argparse
import math
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from robosim import protocol as P                                   # noqa: E402
from robosim.bridge import PhysicsBridge                            # noqa: E402
from robosim.logger import RunLogger                                # noqa: E402
from robosim.terrain import Heightmap                               # noqa: E402  (Module 2)
from robosim.jsbsim_vehicle import JsbVehicle, LAT0_DEG, LON0_DEG                      # noqa: E402
from robosim.telemetry import send_telemetry, TELEM_FLIGHT          # noqa: E402

VEHICLE_ID = 3
HERE = os.path.dirname(os.path.abspath(__file__))
TERRAIN = os.path.join(HERE, "..", "..", "data", "terrain", "heightmap.png")

# Hand trim for 16 m/s level flight, found by sims/trim_trainer.py (do_simple_trim cannot trim
# this model, see 03_trim.md). Starting from it, the aircraft flies level hands-off.
TRIM = {"alpha_deg": 1.054, "elevator": 0.0046, "pusher": 0.1643, "airspeed": 16.0}


def clamp(x, lo, hi):
    return max(lo, min(hi, x))


def wrap180(a):
    return (a + 180.0) % 360.0 - 180.0


class Autopilot:
    """Lesson 7 autopilot as a class. Targets: alt (m ASL), heading (deg), speed (m/s).
    pitch_override / bank_override replace the outer loops (used by the Check scenario)."""

    def __init__(self, dt, trim=TRIM):
        self.dt, self.trim, self.v_int = dt, trim, 0.0
        self.alt, self.heading, self.speed = 40.0, 0.0, trim["airspeed"]
        self.pitch_override = self.bank_override = None
        self.pitch_cmd = self.bank_cmd = 0.0

    def update(self, s):
        """s = JsbVehicle.state(). Returns elevator, aileron, pusher commands."""
        if self.pitch_override is None:
            self.pitch_cmd = clamp(0.8 * (self.alt - s["h_asl"]) - 1.0 * s["climb_rate"] + 1.2, -10, 12)
        else:
            self.pitch_cmd = self.pitch_override
        elevator = -(0.05 * (self.pitch_cmd - s["pitch_deg"]) - 0.3 * s["q"])   # negative = nose up

        if self.bank_override is None:
            self.bank_cmd = clamp(1.5 * wrap180(self.heading - s["heading_deg"]), -30, 30)
        else:
            self.bank_cmd = self.bank_override
        aileron = 0.04 * (self.bank_cmd - s["roll_deg"]) - 0.1 * s["p"]

        err = self.speed - s["airspeed"]
        self.v_int = clamp(self.v_int + err * self.dt, -5, 5)
        pusher = clamp(self.trim["pusher"] + 0.08 * err + 0.03 * self.v_int, 0, 1)
        return elevator, aileron, pusher


# ------------------------------------------------------------------ scenarios
class Lap:
    """Waypoint circuit near the map edge (ENU m, altitude m ASL), over the border hills
    (10-19 m high): climb to 45 m going north, turn east, descend to 28 m on the way south and
    west. The 45 m acceptance radius makes the plane turn early, which keeps it on the map."""
    start = dict(e=-112.0, n=-60.0, h_asl=35.0, heading_deg=0.0)
    waypoints = [(-112, 112, 45), (112, 112, 45), (112, -112, 28), (-112, -112, 28)]
    accept_m = 45.0

    def __init__(self):
        self.i = 0

    def update(self, t, s, ap):
        e, n, h = self.waypoints[self.i]
        if math.hypot(e - s["e"], n - s["n"]) < self.accept_m:
            self.i = (self.i + 1) % len(self.waypoints)
            e, n, h = self.waypoints[self.i]
        ap.heading = math.degrees(math.atan2(e - s["e"], n - s["n"])) % 360   # bearing, 0 = north
        ap.alt = h
        return f"wp{self.i + 1}"


class Check:
    """Three steady states for the Module 11 Check, chosen to stay over the 256 m map:
    LEVEL (straight north), TURN (steady 25 deg left bank, altitude held), CLIMB (fixed 8 deg pitch).
    The compare windows are the settled end of each segment."""
    start = dict(e=0.0, n=-125.0, h_asl=40.0, heading_deg=0.0)
    segments = [(0, "LEVEL"), (12, "TURN"), (32, "CLIMB")]
    windows = {"LEVEL": (7, 12), "TURN": (26, 32), "CLIMB": (39, 44)}

    def __init__(self):
        self.climb_heading = None

    def update(self, t, s, ap):
        name = [n for t0, n in self.segments if t >= t0][-1]
        ap.pitch_override = ap.bank_override = None
        ap.alt = 40.0
        if name == "LEVEL":
            ap.heading = 0.0
        elif name == "TURN":
            ap.bank_override = -25.0                        # left: circle stays on the map
        else:
            if self.climb_heading is None:
                self.climb_heading = s["heading_deg"]       # climb straight ahead from here
            ap.pitch_override, ap.heading = 8.0, self.climb_heading
        return name


class Crash:
    """Fly north at 30 m ASL straight into the 45 m radio mast at ENU (-40, 0)."""
    start = dict(e=-40.0, n=-90.0, h_asl=30.0, heading_deg=0.0)

    def update(self, t, s, ap):
        ap.alt, ap.heading = 30.0, 0.0
        return "to-mast"


SCENARIOS = {"lap": Lap, "check": Check, "crash": Crash}


# ------------------------------------------------------------------ main
def main():
    ap_ = argparse.ArgumentParser()
    ap_.add_argument("--scenario", choices=SCENARIOS, default="lap")
    ap_.add_argument("--duration", type=float, default=90.0, help="sim seconds")
    ap_.add_argument("--rate", type=float, default=120.0, help="JSBSim Hz")
    ap_.add_argument("--pose-hz", type=float, default=60.0)
    ap_.add_argument("--speedup", type=float, default=1.0, help="0 = as fast as possible")
    ap_.add_argument("--no-wait", action="store_true", help="do not wait for the viewer's HELLO")
    ap_.add_argument("--viewer-port", type=int, default=P.PORT_TO_VIEWER)
    ap_.add_argument("--listen-port", type=int, default=P.PORT_TO_PHYSICS)
    ap_.add_argument("--logs", default=os.path.join(HERE, "..", "..", "logs"))
    args = ap_.parse_args()

    hm = Heightmap.load(TERRAIN)
    plane = JsbVehicle("trainer", hm, rate_hz=args.rate)
    br = PhysicsBridge(viewer_port=args.viewer_port, listen_port=args.listen_port)
    log = RunLogger(args.logs, run_name=f"plane_{args.scenario}", seed=0,
                    meta={"physics": "jsbsim", "model": "trainer", "vehicle_id": VEHICLE_ID,
                          "physics_hz": args.rate, "pose_hz": args.pose_hz, "scenario": args.scenario,
                          "geo_origin": [LAT0_DEG, LON0_DEG, 0.0],
                          "terrain": "data/terrain/heightmap.png", "trim": TRIM})

    def reset():
        scen = SCENARIOS[args.scenario]()
        plane.place(**scen.start, airspeed=TRIM["airspeed"], alpha_deg=TRIM["alpha_deg"],
                    controls={"fcs/elevator-cmd": TRIM["elevator"], "fcs/pusher-cmd": TRIM["pusher"]})
        br.mark_reset()
        return scen, Autopilot(plane.dt)

    scen, ap = reset()
    send = lambda paused=False: br.send_pose(plane.t, VEHICLE_ID, *plane.godot_pose(), paused=paused)
    if not args.no_wait:
        print(f"waiting for the viewer on UDP {args.listen_port} ...")
        br.wait_for_viewer(send_idle_pose=lambda: send(True))   # works in both start orders
    print(f"flying scenario '{args.scenario}', logs in {log.dir}")

    steps_per_pose = max(1, round(args.rate / args.pose_hz))
    frame_s = steps_per_pose * plane.dt                     # sim seconds per pose
    paused = crashed = False
    crash_reason, label, frames_since_crash = "", "", 0
    next_wall, k = time.monotonic(), 0
    while plane.t < args.duration and frames_since_crash < 3.0 / frame_s:
        # ---- 1. messages from the viewer (commands are ACKed inside poll)
        for m in br.poll(plane.t):
            if m["type"] == P.MSG_COMMAND:
                if m["cmd"] == P.CMD_PAUSE:
                    paused = True
                elif m["cmd"] == P.CMD_RESUME:
                    paused = False
                elif m["cmd"] == P.CMD_RESET:
                    scen, ap = reset()
                    crashed, paused, crash_reason, frames_since_crash = False, False, "", 0
            elif (m["type"] == P.MSG_SENSOR and m["vehicle_id"] == VEHICLE_ID
                  and m["sensor"] == P.SENSOR_CONTACT and m["values"][0] > 0.5 and not crashed):
                crashed, crash_reason = True, "obstacle"          # Python decides, Godot only reports
                log.write("event", plane.t, event="crash", reason="obstacle", pose_t_sim=m["t_sim"],
                          nx=m["values"][1], ny=m["values"][2], nz=m["values"][3])
                print(f"t={plane.t:6.2f}  CRASH: obstacle contact reported by Godot (pose t={m['t_sim']:.2f})")

        # ---- 2. physics: autopilot + JSBSim, several steps per pose
        if not (paused or crashed):
            for _ in range(steps_per_pose):
                s = plane.state()
                label = scen.update(plane.t, s, ap)
                elev, ail, push = ap.update(s)
                plane.fdm["fcs/elevator-cmd"] = elev
                plane.fdm["fcs/aileron-cmd"] = ail
                plane.fdm["fcs/pusher-cmd"] = push
                plane.step()                                # terrain feed + fdm.run()
            s = plane.state()
            if s["agl"] < 0.3:                              # JSBSim knows the ground itself
                crashed, crash_reason = True, "terrain"
                log.write("event", plane.t, event="crash", reason="terrain", pose_t_sim=plane.t,
                          nx=0, ny=1, nz=0)
                print(f"t={plane.t:6.2f}  CRASH: terrain (AGL {s['agl']:.2f} m)")
            log.write("pose", plane.t, e=s["e"], n=s["n"], h_asl=s["h_asl"], agl=s["agl"],
                      terrain=s["terrain"], roll_deg=s["roll_deg"], pitch_deg=s["pitch_deg"],
                      heading_deg=s["heading_deg"], airspeed=s["airspeed"],
                      groundspeed=s["groundspeed"], alpha_deg=s["alpha_deg"], segment=label)
            log.write("command", plane.t, alt_cmd=ap.alt, heading_cmd_deg=ap.heading, speed_cmd=ap.speed,
                      pitch_cmd_deg=ap.pitch_cmd, bank_cmd_deg=ap.bank_cmd,
                      elevator=plane.fdm["fcs/elevator-cmd"], aileron=plane.fdm["fcs/aileron-cmd"],
                      pusher=plane.fdm["fcs/pusher-cmd"])
        if crashed:
            frames_since_crash += 1                         # keep showing the crash for 3 s

        # ---- 3. outputs to the viewer: pose every frame, telemetry at 10 Hz
        send(paused or crashed)
        if k % max(1, round(args.pose_hz / 10)) == 0:
            s = plane.state()
            send_telemetry(br, plane.t, VEHICLE_ID, TELEM_FLIGHT,
                           [s["airspeed"], s["alpha_deg"], s["agl"], s["terrain"], float(crashed), 0.0, 0.0])
        k += 1

        # ---- 4. real-time pacing: one frame of wall time per pose (also while paused)
        if args.speedup > 0:
            next_wall += frame_s / args.speedup
            time.sleep(max(0.0, next_wall - time.monotonic()))

    br.tx.sendto(P.pack_simple(P.MSG_BYE, br._next(), plane.t), br.viewer)
    log.close()
    print(f"done at t={plane.t:.1f} s ({'CRASH: ' + crash_reason if crashed else 'no crash'}); log {log.dir}")


if __name__ == "__main__":
    main()
