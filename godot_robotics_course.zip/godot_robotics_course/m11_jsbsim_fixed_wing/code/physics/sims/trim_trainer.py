"""
trim_trainer.py - find the trainer's cruise trim (Module 11, sub-topic 3).

Step 1  try JSBSim's own trim (simulation/do_simple_trim = 1) and show why it fails here
Step 2  "settle trim": let the lesson-7 autopilot hold 16 m/s level flight for 40 s and
        average the last 5 s of alpha, elevator and pusher
Step 3  prove it: start a fresh aircraft from those numbers, hands off, for 30 s

Run from robosim/physics:   python sims/trim_trainer.py [--speed 16]
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import jsbsim                                                       # noqa: E402
from robosim.jsbsim_vehicle import JsbVehicle                       # noqa: E402

FT = 0.3048


def try_jsbsim_trim():
    v = JsbVehicle("trainer")
    v.place(0, 0, h_asl=60, airspeed=16, alpha_deg=1)
    f = v.fdm
    try:
        f["simulation/do_simple_trim"] = 1          # 1 = full longitudinal trim
        print("JSBSim trim converged (unexpected for this model):",
              f"alpha {f['aero/alpha-deg']:.2f} deg")
    except jsbsim.TrimFailureError as exc:
        print(f"JSBSim trim: {exc}")
    print(f"  alpha after the attempt: {f['aero/alpha-deg']:.2f} deg, udot {f['accelerations/udot-ft_sec2'] * FT:+.2f} m/s^2")
    print("  The trim moves the ENGINE throttles and fcs/pitch-trim-cmd-norm, fcs/aileron-cmd-norm,")
    print("  fcs/rudder-cmd-norm. trainer.xml has no <engine> (its pusher is an external force) and")
    print("  its surfaces read fcs/elevator-cmd and fcs/aileron-cmd, so the trim's controls move no")
    print("  force at all. It cannot converge. (set_debug_level(1) prints the full trim report.)\n")


def settle_trim(speed, alt=60.0, seconds=40.0):
    v = JsbVehicle("trainer")
    v.place(0, 0, h_asl=alt, airspeed=speed, alpha_deg=1, controls={"fcs/pusher-cmd": 0.17})
    f, dt, v_int, acc = v.fdm, v.dt, 0.0, []
    while v.t < seconds:
        s = v.state()
        pitch_cmd = max(-10, min(12, 0.8 * (alt - s["h_asl"]) - 1.0 * s["climb_rate"] + 1.2))
        f["fcs/elevator-cmd"] = -(0.05 * (pitch_cmd - s["pitch_deg"]) - 0.3 * s["q"])
        f["fcs/aileron-cmd"] = 0.04 * (0 - s["roll_deg"]) - 0.1 * s["p"]
        v_int = max(-5, min(5, v_int + (speed - s["airspeed"]) * dt))
        f["fcs/pusher-cmd"] = 0.17 + 0.08 * (speed - s["airspeed"]) + 0.03 * v_int
        v.step()
        if v.t > seconds - 5:
            acc.append((s["alpha_deg"], f["fcs/elevator-cmd"], f["fcs/pusher-cmd"], s["climb_rate"]))
    n = len(acc)
    alpha, elev, push, climb = (sum(a[i] for a in acc) / n for i in range(4))
    print(f"settle trim at {speed} m/s: alpha {alpha:.3f} deg, elevator {elev:.4f}, pusher {push:.4f}"
          f"  (mean climb rate {climb:+.3f} m/s)")
    return {"alpha_deg": round(alpha, 3), "elevator": round(elev, 4), "pusher": round(push, 4), "airspeed": speed}


def verify(trim, alt=60.0, seconds=30.0):
    v = JsbVehicle("trainer")
    v.place(0, 0, h_asl=alt, airspeed=trim["airspeed"], alpha_deg=trim["alpha_deg"],
            controls={"fcs/elevator-cmd": trim["elevator"], "fcs/pusher-cmd": trim["pusher"]})
    hs, vs = [], []
    while v.t < seconds:
        v.step()
        s = v.state()
        hs.append(s["h_asl"])
        vs.append(s["airspeed"])
    print(f"hands off for {seconds:.0f} s from the trim: altitude {min(hs):.2f}..{max(hs):.2f} m "
          f"(start {alt:.0f}), airspeed {min(vs):.2f}..{max(vs):.2f} m/s")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--speed", type=float, default=16.0)
    a = ap.parse_args()
    try_jsbsim_trim()
    trim = settle_trim(a.speed)
    verify(trim)
    print("\nTRIM =", trim)
