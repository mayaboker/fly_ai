"""
quadplane_jsbsim.py - Module 11 stretch goal: the JSBSim quadplane (vehicle 4) with its
transition phases shown in the Godot HUD.

The flight logic is lesson 8 of the JSBSim course (fly_vtol.py), unchanged in its gains.
What is new here: the course bridge (POSE for vehicle 4, TELEMETRY with the phase code),
the terrain feed, and a cruise leg that turns back so the flight stays over the 256 m map.

  HOVER_UP -> TRANSITION -> CRUISE (turn to 180) -> BACK_TRANS -> HOVER_DOWN -> LANDED

Run from robosim/physics:   python sims/quadplane_jsbsim.py
Viewer:                     godot --path ../godot res://scenes/plane_lab.tscn -- --vehicle=4
"""
import argparse
import math
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from robosim import protocol as P                                   # noqa: E402
from robosim.bridge import PhysicsBridge                            # noqa: E402
from robosim.logger import RunLogger                                # noqa: E402
from robosim.terrain import Heightmap                               # noqa: E402
from robosim.jsbsim_vehicle import JsbVehicle                       # noqa: E402
from robosim.telemetry import send_telemetry, TELEM_FLIGHT, PHASES  # noqa: E402
from plane_jsbsim import TERRAIN, HERE             # noqa: E402

VEHICLE_ID = 4
G, MASS, LIFT_MAX = 9.78, 3.0, 12.0
ALT_AGL = 30.0            # m above the pad
V_CRUISE, V_WING = 17.0, 13.0
HOVER = MASS * G / (4 * LIFT_MAX)


def clamp(x, lo, hi):
    return max(lo, min(hi, x))


class Integrator:
    def __init__(self, lim, dt):
        self.v, self.lim, self.dt = 0.0, lim, dt

    def __call__(self, err):
        self.v = clamp(self.v + err * self.dt, -self.lim, self.lim)
        return self.v


class VtolPilot:
    """Lesson 8 controllers. Altitudes here are ASL: pad height + ALT_AGL."""

    def __init__(self, v):
        self.v, self.f = v, v.fdm
        self.alt_i, self.v_i = Integrator(2.0, v.dt), Integrator(5.0, v.dt)
        self.phase, self.t_phase, self.lift_gain = "HOVER_UP", 0.0, 1.0
        self.pad_h = v.terrain_m
        self.heading_cmd = 0.0

    def multirotor(self, alt_cmd, climb_limit, roll_cmd, pitch_cmd, heading_cmd, gain=1.0):
        f, s = self.f, self.v.state()
        vz_cmd = clamp(1.0 * (alt_cmd - s["h_asl"]), -climb_limit, climb_limit)
        err = vz_cmd - s["climb_rate"]
        phi, theta = math.radians(s["roll_deg"]), math.radians(s["pitch_deg"])
        tilt = max(0.6, math.cos(phi) * math.cos(theta))
        T = (HOVER + 0.20 * err + 0.10 * self.alt_i(err)) / tilt * gain
        R = 0.9 * (math.radians(roll_cmd) - phi) - 0.20 * s["p"]
        Pc = 0.55 * (math.radians(pitch_cmd) - theta) - 0.13 * s["q"]
        hdg_err = (heading_cmd - s["heading_deg"] + 180) % 360 - 180
        Y = clamp(0.6 * (math.radians(hdg_err) - s["r"]), -0.15, 0.15)
        return [T - R + Pc + Y, T + R - Pc + Y, T + R + Pc - Y, T - R - Pc - Y]

    def brake_angles(self):
        s = self.v.state()
        return clamp(-3.0 * s["v"], -8, 8), clamp(3.0 * s["u"], -8, 8)

    def airplane(self, alt_cmd, heading_cmd, speed_cmd):
        s = self.v.state()
        pitch_cmd = clamp(0.8 * (alt_cmd - s["h_asl"]) - 1.0 * s["climb_rate"] + 2.0, -10, 12)
        elevator = -(0.05 * (pitch_cmd - s["pitch_deg"]) - 0.3 * s["q"])
        hdg_err = (heading_cmd - s["heading_deg"] + 180) % 360 - 180
        aileron = 0.04 * (clamp(1.5 * hdg_err, -30, 30) - s["roll_deg"]) - 0.1 * s["p"]
        pusher = 0.25 + 0.08 * (speed_cmd - s["airspeed"]) + 0.03 * self.v_i(speed_cmd - s["airspeed"])
        return elevator, aileron, pusher

    def enter(self, new):
        self.phase, self.t_phase = new, self.v.t
        s = self.v.state()
        print(f"t={self.v.t:5.1f} s  phase {new:11s}  airspeed {s['airspeed']:4.1f} m/s  AGL {s['agl']:4.1f} m")

    def step(self):
        """One control step. Returns False when landed."""
        t, s, dt = self.v.t, self.v.state(), self.v.dt
        V, alt = s["airspeed"], self.pad_h + ALT_AGL
        lift, elev, ail, push = [0.0] * 4, 0.0, 0.0, 0.0
        if self.phase == "HOVER_UP":
            lift = self.multirotor(alt, 2.0, *self.brake_angles(), 0)
            if s["h_asl"] > alt - 0.5 and t > 5:
                self.enter("TRANSITION")
        elif self.phase == "TRANSITION":
            w = clamp((V - 6.0) / (V_WING - 6.0), 0, 1)
            e_fw, a_fw, _ = self.airplane(alt, 0, V_CRUISE)
            push, elev, ail = 0.9, w * e_fw, w * a_fw
            lift = self.multirotor(alt, 1.0, 0, 4.0 * w, 0)
            if V > V_WING and sum(lift) / 4 < 0.25:
                self.enter("CRUISE")
        elif self.phase == "CRUISE":
            self.lift_gain = max(0.0, self.lift_gain - dt / 1.0)
            self.heading_cmd = 180.0 if t - self.t_phase > 1.0 else 0.0   # turn back over the map
            elev, ail, push = self.airplane(alt, self.heading_cmd, V_CRUISE)
            if self.lift_gain > 0:
                lift = self.multirotor(alt, 1.0, 0, 4.0, 0, gain=self.lift_gain)
            if t - self.t_phase > 10:
                self.enter("BACK_TRANS")
                self.lift_gain = 0.0
        elif self.phase == "BACK_TRANS":
            self.lift_gain = min(1.0, self.lift_gain + dt / 1.0)
            w = clamp((V - 6.0) / (V_WING - 6.0), 0, 1)
            e_fw, a_fw, _ = self.airplane(alt, self.heading_cmd, 0)
            elev, ail = w * e_fw, w * a_fw
            lift = self.multirotor(alt, 1.0, 0, clamp(0.8 * V + 1.0, 0, 10), self.heading_cmd, gain=self.lift_gain)
            if V < 2.0:
                self.enter("HOVER_DOWN")
        elif self.phase == "HOVER_DOWN":
            lift = self.multirotor(s["terrain"], 1.0, *self.brake_angles(), self.heading_cmd)
            if s["agl"] < 0.2:
                lift = [0.0] * 4
                if t - self.t_phase > 3:
                    self.enter("LANDED")
        f = self.f
        for i in range(4):
            f[f"fcs/lift[{i}]/cmd"] = clamp(lift[i], 0, 1)
        f["fcs/elevator-cmd"], f["fcs/aileron-cmd"], f["fcs/pusher-cmd"] = elev, ail, push
        self.v.step()
        return self.phase != "LANDED"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rate", type=float, default=240.0, help="JSBSim Hz (lesson 8 used 240)")
    ap.add_argument("--pose-hz", type=float, default=60.0)
    ap.add_argument("--speedup", type=float, default=1.0)
    ap.add_argument("--no-wait", action="store_true")
    ap.add_argument("--viewer-port", type=int, default=P.PORT_TO_VIEWER)
    ap.add_argument("--listen-port", type=int, default=P.PORT_TO_PHYSICS)
    ap.add_argument("--logs", default=os.path.join(HERE, "..", "..", "logs"))
    args = ap.parse_args()

    v = JsbVehicle("quadplane", Heightmap.load(TERRAIN), rate_hz=args.rate)
    # On the ground (AGL 0.16 m like lesson 8's ground.xml), west of center: the right turn in
    # CRUISE (radius ~65 m) and the long back-transition then stay over the map.
    v.place(-60.0, -40.0, agl=0.16, heading_deg=0.0)
    pilot = VtolPilot(v)
    br = PhysicsBridge(viewer_port=args.viewer_port, listen_port=args.listen_port)
    log = RunLogger(args.logs, run_name="quadplane", seed=0,
                    meta={"physics": "jsbsim", "model": "quadplane", "vehicle_id": VEHICLE_ID,
                          "physics_hz": args.rate, "pose_hz": args.pose_hz})
    send = lambda: br.send_pose(v.t, VEHICLE_ID, *v.godot_pose())
    if not args.no_wait:
        print(f"waiting for the viewer on UDP {args.listen_port} ...")
        br.wait_for_viewer(send_idle_pose=send)
    print("phase HOVER_UP")
    steps = max(1, round(args.rate / args.pose_hz))
    next_wall, k, flying = time.monotonic(), 0, True
    while flying and v.t < 150:
        br.poll(v.t)                                       # commands are ignored in this script
        for _ in range(steps):
            flying = pilot.step() and flying
        s = v.state()
        code = PHASES.index(pilot.phase)
        log.write("pose", v.t, e=s["e"], n=s["n"], h_asl=s["h_asl"], agl=s["agl"], airspeed=s["airspeed"],
                  pitch_deg=s["pitch_deg"], roll_deg=s["roll_deg"], heading_deg=s["heading_deg"], phase=pilot.phase)
        send()
        if k % max(1, round(args.pose_hz / 10)) == 0:
            send_telemetry(br, v.t, VEHICLE_ID, TELEM_FLIGHT,
                           [s["airspeed"], s["alpha_deg"], s["agl"], s["terrain"], 0.0, float(code), 0.0])
        k += 1
        if args.speedup > 0:
            next_wall += steps * v.dt / args.speedup
            time.sleep(max(0.0, next_wall - time.monotonic()))
    for _ in range(30):                                    # let the viewer show LANDED for a moment
        send()
        send_telemetry(br, v.t, VEHICLE_ID, TELEM_FLIGHT, [0, 0, v.state()["agl"], v.terrain_m, 0, 6.0, 0])
        time.sleep(0.05 if args.speedup > 0 else 0)
    br.tx.sendto(P.pack_simple(P.MSG_BYE, br._next(), v.t), br.viewer)
    log.close()
    s = v.state()
    print(f"landed at ENU ({s['e']:.1f}, {s['n']:.1f}), {math.hypot(s['e'], s['n']):.1f} m from the start point, t={v.t:.1f} s")


if __name__ == "__main__":
    main()
