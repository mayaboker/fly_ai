"""
jsbsim_vehicle.py - one JSBSim aircraft on the shared terrain (Module 11).

    v = JsbVehicle("trainer", hm, rate_hz=120)
    v.place(e=-105, n=-60, h_asl=35, heading_deg=0, airspeed=16, alpha_deg=1.05)
    v.step()                       # samples the terrain under the aircraft, then fdm.run()
    pos, quat, vel = v.godot_pose()
    s = v.state()                  # SI units + degrees, for autopilots and logs

What this adds on top of plain JSBSim:
  * initial conditions from ENU meters (the course world) instead of lat/lon/feet
  * the terrain feed: before every step, position/terrain-elevation-asl-ft is set to the
    shared heightmap height under the aircraft, so JSBSim's AGL and ground contact match
    the terrain Godot draws
  * conversion to the wire format with robosim.frames (convert once, on the physics side)
"""
import math
import os

import jsbsim

from .frames import FT, GeoOrigin, jsbsim_state_to_godot, enu_to_godot_pos

# The course's geographic anchor: ENU (0, 0, 0) = this lat/lon at 0 m above sea level.
# Godot y is then height above sea level, and the terrain heights are ASL too.
LAT0_DEG, LON0_DEG = 32.08, 34.80


def enu_to_geo(origin, e, n):
    """Inverse of GeoOrigin.to_enu for the horizontal part: ENU (e, n) m -> (lat, lon) rad."""
    lat, lon, _ = origin.from_enu(e, n, 0.0)          # robosim.frames (shared code)
    return lat, lon


class JsbVehicle:
    def __init__(self, model, heightmap=None, rate_hz=120.0, root=None):
        root = root or os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
        self.fdm = jsbsim.FGFDMExec(os.path.abspath(root))   # expects root/aircraft/<model>/<model>.xml
        self.fdm.set_debug_level(0)
        if not self.fdm.load_model(model):
            raise RuntimeError(f"cannot load JSBSim model {model!r} from {root}/aircraft")
        self.fdm.set_dt(1.0 / rate_hz)
        self.dt = 1.0 / rate_hz
        self.hm = heightmap
        self.origin = GeoOrigin(math.radians(LAT0_DEG), math.radians(LON0_DEG), 0.0)
        self.terrain_m = 0.0
        self._started = False

    # ---------------------------------------------------------------- terrain
    def terrain_at(self, e, n):
        return float(self.hm.height_at(e, n)) if self.hm is not None else 0.0

    def feed_terrain(self):
        """Write the heightmap height under the aircraft into JSBSim. Call before every run()."""
        e, n, _ = self.enu()
        self.terrain_m = self.terrain_at(e, n)
        self.fdm["position/terrain-elevation-asl-ft"] = self.terrain_m / FT

    # ---------------------------------------------------------------- initial conditions
    def place(self, e, n, h_asl=None, agl=None, heading_deg=0.0, airspeed=0.0,
              alpha_deg=0.0, gamma_deg=0.0, roll_deg=0.0, controls=None):
        """Initial conditions from ENU meters. Give either h_asl or agl."""
        f = self.fdm
        lat, lon = enu_to_geo(self.origin, e, n)
        self.terrain_m = self.terrain_at(e, n)
        h = h_asl if h_asl is not None else self.terrain_m + agl
        f["ic/lat-geod-rad"] = lat
        f["ic/long-gc-rad"] = lon
        f["ic/terrain-elevation-ft"] = self.terrain_m / FT
        f["ic/h-sl-ft"] = h / FT
        f["ic/psi-true-deg"] = heading_deg
        f["ic/phi-deg"] = roll_deg
        if airspeed > 0:
            f["ic/vt-fps"] = airspeed / FT
            f["ic/alpha-deg"] = alpha_deg
            f["ic/gamma-deg"] = gamma_deg            # theta = alpha + gamma (wings level)
        else:
            f["ic/u-fps"] = f["ic/v-fps"] = f["ic/w-fps"] = 0.0
            f["ic/theta-deg"] = 0.0
        for k, v in (controls or {}).items():
            f[k] = v
        if self._started:
            f.reset_to_initial_conditions(0)    # a second place(): also resets sim time and filters
        elif not f.run_ic():
            raise RuntimeError("run_ic failed")
        self._started = True
        for k, v in (controls or {}).items():  # again: a reset puts the FCS inputs back to 0
            f[k] = v
        self.feed_terrain()

    # ---------------------------------------------------------------- stepping
    def step(self):
        self.feed_terrain()
        self.fdm.run()

    @property
    def t(self):
        return self.fdm.get_sim_time()

    # ---------------------------------------------------------------- outputs
    def enu(self):
        f = self.fdm
        return self.origin.to_enu(f["position/lat-geod-rad"], f["position/long-gc-rad"],
                                  f["position/h-sl-ft"] * FT)

    def godot_pose(self):
        """(pos, quat_xyzw, vel) in the Godot world frame, meters and m/s."""
        f = self.fdm
        pos, quat = jsbsim_state_to_godot(f, self.origin)
        v_enu = (f["velocities/v-east-fps"] * FT, f["velocities/v-north-fps"] * FT,
                 -f["velocities/v-down-fps"] * FT)
        return pos, quat, enu_to_godot_pos(v_enu)

    def state(self):
        """Everything an autopilot or a log needs, in SI units and degrees."""
        f = self.fdm
        e, n, u = self.enu()
        return {
            "e": e, "n": n, "h_asl": u,
            "agl": f["position/h-agl-ft"] * FT,
            "terrain": self.terrain_m,
            "roll_deg": f["attitude/phi-deg"],
            "pitch_deg": f["attitude/theta-deg"],
            "heading_deg": f["attitude/psi-deg"] % 360.0,
            "p": f["velocities/p-rad_sec"], "q": f["velocities/q-rad_sec"], "r": f["velocities/r-rad_sec"],
            "airspeed": f["velocities/vt-fps"] * FT,
            "groundspeed": f["velocities/vg-fps"] * FT,
            "climb_rate": f["velocities/h-dot-fps"] * FT,
            "alpha_deg": f["aero/alpha-deg"],
            "u": f["velocities/u-fps"] * FT, "v": f["velocities/v-fps"] * FT,
        }
