"""
test_terrain_feed.py - does JSBSim's ground match the shared heightmap? (Module 11)

  1. AGL:     fly the 'lap' route for 60 s; at every step JSBSim's h-agl must equal
              h-sl minus the heightmap height under the aircraft
  2. contact: drop the stationary trainer at points with different terrain heights;
              it must come to rest on that terrain, not on JSBSim's default sea-level ground
  3. control: the same drop WITHOUT the feed lands at 0 m (shows what the feed fixes)
  4. prints the heightmap height at the probe points that plane_lab.tscn -- --probe-terrain
              raycasts, so both engines can be compared (terrain.md validation)

Run from robosim/physics:   python tests/test_terrain_feed.py
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(HERE, "..", "sims"))
from robosim.terrain import Heightmap                               # noqa: E402
from robosim.jsbsim_vehicle import JsbVehicle                       # noqa: E402
from robosim.frames import FT                                       # noqa: E402
import plane_jsbsim as PJ                                           # noqa: E402

PROBES = [(0.0, 0.0), (-112.0, 20.0), (115.0, -40.0), (30.5, 77.25), (-120.0, -120.0)]   # ENU (e, n)

hm = Heightmap.load(os.path.join(HERE, "..", "..", "data", "terrain", "heightmap.png"))

# ---- 1. AGL along a real flight
v = JsbVehicle("trainer", hm)
scen, ap = PJ.Lap(), PJ.Autopilot(v.dt)
v.place(**scen.start, airspeed=16, alpha_deg=PJ.TRIM["alpha_deg"],
        controls={"fcs/elevator-cmd": PJ.TRIM["elevator"], "fcs/pusher-cmd": PJ.TRIM["pusher"]})
worst_fed, worst_now, top = 0.0, 0.0, 0.0
while v.t < 60:
    s = v.state()
    scen.update(v.t, s, ap)
    v.fdm["fcs/elevator-cmd"], v.fdm["fcs/aileron-cmd"], v.fdm["fcs/pusher-cmd"] = ap.update(s)
    v.step()                       # feeds the terrain at the position BEFORE this step, then runs
    e, n, h = v.enu()
    agl = v.fdm["position/h-agl-ft"] * FT
    worst_fed = max(worst_fed, abs(agl - (h - v.terrain_m)))          # against the height we fed
    worst_now = max(worst_now, abs(agl - (h - hm.height_at(e, n))))  # against the new position
    top = max(top, hm.height_at(e, n))
print(f"1. AGL along 60 s of the lap (terrain up to {top:.1f} m under the aircraft):")
print(f"   vs the fed height:            worst error {worst_fed * 100:.3f} cm")
print(f"   vs the terrain after the step: worst error {worst_now * 100:.2f} cm "
      f"(one-step lag: the aircraft moves {16 * v.dt * 100:.0f} cm per step)")
assert worst_fed < 0.01 and worst_now < 0.10, "JSBSim AGL does not follow the heightmap"


# ---- 2. + 3. drop tests
def drop(e, n, feed=True):
    d = JsbVehicle("trainer", hm if feed else None)
    d.place(e, n, h_asl=hm.height_at(e, n) + 0.3)          # 0.3 m above the real terrain, no speed
    while d.t < 6.0:
        d.step()
    return d.state()["h_asl"]


print("2./3. drop tests (trainer at rest, CG height):")
for e, n in PROBES[1:4]:
    ter = hm.height_at(e, n)
    with_feed = drop(e, n, True)
    without = drop(e, n, False)
    print(f"   ENU ({e:7.2f}, {n:7.2f})  terrain {ter:6.3f} m   rests at {with_feed:6.3f} m with feed "
          f"({with_feed - ter:+.3f} above terrain)   {without:6.3f} m without feed")
    assert 0.0 < with_feed - ter < 0.3, "aircraft does not rest on the fed terrain"
    assert without < 0.3, "control case should fall to sea level"

# ---- 4. probe heights for the Godot comparison
print("4. heightmap probes (compare with: godot --headless --path ../godot res://scenes/plane_lab.tscn -- --probe-terrain):")
for e, n in PROBES:
    print(f"   ENU ({e:7.2f}, {n:7.2f})  Godot (x={e:7.2f}, z={-n:7.2f})  h = {hm.height_at(e, n):.4f} m")
print("terrain feed: all tests pass")
