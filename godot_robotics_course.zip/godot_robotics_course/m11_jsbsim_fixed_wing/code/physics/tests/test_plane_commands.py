"""
test_plane_commands.py - plane_jsbsim.py obeys PAUSE / RESUME / RESET and reacts to a contact.
A tiny fake viewer (Python, no Godot) plays SimBridge's part over UDP.

Run from robosim/physics:   python tests/test_plane_commands.py
(uses ports 9210/9211 so it does not disturb a running viewer on 9001/9002)
"""
import os
import socket
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
from robosim import protocol as P                                   # noqa: E402
from robosim.telemetry import MSG_TELEMETRY, unpack_telemetry       # noqa: E402

VIEW, PHYS = 9210, 9211
rx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
rx.bind(("127.0.0.1", VIEW))
rx.settimeout(0.05)
tx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
seq = 0
proc = subprocess.Popen([sys.executable, os.path.join(HERE, "..", "sims", "plane_jsbsim.py"), "--scenario", "crash",
                         "--duration", "60", "--viewer-port", str(VIEW), "--listen-port", str(PHYS),
                         "--logs", os.path.join(HERE, "..", "..", "logs", "test")],
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)


def send(pkt):
    tx.sendto(pkt, ("127.0.0.1", PHYS))


def nxt():
    global seq
    seq += 1
    return seq


def listen(seconds):
    """Collect packets for a while. Returns (poses, acks, telemetry)."""
    poses, acks, tel = [], [], []
    t_end = time.monotonic() + seconds
    while time.monotonic() < t_end:
        try:
            data, _ = rx.recvfrom(2048)
        except socket.timeout:
            continue
        m = P.unpack(data)
        if m is None:
            continue
        if m["type"] == P.MSG_POSE:
            poses.append(m)
        elif m["type"] == P.MSG_ACK:
            acks.append(m["acked_seq"])
        elif m["type"] == MSG_TELEMETRY:
            tel.append(unpack_telemetry(data))
    return poses, acks, tel


def command(cmd):
    """Send a command, wait for its ACK, return the poses that arrived meanwhile."""
    s = nxt()
    send(P.pack_command(s, 0.0, 3, cmd))
    poses, acks, _ = listen(0.3)
    assert s in acks, f"command {cmd} was not ACKed"
    return poses


try:
    time.sleep(1.5)                       # let JSBSim load
    send(P.pack_simple(P.MSG_HELLO, nxt(), 0.0))
    poses, _, tel = listen(1.0)
    assert poses and poses[0]["vehicle_id"] == 3, "no poses for vehicle 3"
    t_run = poses[-1]["t_sim"]
    print(f"running:  {len(poses)} poses in the first second, t_sim {t_run:.2f}, telemetry packets {len(tel)}")

    command(P.CMD_PAUSE)
    p1, _, _ = listen(0.5)
    assert all(p["flags"] & P.POSE_FLAG_PAUSED for p in p1[2:]), "PAUSED flag missing"
    assert p1[-1]["t_sim"] == p1[2]["t_sim"], "sim time moved while paused"
    print(f"paused:   t_sim frozen at {p1[-1]['t_sim']:.2f}, PAUSED flag set")

    command(P.CMD_RESUME)
    p2, _, _ = listen(0.5)
    assert p2[-1]["t_sim"] > p1[-1]["t_sim"], "did not resume"
    print(f"resumed:  t_sim {p2[-1]['t_sim']:.2f}")

    p3 = command(P.CMD_RESET)
    p3 += listen(0.3)[0]
    first = [p for p in p3 if p["flags"] & P.POSE_FLAG_RESET]
    assert first and first[0]["t_sim"] < 0.1, "no RESET pose with t_sim ~ 0"
    print(f"reset:    RESET flag seen, t_sim back to {first[0]['t_sim']:.3f}")

    # Godot would send this when the Hull touches the mast; any pose time is fine for the test
    send(P.pack_sensor(nxt(), p3[-1]["t_sim"], 3, P.SENSOR_CONTACT, [1.0, 0.0, 0.0, 1.0, 0.0]))
    p4, _, tel = listen(0.6)
    assert tel and tel[-1]["values"][4] == 1.0, "crash flag not set in TELEMETRY"
    assert p4[-1]["flags"] & P.POSE_FLAG_PAUSED and p4[-1]["t_sim"] == p4[-3]["t_sim"], "still flying after crash"
    print(f"contact:  crash flag set, aircraft frozen at t_sim {p4[-1]['t_sim']:.2f}")
    print("plane commands: all tests pass")
finally:
    proc.terminate()
    out = proc.communicate(timeout=5)[0]
    if "CRASH" not in out:
        print(out)
