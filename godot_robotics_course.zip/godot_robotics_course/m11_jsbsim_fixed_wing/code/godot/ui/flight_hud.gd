class_name FlightHud
extends Control
## Flight HUD: heading, pitch, roll, altitude, speed - computed from the RENDERED node
## transform (what you see is what is checked), plus an attitude indicator and the
## TELEMETRY values (airspeed, alpha, AGL, crash, quadplane phase) when they arrive.

const PHASES := ["", "HOVER_UP", "TRANSITION", "CRUISE", "BACK_TRANS", "HOVER_DOWN", "LANDED"]

var values := {}               ## the last numbers shown, for tests and recorders
var _main: Label
var _telem: Label
var _status: Label
var _pitch_deg := 0.0
var _roll_deg := 0.0


## Godot basis of a model (nose -Z, top +Y) -> Vector3(heading_deg 0..360, pitch_deg, roll_deg).
## Inverse of the frames.md shortcut basis = Basis.from_euler(Vector3(theta, -psi, -phi)) (YXZ),
## so heading = -euler.y, pitch = euler.x, roll = -euler.z. Valid for |pitch| < 90 deg.
static func attitude_deg(b: Basis) -> Vector3:
	var e := b.orthonormalized().get_euler()        # default order YXZ
	return Vector3(fposmod(-rad_to_deg(e.y), 360.0), rad_to_deg(e.x), -rad_to_deg(e.z))


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_main = _label(Vector2(16, 12), 22)
	_telem = _label(Vector2(16, 76), 17)
	_status = _label(Vector2(16, 128), 17)
	_main.text = "waiting for physics ..."


func _label(pos: Vector2, size: int) -> Label:
	var l := Label.new()
	l.position = pos
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 6)
	add_child(l)
	return l


## Update from the plane node's global transform, its velocity (Godot frame, m/s), the
## terrain height under it (m) and the sim time it was rendered for.
func show_state(xf: Transform3D, vel: Vector3, terrain_h: float, t_sim: float) -> void:
	var att := attitude_deg(xf.basis)
	values = {"t_sim": t_sim, "heading_deg": att.x, "pitch_deg": att.y, "roll_deg": att.z,
		"alt_m": xf.origin.y, "agl_m": xf.origin.y - terrain_h, "speed_mps": vel.length()}
	_pitch_deg = att.y
	_roll_deg = att.z
	_main.text = "HDG %03.0f   PITCH %+5.1f   ROLL %+6.1f\nALT %5.1f m   AGL %5.1f m   SPD %4.1f m/s" % [
		att.x, att.y, att.z, values.alt_m, values.agl_m, values.speed_mps]
	queue_redraw()


## TELEMETRY code 1: airspeed, alpha, agl, terrain, crashed, phase, ...
func show_telemetry(v: PackedFloat32Array) -> void:
	if v.size() < 6:
		return
	var phase: String = PHASES[clampi(int(v[5]), 0, PHASES.size() - 1)]
	_telem.text = "airspeed %4.1f m/s   alpha %+4.1f deg   JSBSim AGL %5.1f m%s" % [
		v[0], v[1], v[2], ("\nphase  " + phase) if phase != "" else ""]
	if v[4] > 0.5:
		_status.text = "CRASH"
		_status.add_theme_color_override("font_color", Color(1, 0.3, 0.2))
	elif _status.text == "CRASH":
		_status.text = ""


func show_status(text: String) -> void:
	if _status.text != "CRASH":
		_status.text = text


func _draw() -> void:
	# attitude indicator, bottom-left: horizon line rotated by -roll, shifted by pitch
	var c := Vector2(110, size.y - 110)
	var r := 80.0
	draw_circle(c, r, Color(0, 0, 0, 0.35))
	var shift := clampf(_pitch_deg * 2.0, -r, r)                  # 2 px per degree
	var dir := Vector2.RIGHT.rotated(deg_to_rad(-_roll_deg))
	var nrm := Vector2(dir.y, -dir.x)                               # "up" on the horizon
	var mid := c - nrm * shift                                      # nose up -> horizon moves down
	draw_line(mid - dir * r * 0.95, mid + dir * r * 0.95, Color(0.4, 0.8, 1.0), 3.0)
	draw_line(c - Vector2(30, 0), c - Vector2(8, 0), Color.YELLOW, 3.0)   # fixed aircraft symbol
	draw_line(c + Vector2(8, 0), c + Vector2(30, 0), Color.YELLOW, 3.0)
	draw_circle(c, 3.0, Color.YELLOW)
