extends Node3D
## Module 11 viewer: the JSBSim plane (vehicle 3) or quadplane (vehicle 4) over the shared terrain.
##   - places the vehicle from POSE with the Module 5 render clock + SimBridge.sample()
##   - main view: chase or onboard camera (action camera_next, key C); onboard picture-in-picture
##     from a Module 6 CameraRig on the vehicle's fpv_cam mount
##   - HUD computed from the RENDERED transform; TELEMETRY adds airspeed, alpha, crash, phase
##   - obstacles exist only here: an Area3D (plus a sweep) reports SENSOR_CONTACT to Python
## Actions (Module 2 project): camera_next (C), pause_toggle (P), reset (R).
## Test options (after "--" on the command line):
##   --ports=9210,9211    listen port, physics port         --vehicle=4   quadplane
##   --hud-log=PATH       write the HUD numbers every frame (Module 11 Check)
##   --probe-terrain      print terrain heights at the probe points, then quit
##   --screenshot=PATH@T  save the main view (+ _onboard.png) at sim time T    --quit-after=SECONDS

@export var vehicle_id := 3
## Radio masts, ENU meters: Vector4(east, north, height, radius). Only Godot knows them.
@export var masts: Array[Vector4] = [Vector4(-40, 0, 45, 0.6), Vector4(60, 60, 30, 0.6)]

const OBSTACLE_LAYER := 2                       # Module 2 layer names: 1 terrain, 2 obstacles
const PROBES := [Vector2(0, 0), Vector2(-112, 20), Vector2(115, -40), Vector2(30.5, 77.25), Vector2(-120, -120)]

@onready var bridge: TelemetryBridge = $SimBridge
@onready var terrain: HeightmapTerrain = $Terrain
@onready var plane: Vehicle = $Plane
@onready var view_cam: Camera3D = $ViewCam
@onready var hud: FlightHud = $UI/Hud
@onready var pip: TextureRect = $UI/Pip

var clock := RenderClock.new()
var t_render := -1.0
var onboard: CameraRig
var hull: Area3D
var hull_shape: CollisionShape3D
var _onboard_main := false
var _args := {}
var _recorder: FileAccess
var _contact_sent_wall := 0.0
var _was_stale := true
var _got_pose := false
var _shot_done := false
var _paused_flag := false
var _prev_hull_xf := Transform3D()


func _enter_tree() -> void:
	for a in OS.get_cmdline_user_args():
		var kv := a.trim_prefix("--").split("=", true, 1)
		_args[kv[0]] = kv[1] if kv.size() > 1 else ""
	if _args.has("ports"):
		var p: PackedStringArray = _args.ports.split(",")
		$SimBridge.listen_port = int(p[0])
		$SimBridge.physics_port = int(p[1])
	if _args.has("vehicle"):
		vehicle_id = int(_args.vehicle)
	if vehicle_id == 4:                           # swap in Module 2's quadplane scene
		var old := $Plane
		remove_child(old)
		old.free()
		var qp: Node3D = load("res://vehicles/quadplane.tscn").instantiate()
		qp.name = "Plane"
		add_child(qp)


func _ready() -> void:
	_build_masts()
	_build_hull()
	onboard = CameraRig.new()                    # Module 6: own SubViewport + Camera3D
	onboard.camera_name = "onboard"
	onboard.mode = CameraRig.Mode.RIGID
	onboard.image_size = Vector2i(640, 360)
	onboard.fov_v_deg = 60.0
	plane.mount("fpv_cam").add_child(onboard)
	pip.texture = onboard.viewport.get_texture()
	bridge.pose_received.connect(_on_pose)
	bridge.telemetry_received.connect(_on_telemetry)
	bridge.physics_reset.connect(func() -> void:
		clock.reset()
		_prev_hull_xf = Transform3D())
	if _args.has("hud-log"):
		Engine.max_fps = 60
		_recorder = FileAccess.open(_args["hud-log"], FileAccess.WRITE)
		_recorder.store_line("t_sim,heading_deg,pitch_deg,roll_deg,alt_m,agl_m,speed_mps")
	if _args.has("probe-terrain"):
		_probe_terrain.call_deferred()


func _process(delta: float) -> void:
	var stale := bridge.is_stale()
	if stale != _was_stale:
		hud.show_status("NO DATA FROM PHYSICS" if stale else "")
		_was_stale = stale
	if not bridge.has_vehicle(vehicle_id):
		return
	_got_pose = true
	t_render = clock.advance(delta, bridge.latest_t_sim, _paused_flag)
	plane.global_transform = bridge.sample(vehicle_id, t_render)
	var x := plane.global_position
	hud.show_state(plane.global_transform, bridge.latest_velocity(vehicle_id),
			terrain.height_at_world(x.x, x.z), t_render)
	_update_view_cam(delta)
	onboard.sync_now()                           # the rig would also do this itself, later this frame
	_report_contact()
	_test_hooks()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("camera_next"):
		_onboard_main = not _onboard_main
	elif event.is_action_pressed("pause_toggle"):            # reliable: resent until ACKed
		bridge.send_command(vehicle_id, RsProtocol.CMD_RESUME if _paused_flag else RsProtocol.CMD_PAUSE)
	elif event.is_action_pressed("reset"):
		bridge.send_command(vehicle_id, RsProtocol.CMD_RESET)


# ------------------------------------------------------------------ cameras
func _update_view_cam(delta: float) -> void:
	if _onboard_main:                            # main view = the onboard camera's pose
		view_cam.global_transform = plane.mount("fpv_cam").global_transform
		return
	# chase: behind and above, following heading only (no roll), smoothed
	var fwd := -plane.global_basis.z
	var flat := Vector3(fwd.x, 0.0, fwd.z)
	flat = flat.normalized() if flat.length() > 0.1 else Vector3.FORWARD
	var want := plane.global_position - flat * 4.0 + Vector3.UP * 1.2
	var k := 1.0 - exp(-delta * 10.0)                       # lag behind 'want' ~ speed / 10
	var pos := want if view_cam.global_position.distance_to(want) > 30.0 \
			else view_cam.global_position.lerp(want, k)
	view_cam.global_transform = Transform3D(Basis.IDENTITY, pos).looking_at(
			plane.global_position + Vector3.UP * 0.3, Vector3.UP)


# ------------------------------------------------------------------ obstacles + contact
func _build_masts() -> void:
	var red := StandardMaterial3D.new()
	red.albedo_color = Color(0.85, 0.15, 0.1)
	var white := StandardMaterial3D.new()
	white.albedo_color = Color(0.95, 0.95, 0.95)
	for m in masts:
		var base := terrain.height_at(m.x, m.y)
		var body := StaticBody3D.new()
		body.collision_layer = 1 << (OBSTACLE_LAYER - 1)
		body.collision_mask = 0
		body.position = Vector3(m.x, base + m.z / 2.0, -m.y)          # ENU -> Godot
		var cs := CollisionShape3D.new()
		var shape := CylinderShape3D.new()
		shape.height = m.z
		shape.radius = m.w
		cs.shape = shape
		body.add_child(cs)
		var seg := 5.0                                              # red/white bands, 5 m each
		for i in int(ceil(m.z / seg)):
			var mi := MeshInstance3D.new()
			var cyl := CylinderMesh.new()
			cyl.top_radius = m.w
			cyl.bottom_radius = m.w
			cyl.height = minf(seg, m.z - i * seg)
			mi.mesh = cyl
			mi.material_override = red if i % 2 == 0 else white
			mi.position.y = -m.z / 2.0 + i * seg + cyl.height / 2.0
			body.add_child(mi)
		$Obstacles.add_child(body)


## An Area3D with the same box as the vehicle's Body shape (Module 2), watching obstacles only.
## The terrain is NOT in the mask: JSBSim owns the ground (terrain feed + its own contacts).
func _build_hull() -> void:
	var body_shape: CollisionShape3D = plane.get_node("Body/Shape")
	hull = Area3D.new()
	hull.name = "Hull"
	hull.collision_layer = 0
	hull.collision_mask = 1 << (OBSTACLE_LAYER - 1)
	hull.monitorable = false
	hull_shape = CollisionShape3D.new()
	hull_shape.shape = body_shape.shape
	hull_shape.transform = body_shape.transform
	hull.add_child(hull_shape)
	plane.add_child(hull)


func _report_contact() -> void:
	## SENSOR_CONTACT: hit, nx, ny, nz, depth. Sent every frame while touching, 5 Hz otherwise.
	## Two checks: the Area3D overlap (are we inside an obstacle now?) and a shape SWEEP from
	## last frame's pose to this one. At 16 m/s and 20 FPS the plane jumps 0.8 m per frame,
	## more than a 0.6 m mast radius: an overlap test alone can step right over the mast.
	var hit := not hull.get_overlapping_bodies().is_empty()
	var xf := hull_shape.global_transform
	var hit_xf := xf                                         # where the hull touched
	if _prev_hull_xf != Transform3D() and not hit:
		var q := PhysicsShapeQueryParameters3D.new()
		q.shape = hull_shape.shape
		q.transform = _prev_hull_xf
		q.motion = xf.origin - _prev_hull_xf.origin
		q.collision_mask = hull.collision_mask
		var frac := get_world_3d().direct_space_state.cast_motion(q)
		hit = frac.size() == 2 and frac[1] < 1.0
		if hit:
			hit_xf = _prev_hull_xf.translated(q.motion * frac[1])
	_prev_hull_xf = xf
	var now := Time.get_ticks_msec() / 1000.0
	if not hit and now - _contact_sent_wall < 0.2:
		return
	_contact_sent_wall = now
	var n := Vector3.ZERO
	if hit:
		var q2 := PhysicsShapeQueryParameters3D.new()
		q2.shape = hull_shape.shape
		q2.transform = hit_xf
		q2.collision_mask = hull.collision_mask
		q2.margin = 2.0                                          # find the nearest obstacle surface
		n = get_world_3d().direct_space_state.get_rest_info(q2).get("normal", Vector3.ZERO)
		hud.show_status("CONTACT")
	bridge.send_sensor(t_render, vehicle_id, RsProtocol.SENSOR_CONTACT,
			PackedFloat32Array([1.0 if hit else 0.0, n.x, n.y, n.z, 0.0]))


func _on_pose(vid: int, msg: Dictionary) -> void:
	if vid != vehicle_id:
		return
	clock.observe(msg.t_sim, Time.get_ticks_usec() / 1e6)
	var p: bool = msg.flags & RsProtocol.POSE_FLAG_PAUSED != 0
	if p != _paused_flag:
		_paused_flag = p
		hud.show_status("PAUSED" if p else "")


func _on_telemetry(vid: int, code: int, _t: float, values: PackedFloat32Array) -> void:
	if vid == vehicle_id and code == TelemetryBridge.TELEM_FLIGHT:
		hud.show_telemetry(values)


# ------------------------------------------------------------------ test hooks
func _test_hooks() -> void:
	if _recorder:
		var v := hud.values
		_recorder.store_line("%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f" % [v.t_sim, v.heading_deg, v.pitch_deg,
				v.roll_deg, v.alt_m, v.agl_m, v.speed_mps])
	if _args.has("screenshot") and not _shot_done:
		var parts: PackedStringArray = _args.screenshot.split("@")
		if t_render >= float(parts[1]):
			_shot_done = true
			await RenderingServer.frame_post_draw
			get_viewport().get_texture().get_image().save_png(parts[0])
			onboard.get_image().save_png(parts[0].get_basename() + "_onboard.png")
			print("screenshot saved at t_sim %.2f (%.0f FPS): %s" % [t_render, Engine.get_frames_per_second(), parts[0]])


func _physics_process(_delta: float) -> void:
	var t := Time.get_ticks_msec() / 1000.0
	if _args.has("quit-after") and t > float(_args["quit-after"]):
		_quit()
	if _got_pose and _args.has("hud-log") and bridge.seconds_since_pose() > 1.5:
		_quit()                                 # physics finished: stop recording


func _quit() -> void:
	if _recorder:
		_recorder.close()
		_recorder = null
	get_tree().quit()


func _probe_terrain() -> void:
	await get_tree().physics_frame
	await get_tree().physics_frame
	for p: Vector2 in PROBES:
		print("probe ENU (%7.2f, %7.2f)  ray %.4f m  bilinear %.4f m" % [p.x, p.y,
				terrain.raycast_height(p.x, -p.y), terrain.height_at(p.x, p.y)])
	_quit()
