class_name TerrainSkirt
extends MeshInstance3D
## Visual-only ground around the 256 m map, for vehicles that see far (Module 11).
##
## A plane 40 m up sees well past the map edge. Without a skirt, the camera shows the sky's
## "ground" color there, and the horizon looks wrong. Outside the map, both height samplers
## (robosim/terrain.py and HeightmapTerrain.height_at) clamp to the edge value, which means
## "the edge height continues outward". The skirt draws exactly that: every edge sample is
## extruded outward by skirt_m at its own height. No collision: nothing should fly there.

@export var terrain: HeightmapTerrain
@export var skirt_m := 3000.0
@export var color := Color(0.27, 0.33, 0.18)


func _ready() -> void:
	if terrain == null:
		push_error("TerrainSkirt: set the terrain property")
		return
	if terrain.size_px == 0:
		await terrain.terrain_built
	build()


func build() -> void:
	var n := terrain.size_px
	var h: PackedFloat32Array = terrain.heights
	var half := (n - 1) / 2.0 * terrain.meters_per_px
	var mpp := terrain.meters_per_px
	var L := skirt_m
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	st.set_color(color)
	st.set_normal(Vector3.UP)
	var quad := func(a: Vector3, b: Vector3, c: Vector3, d: Vector3) -> void:
		# Godot's front faces are clockwise seen from the camera. Seen from above, that means
		# cross(b - a, c - a).y < 0 (the same winding as HeightmapTerrain's cells).
		var tri: Array = [a, b, c, a, c, d] if (b - a).cross(c - a).y < 0.0 else [a, c, b, a, d, c]
		for v: Vector3 in tri:
			st.add_vertex(v)
	for i in n - 1:
		var x0 := (i - (n - 1) / 2.0) * mpp
		var x1 := x0 + mpp
		var nn0 := h[i]                                  # north edge, row 0
		var nn1 := h[i + 1]
		quad.call(Vector3(x0, nn0, -half), Vector3(x1, nn1, -half), Vector3(x1, nn1, -half - L), Vector3(x0, nn0, -half - L))
		var s0 := h[(n - 1) * n + i]                      # south edge, row n-1
		var s1 := h[(n - 1) * n + i + 1]
		quad.call(Vector3(x0, s0, half), Vector3(x1, s1, half), Vector3(x1, s1, half + L), Vector3(x0, s0, half + L))
		var w0 := h[i * n]                                # west edge, column 0 (here x0 is a z)
		var w1 := h[(i + 1) * n]
		quad.call(Vector3(-half, w0, x0), Vector3(-half, w1, x1), Vector3(-half - L, w1, x1), Vector3(-half - L, w0, x0))
		var e0 := h[i * n + n - 1]                        # east edge, column n-1
		var e1 := h[(i + 1) * n + n - 1]
		quad.call(Vector3(half, e0, x0), Vector3(half, e1, x1), Vector3(half + L, e1, x1), Vector3(half + L, e0, x0))
	for cxz: Vector2 in [Vector2(-1, -1), Vector2(1, -1), Vector2(1, 1), Vector2(-1, 1)]:
		var r := 0 if cxz.y < 0 else n - 1
		var c := 0 if cxz.x < 0 else n - 1
		var y := h[r * n + c]
		var a := Vector3(cxz.x * half, y, cxz.y * half)
		quad.call(a, a + Vector3(cxz.x * L, 0, 0), a + Vector3(cxz.x * L, 0, cxz.y * L), a + Vector3(0, 0, cxz.y * L))
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.vertex_color_is_srgb = true
	mat.roughness = 0.95
	mesh = st.commit()
	material_override = mat
