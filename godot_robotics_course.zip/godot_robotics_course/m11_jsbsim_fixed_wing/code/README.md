# Module 11 reference code

Paths mirror `robosim/`. Copy them over your project after you have tried the lab yourself.

```
code/
├── physics/
│   ├── robosim/jsbsim_vehicle.py     JsbVehicle: ENU initial conditions, terrain feed, Godot pose, SI state
│   ├── robosim/telemetry.py          TELEMETRY message (type 100); identical to reference/code
│   ├── sims/plane_jsbsim.py          the lab: trainer, vehicle 3, scenarios lap / check / crash
│   ├── sims/trim_trainer.py          do_simple_trim test + settle trim + hands-off proof
│   ├── sims/quadplane_jsbsim.py      stretch: lesson 8 VTOL mission, vehicle 4, phases in TELEMETRY
│   └── tests/test_terrain_feed.py, test_plane_commands.py
├── godot/
│   ├── bridge/telemetry_bridge.gd    TelemetryBridge extends SimBridge; identical to reference/code
│   ├── ui/flight_hud.gd              FlightHud: HUD from the rendered transform + attitude indicator
│   ├── terrain/terrain_skirt.gd      TerrainSkirt: visual apron around the map
│   └── scenes/plane_lab.tscn, plane_lab.gd
└── tools/compare_hud.py, plot_plane_run.py
```

## What else it needs from the project

| From | Files |
|---|---|
| reference | `robosim/{frames,protocol,logger}.py`, `bridge/protocol.gd`, `aircraft/trainer`, `aircraft/quadplane` (copied to `physics/aircraft/`) |
| Module 2 | `robosim/terrain.py`, `data/terrain/heightmap.{png,json}` and `range.json`, `godot/terrain/{heightmap_terrain,png16}.gd`, `godot/world/range_builder.gd`, `godot/vehicles/{vehicle.gd,plane.tscn,quadplane.tscn}`, `project.godot` (input actions `camera_next`, `pause_toggle`, `reset`; layer names) |
| Module 4 / reference | `robosim/bridge.py` and `godot/bridge/sim_bridge.gd` as in `reference/code` |
| Module 5 | `godot/bridge/render_clock.gd` |
| Module 6 | `godot/cameras/{camera_rig,camera_intrinsics}.gd` |

Run `godot --headless --path godot --import` once after copying (new `class_name` scripts).

## How to run

From `robosim/physics`:

```bash
python sims/trim_trainer.py                         # trim (sub-topic 02)
python tests/test_terrain_feed.py                   # terrain feed (sub-topic 04)
python tests/test_plane_commands.py                 # commands + contact, fake viewer on 9210/9211
python sims/plane_jsbsim.py                         # lap, waits for the viewer
python sims/plane_jsbsim.py --scenario crash        # into the mast
python sims/plane_jsbsim.py --no-wait --speedup 0   # no viewer, as fast as possible
python sims/quadplane_jsbsim.py                     # stretch, vehicle 4
```

From `robosim`:

```bash
godot --path godot res://scenes/plane_lab.tscn                     # vehicle 3
godot --path godot res://scenes/plane_lab.tscn -- --vehicle=4       # quadplane
godot --headless --path godot res://scenes/plane_lab.tscn -- --probe-terrain
godot --headless --path godot res://scenes/plane_lab.tscn -- --hud-log=/tmp/hud.csv
python tools/compare_hud.py logs/<run>_plane_check/pose.csv /tmp/hud.csv
python tools/plot_plane_run.py logs/<run>_plane_lap
```

Viewer options after `--`: `--ports=L,P`, `--vehicle=4`, `--hud-log=PATH`, `--probe-terrain`, `--screenshot=PATH@T_SIM`, `--quit-after=SECONDS`. Keys: C camera, P pause/resume, R reset.

## What was verified, and how

Tested with Godot 4.7.2 (headless, and the Compatibility renderer on Mesa llvmpipe under `xvfb-run`), JSBSim 1.3.1, Python 3.11, on ports 9210/9211 (quadplane 9220/9221). The project used for the tests was assembled from `reference/` plus the Module 2, 4, 5 and 6 code folders as listed above.

| Test | Result |
|---|---|
| `trim_trainer.py` | `do_simple_trim` raises `TrimFailureError`; settle trim α 1.054°, elevator 0.0046, pusher 0.1643; 30 s hands-off: 59.72–60.00 m, 15.91–16.08 m/s. With the FCS warmed first: 59.99–60.01 m |
| `test_terrain_feed.py` | pass: AGL vs fed height 0.020 cm; after-step lag 5.93 cm; drops rest +0.108 m above 8.535, 10.899, 1.744 m terrain; without feed at 0.108 m ASL |
| `--probe-terrain` | Godot bilinear = Python at 5 points; ray within 0.3 mm |
| HUD check (`check` scenario, headless viewer, `compare_hud.py`) | PASS. Worst: heading 0.0008°, pitch 0.0001°, roll 0.0001°, altitude 0.0001 m, speed 0.0019 m/s, AGL 0.062 m |
| `lap`, 90 s, no viewer | no crash; min AGL 14.4 m; 26.4–44.6 m ASL; 14.9–17.9 m/s |
| `crash` with headless viewer (60 FPS) | contact reported for pose t = 5.54 s, decided at 5.57 s, normal (0.00, −0.02, 1.00) |
| `crash` with software-rendered viewer (1–2 FPS) | detected in all 3 runs thanks to the sweep; up to 0.97 s of sim time late. An earlier overlap-only version missed the mast at 2 FPS |
| `test_plane_commands.py` | pass: PAUSE/RESUME/RESET, contact → crash flag |
| `quadplane_jsbsim.py` + viewer `--vehicle=4` (screenshot) | phases at 15.1 / 18.0 / 28.0 / 46.5 / 72.5 s; ≥ 27 m AGL in wing-borne flight; HUD shows the phase |
| Screenshots (xvfb) | chase view, HUD, attitude indicator, onboard PiP, skirt, range, masts: looked at, correct signs (right bank: green tip down, horizon right end up) |

Not tested here:

- Keyboard input (C, P, R) in a window. The same commands were tested through UDP by `test_plane_commands.py`, and the camera toggle is three lines.
- Frame rate on a real GPU. The software renderer ran the lab at 1–3 FPS; that number says nothing about your machine.
- Terrain3D (the course treats it as optional; this lab uses Module 2's fallback terrain).

## Proposed shared changes

Items 1–3 were adopted into `reference/`: `GeoOrigin.from_enu` (now used by `jsbsim_vehicle.enu_to_geo`), a bridge where any valid viewer packet counts as alive and `SimBridge` says HELLO again on the first pose of each physics session (so `plane_jsbsim.py` uses the shared `wait_for_viewer()`), and TELEMETRY (type 100, codes 1–3) documented in `reference/protocol.md`. Still open:

4. `SimBridge`: a public `latest_velocity(id)` and `seconds_since_pose()` (now in `TelemetryBridge`).
