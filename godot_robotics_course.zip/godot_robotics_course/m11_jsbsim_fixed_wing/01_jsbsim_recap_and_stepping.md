# 01 JSBSim recap: the trainer, stepping, controls and state

Modules 9 and 10 used PyBullet, a rigid-body engine. You gave it masses and contacts, and you computed the propeller forces yourself. A fixed-wing aircraft needs more than that. Lift and drag depend on airspeed, angle of attack and air density. Stability comes from the moments those forces make. JSBSim is a flight dynamics model built for exactly this: it computes aerodynamic forces from coefficient tables, has a standard atmosphere, integrates the equations of motion on a rotating, round Earth, and has simple ground reactions. That is why the course uses it for the plane.

This page recaps what you need from lessons 7–8 of the companion JSBSim course. If any line here is new to you, do those lessons first.

## The rule does not change

```
 Python (owns time and dynamics)                       Godot (owns the scene)
 ───────────────────────────────                       ──────────────────────────
 JSBSim trainer, 120 Hz ── POSE 60 Hz (Godot frame) ─▶ plane node, cameras, HUD
 autopilot, terrain feed ◀─ SENSOR_CONTACT ──────────── obstacles (Area3D)
 crash decision          ◀─ COMMAND pause/reset ─────── keys
```

JSBSim is the only thing that moves the plane. Godot never integrates anything.

## The trainer in one table

`reference/code/aircraft/trainer/trainer.xml` is the lesson 7 aircraft: a small electric pusher, built with the classic coefficient build-up (`force = q̄ · S · C`).

| Item | Value | Why it matters here |
|---|---|---|
| Mass | 2.5 kg | weight 24.5 N |
| Wing | 1.6 m span, 0.25 m chord, 0.40 m² | Godot's `plane.tscn` (Module 2) has the same size |
| Stall | CL max 1.45 at α ≈ 15° | √(2W / (ρ S CLmax)) ≈ 8.3 m/s at sea level; we cruise at 16 m/s |
| Propulsion | no `<engine>`; the pusher is an `<external_reactions>` force, max 15 N, first-order lag | matters for trimming (sub-topic 02) |
| Ground | four STRUCTURE contacts: nose, tail, two wing tips | the plane can rest and "crash" on JSBSim's ground |
| Controls | `fcs/elevator-cmd`, `fcs/aileron-cmd` (−1…1), `fcs/pusher-cmd` (0…1) | no rudder, no flaps |

Two sign conventions catch everybody once:

| Property | + means | Effect |
|---|---|---|
| `fcs/elevator-cmd` | trailing edge **down** | nose **down**. To climb you command a negative elevator. |
| `fcs/aileron-cmd` | roll **right** | right wing goes down |

## Loading and stepping

JSBSim looks for `<root>/aircraft/<model>/<model>.xml`. In the course project the root is `robosim/physics/`, so the models live in `robosim/physics/aircraft/`.

```python
import jsbsim
fdm = jsbsim.FGFDMExec("physics")      # root folder that contains aircraft/
fdm.set_debug_level(0)                 # silence most of the console output
fdm.load_model("trainer")
fdm.set_dt(1 / 120)                    # 120 Hz is also JSBSim's default
# ... initial conditions (sub-topic 02) ...
fdm.run_ic()
while fdm.get_sim_time() < 60:
    fdm["fcs/pusher-cmd"] = 0.164
    fdm.run()                          # one step of dt
```

The course default for JSBSim is **120 Hz**, the course pose stream is 60 Hz. So the physics loop runs two JSBSim steps per pose:

```python
steps_per_pose = round(physics_hz / pose_hz)        # 120 / 60 = 2
for _ in range(steps_per_pose):
    autopilot_and_controls()
    vehicle.step()                                  # terrain feed + fdm.run()
bridge.send_pose(vehicle.t, 3, *vehicle.godot_pose())
next_wall += steps_per_pose * dt                    # real-time pacing (Module 5)
time.sleep(max(0, next_wall - time.monotonic()))
```

The physics rate is a per-vehicle parameter. The lesson 8 quadplane runs at 240 Hz because its lift motors need it. `quadplane_jsbsim.py` keeps 240 Hz and still sends poses at 60 Hz (four steps per pose).

Why not one JSBSim step per render frame? Because the render rate changes with the scene and the GPU. The physics must not. A fixed step keeps the flight identical whether Godot runs at 144 FPS, 30 FPS or not at all.

## Control inputs

The trainer's flight control system is three properties. Write them before each `run()`:

```python
fdm["fcs/elevator-cmd"] = elevator      # -1..1, + = nose down
fdm["fcs/aileron-cmd"]  = aileron       # -1..1, + = roll right
fdm["fcs/pusher-cmd"]   = pusher        # 0..1  -> 0..15 N after a 0.1 s lag
```

The autopilot from lesson 7 is three cascaded loops. `plane_jsbsim.py` keeps the gains and wraps them in a class:

| Outer loop | Inner loop | Output |
|---|---|---|
| altitude error → pitch command (−10…12°) | pitch error, pitch rate q | elevator |
| heading error → bank command (±30°) | bank error, roll rate p | aileron |
| airspeed error (PI) | — | pusher, around the trim value |

## Reading state

All state is in properties. Names end with their unit. Learn this short list; it is all the lab needs.

| Property | Meaning | Unit |
|---|---|---|
| `position/lat-geod-rad`, `position/long-gc-rad` | geodetic latitude, longitude | rad |
| `position/h-sl-ft` | height above sea level | ft |
| `position/h-agl-ft` | height above JSBSim's ground | ft |
| `attitude/phi-rad`, `theta-rad`, `psi-rad` (or `-deg`) | roll, pitch, true heading | rad / deg |
| `velocities/vt-fps` | true airspeed | ft/s |
| `velocities/vg-fps` | horizontal ground speed | ft/s |
| `velocities/v-north-fps`, `v-east-fps`, `v-down-fps` | velocity in the local NED frame | ft/s |
| `velocities/u-fps`, `v-fps`, `w-fps` | velocity in body axes (FRD) | ft/s |
| `velocities/p-rad_sec`, `q-rad_sec`, `r-rad_sec` | body rates (FRD) | rad/s |
| `velocities/h-dot-fps` | climb rate | ft/s |
| `aero/alpha-deg`, `aero/beta-deg` | angle of attack, sideslip | deg |

The course wraps these in `robosim/jsbsim_vehicle.py`. `JsbVehicle.state()` returns one dictionary in SI units and degrees, so the autopilot and the logs never see feet:

```python
from robosim.jsbsim_vehicle import JsbVehicle
v = JsbVehicle("trainer", heightmap, rate_hz=120)
v.place(e=-112, n=-60, h_asl=35, heading_deg=0, airspeed=16, alpha_deg=1.054)
s = v.state()
print(s["airspeed"], s["alpha_deg"], s["agl"], s["heading_deg"])   # m/s, deg, m, deg
```

Keep two speeds apart. `airspeed` (`vt-fps`) is relative to the air, and it is what the wing feels and what the autopilot holds. The pose on the wire carries the **ground** velocity. With no wind they are equal; with wind they are not, and the HUD must say which one it shows (sub-topic 06).

## Try it

- Run `python sims/trim_trainer.py` once (sub-topic 02 explains it), then fly the trainer hands-off from that trim for 60 s with `fdm.run()` in a loop and print `h-sl-ft` every 5 s. Is it level?
- Add a 1 s elevator pulse of −0.2 at t = 2 s. Plot altitude. You should see the slow phugoid from lesson 7.
- Change `fdm.set_dt(1/60)` and repeat. Does the altitude trace change? By how much at t = 60 s? That difference is why the step size belongs in `run.json`.
- Print `velocities/vt-fps` and `velocities/vg-fps` during a steep climb (pitch 8°). Why is `vg` smaller than `vt` even with no wind? (Hint: `vg` is horizontal only.) Which one should a HUD call "speed"?

## References

- JSBSim reference manual and property list: <https://jsbsim-team.github.io/jsbsim-reference-manual/>
- JSBSim Python API (`FGFDMExec`): <https://jsbsim-team.github.io/jsbsim/>
- Companion course, lessons 7 (`fly_plane.py`) and 8 (`fly_vtol.py`)
- [Frames cheat sheet](../reference/frames.md), [Module 5: time and rates](../m05_time_rates/README.md)
