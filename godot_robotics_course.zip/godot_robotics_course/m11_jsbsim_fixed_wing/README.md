# Module 11: JSBSim fixed-wing lab (8 h)

## What you will build

The JSBSim "trainer" from the companion JSBSim course flies a climb, turn and descent over the shared terrain, and Godot draws it with a chase camera, an onboard camera and a flight HUD. JSBSim's ground follows the Godot terrain because Python feeds it the heightmap height every step. Obstacles exist only in Godot: when the plane touches one, Godot reports a contact and Python decides that the flight is over. Then you prove that the HUD shows JSBSim's numbers, at three steady states.

![The plane lab: chase view, HUD, attitude indicator and onboard picture-in-picture](img/plane_lab_chase.png)

## Prerequisites

- Modules 1–8. You need the test range (Module 2: terrain, `plane.tscn`, `quadplane.tscn`), the JSBSim → Godot conversion (Module 3), the bridge (Module 4, as in `reference/code`), `RenderClock` (Module 5), `CameraRig` (Module 6) and the contact sensor idea (Module 8).
- **Lessons 7–8 of the companion course *JSBSim from zero to quad and VTOL*.** This module flies their aircraft and reuses their autopilot. Sub-topic 01 recaps the essentials, but it does not teach coefficient build-up again.
- The JSBSim models in [`reference/code/aircraft`](../reference/code/aircraft) copied to `robosim/physics/aircraft/`.

## Sub-topics

| File | Topic | Time |
|---|---|---:|
| [01_jsbsim_recap_and_stepping.md](01_jsbsim_recap_and_stepping.md) | The trainer model, loading it, stepping at 120 Hz, control inputs, reading state | 1 h |
| [02_initial_conditions_and_trim.md](02_initial_conditions_and_trim.md) | `ic/` properties vs initialize XML, `do_simple_trim` (and why it fails here), a settle trim | 1 h |
| [03_state_to_godot.md](03_state_to_godot.md) | `GeoOrigin`, `jsbsim_state_to_godot`, velocities, the HUD read back from the node | 0.75 h |
| [04_terrain_feed.md](04_terrain_feed.md) | `position/terrain-elevation-asl-ft` from the shared heightmap; testing it | 1 h |
| [05_obstacles_and_crash.md](05_obstacles_and_crash.md) | Obstacles only Godot knows: Area3D, a shape sweep, SENSOR_CONTACT, the crash decision | 0.75 h |
| [06_cameras_hud_telemetry.md](06_cameras_hud_telemetry.md) | Chase and onboard cameras, the terrain skirt, the HUD, the TELEMETRY extension | 1 h |
| [lab.md](lab.md) | `plane_jsbsim.py` + `plane_lab.tscn`, the scenario, the HUD check; quadplane stretch | 2.5 h |

## Deliverables

- `physics/robosim/jsbsim_vehicle.py` (new shared file). `physics/robosim/telemetry.py` and `godot/bridge/telemetry_bridge.gd` are already there from setup (shared code; this module adds code 1 = FLIGHT, see [protocol.md](../reference/protocol.md)).
- `physics/sims/plane_jsbsim.py` (vehicle id 3), `physics/sims/trim_trainer.py`.
- `physics/tests/test_terrain_feed.py`, `physics/tests/test_plane_commands.py`.
- `godot/scenes/plane_lab.tscn` + `plane_lab.gd`, `godot/ui/flight_hud.gd`, `godot/terrain/terrain_skirt.gd`.
- `tools/compare_hud.py`, `tools/plot_plane_run.py`.
- One `plane_lap` run folder with its `plane_run.png`, and the output of the HUD check.

## Check

All numbers come from the reference code in [code/](code/README.md) (Godot 4.7.2, JSBSim 1.3.1, Python 3.11).

1. **Trim.** `python sims/trim_trainer.py` reports that `do_simple_trim` fails for this model, then finds a 16 m/s trim. Flown hands-off for 30 s from that trim, the altitude stays within 0.5 m and the airspeed within 0.2 m/s. Reference: alpha 1.054°, elevator 0.0046, pusher 0.1643; altitude 59.72–60.00 m, airspeed 15.91–16.08 m/s.
2. **Terrain feed.** `python tests/test_terrain_feed.py` passes. JSBSim's AGL equals `h − terrain` to within 0.01 m (reference: 0.020 cm), and a trainer dropped at three points rests 0.1 m above the heightmap there (reference: +0.108 m at 8.535 m, 10.899 m and 1.744 m of terrain). The same probe points in Godot (`plane_lab.tscn -- --probe-terrain`) agree with Python within 1 mm.
3. **HUD matches JSBSim.** With the `check` scenario and the Godot HUD recorder, `tools/compare_hud.py` passes at all three steady states (level, 25° turn, 8° climb): heading, pitch and roll within 0.5°, altitude within 0.2 m, speed within 0.2 m/s. Reference worst errors: 0.0008°, 0.0001 m, 0.0019 m/s. Report your table.
4. **Obstacles.** In the `crash` scenario the plane hits the mast that only Godot knows about, Godot reports `SENSOR_CONTACT`, and Python logs a crash event and freezes the aircraft. Reference (60 FPS viewer): contact reported for the pose at t = 5.54 s, crash decided at t = 5.57 s.
5. **Commands.** `python tests/test_plane_commands.py` passes: PAUSE freezes sim time, RESUME continues, RESET restarts at t ≈ 0 with the RESET flag, a contact sets the crash flag.
6. **Lap.** The `lap` scenario flies 90 s without a crash, climbs, turns and descends over the border hills, and `tools/plot_plane_run.py` makes the plot. Reference: minimum AGL 14.4 m, altitude 26.4–44.6 m ASL.

## Common mistakes

- **Trusting `do_simple_trim` on a custom FCS.** It moves the engine throttles and the standard `-norm` control properties. If your model reads other properties, the trim cannot work, and the exception is the only hint. Check what the trim moves before you use it.
- **Feeding the terrain once.** `ic/terrain-elevation-ft` sets the ground for the initial condition only. Without `position/terrain-elevation-asl-ft` every step, JSBSim's ground stays at the start height while Godot's hills rise under the plane. In our drop test, the plane without the feed fell through 10 m of Godot terrain to sea level.
- **Comparing the HUD with "now".** The viewer draws about 25 ms behind the newest pose (Module 5). In a 16°/s turn that looks like a 0.38° heading error. Compare at the sim time the frame was drawn for; only then do you measure the conversion and not the latency.
- **An overlap test on a fast vehicle.** At 16 m/s and 20 FPS the plane moves 0.8 m per frame, more than the mast's radius. Use a shape sweep from the last pose to this one as well. Ours caught the mast even at 1 FPS.
- **Letting Godot decide the crash.** Godot only reports contact. The physics process owns the vehicle's state, so it sets the crash flag, logs it with the pose time, and stops or resets the dynamics.
- **Feet and knots on the wire.** Convert in Python with `robosim.frames`. The HUD shows meters and m/s because the wire carries nothing else.
