# 03 From JSBSim state to the Godot node, and back to the HUD

JSBSim speaks lat/lon, feet, NED and FRD Euler angles. Godot wants meters in its own frame and a quaternion for a model whose nose is −Z. Module 3 derived the conversion and tested it on single poses. This page uses it for a whole flight and adds two things a flying vehicle needs: velocity, and a way to prove that what the HUD shows is what JSBSim computed.

## One anchor for everything

The course world needs one geographic anchor. `robosim/jsbsim_vehicle.py` defines it:

```python
LAT0_DEG, LON0_DEG = 32.08, 34.80          # the JSBSim course's start point
origin = GeoOrigin(math.radians(LAT0_DEG), math.radians(LON0_DEG), 0.0)   # h0 = 0 m
```

`h0 = 0` is a choice with a consequence: ENU "up" is **height above sea level**, so Godot `y` is ASL too. The terrain heightmap is also ASL (0–20 m). Then three numbers line up without any offsets:

| Quantity | Python | Godot |
|---|---|---|
| aircraft height ASL | `position/h-sl-ft · 0.3048` | `plane.global_position.y` |
| terrain under it | `Heightmap.height_at(e, n)` | `HeightmapTerrain.height_at(e, n)` |
| AGL | `h_asl − terrain` (= JSBSim's `h-agl-ft`, see 04) | `y − terrain.height_at_world(x, z)` |

If you put the origin at the terrain's lowest point instead, everything still works, but every log column then needs a note saying "relative to what". Write `geo_origin` into `run.json` either way (`plane_jsbsim.py` does).

## Position and orientation: one call

```python
from robosim.frames import jsbsim_state_to_godot
pos, quat = jsbsim_state_to_godot(fdm, origin)    # Godot meters, (x, y, z, w)
```

Inside, as derived in Module 3 and listed in the [frames cheat sheet](../reference/frames.md):

```
p_enu     = origin.to_enu(lat, lon, h_sl · 0.3048)
R_enu_flu = T_ENU_NED · R_zyx(φ, θ, ψ) · D_FRD_FLU
pos       = M_GODOT_ENU · p_enu                          = (E, U, −N)
quat      = quat(M_GODOT_ENU · R_enu_flu · C_FLU_MODEL)
```

`plane_jsbsim.py` calls this once per pose and never anywhere else. The viewer receives finished Godot poses.

## Velocity: one more line

The POSE message also carries a velocity, in the Godot frame. The viewer uses it to extrapolate for up to 50 ms when a packet is late (Module 5), and the HUD uses its length as the speed. JSBSim gives the velocity in the local NED frame:

```python
v_enu = (fdm["velocities/v-east-fps"] * FT,
         fdm["velocities/v-north-fps"] * FT,
         -fdm["velocities/v-down-fps"] * FT)
vel = enu_to_godot_pos(v_enu)              # = (vE, vU, −vN): same matrix as positions
```

This is the **ground** velocity relative to the Earth's surface, not the airspeed. In still air their magnitudes agree; our check below shows 0.002 m/s.

## Back again: the HUD reads the node

A HUD could display numbers that Python sends along. That would prove nothing about the scene. The course HUD instead reads the **rendered node's transform** and converts it back. If heading, pitch and roll come out right, then the quaternion on the wire, the interpolation, the model's axes and the node hierarchy are all right too. It is an end-to-end test that runs every frame.

The inverse of the cheat-sheet shortcut `Basis.from_euler(Vector3(θ, −ψ, −φ))` (order YXZ) is `Basis.get_euler()` with the same default order:

```gdscript
## Godot basis of a model (nose -Z, top +Y) -> Vector3(heading_deg 0..360, pitch_deg, roll_deg).
static func attitude_deg(b: Basis) -> Vector3:
	var e := b.orthonormalized().get_euler()        # default order YXZ
	return Vector3(fposmod(-rad_to_deg(e.y), 360.0), rad_to_deg(e.x), -rad_to_deg(e.z))
```

| HUD value | From the node | Unit |
|---|---|---|
| heading | `−euler.y`, wrapped to 0…360 | deg, 0 = north, 90 = east |
| pitch | `euler.x` | deg, + nose up |
| roll | `−euler.z` | deg, + right wing down |
| altitude | `global_position.y` | m ASL |
| AGL | `y − terrain.height_at_world(x, z)` | m |
| speed | `latest_velocity(id).length()` | m/s, ground speed |

Euler angles have a singularity at pitch ±90°. A trainer never gets there; an aerobatic model would, and its HUD would need the quaternion instead.

## The check: three steady states

Why steady states? During a transient, the HUD and JSBSim are compared at slightly different times and the error you measure is mostly the rate of change times the time offset. In a steady state the rates are constant (or zero), so a time offset hardly matters and what is left is the conversion error.

`plane_jsbsim.py --scenario check` flies:

| Segment | Time | What is steady | Compare window |
|---|---|---|---|
| LEVEL | 0–12 s | straight north at 40 m, 16 m/s, from the trim | 7–12 s |
| TURN | 12–32 s | 25° left bank, altitude held; heading changes at a constant rate | 26–32 s |
| CLIMB | 32–44 s | fixed 8° pitch, pusher holds speed | 39–44 s |

Godot runs headless with `-- --hud-log=hud.csv` and writes the HUD numbers every frame, stamped with the sim time the frame was drawn for. `tools/compare_hud.py` interpolates JSBSim's logged truth at those times. Our run:

```
state  quantity        JSBSim  Godot HUD  mean err max |err|
LEVEL  heading_deg      0.005      0.005   -0.0000    0.0000 deg
LEVEL  pitch_deg        1.090      1.090   -0.0000    0.0001 deg
LEVEL  roll_deg        -0.007     -0.007   +0.0000    0.0000 deg
LEVEL  alt_m           40.260     40.260   +0.0000    0.0001 m
LEVEL  speed_mps       16.017     16.017   -0.0000    0.0001 m/s
TURN   heading_deg    107.526    107.527   +0.0000    0.0008 deg
TURN   pitch_deg        1.725      1.725   +0.0000    0.0001 deg
TURN   roll_deg       -24.315    -24.315   +0.0000    0.0001 deg
TURN   alt_m           37.407     37.407   +0.0000    0.0001 m
TURN   speed_mps       15.950     15.950   +0.0002    0.0003 m/s
CLIMB  heading_deg     61.775     61.775   +0.0000    0.0001 deg
CLIMB  pitch_deg        7.875      7.875   +0.0000    0.0001 deg
CLIMB  roll_deg        -0.009     -0.009   -0.0000    0.0001 deg
CLIMB  alt_m           52.266     52.266   +0.0000    0.0001 m
CLIMB  speed_mps       15.556     15.556   +0.0005    0.0019 m/s
Check: PASS (limits {'deg': 0.5, 'm': 0.2, 'm/s': 0.2})
```

(The tool also prints AGL; that row is discussed in sub-topic 04.) The residual errors are float32 rounding on the wire and linear interpolation between 60 Hz samples. The thresholds are generous on purpose: they catch a sign error or a wrong axis, not rounding.

**The same data, compared the wrong way.** If you compare each HUD row with the truth 25 ms later (the newest pose, the render clock's delay), the TURN heading error becomes 0.38° and the CLIMB altitude error 4.5 cm. Nothing in the conversion changed. That is the latency of drawing slightly in the past, and it is the reason every log row carries the sim time it belongs to.

## Try it

- Swap the sign of roll in `attitude_deg` and rerun the check. Which states fail? Which pass anyway, and why does that make the turn segment necessary?
- Replace `origin.h0 = 0` with `h0 = 10`. What must change in Godot so that the plane still flies above the terrain? (Answer before you try it.)
- Add a column `vt_mps` (airspeed) to the HUD log by using the TELEMETRY message (sub-topic 06). Set a 5 m/s wind from the west in JSBSim (`atmosphere/wind-east-fps`) and compare ground speed and airspeed in the TURN segment.
- Compare at the newest pose time instead of the drawn time and reproduce the 0.38° heading error.

## References

- [Frames cheat sheet](../reference/frames.md), [Module 3: JSBSim geodetic](../m03_frames/04_jsbsim_geodetic.md)
- Godot `Basis.get_euler`, `EulerOrder`: <https://docs.godotengine.org/en/stable/classes/class_basis.html>
- [Module 5: interpolation and the render clock](../m05_time_rates/03_interpolation.md)
