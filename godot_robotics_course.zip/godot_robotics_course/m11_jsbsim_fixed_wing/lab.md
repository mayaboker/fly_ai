# Lab 11: the JSBSim trainer over the shared terrain (2.5 h)

You will add a JSBSim fixed-wing scenario to `robosim/`, fly it over the terrain with chase and onboard cameras and a HUD, crash it into a mast that only Godot knows about, and prove that the HUD shows JSBSim's numbers.

## Files

| File | New / changed | What it does |
|---|---|---|
| `physics/aircraft/{trainer,quadplane}/` | new (copy) | JSBSim models from `reference/code/aircraft` |
| `physics/robosim/jsbsim_vehicle.py` | new | `JsbVehicle`: ICs from ENU, terrain feed, Godot pose, state in SI |
| `physics/robosim/telemetry.py` | shared code (from setup) | TELEMETRY message (type 100), Python side; used since Module 10 |
| `physics/sims/trim_trainer.py` | new | trim test + settle trim |
| `physics/sims/plane_jsbsim.py` | new | the scenario: vehicle 3, autopilot, crash logic, logs |
| `physics/sims/quadplane_jsbsim.py` | new (stretch) | the lesson 8 VTOL mission, vehicle 4 |
| `physics/tests/test_terrain_feed.py`, `test_plane_commands.py` | new | tests |
| `godot/bridge/telemetry_bridge.gd` | shared code (from setup) | `TelemetryBridge extends SimBridge` |
| `godot/ui/flight_hud.gd` | new | `FlightHud` |
| `godot/terrain/terrain_skirt.gd` | new | `TerrainSkirt` |
| `godot/scenes/plane_lab.tscn`, `plane_lab.gd` | new | the viewer |
| `tools/compare_hud.py`, `tools/plot_plane_run.py` | new | Check and plots |

Reused, unchanged: Module 2 (`HeightmapTerrain`, `RangeBuilder`, `plane.tscn`, `quadplane.tscn`, `robosim/terrain.py`, the project's input actions and layer names), Module 4 (`sim_bridge.gd` and `bridge.py` as in `reference/code`), Module 5 (`RenderClock`), Module 6 (`CameraRig`, `CameraIntrinsics`).

The finished files are in [code/](code/README.md). Try each step first.

## Step 0: prerequisites (10 min)

```bash
cd ~/robosim
cp -r <course>/reference/code/aircraft physics/          # trainer, quadplane, quad_rpy
ls data/terrain/heightmap.png data/terrain/range.json     # from Module 2
grep -n "Always say HELLO" godot/bridge/sim_bridge.gd     # Module 4 fix is in
ls godot/bridge/render_clock.gd godot/cameras/camera_rig.gd
```

If the heightmap is missing, run `python tools/make_heightmap.py` (Module 2).

## Step 1: `JsbVehicle` (25 min)

Write `physics/robosim/jsbsim_vehicle.py` with:

- `LAT0_DEG, LON0_DEG = 32.08, 34.80` and `GeoOrigin(lat0, lon0, 0.0)`;
- `place(e, n, h_asl=None, agl=None, heading_deg, airspeed, alpha_deg, gamma_deg, roll_deg, controls)` using `ic/` properties, `run_ic()` the first time and `reset_to_initial_conditions(0)` after that, and the controls written again **after** the reset;
- `feed_terrain()` and `step()` (sub-topic 04);
- `godot_pose()` returning `(pos, quat, vel)` through `jsbsim_state_to_godot` and the NED velocity;
- `state()` returning the dictionary from sub-topic 01.

Quick test from `physics/`:

```python
import sys; sys.path.insert(0, ".")
from robosim.terrain import Heightmap
from robosim.jsbsim_vehicle import JsbVehicle
v = JsbVehicle("trainer", Heightmap.load("../data/terrain/heightmap.png"))
v.place(0, -60, h_asl=40, airspeed=16, alpha_deg=1)
for _ in range(240): v.step()
print(round(v.t, 3), v.godot_pose()[0], round(v.state()["airspeed"], 2))
```

Ours printed `2.0 (0.0019, 39.38, 29.57) 14.58`: t = 2 s, about 30 m flown north from n = −60 (north is −Z, so z = +29.6), and the airspeed already down to 14.6 m/s because nothing commands the pusher yet. Add `controls={"fcs/pusher-cmd": 0.1643, "fcs/elevator-cmd": 0.0046}` and run it again.

## Step 2: trim (15 min)

```bash
python sims/trim_trainer.py
```

Expected (ours):

```
JSBSim trim: Trim Failed
...
settle trim at 16.0 m/s: alpha 1.054 deg, elevator 0.0046, pusher 0.1643  (mean climb rate -0.000 m/s)
hands off for 30 s from the trim: altitude 59.72..60.00 m (start 60), airspeed 15.91..16.08 m/s
```

Put your numbers in `TRIM` at the top of `plane_jsbsim.py`.

## Step 3: terrain feed test (15 min)

```bash
python tests/test_terrain_feed.py
```

It must end with `terrain feed: all tests pass`. Keep the printed probe heights; you will compare them with Godot in step 6.

## Step 4: the scenario script (40 min)

Write `physics/sims/plane_jsbsim.py` (`robosim/telemetry.py` is already there). The main loop, once per pose (60 Hz):

1. `br.poll()`: PAUSE / RESUME / RESET commands, and `SENSOR_CONTACT` for vehicle 3 → crash.
2. Unless paused or crashed: two times (`120 Hz / 60 Hz`): scenario → autopilot → write `fcs/*` → `plane.step()`.
3. Ground crash if `agl < 0.3`. Log `pose` (truth, in SI and degrees) and `command`.
4. Send the pose (PAUSED flag while paused or crashed) and, every 6th frame, TELEMETRY code 1.
5. Real-time pacing.

Scenarios: `lap` (waypoints at the map edge, climb to 45 m, descend to 28 m), `check` (three steady states), `crash` (straight at the mast). To wait for the viewer, call `br.wait_for_viewer(send_idle_pose=...)`: it sends a paused idle pose every 0.1 s, so the plane is visible before the run starts, and it works in either start order.

Test without a viewer, as fast as possible:

```bash
python sims/plane_jsbsim.py --no-wait --speedup 0
python ../tools/plot_plane_run.py ../logs/<newest>_plane_lap
```

Expected: `done at t=90.0 s (no crash)` and `min AGL 14.4 m, altitude 26.4-44.6 m ASL, airspeed 14.9-17.9 m/s`.

![Lap: track over the heightmap, altitude above the terrain, airspeed and bank](img/plane_lap.png)

## Step 5: the viewer (40 min)

1. Add `ui/flight_hud.gd` and `terrain/terrain_skirt.gd` (sub-topics 05 and 06). `bridge/telemetry_bridge.gd` is already there (shared code).
2. Build `scenes/plane_lab.tscn`: `SimBridge` (with the TelemetryBridge script), `WorldEnvironment`, `Sun`, `Terrain` (HeightmapTerrain), `TerrainSkirt` and `Range` (both with `terrain = ../Terrain`), `Obstacles`, an instance of `vehicles/plane.tscn` named `Plane`, `ViewCam`, and a `CanvasLayer` with the `Hud` control and a `Pip` TextureRect.
3. Write `scenes/plane_lab.gd`: masts, hull, onboard `CameraRig`, render clock, HUD, contact, keys, and the test options.
4. Run `godot --headless --path godot --import` once (new `class_name`s).

Check the terrain from Godot:

```bash
godot --headless --path godot res://scenes/plane_lab.tscn -- --probe-terrain
```

The bilinear column must equal step 3's probe heights; the ray column within a millimeter.

## Step 6: fly it (15 min)

```bash
godot --path godot res://scenes/plane_lab.tscn &          # start order does not matter
cd physics && python sims/plane_jsbsim.py
```

- Watch the climb over the west hills, the turns, and the descent. The HUD's AGL drops over the hills while ALT does not.
- Press C: the main view switches to the onboard camera. Press P twice, then R.
- Watch the attitude indicator in a right turn: the horizon's right end goes up.

## Step 7: crash into the mast (10 min)

```bash
cd physics && python sims/plane_jsbsim.py --scenario crash
```

Expected (60 FPS viewer): `CRASH: obstacle contact reported by Godot (pose t=5.54)` within a frame or two of t = 5.55 s, the HUD shows CONTACT then CRASH, and the run folder has an `event.csv` row with `reason = obstacle`, the pose time and a normal of about (0, 0, 1).

## Step 8: commands (5 min)

Close the viewer, then:

```bash
python tests/test_plane_commands.py
```

It plays the viewer's part over UDP and must print `plane commands: all tests pass`.

## Step 9: the Check (20 min)

Headless viewer recording the HUD, physics flying the three steady states:

```bash
godot --headless --path godot res://scenes/plane_lab.tscn -- --hud-log=/tmp/hud.csv &
cd physics && python sims/plane_jsbsim.py --scenario check --duration 44
cd .. && python tools/compare_hud.py logs/<newest>_plane_check/pose.csv /tmp/hud.csv
```

The viewer quits by itself 1.5 s after the physics process stops. Expected: `Check: PASS`, with a table like the one in [03_state_to_godot.md](03_state_to_godot.md). Our worst errors: heading 0.0008°, pitch 0.0001°, roll 0.0001°, altitude 0.0001 m, speed 0.0019 m/s; AGL 0.062 m (the one-step terrain lag, sub-topic 04).

## Expected output, all steps

| Step | Pass when |
|---|---|
| 2 | `do_simple_trim` fails as explained; hands-off altitude within 0.5 m for 30 s |
| 3 | `terrain feed: all tests pass` |
| 4 | 90 s lap, no crash, min AGL > 10 m |
| 5 | Godot probe heights = Python's within 1 mm |
| 7 | crash event logged, reason obstacle, pose time within 0.1 s of the geometric contact (60 FPS viewer) |
| 8 | `plane commands: all tests pass` |
| 9 | `Check: PASS` |

## Stretch goals

1. **Quadplane.** Run `python sims/quadplane_jsbsim.py` and the viewer with `-- --vehicle=4`. The HUD shows HOVER_UP → TRANSITION → CRUISE → BACK_TRANS → HOVER_DOWN → LANDED. Ours: TRANSITION at 15.1 s, CRUISE at 18.0 s, BACK_TRANS at 28.0 s, HOVER_DOWN at 46.5 s, LANDED at 72.5 s, never below 27 m AGL in the wing-borne phases. Add a HUD bar for the mean lift-motor command (a new TELEMETRY value).
2. **Wind.** Set `atmosphere/wind-east-fps` and show ground speed and airspeed side by side. Which one does the autopilot hold? Which one should a landing approach use?
3. **Terrain-following.** Make the altitude command `terrain + 25 m` instead of a fixed ASL value. What happens at the map edge, where the hills start within a few meters?
4. **Landing.** Glide onto the flat apron near the pad and stop. Log the touchdown vertical speed (JSBSim) and the first frame where Godot's `range` mount rangefinder (Module 8) reads below 0.2 m. How far apart are they in sim time?
5. **Replay.** Also log the wire pose (Godot position and quaternion) as a stream, in the columns Module 5's `tools/replay_poses.py` reads, replay a `check` run into the viewer and record the HUD again. Do you get the same Check table without JSBSim running?
