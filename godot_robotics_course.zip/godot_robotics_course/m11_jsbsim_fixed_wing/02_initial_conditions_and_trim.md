# 02 Initial conditions and trim

A flight simulation starts from a state: where the aircraft is, how it is oriented, how fast it moves, and where its controls are. If that state is not an equilibrium, the first seconds of every run are a transient: the nose drops, the speed oscillates, the autopilot fights. That transient pollutes every measurement you take in those seconds, including the HUD check of this module. So you want two things: a clean way to set the initial state, and a **trim**, the control settings that make that state steady.

## Two ways to set initial conditions

**1. An initialize XML file** next to the model. The lesson 7 file `trainer/cruise.xml`:

```xml
<initialize name="cruise">
  <latitude unit="DEG"> 32.08 </latitude>
  <longitude unit="DEG"> 34.80 </longitude>
  <altitudeAGL unit="M"> 60 </altitudeAGL>
  <vt unit="FT/SEC"> 52.49 </vt>     <!-- 16 m/s -->
  <psi unit="DEG"> 0 </psi>
  <theta unit="DEG"> 1 </theta>
  <alpha unit="DEG"> 1 </alpha>
</initialize>
```

```python
fdm.load_ic("cruise", True)     # True = the name is relative to the aircraft folder
fdm.run_ic()
```

Good for a fixed, named start you want to keep under version control.

**2. `ic/` properties from Python.** Every field of the XML has a property: `ic/lat-geod-deg`, `ic/h-sl-ft`, `ic/vt-fps`, `ic/alpha-deg`, `ic/psi-true-deg`, `ic/terrain-elevation-ft`, and more. Set them, then call `run_ic()`:

```python
fdm["ic/lat-geod-rad"] = lat
fdm["ic/long-gc-rad"] = lon
fdm["ic/terrain-elevation-ft"] = terrain_m / FT   # ground height for THIS initial condition
fdm["ic/h-sl-ft"] = h_asl / FT
fdm["ic/psi-true-deg"] = 0.0
fdm["ic/vt-fps"] = 16.0 / FT
fdm["ic/alpha-deg"] = 1.054
fdm["ic/gamma-deg"] = 0.0                         # flight-path angle: level, so theta = alpha
fdm.run_ic()
```

The course uses the second way because scenarios start in ENU meters (`e`, `n`, height), not in lat/lon. `JsbVehicle.place()` converts with the inverse of `GeoOrigin.to_enu`, which the shared `robosim/frames.py` provides as `GeoOrigin.from_enu`:

```python
def enu_to_geo(origin, e, n):
    lat, lon, _ = origin.from_enu(e, n, 0.0)
    # = (lat0 + n / EARTH_R,  lon0 + e / (EARTH_R * cos(lat0)))
    return lat, lon
```

Flat-earth, like `GeoOrigin` itself, and its exact inverse, so a scenario that asks for (e, n) gets exactly (e, n) back in the logs and in Godot. Compared with real WGS84 positions the flat-earth frame is off by about 3.9 m at 1 km and 20 m at 5 km ([frames](../reference/frames.md), measured in [Module 3](../m03_frames/04_jsbsim_geodetic.md)). That does not matter inside the simulation, but it does when you compare with real GPS or a map.

### Resetting: `run_ic()` is not a reset

We measured two things that surprise people:

| Call | Sim time afterwards | FCS inputs (`fcs/pusher-cmd`, …) |
|---|---|---|
| `run_ic()` a second time | **not** reset (it stayed at 2.0 s in our test) | unchanged |
| `reset_to_initial_conditions(0)` | 0.0 | **reset to the model's defaults (0)** |

So `JsbVehicle.place()` calls `run_ic()` the first time and `reset_to_initial_conditions(0)` after that, and it writes the control trim **after** the reset. Without the second write, the pusher restarts at 0 and the plane decelerates after every RESET. The RESET flag on the next pose (protocol v1) then tells the viewer to clear its buffers; `t_sim` going back to 0 would also do it.

## What a trim is

For straight, level flight at speed V, three things must balance:

| Balance | Adjusted by |
|---|---|
| lift = weight | angle of attack α |
| thrust = drag | pusher |
| pitching moment = 0 | elevator |

So a trim is a triple (α, elevator, pusher) for a given V and altitude. JSBSim can search for it: setting `simulation/do_simple_trim` starts its trim routine (0 = longitudinal, 1 = full).

## `do_simple_trim` on the trainer: it fails

Try it (`sims/trim_trainer.py`, step 1):

```python
try:
    fdm["simulation/do_simple_trim"] = 1
except jsbsim.TrimFailureError as exc:
    print("JSBSim trim:", exc)            # -> JSBSim trim: Trim Failed
```

With `fdm.set_debug_level(1)` JSBSim prints its trim report. Our run:

```
  Trim failed
  Angle of Attack     : 1.1    wdot : 3.86e-01  Tolerance: 1e-03  Failed
  Throttle            : 0.5    udot : -3.22e+00 Tolerance: 1e-03  Failed
  Pitch Trim          : 0      qdot : 2.65e-01  Tolerance: 1e-04  Failed
```

The report says what the trim **moves**: the engine throttles, `fcs/pitch-trim-cmd-norm`, and (for a full trim) the aileron and rudder `-norm` commands. The trainer has no `<engine>`; its pusher is an external force driven by `fcs/pusher-cmd`. Its elevator reads `fcs/elevator-cmd`. So nothing the trim moves changes any force. It cannot converge. The model is fine; it just does not use the property names JSBSim's trim knows.

You could rewrite the model to route `fcs/pitch-trim-cmd-norm` into the elevator and to declare a real engine. For this course that is the wrong fix: the model belongs to the JSBSim course, and you will meet many custom models like it. Learn the general workaround instead.

## A settle trim

The idea: let the autopilot you already trust fly the condition you want, wait until everything is steady, and read the controls.

```python
def settle_trim(speed, alt=60.0, seconds=40.0):
    v = JsbVehicle("trainer")
    v.place(0, 0, h_asl=alt, airspeed=speed, alpha_deg=1, controls={"fcs/pusher-cmd": 0.17})
    ...                                        # lesson 7 autopilot, holding alt, heading 0, speed
    # average the last 5 s
    return {"alpha_deg": ..., "elevator": ..., "pusher": ..., "airspeed": speed}
```

Then **prove** it: start a fresh aircraft from exactly those numbers, controls fixed, autopilot off, and watch.

```
$ python sims/trim_trainer.py
JSBSim trim: Trim Failed
...
settle trim at 16.0 m/s: alpha 1.054 deg, elevator 0.0046, pusher 0.1643  (mean climb rate -0.000 m/s)
hands off for 30 s from the trim: altitude 59.72..60.00 m (start 60), airspeed 15.91..16.08 m/s
TRIM = {'alpha_deg': 1.054, 'elevator': 0.0046, 'pusher': 0.1643, 'airspeed': 16.0}
```

At 20 m/s the same script gives α −0.553°, elevator 0.0847, pusher 0.2203, and the hands-off altitude stays within 0.42 m.

The 0.3 m dip is not a trim error. It comes from the pusher's lag filter: right after `run_ic()` its output is near 0 (we read 0.0066 with a 0.1643 command), so for the first few tenths of a second the thrust is short and the plane sinks a little. That kick excites the phugoid, which decays slowly. We checked it by "warming" the FCS before the flight, stepping it with the integration suspended:

```python
f.suspend_integration()          # run the FCS, do not move the aircraft
for _ in range(240):
    f.run()
f.resume_integration()           # pusher-lag is now 0.1643, sim time is still 0
```

From the warmed start the hands-off altitude stays within 59.99–60.01 m for 30 s. The course scenarios do not warm the filter, because the autopilot absorbs the kick and because "the initial state includes the filters" is worth seeing once.

Copy the result into `plane_jsbsim.py`:

```python
TRIM = {"alpha_deg": 1.054, "elevator": 0.0046, "pusher": 0.1643, "airspeed": 16.0}
```

Every scenario starts from it, and the autopilot uses the trim pusher as its feed-forward.

### When to use which

| Method | Works when | Cost |
|---|---|---|
| `do_simple_trim` | the model uses JSBSim's standard engine and `-norm` control properties | instant |
| Settle trim (this page) | you have a stable autopilot for the condition | one simulated minute |
| Your own solver: set ICs, `run_ic()`, read `accelerations/udot-ft_sec2`, `wdot`, `qdot`, adjust α / elevator / thrust until they are zero | always, if you can evaluate the forces at `run_ic()` | more code; watch FCS filters (the pusher lag above) |

## Try it

- Run `trim_trainer.py --speed 13` and `--speed 20`. Plot α against speed. Where does α approach the stall angle (≈ 15°)?
- Start the `check` scenario without the trim (`alpha_deg=0`, pusher 0.17, elevator 0) and plot the first 10 s of altitude. How long until it is as steady as the trimmed start?
- Write the 16 m/s trim as `aircraft/trainer/cruise16.xml` (an initialize file) and load it with `load_ic`. Then set `fcs/elevator-cmd` and `fcs/pusher-cmd` after `run_ic()`. Do you get the same hands-off flight?
- Call `run_ic()` twice and print `get_sim_time()`. Then try `reset_to_initial_conditions(0)` and print `fcs/pusher-cmd`.

## References

- JSBSim initial conditions (`ic/` properties, initialize files): <https://jsbsim-team.github.io/jsbsim-reference-manual/>
- `FGTrim` and the trim modes: JSBSim source, `src/initialization/FGTrim.cpp`
- Companion course lesson 7 (`fly_plane.py`, Part A: the phugoid)
