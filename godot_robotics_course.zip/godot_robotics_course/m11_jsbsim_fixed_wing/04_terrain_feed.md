# 04 The terrain feed: one ground for JSBSim and Godot

JSBSim has its own idea of the ground: a sphere (or ellipsoid) at a terrain elevation that you can set. Godot has the shared heightmap from Module 2, with hills up to about 19 m at the map edge. If nobody connects the two, JSBSim flies over a flat sea-level world while Godot draws hills. The plane can then fly "through" a hill in the picture, or land in mid-air above the valley, and a downward rangefinder in Godot disagrees with JSBSim's AGL by the hill height.

The fix is simple and cheap: before every JSBSim step, Python samples the shared heightmap under the aircraft and tells JSBSim the ground elevation there. This is the JSBSim row in the [terrain contract](../reference/terrain.md).

## Which property

| Property | When it applies | Use |
|---|---|---|
| `ic/terrain-elevation-ft` | at `run_ic()` only | so that `altitudeAGL` in an initial condition means the right thing |
| `position/terrain-elevation-asl-ft` | every step, from now on | the terrain feed |

Both are in **feet above sea level**. Writing the second one moves JSBSim's ground immediately: `position/h-agl-ft` changes in the same step, and the landing-gear contacts (here the trainer's STRUCTURE points) react to the new ground in the next `run()`.

## The code

```python
class JsbVehicle:
    def feed_terrain(self):
        """Write the heightmap height under the aircraft into JSBSim. Call before every run()."""
        e, n, _ = self.enu()
        self.terrain_m = self.terrain_at(e, n)                   # Module 2: Heightmap.height_at
        self.fdm["position/terrain-elevation-asl-ft"] = self.terrain_m / FT

    def step(self):
        self.feed_terrain()
        self.fdm.run()
```

`self.hm` is the `Heightmap` from `robosim/terrain.py` (Module 2). It reads all 16 bits of the PNG and samples bilinearly with exactly the same rule as `HeightmapTerrain.height_at` in Godot. Outside the map both clamp to the edge value.

Cost: one bilinear lookup per step. At 120 Hz that is nothing next to `fdm.run()`.

## What JSBSim's terrain model can and cannot do

JSBSim's default ground is a flat surface at the elevation you set, under the whole aircraft. It has no slope. That has consequences:

| Situation | Effect | Matters for |
|---|---|---|
| Plane in flight | AGL is exact at the CG position | autopilot, HUD, logs: fine |
| Wheels/contacts on a slope | all contacts see the same flat ground | a landing on a steep hill looks slightly wrong |
| Sharp ridge between two steps | the ground jumps by (slope × distance flown in one step) | at 16 m/s and 120 Hz, 13 cm per step: fine |
| Wing tip touching a hill beside the CG | not detected | use a Godot sensor (sub-topic 05) if you care |

For a rover or a hard landing on rough ground, use a physics engine with a real height field (PyBullet, Module 9). For an aircraft that flies over terrain and lands on flat ground, the feed is enough.

## Test it

`tests/test_terrain_feed.py` checks four things.

**1. AGL along a real flight.** Fly the `lap` route for 60 s and compare JSBSim's AGL with `h − terrain` at every step:

```
1. AGL along 60 s of the lap (terrain up to 16.2 m under the aircraft):
   vs the fed height:            worst error 0.020 cm
   vs the terrain after the step: worst error 5.93 cm (one-step lag: the aircraft moves 13 cm per step)
```

The first line says JSBSim uses exactly what we fed. The second shows the price of feeding *before* the step: the aircraft then moves 13 cm, and on a slope the ground under it is a few centimeters different. This is also why the HUD check shows AGL errors up to 6 cm while altitude errors are 0.1 mm: Godot computes AGL at the drawn position, JSBSim used the height from one step earlier.

**2. The ground holds the aircraft.** Drop the stationary trainer from 0.3 m above the heightmap at three places and let it settle for 6 s:

```
2./3. drop tests (trainer at rest, CG height):
   ENU (-112.00,   20.00)  terrain  8.535 m   rests at  8.643 m with feed (+0.108 above terrain)    0.108 m without feed
   ENU ( 115.00,  -40.00)  terrain 10.899 m   rests at 11.007 m with feed (+0.108 above terrain)    0.107 m without feed
   ENU (  30.50,   77.25)  terrain  1.744 m   rests at  1.853 m with feed (+0.109 above terrain)    0.108 m without feed
```

With the feed it rests on its nose and tail contacts 0.108 m above the heightmap, wherever it is. **3. Without the feed** (the control case) it falls straight through Godot's 10.9 m hill and rests 0.108 m above sea level. A test needs a case that fails without the fix; this is it.

A note on drop height: our first version dropped from 2 m. The trainer has only four contact points and no wheels, so it tumbled on impact and was still rocking after 6 s. A test should test one thing; 0.3 m tests the ground, not the tumbling.

**4. Python and Godot agree on the heights.** The test prints the heightmap at five probe points. The plane scene prints the same points from Godot, both by bilinear lookup and by a ray against the `HeightMapShape3D`:

```
$ godot --headless --path godot res://scenes/plane_lab.tscn -- --probe-terrain
probe ENU (   0.00,    0.00)  ray 0.0000 m  bilinear 0.0000 m
probe ENU (-112.00,   20.00)  ray 8.5349 m  bilinear 8.5350 m
probe ENU ( 115.00,  -40.00)  ray 10.8989 m  bilinear 10.8989 m
probe ENU (  30.50,   77.25)  ray 1.7442 m  bilinear 1.7445 m
probe ENU (-120.00, -120.00)  ray 10.4302 m  bilinear 10.4302 m
```

Python's values are identical to the bilinear column. The ray differs by up to 0.3 mm at (30.5, 77.25), a point between pixels: the collision shape is made of flat triangles, the bilinear surface is not. Module 2's tolerance (5 cm for rays) covers it with room to spare.

## Where the feed goes in the loop

```
for each JSBSim step:
    s = vehicle.state()          # read
    commands = autopilot(s)      # decide
    write commands               # act
    vehicle.feed_terrain()       # ground under the CURRENT position
    fdm.run()                    # integrate one dt
```

Feeding after `run()` would use the new position for the next step, which is the same thing one line later. Feeding only every pose (60 Hz) instead of every step would double the lag to 27 cm per update at 16 m/s; still fine for flight, worse for landings. Feed every step; it costs nothing.

## Try it

- Comment out `feed_terrain()` in `JsbVehicle.step()` and run the `lap`. Plot JSBSim's AGL against `h − terrain`. Where is the difference largest?
- Lower the lap's southern leg to 20 m ASL. Does the plane hit the hills? Who detects it: JSBSim (`agl < 0.3`) or Godot? Why?
- Change the test to feed only every second step. How does the "after the step" error change?
- Put the quadplane (`quadplane_jsbsim.py`) on a 10 m hill (`place(-112, 20, agl=0.16)`). Does HOVER_UP still climb to 30 m above the hill?

## References

- [Terrain contract](../reference/terrain.md), [Module 2: terrain from a heightmap](../m02_scene_assets/04_terrain_heightmap.md)
- JSBSim ground callback and `position/terrain-elevation-asl-ft`: JSBSim reference manual, "FGInertial / FGGroundCallback" (<https://jsbsim-team.github.io/jsbsim-reference-manual/>)
