# 06 Chase and onboard cameras, the HUD, and a telemetry extension

A pilot (or you, debugging an autopilot) needs two views. The **chase view** shows the aircraft's attitude against the world: you see the bank, the climb, the hill coming. The **onboard view** shows what a camera on the aircraft would see, which is what vision code will get. The **HUD** puts the numbers on top. This page builds all three and adds one protocol message for the numbers the pose cannot carry.

## The chase camera

A chase camera that is rigidly attached behind the plane rolls with it. That is disorienting and hides the bank angle, the very thing you want to see. The lab's chase camera follows the **heading only**, stays level, and lags a little:

```gdscript
var fwd := -plane.global_basis.z
var flat := Vector3(fwd.x, 0.0, fwd.z).normalized()       # heading, no pitch or roll
var want := plane.global_position - flat * 4.0 + Vector3.UP * 1.2
var k := 1.0 - exp(-delta * 10.0)                         # frame-rate independent smoothing
var pos := want if view_cam.global_position.distance_to(want) > 30.0 \
		else view_cam.global_position.lerp(want, k)        # jump after a reset
view_cam.global_transform = Transform3D(Basis.IDENTITY, pos).looking_at(
		plane.global_position + Vector3.UP * 0.3, Vector3.UP)
```

The exponential form `1 − exp(−rate · delta)` gives the same smoothing at 30 and 144 FPS. With rate 10/s and 16 m/s, the camera trails its target by about 1.6 m. Our first version used rate 4/s and a 5 m offset: the plane sat about 9 m away and looked like a toy. The 30 m jump rule matters after RESET, when the plane teleports.

This is a human view. It never feeds a sensor, so the smoothing is harmless.

## The onboard camera

Module 6's `CameraRig` gives a camera its own `SubViewport`, so it renders at its own size and can be read back. The lab puts one on the plane's `fpv_cam` mount (Module 2: 0.5 m ahead of the CG, looking along −Z) in RIGID mode, so it rolls and pitches with the aircraft:

```gdscript
onboard = CameraRig.new()
onboard.camera_name = "onboard"
onboard.mode = CameraRig.Mode.RIGID
onboard.image_size = Vector2i(640, 360)
onboard.fov_v_deg = 60.0
plane.mount("fpv_cam").add_child(onboard)
pip.texture = onboard.viewport.get_texture()      # picture-in-picture, bottom right
```

The `camera_next` action (key C, from the Module 2 project) switches the **main** view between the chase position and the onboard pose. The PiP always shows the onboard rig.

Two details from Module 6 and 7 that matter in a fast vehicle:

- The plane node is moved in `_process`. `CameraRig` copies its pose in its own `_process` with a high `process_priority`, so it runs later in the same frame. The lab also calls `onboard.sync_now()` right after moving the plane, so anything that uses the camera pose in the same function sees the new one.
- `SimBridge` must process its packets **before** the lab uses them, or every frame draws last frame's pose. `SimBridge` sets `process_priority = -100` in its own `_ready()`, so this is automatic. In the capstone starter, running the bridge first cut the measured pose receive age from 16.6 ms to 0.25 ms.

## The terrain skirt

A plane 40 m up sees well past the 256 m map. Beyond the edge, the camera shows the sky's "ground" color and the horizon looks like a cliff. Module 2's terrain was built for ground vehicles, which never see that far.

`terrain/terrain_skirt.gd` draws a visual-only apron, 3 km wide, around the map. It extrudes every edge sample outward **at its own height**. That is exactly what the height samplers do outside the map (they clamp to the edge), so the skirt shows the ground that JSBSim, through the terrain feed, actually flies over. It has no collision; nothing should fly there in this course.

One pitfall: the skirt quads on the four sides have different winding. A side with the wrong winding is culled and simply disappears. The skirt picks the triangle order from the sign of `cross(b − a, c − a).y` for every quad, so all faces point up.

## The HUD

`ui/flight_hud.gd` (`FlightHud`, a `Control`) shows:

```
HDG 022   PITCH +1.1   ROLL +29.8
ALT  42.7 m   AGL  36.9 m   SPD 16.6 m/s
airspeed 16.7 m/s   alpha +1.2 deg   JSBSim AGL  39.0 m
phase  TRANSITION                                   (quadplane only)
```

The first two lines come from the **rendered node** (sub-topic 03): `attitude_deg(plane.global_transform.basis)`, `global_position.y`, the terrain under it, and the pose velocity. The third line comes from TELEMETRY (below). Seeing both is useful: when they disagree, either the data is old (TELEMETRY arrives at 10 Hz, the pose drawing is 25 ms behind) or something is wrong.

A small attitude indicator is drawn in `_draw()`: a horizon line rotated by −roll and shifted down by 2 px per degree of nose-up pitch, behind a fixed yellow aircraft symbol. In a right bank the horizon's right end goes up, as in a real cockpit. Use it to sanity-check roll signs in one glance.

## TELEMETRY: a protocol extension the right way

The pose carries position, orientation and velocity. Airspeed, angle of attack, JSBSim's AGL, the crash flag and the quadplane's flight phase do not fit. The protocol's rule is: **never change an existing message; add a new type**. The course's TELEMETRY extension, specified in [protocol.md](../reference/protocol.md) and shipped with the shared code, is such a type. Module 10 used code 2 for motor outputs; this module uses code 1:

| Field | Value |
|---|---|
| type | **100** = TELEMETRY (physics → viewer, unreliable, latest wins) |
| body | `vehicle_id u16, code u16, count u16, reserved u16, count × f32`, the same layout as SENSOR |
| code 1 = FLIGHT | `airspeed_mps, alpha_deg, agl_m, terrain_m, crashed 0/1, phase, reserved` |
| code 2 = MOTORS | four motor outputs 0–1, order 1..4 (Module 10) |
| code 3 = TTC | state, tau_est, speed, true distance, true tau (Module 12 starter) |
| rate | 10 Hz |

Why 100? Types 1–6 belong to v1. Using a high number for local extensions, like the 100–199 range for experimental commands, keeps clear of future course types. A viewer that does not know type 100 ignores it: `SimBridge._process` only matches POSE and ACK. So old viewers keep working and old logs stay readable.

Python, `robosim/telemetry.py`:

```python
MSG_TELEMETRY, TELEM_FLIGHT = 100, 1

def pack_telemetry(seq, t_sim, vehicle_id, code, values):
    return (P._header(MSG_TELEMETRY, seq, t_sim) + P.SENSOR_HEAD.pack(vehicle_id, code, len(values), 0)
            + struct.pack(f"<{len(values)}f", *values))
```

Godot, `bridge/telemetry_bridge.gd`: a subclass of `SimBridge`, so `sim_bridge.gd` stays untouched. It drains the socket itself, hands POSE and ACK to the parent's code, handles type 100, and then calls `super._process()` for HELLO and command resends:

```gdscript
class_name TelemetryBridge
extends SimBridge

signal telemetry_received(vehicle_id: int, code: int, t_sim: float, values: PackedFloat32Array)

func _process(delta: float) -> void:
	while _udp.get_available_packet_count() > 0:
		var pkt := _udp.get_packet()
		var msg := RsProtocol.unpack(pkt)
		if msg.is_empty():
			continue
		match msg.type:
			RsProtocol.MSG_POSE:
				_on_pose(msg)
			RsProtocol.MSG_ACK:
				_pending.erase(msg.acked_seq)
			MSG_TELEMETRY:
				_on_telemetry(pkt, msg)
	super._process(delta)        # finds the socket empty; sends HELLO and resends commands
```

It also adds two small helpers the lab needs: `latest_velocity(id)` and `seconds_since_pose()`. Write the extension into your capstone's protocol document (Module 12): type, layout, codes, rate, reliability.

## The quadplane's phases (stretch goal)

`quadplane_jsbsim.py` flies the lesson 8 mission and sends its phase as TELEMETRY code 1, value 5: 1 HOVER_UP, 2 TRANSITION, 3 CRUISE, 4 BACK_TRANS, 5 HOVER_DOWN, 6 LANDED. Start the viewer with `-- --vehicle=4`: the lab swaps in Module 2's `quadplane.tscn` and the HUD prints the phase.

![The quadplane in TRANSITION over the range](img/quadplane_transition.png)

## A word on frame rate

The screenshots on these pages come from a server without a GPU (Mesa llvmpipe). The plane lab ran at 1–3 FPS there, with shadows, two viewports and the range. A desktop GPU runs it far faster. Do not quote our frame rates; measure yours (the capstone shows how).

## Try it

- Set the chase smoothing rate to 2/s and fly the lap. How far behind is the plane in the turns? Is the bank still readable?
- Make the onboard rig GIMBAL_LEVEL instead of RIGID. What do you lose for a pilot? What do you gain for a vision algorithm?
- Add `beta_deg` (sideslip) to TELEMETRY code 1 as a new value at the end. Do old viewers still work? Why is appending safe here when changing the POSE layout is not?
- Turn the skirt off (`skirt_m = 0`) and take a screenshot from 40 m near the map edge.

## References

- [Module 6: CameraRig and mounts](../m06_cameras/04_camera_mounts.md), [Module 7: readback timing](../m07_frame_transport/01_readback.md)
- Godot `Control._draw`, `CanvasItem.draw_line`: <https://docs.godotengine.org/en/stable/classes/class_canvasitem.html>
- [Protocol v1, "Changing the protocol"](../reference/protocol.md)
