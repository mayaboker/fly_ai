# 00 Setup (about 1 hour, once)

The commands are for Ubuntu 24.04. On Windows and macOS the Python parts are the same. Module 7's shared memory (`/dev/shm`) is Linux-only, and Module 7 gives a fallback.

## 1. Godot 4.7.2

Download the **standard** (not .NET) build from <https://godotengine.org/download/archive/4.7.2-stable/>:

```bash
mkdir -p ~/tools && cd ~/tools
wget https://github.com/godotengine/godot/releases/download/4.7.2-stable/Godot_v4.7.2-stable_linux.x86_64.zip
unzip Godot_v4.7.2-stable_linux.x86_64.zip
ln -sf ~/tools/Godot_v4.7.2-stable_linux.x86_64 ~/tools/godot
~/tools/godot --version        # 4.7.2.stable.official...
```

## 2. Python environment

```bash
sudo apt install python3-venv python3-pip
python3 -m venv ~/robosim-venv
source ~/robosim-venv/bin/activate
pip install pybullet jsbsim numpy matplotlib opencv-python
python -c "import pybullet, jsbsim, numpy, cv2; print('jsbsim', jsbsim.__version__)"
```

## 3. Create the project skeleton

```bash
mkdir -p ~/robosim/{godot,physics/sims,physics/tests,data/terrain,tools,logs}
cp -r <course>/reference/code/python/robosim ~/robosim/physics/
cp -r <course>/reference/code/godot/bridge   ~/robosim/godot/
cp <course>/reference/code/test_frames.py    ~/robosim/physics/tests/
cd ~/robosim/physics && python tests/test_frames.py
# frames: all tests pass (incl. Godot YXZ shortcut equivalence)
```

## 4. VS Code

- Install the **godot-tools** extension. In its settings, set *Godot Editor Path* to `~/tools/godot`.
- In Godot, open *Editor → Editor Settings → Text Editor → External*, enable *Use External Editor*, and set the exec path to `code` with flags `{project} --goto {file}:{line}:{col}`.
- Install the Python extension and select `~/robosim-venv/bin/python` as the interpreter.

## 5. Headless Godot (used for tests and CI)

You will use these from Module 1 on. They need a `project.godot`, which Module 1's lab creates in `~/robosim/godot`. Right now that folder only holds `bridge/`, so do not run them yet (without a project, Godot opens the Project Manager instead and never returns in headless mode).

```bash
~/tools/godot --headless --path ~/robosim/godot --import      # build the class cache once
~/tools/godot --headless --path ~/robosim/godot                # run without a window
```

After you add a new `class_name` script, run `--import` once. Otherwise other scripts can't find the class from the command line.

## Check

- `godot --version` prints 4.7.2.
- `tests/test_frames.py` passes.
- VS Code opens a `.gd` file from Godot when you double-click it.
