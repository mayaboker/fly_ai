# 02 Scenes, nodes, the scene tree, instancing and signals (45 min)

Godot has one building block: the **node**. A camera is a node, a mesh is a node, a light is a node, and so is a UDP bridge with no visual at all. Nodes form a tree. A **scene** is a branch of that tree saved to a file (`.tscn`). You can drop a saved scene into another scene as many times as you like. That is **instancing**. A robot simulator maps onto this model well. The world is a scene, each vehicle is a scene, and each sensor rig is a scene inside a vehicle.

## The scene tree of the Module 1 viewer

```
Main                (Node3D, main.gd, process_mode = Always)
├── Environment     (WorldEnvironment: sky, ambient light, tone mapping)
├── Sun             (DirectionalLight3D)
├── World           (Node3D: a folder, no behavior)
│   ├── Ground      (Node3D, ground_grid.gd: builds plane + 1 m grid lines)
│   ├── AxisMarker  (Node3D, axis_marker.gd: builds arrows + labels)
│   ├── RefCube     (MeshInstance3D, BoxMesh 1 × 1 × 1 m)
│   └── DemoSpinner (MeshInstance3D, demo_spinner.gd, group "resettable")
├── Cameras
│   ├── FreeFly     (Camera3D, free_fly_camera.gd)
│   └── Orbit       (Camera3D, orbit_camera.gd)
└── UI              (CanvasLayer: 2D drawn on top of the 3D view)
    └── Status      (Label)
```

Each node has exactly one parent. A child's transform is relative to its parent. When you move `World`, everything under it moves. Module 2 uses this for vehicles: sensor mounts are children of the vehicle, so they follow it for free.

Node types you need in this course:

| Node | What it is | Used for |
|---|---|---|
| `Node` | no transform | bridge, loggers, managers |
| `Node3D` | a 3D transform, nothing visible | folders, vehicle roots, pivots |
| `MeshInstance3D` | draws a `Mesh` resource | everything visible |
| `Camera3D` | a view into the 3D world | FPV, chase, orbit cameras |
| `DirectionalLight3D` | the sun | lighting and shadows |
| `WorldEnvironment` | sky, ambient, fog, tone mapping | the look of the world |
| `Marker3D` | a `Node3D` with a visible cross in the editor | sensor mounts (Module 2) |
| `StaticBody3D` + `CollisionShape3D` | a shape the physics *queries* can hit | rays, lidar (Module 8) |
| `CanvasLayer`, `Label` | 2D overlay | status text, HUD |

**Nodes vs resources.** A `MeshInstance3D` is a node and a `BoxMesh` is a *resource*. Resources are data: meshes, materials, shapes, environments. Several nodes can share one resource. In a `.tscn` file, resources appear as `[sub_resource]` blocks and nodes as `[node]` blocks.

## Reaching other nodes from a script

```gdscript
@onready var _status: Label = $UI/Status                 # path relative to this node
@onready var _cameras: Array[Camera3D] = [$Cameras/FreeFly, $Cameras/Orbit]

func _ready() -> void:
	var sun := get_node("Sun") as DirectionalLight3D     # same as $Sun
	print(sun.global_transform.basis.z)
```

`$Path` is shorthand for `get_node("Path")`. `@onready` delays the assignment until `_ready()`, when the children exist. Paths break when you rename or move nodes. For nodes that scripts look up often, right-click the node and pick *Access as Unique Name*. Then `%Status` finds it anywhere in the scene.

## Instancing

Instancing is how one vehicle scene becomes four vehicles on the range, or how a `camera_rig.tscn` gets attached to every vehicle in Module 6.

In the editor: drag `vehicles/rover.tscn` from the FileSystem dock into the 3D viewport, or use the chain-link button in the Scene dock. In code:

```gdscript
const RoverScene := preload("res://vehicles/rover.tscn")

func spawn_rover(at: Vector3) -> Node3D:
	var rover := RoverScene.instantiate() as Node3D
	rover.position = at
	$Vehicles.add_child(rover)
	return rover
```

An instance shows in the tree as one node with a "scene" icon. Its inner nodes belong to the vehicle scene. If you edit `rover.tscn`, every instance changes. If you override a property on one instance (say, its color), only that instance changes, and the main scene stores the override.

## Signals: "something happened"

A signal is an event a node announces. Other nodes connect functions to it. The emitter does not know who listens. This keeps parts of the simulator independent. For example, the bridge emits `pose_received`, and the HUD, the logger and the vehicle each decide what to do with it.

Built-in example: a `Timer` that prints the camera position once a second.

```gdscript
func _ready() -> void:
	var t := Timer.new()
	t.wait_time = 1.0
	t.autostart = true
	t.timeout.connect(_on_tick)          # connect a method to the signal
	add_child(t)

func _on_tick() -> void:
	print("camera at ", get_viewport().get_camera_3d().global_position)
```

Your own signals:

```gdscript
# terrain/heightmap_terrain.gd (Module 2)
signal terrain_built

func _build() -> void:
	# ... make mesh and collision ...
	terrain_built.emit()
```

```gdscript
# a listener
func _ready() -> void:
	$World/Terrain.terrain_built.connect(func() -> void: print("terrain is ready"))
```

Signals can carry arguments. The course bridge (Module 4, [sim_bridge.gd](../reference/code/godot/bridge/sim_bridge.gd)) declares:

```gdscript
signal pose_received(vehicle_id: int, msg: Dictionary)
signal physics_reset
```

You can also connect signals in the editor. Select the node, open the **Node** dock, double-click the signal and pick a target method. The connection is saved in the `.tscn` as a `[connection]` line. Code connections are easier to search and review, so this course prefers them for anything that matters.

**Rule of thumb: call down, signal up.** A parent may call methods on its children, because it knows they exist. A child should not reach up the tree to call its parent. It emits a signal instead. In the lab, `main.gd` calls `reset_view()` on its cameras (down). In Module 2, the terrain emits `terrain_built` (up) rather than poking the range builder.

## Groups: "all nodes of a kind"

A group is a tag. Any node can be in any number of groups.

```gdscript
add_to_group("vehicles")                          # in code
get_tree().get_nodes_in_group("vehicles")         # all of them
get_tree().call_group("resettable", "reset")      # call reset() on every member
```

In the editor: *Node* dock → *Groups*. The lab puts `DemoSpinner` in group `resettable`. The reset key then calls `reset()` on every member without knowing what they are. Later modules add vehicles and sensor buffers to the same group. Module 2 uses groups `vehicles`, `gates`, `obstacles` and `terrain`.

## Try it

- In the running lab scene, open the Scene dock's **Remote** tab ([05](05_debugging_and_tools.md)). Find the arrows and labels under `AxisMarker` that are not in `main.tscn`. Where do they come from?
- Instance `RefCube` a second time by duplicating it (Ctrl+D). Change only the copy's position. Look at the `.tscn` diff: what got stored?
- Add a `Timer` child to `Main` in the editor and connect its `timeout` signal to a new method in `main.gd` through the Node dock. Find the `[connection]` line in `main.tscn`.
- Put `RefCube` in group `resettable` and give it a `reset()` that sets its scale back to 1. Scale it in the Remote inspector while running, then press `R`.

## References

- Godot docs, *Nodes and scenes*: <https://docs.godotengine.org/en/stable/getting_started/step_by_step/nodes_and_scenes.html>
- Godot docs, *Creating instances*: <https://docs.godotengine.org/en/stable/getting_started/step_by_step/instancing.html>
- Godot docs, *Using signals*: <https://docs.godotengine.org/en/stable/getting_started/step_by_step/signals.html>
- Godot docs, *Groups*: <https://docs.godotengine.org/en/stable/tutorials/scripting/groups.html>
- Godot docs, *Scene Unique Nodes*: <https://docs.godotengine.org/en/stable/tutorials/scripting/scene_unique_nodes.html>
