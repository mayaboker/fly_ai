# Lab 1: The robosim viewer (90 min)

You start `~/robosim/godot`, the Godot half of the project that grows through all 12 modules. At the end of this lab it has a free-fly camera and an orbit camera (switch with `C`), a status line, pause (`P`) and reset (`R`), an axis marker that shows the course's world frame, a 1 m reference cube, and a headless test.

The finished files are in [code/godot/](code/godot/). Try to build it yourself first. Copy from there when you are stuck.

## Files

| File | New / changed |
|---|---|
| `godot/project.godot` | new: name, window size, MSAA, input actions, main scene |
| `godot/main.tscn`, `godot/main.gd` | new |
| `godot/cameras/free_fly_camera.gd`, `godot/cameras/orbit_camera.gd` | new |
| `godot/world/axis_marker.gd`, `godot/world/ground_grid.gd`, `godot/world/demo_spinner.gd` | new |
| `godot/tests/test_m01.gd` | new |
| `robosim/.gitignore` | new |

`godot/bridge/` from [00 Setup](../00_setup/README.md) is already there. This lab does not use it yet.

## Step 1: Create the project

1. Start Godot (`~/tools/godot`). In the Project Manager choose **Create**. Project name `robosim`, path `~/robosim/godot`, renderer **Forward+**. The folder is not empty (it contains `bridge/`). Confirm that this is fine.
2. Close the editor, then build the class cache once, because `bridge/` contains `class_name` scripts:

   ```bash
   cd ~/robosim/godot && ~/tools/godot --headless --path . --import
   ```

3. Reopen the project. Create the folders `cameras/`, `world/` and `tests/` in the FileSystem dock (right-click → *New Folder*).

## Step 2: Project settings and input map

*Project → Project Settings*, with **Advanced Settings** on:

| Setting | Value |
|---|---|
| Display → Window → Size → Viewport Width / Height | 1280 / 720 |
| Rendering → Anti Aliasing → Quality → MSAA 3D | 4× (Medium) |

**Input Map** tab: add these actions. For each one click *+ Add*, then the `+` on the action row, press the key, and tick **Physical**:

| Action | Key |
|---|---|
| `move_forward`, `move_back`, `move_left`, `move_right` | W, S, A, D |
| `move_up`, `move_down` | E, Q |
| `move_fast` | Shift |
| `camera_next` | C |
| `pause_toggle` | P |
| `reset` | R |

Close the dialog and open `project.godot` in a text editor. You should find an `[input]` section with ten entries.

## Step 3: The main scene skeleton

*Scene → New Scene*, root **3D Scene** (`Node3D`), rename it `Main`. Add children until the tree looks like this (*+* button or Ctrl+A):

```
Main                Node3D
├── Environment     WorldEnvironment
├── Sun             DirectionalLight3D
├── World           Node3D
│   ├── Ground      Node3D
│   ├── AxisMarker  Node3D
│   ├── RefCube     MeshInstance3D
│   └── DemoSpinner MeshInstance3D
├── Cameras         Node3D
│   ├── FreeFly     Camera3D
│   └── Orbit       Camera3D
└── UI              CanvasLayer
    └── Status      Label
```

Set these properties in the Inspector:

| Node | Property | Value |
|---|---|---|
| `Main` | Process → Mode | **Always** (keys must work while paused) |
| `Environment` | Environment | *New Environment*. Then Background → Mode **Sky**, Sky → *New Sky* → Sky Material *New ProceduralSkyMaterial*; Ambient Light → Source **Sky**; Tonemap → Mode **Filmic** |
| `Sun` | Transform → Rotation | x = −50°, y = 30°, z = 0 |
| `Sun` | Shadow → Enabled | on |
| `RefCube` | Mesh | *New BoxMesh* (default size is 1 × 1 × 1 m) |
| `RefCube` | Transform → Position | (−3, 0.5, 2): the bottom face sits on y = 0 |
| `RefCube` | Surface Material Override → 0 | *New StandardMaterial3D*, Albedo color yellow |
| `DemoSpinner` | Mesh | *New BoxMesh*, size (0.5, 0.5, 0.5), any color |
| `DemoSpinner` | Node dock → Groups | add `resettable` |
| `FreeFly`, `Orbit` | Far | 2000 m (Module 2's terrain is 256 m wide) |
| `FreeFly` | Transform → Position / Rotation | (8, 4, 10) / x = −15.3°, y = 38.7°: looks at (0, 0.5, 0), just above the origin |
| `Status` | Position | (12, 8). Theme Overrides: font size 18, outline size 4, outline color black |

Save as `res://main.tscn`. In *Project Settings → Application → Run*, set **Main Scene** to it.

## Step 4: World scripts

Create these three scripts and attach them (drag the `.gd` file onto the node, or use the script icon):

| Script | Attach to | What it does |
|---|---|---|
| [`world/ground_grid.gd`](code/godot/world/ground_grid.gd) | `World/Ground` | 100 × 100 m dark plane plus 1 m line grid, every 10th line brighter |
| [`world/axis_marker.gd`](code/godot/world/axis_marker.gd) | `World/AxisMarker` | red/green/blue arrows, 2 m long, with labels |
| [`world/demo_spinner.gd`](code/godot/world/demo_spinner.gd) | `World/DemoSpinner` | circles the origin on its own pausable clock |

The labels of the axis marker are the point of this lab. They must say what [frames.md](../reference/frames.md) says about the Godot world:

```gdscript
_arrow(Vector3.RIGHT, X_COLOR, "+X  East")
_arrow(Vector3.UP, Y_COLOR, "+Y  Up")
_arrow(Vector3.BACK, Z_COLOR, "+Z  South")
# North is the direction people look for first: label the -Z end too
_shaft(Vector3.FORWARD, Z_COLOR.lerp(Color.WHITE, 0.5), 0.01)
_label(Vector3.FORWARD * (length + 0.5), Z_COLOR.lerp(Color.WHITE, 0.3), "-Z  North")
```

`Vector3.FORWARD` is `(0, 0, −1)` and `Vector3.BACK` is `(0, 0, 1)`. Godot calls −Z "forward" because cameras and models look that way. In our world, −Z is also north. That is why vehicles are parked nose −Z in Module 2: "nose north" and "Godot forward" are the same direction.

Both `ground_grid.gd` and `axis_marker.gd` are `@tool` scripts, so the grid and the arrows appear in the editor viewport as soon as you attach them. If they do not, close and reopen the scene.

## Step 5: The cameras

Create [`cameras/free_fly_camera.gd`](code/godot/cameras/free_fly_camera.gd) and [`cameras/orbit_camera.gd`](code/godot/cameras/orbit_camera.gd) and attach them to `FreeFly` and `Orbit`. The core of each:

```gdscript
# free-fly: WASD in the camera's own frame, Q/E straight down/up
var in2 := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
var dir := basis * Vector3(in2.x, 0.0, in2.y)
dir.y += Input.get_axis("move_down", "move_up")
position += dir.limit_length(1.0) * v * delta
```

```gdscript
# orbit: the camera sits on a sphere around target and its -Z points at it
var b := Basis.from_euler(Vector3(deg_to_rad(pitch_deg), deg_to_rad(yaw_deg), 0.0))
transform = Transform3D(b, target + b * Vector3(0.0, 0.0, distance))
```

Both scripts return early from input handling when `current` is false. Only the active camera reacts to keys. Both have `reset_view()`, which restores the pose they had at start.

Orbit exports: `target`, `follow` (a node to track, used in later modules), `distance`, `yaw_deg` (0 = camera south of the target, looking north), `pitch_deg` (negative = looking down).

## Step 6: `main.gd`

Attach [`main.gd`](code/godot/main.gd) to `Main`. It does four things:

```gdscript
@onready var _cameras: Array[Camera3D] = [$Cameras/FreeFly, $Cameras/Orbit]

func _ready() -> void:
	_set_camera(0)                                   # FreeFly is current at start

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("camera_next"):
		_set_camera((_cam_index + 1) % _cameras.size())
	elif event.is_action_pressed("pause_toggle"):
		get_tree().paused = not get_tree().paused
	elif event.is_action_pressed("reset"):
		reset()                                      # cameras home + call_group("resettable", "reset")
```

and in `_process` it writes the status line, including the camera position converted to ENU:

```
FPS 60   camera: FreeFly [C]   running [P]   reset [R]
camera ENU  E 8.0  N -10.0  U 4.0 m
```

The start pose `(8, 4, 10)` in Godot is E = 8, N = −10, U = 4: southeast of the origin. Check that against [frames.md](../reference/frames.md) by hand once.

## Step 7: Run it

Press **F5**. Then:

1. Hold the right mouse button and look around, and fly with WASD, Q/E and Shift.
2. Press `C`. The status says `Orbit`. Right-drag to orbit, use the wheel to zoom, and WASD to move the target.
3. Press `P`. The status says `PAUSED`, the spinner freezes, and the cameras still move. Press `P` again.
4. Press `R`. The cameras jump home and the spinner restarts from angle 0.
5. Fly north (toward the `-Z North` label). The status `N` value increases.

## Step 8: The headless test

Copy [`tests/test_m01.gd`](code/godot/tests/test_m01.gd) into `godot/tests/`, then:

```bash
cd ~/robosim/godot
~/tools/godot --headless --path . --import       # new class_name scripts were added
~/tools/godot --headless --path . -s tests/test_m01.gd
```

Expected output (this is the run used to verify the reference code):

```
PASS  FreeFly is the active camera at start
PASS  FreeFly looks at the origin (its -Z)
PASS  C switches to Orbit
PASS  Orbit looks at its target
PASS  C again switches back to FreeFly
PASS  P pauses the tree; spinner time frozen at 0.086 s
PASS  status label shows PAUSED and the camera name
PASS  P again resumes
PASS  R resets the spinner clock
PASS  R puts FreeFly back home
axis labels: ["+X  East", "+Y  Up", "+Z  South", "-Z  North"]
PASS  axis labels X=East, Y=Up, Z=South, -Z=North
PASS  RefCube is 1 m and sits on y = 0
M01 RESULT: PASS (0 failed)
```

The frozen spinner time differs from run to run. If your FreeFly start pose differs from (8, 4, 10), edit the two lines in the test that use it.

## Step 9: Commit

```bash
cd ~/robosim
printf 'godot/.godot/\nlogs/\n__pycache__/\n*.pyc\n' > .gitignore
git init && git add -A && git commit -m "Module 1: viewer with cameras, status, pause/reset, axis marker"
git ls-files | grep '\.godot/' || echo "cache not committed: good"
```

## Check

Go through the **Check** list in the [module README](README.md): Inspector change vs code change, which camera is active and why, pause/reset, axis labels against [frames.md](../reference/frames.md), the 1 m cube on the 1 m grid, and a clean repository.

## Stretch goals

- Add a third camera, `TopDown`, looking straight down at the origin from 50 m (rotation x = −90°). Its image-up direction should be north (−Z). Add it to `_cameras`.
- Show the ground height and the camera's heading in compass degrees (0 = north, 90 = east) in the status line. Hint: with `fwd = -camera.global_basis.z`, east = `fwd.x` and north = `-fwd.z`, so heading = `atan2(east, north)`. Check it by looking east (expect 90).
- Make the orbit camera's `follow` track `DemoSpinner` when you press `F`.
- Add a key that toggles *Visible Collision Shapes* at run time (`get_tree().debug_collisions_hint` must be set before nodes enter the tree, so find out what does and does not work).
- Run `test_m01.gd` under `xvfb-run` with `--rendering-driver opengl3 -- --shot=/tmp/m01.png` and look at the image.
