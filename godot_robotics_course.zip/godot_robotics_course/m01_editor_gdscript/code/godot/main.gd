extends Node3D
## Module 1 viewer root: camera switching, status text, pause and reset.
## main.tscn sets process_mode = ALWAYS on this node, so these keys keep working
## while the scene tree is paused.

@onready var _cameras: Array[Camera3D] = [$Cameras/FreeFly, $Cameras/Orbit]
@onready var _status: Label = $UI/Status

var _cam_index := 0


func _ready() -> void:
	_set_camera(0)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("camera_next"):
		_set_camera((_cam_index + 1) % _cameras.size())
	elif event.is_action_pressed("pause_toggle"):
		get_tree().paused = not get_tree().paused
	elif event.is_action_pressed("reset"):
		reset()


## Reset: cameras back home, and every node in group "resettable" gets reset() called.
func reset() -> void:
	for cam in _cameras:
		cam.call("reset_view")
	get_tree().call_group("resettable", "reset")


func _set_camera(i: int) -> void:
	_cam_index = i
	_cameras[i].make_current()


func active_camera_name() -> String:
	var cam := get_viewport().get_camera_3d()
	return cam.name if cam else "none"


func _process(_delta: float) -> void:
	var cam := get_viewport().get_camera_3d()
	var p := cam.global_position if cam else Vector3.ZERO
	# Godot (x, y, z) = (East, Up, South)  ->  ENU (E, N, U) = (x, -z, y)
	_status.text = "FPS %d   camera: %s [C]   %s [P]   reset [R]\ncamera ENU  E %.1f  N %.1f  U %.1f m" % [
		Engine.get_frames_per_second(), active_camera_name(),
		"PAUSED" if get_tree().paused else "running", p.x, -p.z, p.y]
