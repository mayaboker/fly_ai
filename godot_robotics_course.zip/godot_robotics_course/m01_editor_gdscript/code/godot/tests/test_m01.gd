extends SceneTree
## Module 1 automated check. Run from the godot/ folder:
##   godot --headless --path . -s tests/test_m01.gd
## With a display (or xvfb-run) it also saves a screenshot:
##   godot --path . --rendering-driver opengl3 -s tests/test_m01.gd -- --shot=/tmp/m01.png

var _fail := 0


func _initialize() -> void:
	_run()


func _check(ok: bool, what: String) -> void:
	print(("PASS  " if ok else "FAIL  ") + what)
	if not ok:
		_fail += 1


func _press(action: String) -> void:
	var ev := InputEventAction.new()
	ev.action = action
	ev.pressed = true
	root.push_input(ev)


func _frames(n: int) -> void:
	for i in n:
		await process_frame


func _run() -> void:
	var main: Node3D = load("res://main.tscn").instantiate()
	root.add_child(main)
	await _frames(5)

	# 1. cameras: FreeFly starts current, C switches to Orbit and back
	var ff: Camera3D = main.get_node("Cameras/FreeFly")
	var orbit: Camera3D = main.get_node("Cameras/Orbit")
	_check(root.get_camera_3d() == ff, "FreeFly is the active camera at start")
	var to_origin := (Vector3(0, 0.5, 0) - ff.global_position).normalized()
	_check((-ff.global_basis.z).dot(to_origin) > 0.999, "FreeFly looks at the origin (its -Z)")
	_press("camera_next")
	await _frames(2)
	_check(root.get_camera_3d() == orbit, "C switches to Orbit")
	_check((-orbit.global_basis.z).dot((orbit.target - orbit.global_position).normalized()) > 0.999,
			"Orbit looks at its target")
	_press("camera_next")
	await _frames(2)
	_check(root.get_camera_3d() == ff, "C again switches back to FreeFly")

	# 2. pause stops the spinner's clock, cameras keep processing
	var spinner: DemoSpinner = main.get_node("World/DemoSpinner")
	_press("pause_toggle")
	await _frames(2)
	var t0 := spinner.demo_time
	await _frames(10)
	_check(paused and spinner.demo_time == t0, "P pauses the tree; spinner time frozen at %.3f s" % t0)
	var label: Label = main.get_node("UI/Status")
	_check(label.text.contains("PAUSED") and label.text.contains("FreeFly"),
			"status label shows PAUSED and the camera name")
	_press("pause_toggle")
	await _frames(10)
	_check(not paused and spinner.demo_time > t0, "P again resumes")

	# 3. reset puts the spinner clock back to zero and the camera home
	ff.position += Vector3(5, 0, 0)
	_press("reset")          # push_input handles the event immediately
	_check(spinner.demo_time == 0.0, "R resets the spinner clock")
	_check(ff.position.is_equal_approx(Vector3(8, 4, 10)), "R puts FreeFly back home")

	# 4. axis marker: labels match reference/frames.md
	var texts := []
	for c in main.get_node("World/AxisMarker").get_children():
		if c is Label3D:
			texts.append(c.text)
	print("axis labels: ", texts)
	_check(texts == ["+X  East", "+Y  Up", "+Z  South", "-Z  North"], "axis labels X=East, Y=Up, Z=South, -Z=North")

	# 5. reference cube: 1 m and resting on the ground
	var cube: MeshInstance3D = main.get_node("World/RefCube")
	var aabb := cube.global_transform * cube.get_aabb()
	_check(aabb.size.is_equal_approx(Vector3.ONE) and is_zero_approx(aabb.position.y), "RefCube is 1 m and sits on y = 0")

	# 6. optional screenshot (needs a real renderer, e.g. under xvfb-run)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--shot="):
			await _frames(30)
			var img := root.get_texture().get_image()
			img.save_png(arg.trim_prefix("--shot="))
			print("saved ", arg.trim_prefix("--shot="), " ", img.get_size())

	print("M01 RESULT: %s (%d failed)" % ["PASS" if _fail == 0 else "FAIL", _fail])
	quit(_fail)
