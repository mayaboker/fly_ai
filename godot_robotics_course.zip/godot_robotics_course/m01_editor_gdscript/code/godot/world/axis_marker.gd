@tool
class_name AxisMarker
extends Node3D
## XYZ axis marker for the course world frame (reference/frames.md):
##   +X red   = East
##   +Y green = Up
##   +Z blue  = South, so -Z = North
## @tool: the arrows are also drawn inside the editor. They are rebuilt in _ready and
## are not saved into the .tscn (they have no owner), so the scene file stays small.

@export var length := 2.0:                ## arrow length in m
	set(v):
		length = v
		if is_inside_tree():
			_build()
@export var show_labels := true:
	set(v):
		show_labels = v
		if is_inside_tree():
			_build()

const X_COLOR := Color(0.9, 0.15, 0.15)
const Y_COLOR := Color(0.2, 0.8, 0.2)
const Z_COLOR := Color(0.2, 0.4, 1.0)


func _ready() -> void:
	_build()


func _build() -> void:
	for c in get_children():
		if c.has_meta("axis_marker_part"):
			c.free()
	_arrow(Vector3.RIGHT, X_COLOR, "+X  East")
	_arrow(Vector3.UP, Y_COLOR, "+Y  Up")
	_arrow(Vector3.BACK, Z_COLOR, "+Z  South")
	# North is the direction people look for first: label the -Z end too (thin, no arrow head)
	_shaft(Vector3.FORWARD, Z_COLOR.lerp(Color.WHITE, 0.5), 0.01)
	_label(Vector3.FORWARD * (length + 0.5), Z_COLOR.lerp(Color.WHITE, 0.3), "-Z  North")


func _arrow(dir: Vector3, color: Color, text: String) -> void:
	_shaft(dir, color, 0.04)
	var head := MeshInstance3D.new()
	var cone := CylinderMesh.new()
	cone.top_radius = 0.0
	cone.bottom_radius = 0.12
	cone.height = 0.25
	head.mesh = cone
	head.material_override = _mat(color)
	head.basis = _basis_y_to(dir)
	head.position = dir * (length + 0.125)
	_add(head)
	_label(dir * (length + 0.5), color, text)


func _shaft(dir: Vector3, color: Color, radius: float) -> void:
	var m := MeshInstance3D.new()
	var cyl := CylinderMesh.new()            # a CylinderMesh is along its local +Y
	cyl.top_radius = radius
	cyl.bottom_radius = radius
	cyl.height = length
	m.mesh = cyl
	m.material_override = _mat(color)
	m.basis = _basis_y_to(dir)
	m.position = dir * (length / 2.0)
	_add(m)


func _label(pos: Vector3, color: Color, text: String) -> void:
	if not show_labels:
		return
	var l := Label3D.new()
	l.text = text
	l.modulate = color
	l.outline_modulate = Color.BLACK
	l.font_size = 64
	l.outline_size = 18
	l.pixel_size = 0.008                     # 64 px * 0.008 = about 0.5 m tall text
	l.no_depth_test = true                   # readable even when something is in front
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.position = pos
	_add(l)


## Rotation that turns local +Y into dir (dir is one of the six axis directions).
func _basis_y_to(dir: Vector3) -> Basis:
	if dir.is_equal_approx(Vector3.UP):
		return Basis.IDENTITY
	if dir.is_equal_approx(Vector3.DOWN):
		return Basis(Vector3.RIGHT, PI)
	var axis := Vector3.UP.cross(dir).normalized()
	return Basis(axis, Vector3.UP.angle_to(dir))


func _mat(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	return m


func _add(n: Node3D) -> void:
	n.set_meta("axis_marker_part", true)
	add_child(n)
