class_name DemoSpinner
extends Node3D
## A stand-in for "something that moves": circles the origin so pause and reset have a
## visible effect. It is driven by its own clock, and it stops when the tree is paused.
## From Module 4 on, nothing in Godot moves by itself: poses come from the physics process.

@export var radius := 3.0          ## m
@export var height := 1.0          ## m above the ground
@export var period_s := 8.0        ## one lap

var demo_time := 0.0               ## seconds of unpaused time since the last reset


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE   # stop when get_tree().paused is true
	_place()


func reset() -> void:
	demo_time = 0.0
	_place()


func _process(delta: float) -> void:
	demo_time += delta
	_place()


func _place() -> void:
	var a := TAU * demo_time / period_s
	position = Vector3(radius * cos(a), height, -radius * sin(a))   # counter-clockwise seen from above
	rotation.y = a
