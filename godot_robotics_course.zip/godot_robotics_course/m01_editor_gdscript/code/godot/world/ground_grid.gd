@tool
class_name GroundGrid
extends Node3D
## Flat gray ground with a 1 m line grid (every 10th line brighter).
## Module 1 only: Module 2 replaces it with the shared terrain.

@export var half_size := 50       ## grid covers -half_size .. +half_size m on X and Z
@export var ground_color := Color(0.22, 0.24, 0.23)


func _ready() -> void:
	for c in get_children():
		c.free()
	var plane := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(half_size * 2, half_size * 2)
	plane.mesh = pm
	var gm := StandardMaterial3D.new()
	gm.albedo_color = ground_color
	plane.material_override = gm
	plane.position.y = -0.005            # just below the lines, so they never z-fight
	add_child(plane)

	var minor := PackedVector3Array()
	var major := PackedVector3Array()
	for i in range(-half_size, half_size + 1):
		var seg := PackedVector3Array([Vector3(i, 0, -half_size), Vector3(i, 0, half_size),
				Vector3(-half_size, 0, i), Vector3(half_size, 0, i)])
		if i % 10 == 0:
			major.append_array(seg)
		else:
			minor.append_array(seg)
	add_child(_lines(minor, Color(0.3, 0.32, 0.31)))
	add_child(_lines(major, Color(0.55, 0.57, 0.56)))


func _lines(points: PackedVector3Array, color: Color) -> MeshInstance3D:
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = points
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_LINES, arrays)
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = m
	return mi
