class_name FreeFlyCamera
extends Camera3D
## Free-fly camera: WASD to move, Q/E down/up, Shift = fast.
## Hold the RIGHT mouse button to look around (the cursor is captured while held).
## Only the current camera reacts to input.

@export var speed := 10.0                 ## m/s
@export var fast_multiplier := 4.0        ## speed factor while "move_fast" is held
@export var mouse_sensitivity := 0.003    ## radians per mouse pixel
@export_range(0.0, 89.0) var max_pitch_deg := 85.0

var _yaw := 0.0
var _pitch := 0.0
var _home := Transform3D.IDENTITY


func _ready() -> void:
	_home = transform
	_sync_angles()


## Back to the pose the camera had when the scene started.
func reset_view() -> void:
	transform = _home
	_sync_angles()


func _sync_angles() -> void:
	var e := basis.get_euler()            # default order YXZ: x = pitch, y = yaw
	_pitch = e.x
	_yaw = e.y


func _unhandled_input(event: InputEvent) -> void:
	if not current:
		return
	var mb := event as InputEventMouseButton
	if mb and mb.button_index == MOUSE_BUTTON_RIGHT:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if mb.pressed else Input.MOUSE_MODE_VISIBLE
		return
	var mm := event as InputEventMouseMotion
	if mm and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		var lim := deg_to_rad(max_pitch_deg)
		_yaw -= mm.relative.x * mouse_sensitivity
		_pitch = clampf(_pitch - mm.relative.y * mouse_sensitivity, -lim, lim)
		basis = Basis.from_euler(Vector3(_pitch, _yaw, 0.0))


func _process(delta: float) -> void:
	if not current:
		return
	# get_vector returns x = right(+)/left(-), y = back(+)/forward(-): the camera's own x and z
	var in2 := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var dir := basis * Vector3(in2.x, 0.0, in2.y)
	dir.y += Input.get_axis("move_down", "move_up")          # world up/down
	var v := speed * (fast_multiplier if Input.is_action_pressed("move_fast") else 1.0)
	position += dir.limit_length(1.0) * v * delta
