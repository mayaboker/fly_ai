class_name OrbitCamera
extends Camera3D
## Orbit camera: circles a target point (or a followed node).
## Right-drag = orbit, mouse wheel = zoom, WASD = move the target, Q/E = target down/up.
## Only the current camera reacts to input.

@export var target := Vector3.ZERO        ## point to look at (Godot world, m)
@export var follow: Node3D                ## if set, the target tracks this node every frame
@export var distance := 14.0              ## m from target
@export var yaw_deg := 35.0               ## 0 = camera south of target, looking north (-Z)
@export_range(-89.0, 89.0) var pitch_deg := -30.0   ## negative = looking down
@export var min_distance := 1.0
@export var max_distance := 400.0
@export var orbit_sensitivity := 0.3      ## degrees per mouse pixel
@export var pan_speed := 10.0             ## m/s for WASD target moves

var _home := {}


func _ready() -> void:
	_home = {"target": target, "distance": distance, "yaw": yaw_deg, "pitch": pitch_deg}
	_apply()


func reset_view() -> void:
	target = _home.target
	distance = _home.distance
	yaw_deg = _home.yaw
	pitch_deg = _home.pitch
	_apply()


## Place the camera on a sphere around the target. Basis -Z points at the target.
func _apply() -> void:
	var b := Basis.from_euler(Vector3(deg_to_rad(pitch_deg), deg_to_rad(yaw_deg), 0.0))
	transform = Transform3D(b, target + b * Vector3(0.0, 0.0, distance))


func _unhandled_input(event: InputEvent) -> void:
	if not current:
		return
	var mb := event as InputEventMouseButton
	if mb and mb.pressed:
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			distance = maxf(min_distance, distance * 0.9)
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			distance = minf(max_distance, distance / 0.9)
	var mm := event as InputEventMouseMotion
	if mm and (mm.button_mask & MOUSE_BUTTON_MASK_RIGHT):
		yaw_deg -= mm.relative.x * orbit_sensitivity
		pitch_deg = clampf(pitch_deg - mm.relative.y * orbit_sensitivity, -89.0, 89.0)


func _process(delta: float) -> void:
	if follow:
		target = follow.global_position
	elif current:
		var in2 := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
		var flat := Basis(Vector3.UP, deg_to_rad(yaw_deg))      # pan relative to view heading
		var dir := flat * Vector3(in2.x, 0.0, in2.y)
		dir.y = Input.get_axis("move_down", "move_up")
		target += dir.limit_length(1.0) * pan_speed * delta
	_apply()
