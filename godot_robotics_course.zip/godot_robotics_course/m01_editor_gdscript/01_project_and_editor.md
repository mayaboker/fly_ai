# 01 Project structure, the editor and exported properties (45 min)

A Godot project is a folder with a file called `project.godot` in it. Everything inside that folder is the project. Everything outside it is just the rest of your disk. This sounds trivial, but it decides where files go in this course. The Godot project is `robosim/godot/`. The shared terrain lives in `robosim/data/`, outside the project, because the Python side reads it too and because Godot would otherwise "import" it (see below).

## The project folder

```
robosim/godot/
├── project.godot          ← project settings, input map, layer names (plain text)
├── main.tscn              ← a scene (plain text)
├── main.gd                ← a script (plain text)
├── main.gd.uid            ← stable id of the script (Godot 4.4+ writes these)
├── cameras/…              ← your folders, any names you like
├── icon.svg               ← imported asset
├── icon.svg.import        ← import settings for that asset (plain text)
└── .godot/                ← CACHE: imported textures, class list, editor state
```

| Path | What it is | Commit? |
|---|---|---|
| `project.godot` | All project settings. Edited through *Project → Project Settings*, but readable as text | yes |
| `*.tscn`, `*.tres` | Scenes and resources in text form | yes |
| `*.gd` | Scripts | yes |
| `*.uid` | One small file per script or shader, holding its `uid://…` id | yes |
| `*.import` | How an asset (PNG, glTF, WAV) is imported | yes |
| `.godot/` | Cache of imported data, global class list, editor layout | **no** |
| `export_presets.cfg` | Export targets | only if you export builds |

The `.godot/` folder is rebuilt automatically. Delete it when the editor acts strangely. It is safe. Add a `.gitignore` in `robosim/`:

```gitignore
# robosim/.gitignore
godot/.godot/
logs/
__pycache__/
*.pyc
```

## `res://`, `user://` and absolute paths

Inside Godot you name files with virtual paths:

| Prefix | Means | Example |
|---|---|---|
| `res://` | the project folder (read-only in exported builds) | `res://main.tscn` |
| `user://` | a per-user writable folder (`~/.local/share/godot/app_userdata/robosim/` on Linux) | `user://settings.cfg` |
| none | an absolute OS path | `/home/you/robosim/data/terrain/heightmap.png` |

You can convert a virtual path to an OS path with `ProjectSettings.globalize_path("res://")`. Module 2 uses this to reach `robosim/data/terrain/` from inside `robosim/godot/`:

```gdscript
var data_dir := ProjectSettings.globalize_path("res://").path_join("../data/terrain").simplify_path()
```

**Why keep data outside `res://`?** Godot imports every image it finds in the project. A heightmap PNG inside `res://` would be turned into a compressed texture, and the loader converts 16-bit PNGs to 8 bits. You want the raw file, read the same way by Python and Godot. Module 2 shows this in detail.

## A short editor tour

| Area | Default place | Use it for |
|---|---|---|
| Scene dock | top left | the node tree of the open scene; the *Remote* tab while the game runs |
| FileSystem dock | bottom left | files under `res://`; drag scenes from here into the viewport to instance them |
| 3D viewport | center | look at the scene; the gizmo top right shows X red, Y green, Z blue |
| Inspector | right | the properties of the selected node or resource |
| Node dock | right, tab next to Inspector | signals and groups of the selected node |
| Bottom panel | bottom | Output, Debugger, Animation, Shader editor |

Keys you will use all the time: **F5** runs the project's main scene, **F6** runs the scene you are editing, **F8** stops. In the 3D viewport, hold the right mouse button and use WASD to fly, the same way the camera you build in the lab works.

The 3D viewport gizmo uses the same colors as the axis marker in the lab: X red, Y green, Z blue. In this course those axes mean East, Up and South (see [frames](../reference/frames.md)). North is −Z. The gizmo always shows where each axis points from your current view. Read it, rather than trusting the names of the preset views (*Front*, *Rear*, …) to tell you a compass direction.

## The Inspector and exported properties

The Inspector lists every property of the selected node: position, mesh, material, camera FOV, and so on. Your own scripts can add properties to it with `@export`:

```gdscript
class_name FreeFlyCamera
extends Camera3D

@export var speed := 10.0                 ## m/s
@export var fast_multiplier := 4.0        ## speed factor while "move_fast" is held
@export_range(0.0, 89.0) var max_pitch_deg := 85.0
```

Select the camera, and *Speed*, *Fast Multiplier* and *Max Pitch Deg* appear in the Inspector under the script's name. The `##` comment becomes the tooltip.

**Where the value lives.** This is the most important detail on this page.

- The number after `:=` is the **default**. It lives in the script.
- If you change the value in the Inspector, the **scene file** stores it. A small revert arrow appears next to the property.
- The scene's value wins. If you change the default in the script later, nodes that store their own value keep it.

You can see it in the text of `main.tscn`. A camera whose speed was changed in the Inspector looks like this:

```ini
[node name="FreeFly" type="Camera3D" parent="Cameras"]
far = 2000.0
script = ExtResource("2_ff")
speed = 20.0
```

With no `speed =` line, the node uses the script default. This is why the Module 1 Check asks you to change one property in the Inspector and one in code, and to explain the result.

Useful export variants:

| Annotation | Inspector shows |
|---|---|
| `@export var n := 3` | integer field |
| `@export_range(0, 100, 0.5) var pct := 50.0` | slider with limits and step |
| `@export var target: Node3D` | node picker (saved as a NodePath) |
| `@export_file("*.png") var path := ""` | file dialog |
| `@export_flags_3d_physics var layer := 1` | the 32 physics layer checkboxes, with your layer names |
| `@export var color := Color.RED` | color picker |

Use `@export` for the things you tune: speeds, sizes, ports, rates. Do not use it for internal state. Internal variables start with an underscore by convention (`_yaw`) and are not exported.

## Project settings worth knowing now

*Project → Project Settings* edits `project.godot`. For this course:

| Setting | Value | Why |
|---|---|---|
| Application → Run → Main Scene | `res://main.tscn` | what F5 and a headless run start |
| Display → Window → Size | 1280 × 720 | matches the camera sizes used later |
| Rendering → Anti Aliasing → MSAA 3D | 4× | thin lines (grid, roads) shimmer less |
| Input Map | see [03](03_gdscript_and_callbacks.md) | keys become named actions |
| Layer Names → 3D Physics | Module 2 | named collision layers |

Turn on *Advanced Settings* (top right of the dialog) to see all of them.

## Try it

- Create a new project in `~/robosim/godot` (Project Manager → *Create*, renderer *Forward+*). Open `project.godot` in a text editor and find the line that names the project.
- Add a `MeshInstance3D` with a `BoxMesh`. Change *Position* in the Inspector, save, and look at the `.tscn` in a text editor. Click the revert arrow, save again, and see the line disappear.
- Close the editor, delete `.godot/`, and reopen the project. Note what Godot rebuilds and how long it takes.
- Write the `.gitignore` above, run `git init`, and check that `git status` does not list `.godot/`.

## References

- Godot docs, *Project organization*: <https://docs.godotengine.org/en/stable/tutorials/best_practices/project_organization.html>
- Godot docs, *Version control systems*: <https://docs.godotengine.org/en/stable/tutorials/best_practices/version_control_systems.html>
- Godot docs, *File system* (`res://`, `user://`): <https://docs.godotengine.org/en/stable/tutorials/scripting/filesystem.html>
- Godot docs, *GDScript exported properties*: <https://docs.godotengine.org/en/stable/tutorials/scripting/gdscript/gdscript_exports.html>
