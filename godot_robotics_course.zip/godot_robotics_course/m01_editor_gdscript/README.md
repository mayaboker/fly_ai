# Module 1: Godot editor and GDScript essentials (5 h)

## What you will build

You start the `robosim/godot` project that every later module extends. By the end it opens a 3D viewport you can fly through with two cameras (free-fly and orbit). It shows a status line (FPS, active camera, paused state) and has pause and reset keys. It also has a labelled XYZ axis marker at the origin that shows the course's world frame, and a 1 m reference cube.

![Module 1 viewport](img/m01_viewport.png)

*Rendered by `code/godot/tests/test_m01.gd` under xvfb. The FPS value in this image comes from a software renderer and means nothing.*

## Prerequisites

- [00 Setup](../00_setup/README.md) done: Godot 4.7.2 runs, `~/robosim/` exists.
- You have read [the frames cheat sheet](../reference/frames.md), at least the "World frames" table.
- Python and git basics. No Godot experience needed.

## Sub-topics

| File | Topic | Time |
|---|---|---:|
| [01_project_and_editor.md](01_project_and_editor.md) | Project folder, `res://`, the `.godot` cache, what to commit, the Inspector and exported properties | 45 min |
| [02_scenes_nodes_signals.md](02_scenes_nodes_signals.md) | Nodes, the scene tree, scenes, instancing, signals, groups | 45 min |
| [03_gdscript_and_callbacks.md](03_gdscript_and_callbacks.md) | Typed GDScript, `_ready` / `_process` / `_physics_process`, the physics-tick rule, input actions, pause | 60 min |
| [04_scenes_from_code.md](04_scenes_from_code.md) | Building nodes in code vs saving `.tscn`, `@tool`, generated scenes that diff well | 30 min |
| [05_debugging_and_tools.md](05_debugging_and_tools.md) | `print`, the debugger, the remote scene tree, VS Code, headless runs and tests | 30 min |
| [lab.md](lab.md) | Build the viewer: cameras, status text, pause/reset, axis marker, reference cube | 90 min |

## Deliverables

In `~/robosim/godot/`:

- `project.godot` with the input actions `move_*`, `camera_next`, `pause_toggle`, `reset`
- `main.tscn`, `main.gd`
- `cameras/free_fly_camera.gd`, `cameras/orbit_camera.gd`
- `world/axis_marker.gd`, `world/ground_grid.gd`, `world/demo_spinner.gd`
- `tests/test_m01.gd`, which passes headless
- a git repository whose first commit does not contain `.godot/`

## Check

Do all of these before you move on. The automated part is `godot --headless --path . -s tests/test_m01.gd`. It must print `M01 RESULT: PASS (0 failed)`.

1. **Inspector change.** Commit first. Then select `World/RefCube`, change its material's albedo color in the Inspector, and save. `git diff main.tscn` shows one changed line, `albedo_color = ...`. (If you started from the hand-written `code/godot/main.tscn`, the editor's first save also adds `unique_id=` to every node. Commit that save, then make the change.)
2. **Code change.** Change the default `speed` in `free_fly_camera.gd` from 10 to 20 m/s. Run the scene and fly. The camera is faster **only if** `main.tscn` does not override `speed`. Explain why in one sentence (answer: a value saved in the scene overrides the script default).
3. **Active camera.** With the scene running, the status line names the active camera. Press `C` twice and watch it go FreeFly → Orbit → FreeFly. Explain in one or two sentences why FreeFly is active at start. The answer has two parts. `main.gd` calls `make_current()` on it in `_ready()`. Without that call, the first `Camera3D` to enter the tree would become current anyway, and that is also FreeFly.
4. **Pause.** Press `P`. The status line says `PAUSED`, the purple spinner stops, and both cameras still move. Press `R`. The spinner jumps back to its start and the cameras go home.
5. **Axis marker.** The labels read `+X East` (red), `+Y Up` (green), `+Z South` (blue) and `-Z North`. These match the "Godot world" row of [frames.md](../reference/frames.md). When you fly the camera north (toward `-Z`), the `N` value in the status line goes up.
6. **Scale.** Fly next to the reference cube. It covers exactly one cell of the 1 m ground grid.
7. **Repository.** `git status` is clean and `git ls-files | grep .godot/` prints nothing.

## Common mistakes

- **Moving things in `_physics_process`.** Godot's physics tick (60 Hz by default) is not the course's physics. From Module 4 on, the Python process owns time and vehicle motion. Godot only displays poses. See [03](03_gdscript_and_callbacks.md).
- **Changing a script default and expecting the scene to follow.** If the Inspector shows a value with a "revert" arrow, the scene stores its own value and ignores the default.
- **Pausing the tree and losing the keyboard.** When `get_tree().paused` is true, nodes with the default process mode stop, including the one that would unpause. Set `process_mode = Always` on the root of the viewer.
- **Committing `.godot/`.** It is a cache that Godot rebuilds. It is large, machine-specific, and it causes merge conflicts.
- **`class_name` not found when running headless.** After you add a new `class_name` script, run `godot --headless --path . --import` once.
- **Mixing spaces and tabs.** The course uses tabs in `.gd` files. One line with spaces gives a parse error that is easy to miss.

Next: [Module 2: Scenes, terrain and vehicle assets](../m02_scene_assets/README.md)
