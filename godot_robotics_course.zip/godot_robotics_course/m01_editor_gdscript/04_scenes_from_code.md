# 04 Building scenes from code vs saving `.tscn` (30 min)

You can make a node tree in three ways. You can click it together in the editor and save a `.tscn`. You can create the nodes in a script at run time. Or you can create them in a script **once** and save the result as a `.tscn`. A robotics simulator uses all three. The trick is to pick the one that keeps your files reviewable and your numbers in one place.

## The three ways

| Way | Good for | Weak at |
|---|---|---|
| Editor, saved `.tscn` | layout you tune by eye: lights, cameras, UI, the main scene | repeated or computed geometry; numbers that also live in Python |
| Code at run time (`_ready`) | geometry computed from data: terrain from a heightmap, roads from a polyline, axis arrows | you cannot see it in the editor unless the script is `@tool` |
| Code that **generates** a `.tscn` | parametric assets you still want to open, inspect and instance in the editor: the four vehicles | one more step: rerun the generator after edits |

In this course: `main.tscn` is made in the editor, the axis marker, grid, terrain and range are built at run time, and the vehicle scenes are generated (Module 2).

## The `.tscn` text format

A scene file is plain text. That is why it can live in git:

```ini
[gd_scene load_steps=14 format=3]

[ext_resource type="Script" path="res://main.gd" id="1_main"]

[sub_resource type="BoxMesh" id="CubeMesh"]

[sub_resource type="StandardMaterial3D" id="CubeMat"]
albedo_color = Color(0.95, 0.75, 0.2, 1)

[node name="Main" type="Node3D"]
process_mode = 3
script = ExtResource("1_main")

[node name="RefCube" type="MeshInstance3D" parent="World"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -3, 0.5, 2)
mesh = SubResource("CubeMesh")
surface_material_override/0 = SubResource("CubeMat")
```

- `ext_resource`: another file (script, scene, texture).
- `sub_resource`: a resource stored inside this file (mesh, material, shape).
- `node`: one node. Only properties that differ from the default are written.
- `Transform3D(...)` holds 12 numbers: the 3×3 basis **row by row**, then the origin. The first three numbers are row 0 of the basis, not the X axis vector. We checked this. In `main.tscn` the FreeFly camera's 12 numbers were computed in numpy as rows, and `tests/test_m01.gd` confirms that the camera's −Z points at (0, 0.5, 0), just above the origin.

Because only changed properties are written, a one-property change in the Inspector is a one-line diff. That is the "generated scenes diff well" idea. A text format is diffable if the tool that writes it is **deterministic**: the same input gives the same bytes.

## Run-time construction

`world/axis_marker.gd` builds its arrows in `_ready()`:

```gdscript
@tool
class_name AxisMarker
extends Node3D

func _ready() -> void:
	_build()

func _build() -> void:
	for c in get_children():
		if c.has_meta("axis_marker_part"):
			c.free()                         # rebuild cleanly when a property changes
	_arrow(Vector3.RIGHT, X_COLOR, "+X  East")
	_arrow(Vector3.UP, Y_COLOR, "+Y  Up")
	_arrow(Vector3.BACK, Z_COLOR, "+Z  South")
	...

func _add(n: Node3D) -> void:
	n.set_meta("axis_marker_part", true)
	add_child(n)                             # no owner → never saved into main.tscn
```

Three details make this pleasant to use:

1. **`@tool`** makes the script run inside the editor too, so you see the arrows while you lay out the scene. Keep `@tool` scripts small and side-effect free: they run every time the scene opens.
2. **Owner.** A node is saved in a `.tscn` only if its `owner` is the scene root. Nodes added in `_ready()` have no owner, so `main.tscn` contains just `[node name="AxisMarker" ...]` and the script. The 3D geometry never reaches the file.
3. **Exported setters** rebuild on change. Change `length` in the Inspector and the arrows redraw immediately:

```gdscript
@export var length := 2.0:
	set(v):
		length = v
		if is_inside_tree():
			_build()
```

The numbers that define the geometry live in one place: the script defaults and the scene's exported values. Module 2 goes further. The road and gate positions live in `data/terrain/range.json`, which Python and Godot both read, so they cannot disagree.

## Generating a `.tscn` from a script

A script that `extends SceneTree` can run without opening a scene. It builds nodes, sets each node's `owner` to the root, packs them and saves:

```gdscript
# vehicles/build_vehicles.gd (Module 2), run with:
#   godot --headless --path . -s vehicles/build_vehicles.gd
extends SceneTree

func _initialize() -> void:
	var root := Node3D.new()
	root.name = "Rover"
	var body := MeshInstance3D.new()
	body.name = "Chassis"
	var mesh := BoxMesh.new()
	mesh.size = Vector3(0.6, 0.2, 0.9)
	mesh.resource_scene_unique_id = "mesh_Chassis"   # fixed id instead of a random one
	body.mesh = mesh
	root.add_child(body)
	body.owner = root                                # pack() only keeps owned nodes
	var scene := PackedScene.new()
	scene.pack(root)
	ResourceSaver.save(scene, "res://vehicles/rover.tscn")
	quit()
```

The result opens in the editor like any hand-made scene. You can instance it, look at it from all sides, and add children in the scenes that use it.

**Making it deterministic.** By default Godot 4.7 gives every sub-resource a random id (`BoxMesh_w6xgo`) and every node a random `unique_id=` number. Run the generator twice and the files differ on every line. The diff tells you nothing. Module 2's generator fixes both:

- It sets `resource_scene_unique_id` on every mesh, material and shape to a name derived from the node (`mesh_Chassis`).
- It removes the ` unique_id=NNN` attributes after saving. The scenes load fine without them, and the editor adds them back the first time you save the scene there.

We tested this: running the generator twice gives byte-identical files (same `md5sum`). Change the wheel radius in the generator, rerun, and `git diff` shows only the radius lines of the four wheel meshes.

## When to use which

| Situation | Choose |
|---|---|
| You tune it by eye and nobody else needs the numbers | editor `.tscn` |
| It comes from a data file shared with Python | run-time construction from that file |
| It is parametric, you want it in the editor, and you want reviewable diffs | generated `.tscn`, generator committed next to it |
| It is a mesh made by an artist | import glTF (Module 2) |

Do not hand-edit generated files. Edit the generator, rerun it, and commit both.

## Try it

- In the running lab scene, change `AxisMarker.length` to 5 in the Remote inspector. Then change it in the normal Inspector and save. What does `git diff main.tscn` show?
- Remove `@tool` from `axis_marker.gd`, reopen `main.tscn`, and note what disappears from the editor viewport (and what does not disappear in the running game).
- Write a 15-line `extends SceneTree` script that saves a scene with one 1 m `BoxMesh`. Run it twice and compare the files with `diff`. Then set `resource_scene_unique_id` and strip `unique_id=` and compare again.
- Hand-write a `[node]` block for a second cube in `main.tscn` with a `Transform3D` that rotates it 45° about Y. Open the scene and check that the result matches what you intended.

## References

- Godot docs, *TSCN file format*: <https://docs.godotengine.org/en/stable/contributing/development/file_formats/tscn.html>
- Godot docs, *Running code in the editor* (`@tool`): <https://docs.godotengine.org/en/stable/tutorials/plugins/running_code_in_the_editor.html>
- Godot docs, `PackedScene` and `Node.owner`: <https://docs.godotengine.org/en/stable/classes/class_packedscene.html>
- Godot docs, *Command line tutorial* (`--script`): <https://docs.godotengine.org/en/stable/tutorials/editor/command_line_tutorial.html>
