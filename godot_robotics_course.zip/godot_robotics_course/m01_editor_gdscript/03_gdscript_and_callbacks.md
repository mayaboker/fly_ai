# 03 Typed GDScript, the frame callbacks, and input (60 min)

GDScript looks like Python. It has indentation blocks, `func`, `for x in ...` and dictionaries. You will be productive in an hour. Three things differ, and they matter for a simulator. You should add **types**, because they catch mistakes at parse time. The engine calls **your functions on its schedule**, so you have to know which callback runs when. And Godot has **its own physics clock**, which this course must keep away from vehicles.

## Typed GDScript in ten lines

```gdscript
class_name OrbitCamera            # global name: usable as a type anywhere in the project
extends Camera3D                  # the node type this script attaches to

const MIN_PITCH := -89.0          # constant, type inferred (float)
@export var distance := 14.0      # ":=" infers float from the literal
var target: Vector3 = Vector3.ZERO    # explicit type
var _home := {}                   # Dictionary; leading underscore = "private" by convention

func _apply() -> void:            # return type
	var b := Basis.from_euler(Vector3(deg_to_rad(-30.0), deg_to_rad(35.0), 0.0))
	transform = Transform3D(b, target + b * Vector3(0.0, 0.0, distance))
```

| Python habit | GDScript |
|---|---|
| `def f(x: float) -> None:` | `func f(x: float) -> void:` |
| `x = 1.0` | `var x := 1.0` (typed) or `var x = 1.0` (Variant) |
| `list[float]` | `Array[float]` or `PackedFloat32Array` (compact, fast) |
| `dict` | `Dictionary` (`d.key` works for string keys) |
| `None` | `null` |
| `math.radians` | `deg_to_rad` |
| `a if c else b` | same |
| f-strings | `"%.2f m" % x`, `"%s at %d" % [name, n]` |
| `self.x` | `x` (`self` optional) |
| 4 spaces | **tabs** in this course |

**Why types matter here.** Without types, `var p = msg.pos` is a Variant and `p.lenght()` (typo) fails only when that line runs, maybe minutes into a flight. With `var p: Vector3 = msg.pos`, the editor underlines the typo while you type. Typed code also runs faster. Turn the warnings on in *Project Settings → Debug → GDScript* (Advanced Settings): set **Untyped Declaration** to *Warn*. In `project.godot` that is `debug/gdscript/warnings/untyped_declaration=1`.

Value types (`Vector3`, `Transform3D`, `Basis`, `Quaternion`, `Color`) are copied on assignment, like numbers. Objects (nodes, resources) are references. `Array` and `Dictionary` are references too: `var b := a` gives you the same array, not a copy. Use `a.duplicate()` when you need a copy.

`class_name` registers a global type. Other scripts can then write `var cam: OrbitCamera` or `if node is Vehicle`. The editor rebuilds the class list automatically. A command-line run does not, so after you add a `class_name` script, run `godot --headless --path . --import` once.

## The callbacks: who calls what, when

```
 scene starts:   _init()  →  _enter_tree()  →  _ready()        (children's _ready first, then parent's)
 every frame:    _process(delta)                               (once per rendered frame: 30, 60, 144 Hz…)
 every tick:     _physics_process(delta)                       (fixed, 60 Hz by default)
 on input:       _input(event) → (GUI) → _unhandled_input(event)
 leaving:        _exit_tree()
```

| Callback | Rate | In this course, use it for |
|---|---|---|
| `_ready()` | once | find nodes, build generated geometry, bind sockets |
| `_process(delta)` | every rendered frame, variable | cameras, HUD, reading the bridge, placing vehicles from received poses |
| `_physics_process(delta)` | fixed tick, `physics/common/physics_ticks_per_second` = 60 | Godot-side **queries** only (raycasts for sensors, Module 8) |
| `_unhandled_input(event)` | per event | keys and mouse not consumed by UI |

**`_ready` order is bottom-up.** Children are ready before their parent. In Module 2, `World/Terrain` runs `_ready()` (loads the heightmap) before `World/Range` (needs heights), and both run before `Main`. Siblings go in tree order. So reorder siblings in the Scene dock if one depends on another.

## The rule: Godot's physics tick never moves a vehicle

Godot has a full rigid-body engine, and `_physics_process` is its clock. It is tempting to integrate a vehicle there. **Do not.** In this course:

> The Python process (PyBullet or JSBSim) owns simulation time and vehicle dynamics. Godot shows the result.

Here is why, concretely:

| If Godot also moves the vehicle… | …you get |
|---|---|
| two integrators (Godot at 60 Hz, PyBullet at 240 Hz) | two different trajectories that drift apart |
| two clocks (Godot wall-clock ticks, physics sim time) | logs you cannot join on `t_sim` |
| Godot collision response on a body that PyBullet also collides | double bounces, jitter, tunnelling |
| pausing Godot | the vehicle stops in Godot but not in physics |

So what is Godot's physics engine for here? **Queries.** A ray from a range sensor, a lidar sweep, or "is anything inside this box" are all questions asked of static shapes (terrain, walls, gates) and of vehicle shapes that the bridge places. The shapes never move by themselves. Module 2 gives every object a `StaticBody3D` for exactly this. The sensor ownership rule from the course spec decides who computes a reading: *would the reading change if I moved a wall?* Yes → Godot. No → physics process.

In Module 1 nothing comes from physics yet. The lab's purple `DemoSpinner` moves in `_process` with its own clock, only so that pause and reset have something visible to act on. From Module 4 on, `_process` reads poses from the bridge instead, and nothing in Godot integrates motion.

```gdscript
# world/demo_spinner.gd: a visual stand-in, NOT a vehicle
func _process(delta: float) -> void:
	demo_time += delta
	var a := TAU * demo_time / period_s
	position = Vector3(radius * cos(a), height, -radius * sin(a))
```

## Input actions

Do not test raw keys (`KEY_W`) in scripts. Name **actions** in *Project Settings → Input Map* and bind keys to them. Then a gamepad or a different layout only changes the map, not the code.

| Action | Key | Used by |
|---|---|---|
| `move_forward` / `move_back` | W / S | both cameras |
| `move_left` / `move_right` | A / D | both cameras |
| `move_up` / `move_down` | E / Q | both cameras |
| `move_fast` | Shift | free-fly |
| `camera_next` | C | `main.gd` |
| `pause_toggle` | P | `main.gd` |
| `reset` | R | `main.gd` |

Add the key as a **physical** key (the editor's key dialog has a *Physical* option). WASD then stays where it is on AZERTY or Dvorak keyboards.

Two ways to read actions:

```gdscript
# continuous state, polled every frame
func _process(delta: float) -> void:
	var in2 := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var up := Input.get_axis("move_down", "move_up")

# discrete events, once per press
func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("camera_next"):
		_set_camera((_cam_index + 1) % _cameras.size())
```

`get_vector` returns a `Vector2` already clamped to length 1, so diagonal moves are not faster. Use `_unhandled_input` rather than `_input` for game keys, so a focused text field or button gets the key first.

## Pause and process modes

`get_tree().paused = true` stops every node whose **process mode** says so:

| `process_mode` | Runs when paused? | Lab use |
|---|---|---|
| `Inherit` (default) | same as parent | most nodes |
| `Pausable` | no | `DemoSpinner` (sets it in `_ready`) |
| `When Paused` | only when paused | a "PAUSED" overlay |
| `Always` | yes | `Main`, so the cameras, HUD and the unpause key keep working |
| `Disabled` | never | |

The lab sets `Main` to `Always`. Everything inherits that, except `DemoSpinner`, which opts back into `Pausable`. In Module 5, the pause key sends a reliable `PAUSE` command to the physics process instead, and Godot keeps rendering. The ownership rule again.

## Try it

- In `free_fly_camera.gd`, change `func _process(delta: float)` to `func _process(delta)` and add `var s = delta * speed`. With *Untyped Declaration* set to *Warn*, what does the editor say?
- Print `Engine.get_physics_frames()` and `Engine.get_process_frames()` once a second from `main.gd`. Change *Physics Ticks per Second* to 120 and watch the ratio change. Your render rate is not the physics rate.
- Move the spinner code from `_process` to `_physics_process`, set the physics tick to 10 Hz, and watch the motion stutter. Put it back. Module 5 solves this properly with interpolation.
- Add a second key (arrow up) to `move_forward` in the Input Map, without touching any script.

## References

- Godot docs, *GDScript reference*: <https://docs.godotengine.org/en/stable/tutorials/scripting/gdscript/gdscript_basics.html>
- Godot docs, *Static typing in GDScript*: <https://docs.godotengine.org/en/stable/tutorials/scripting/gdscript/static_typing.html>
- Godot docs, *Idle and physics processing*: <https://docs.godotengine.org/en/stable/tutorials/scripting/idle_and_physics_processing.html>
- Godot docs, *Input examples*: <https://docs.godotengine.org/en/stable/tutorials/inputs/input_examples.html>
- Godot docs, *Pausing games and process mode*: <https://docs.godotengine.org/en/stable/tutorials/scripting/pausing_games.html>
