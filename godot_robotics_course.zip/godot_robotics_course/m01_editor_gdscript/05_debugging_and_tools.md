# 05 Debugging, VS Code and headless runs (30 min)

A simulator fails quietly. A wrong sign or a swapped axis still renders something that looks plausible. You need three habits. **Print** the numbers, **inspect the live tree**, and **run checks without a window** so they can run on every change. Godot supports all three.

## Printing

| Call | Goes to | Use |
|---|---|---|
| `print(a, b)` | Output panel and stdout | values, one line |
| `prints(a, b)` / `printt(a, b)` | same, space / tab separated | quick tables |
| `print_rich("[color=red]bad[/color]")` | Output (BBCode colors) | highlight in the editor |
| `push_warning("…")` | Debugger → Errors tab, stderr | something odd, keep going |
| `push_error("…")` | Debugger → Errors tab, stderr, with stack | something wrong |
| `print_debug(x)` | Output, with file and line | where was this printed from? |
| `assert(cond, "msg")` | stops in debug builds only | invariants during development |

Format numbers so they line up and carry units:

```gdscript
print("cam ENU  E %.2f  N %.2f  U %.2f m" % [p.x, -p.z, p.y])
```

Notice the conversion in that line. Godot's `(x, y, z)` is `(East, Up, South)`, so ENU is `(x, −z, y)`. The lab's status label prints the camera position in ENU for exactly this reason: you can compare it with Python numbers without converting in your head.

Do not print every frame at 60 Hz. You cannot read it, and printing is slow. Print on events, or once a second.

## The debugger

Click in the gutter left of a line number to set a **breakpoint** (red dot), or put the keyword `breakpoint` in code. Run with F5. Execution stops there, and the **Debugger** panel (bottom) shows:

| Tab | Shows |
|---|---|
| Stack Trace | the call stack and every local variable; buttons to step over, step into and continue |
| Errors | every `push_error`, `push_warning` and engine error, with the script line |
| Profiler | time per function per frame (start it, then look) |
| Visual Profiler | CPU and GPU time per render stage |
| Monitors | FPS, process time, physics time, memory, object counts, over time |

Use **Monitors → Time → Process** when FPS drops. It tells you whether the time goes to your scripts or to rendering.

## The remote scene tree

While the game runs, the Scene dock shows two tabs: **Local** (the file you edit) and **Remote** (the live tree inside the running game). Click a remote node and the Inspector shows its *current* values, and you can change them live.

This is the best tool in this module for a simulator:

- Nodes built at run time (axis arrows, terrain mesh, roads) are visible only in Remote.
- You can read a vehicle's `global_transform` while it moves.
- You can change `speed` or `distance` live to find a good value, then copy it into the scene.

Changes made in Remote are lost when the game stops. That is a feature: experiment freely.

Two more switches in the editor's **Debug** menu: *Visible Collision Shapes* draws every collision shape (you will want this in Module 2 and Module 8), and *Visible Navigation*. From the command line the first one is `--debug-collisions`.

## VS Code

[00 Setup](../00_setup/README.md) installed the **godot-tools** extension and made VS Code the external editor. What you get:

| Feature | Needs |
|---|---|
| Syntax highlighting, formatting | the extension |
| Completion, go to definition, errors as you type | **the Godot editor running** with the project open (it serves the language server, port 6005 by default) |
| Run and debug from VS Code (breakpoints in VS Code) | a `launch.json` entry of type `godot`, see the extension's README |
| Run tests with one key | a plain VS Code task (below) |

A task file that runs the module's headless test (`robosim/.vscode/tasks.json`):

```json
{
  "version": "2.0.0",
  "tasks": [
    {
      "label": "godot: test m01",
      "type": "shell",
      "command": "~/tools/godot --headless --path godot -s tests/test_m01.gd",
      "group": "test",
      "problemMatcher": []
    }
  ]
}
```

*Terminal → Run Task…* runs it. The course did not test the VS Code integration itself (no desktop here). The commands inside the task were tested.

## Headless runs

Godot runs without a window. The course uses this for every automated test, and later for long recordings.

| Command (from `robosim/godot`) | Does |
|---|---|
| `godot --headless --path . --import` | build `.godot/` (class list, imports), then quit; needed after new `class_name` scripts |
| `godot --headless --path .` | run the main scene with no window and no GPU |
| `godot --headless --path . --quit-after 300` | same, quit after 300 frames |
| `godot --headless --path . -s tests/test_m01.gd` | run a script that `extends SceneTree` instead of the main scene |
| `godot ... -s script.gd -- --shot=/tmp/a.png` | everything after `--` is for your script: `OS.get_cmdline_user_args()` |

A test script is an ordinary GDScript that loads the scene, drives it and checks the results:

```gdscript
extends SceneTree

func _initialize() -> void:
	_run()

func _run() -> void:
	var main: Node3D = load("res://main.tscn").instantiate()
	root.add_child(main)
	for i in 5:
		await process_frame                          # let _ready and a few frames run
	var ev := InputEventAction.new()
	ev.action = "camera_next"
	ev.pressed = true
	root.push_input(ev)                              # simulate pressing C
	await process_frame
	var ok := root.get_camera_3d().name == "Orbit"
	print("PASS" if ok else "FAIL", "  C switches to Orbit")
	quit(0 if ok else 1)                             # exit code for CI and scripts
```

The full version is `code/godot/tests/test_m01.gd`. It checks cameras, pause, reset, the axis labels and the reference cube.

**Headless means no rendering.** The `--headless` driver uses a dummy renderer. `get_texture().get_image()` returns nothing useful. For screenshots on a machine without a display, use a virtual X server and the OpenGL renderer:

```bash
xvfb-run -a -s "-screen 0 1280x720x24" ~/tools/godot --path . --rendering-driver opengl3 \
    -s tests/test_m01.gd -- --shot=/tmp/m01.png
```

That is how the image in this module's README was made. The frame rate under xvfb is from a software rasterizer. Our run showed single-digit FPS. It tells you nothing about your GPU. Measure performance on your real desktop (Module 7 does it properly).

## Try it

- Put a `breakpoint` in `OrbitCamera._apply()`, run, press `C`, and read `pitch_deg` and `distance` in the Stack Trace locals. Step over one line.
- Run the scene, open Remote, select `Cameras/Orbit`, and drag `yaw_deg` in the Inspector. Watch the view orbit.
- Make the test fail on purpose (expect the wrong axis label), run it headless, and check the exit code with `echo $?`.
- Add the `tasks.json` above and run the test from VS Code.

## References

- Godot docs, *Overview of debugging tools*: <https://docs.godotengine.org/en/stable/tutorials/scripting/debug/overview_of_debugging_tools.html>
- Godot docs, *Debugger panel*: <https://docs.godotengine.org/en/stable/tutorials/scripting/debug/debugger_panel.html>
- Godot docs, *Command line tutorial*: <https://docs.godotengine.org/en/stable/tutorials/editor/command_line_tutorial.html>
- godot-tools for VS Code: <https://github.com/godotengine/godot-vscode-plugin>
