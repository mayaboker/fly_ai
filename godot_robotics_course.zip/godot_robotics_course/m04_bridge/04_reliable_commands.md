# 04 Reliable commands: ACK, resend, de-duplicate

A lost pose costs nothing: the next one arrives 17 ms later. A lost RESET is different. The user pressed the button, nothing happened, and nobody knows why. Commands that change the simulation's state must arrive. This page adds a small reliability layer on top of UDP, used only where it is needed.

## Two kinds of command

| Kind | Examples | Rule | API |
|---|---|---|---|
| **Discrete** | PAUSE, RESUME, STEP, RESET, mode change, "arm" | must arrive, exactly once | `bridge.send_command(id, cmd, args)` |
| **Continuous** | stick input at 50 Hz, a velocity setpoint stream | newest wins, like poses; a resend would be stale | `bridge.send_command_unreliable(id, cmd, args)` |

Both use the same COMMAND packet. Only the sender's behavior differs.

## The mechanism

```
viewer (SimBridge)                                physics (PhysicsBridge)
──────────────────                                ───────────────────────
send COMMAND seq=57  ─────────── X lost
   (keep it in _pending)
100 ms, no ACK: resend seq=57 ───────────────▶   new seq 57: ACK it, remember 57, APPLY
                     ◀────── X  ACK 57 lost
100 ms, no ACK: resend seq=57 ───────────────▶   seen 57 before: ACK it again, DO NOT apply
                     ◀───────────── ACK 57
drop 57 from _pending
```

Three rules make this work:

1. **The sender keeps every unacknowledged command and resends it every 100 ms** (`RESEND_S`).
2. **The receiver ACKs every copy it gets, including duplicates.** The ACK itself can be lost. If the receiver only ACKed the first copy, a lost ACK would make the sender resend forever.
3. **The receiver applies a command only the first time it sees that `seq`.** This turns "at least once" delivery into "exactly once" application.

## Viewer side

From [`sim_bridge.gd`](../reference/code/godot/bridge/sim_bridge.gd):

```gdscript
const RESEND_S := 0.1
var _pending := {}            # seq -> {packet, sent_at}

func send_command(vehicle_id: int, cmd: int, args: Array = []) -> int:
	var s := _next_seq()
	var pkt := RsProtocol.pack_command(s, latest_t_sim, vehicle_id, cmd, args)
	_pending[s] = {"packet": pkt, "sent_at": _wall()}
	_send(pkt)
	return s

func _process(_delta: float) -> void:
	# ... while draining packets:
	#     MSG_ACK: _pending.erase(msg.acked_seq)
	var now := _wall()
	for s in _pending.keys():                     # resend unacknowledged commands
		if now - _pending[s].sent_at > RESEND_S:
			_send(_pending[s].packet)
			_pending[s].sent_at = now
```

The resend **reuses the same packet, with the same `seq`**. That is what lets the receiver recognize it. `pending_commands()` returns `_pending.size()`, and the lab shows it on screen. A number that stays above zero means physics is not answering.

## Physics side

From [`bridge.py`](../reference/code/python/robosim/bridge.py) (`PhysicsBridge.poll`):

```python
self.viewer_alive = True                          # any valid packet from the viewer
...                                               # (new-session check, see 05)
if msg["type"] == P.MSG_COMMAND:
    self.tx.sendto(P.pack_ack(self._next(), t_sim, msg["seq"]), self.viewer)   # ACK every copy
    if msg["seq"] in self._seen_cmds:
        continue                                  # a resend of something we already handled
    self._seen_cmds[msg["seq"]] = time.monotonic()
    if len(self._seen_cmds) > 1000:               # bounded memory: forget the oldest 500
        for k in sorted(self._seen_cmds)[:500]:
            del self._seen_cmds[k]
out.append(msg)                                   # new command (or sensor, HELLO): hand it on
```

The scenario script (`spin_bodies.py`) never sees duplicates. It just applies what `poll()` returns. The memory is bounded: after 1000 commands it forgets the oldest 500. A resend arrives within a few hundred milliseconds, so forgetting a command that is minutes old is safe.

There is one trap in this code: what if the viewer restarts and its `seq` counter starts from 1 again? [05](05_handshake_and_failures.md#a-new-viewer-looks-like-a-resend) shows the bug and the fix. Note also that a resend keeps its **old** `seq`, so it usually arrives after packets with higher numbers (sensor readings, a HELLO). The de-duplication must not mistake that for anything special.

## Measured: exactly once under heavy loss

The lab's loss injector drops packets on purpose, on the Python side: 20 % of outgoing POSEs, 50 % of outgoing ACKs, 30 % of incoming COMMANDs. The viewer sent 10 commands. From our run:

| Quantity | Value |
|---|---|
| commands sent by the viewer | 10 |
| COMMAND packets that reached Python's socket | 21 |
| ... of those dropped by the injector | 5 |
| ACKs dropped by the injector | 6 |
| commands applied | PAUSE 4, RESUME 4, RESET 2 = **10** |
| commands still waiting for an ACK at the end | 0 |

Every command arrived at least once, several arrived three times, and each was applied once.

## Make commands idempotent anyway

De-duplication protects against resends of the **same packet**. It does not protect against the user pressing the button twice, which gives two packets with two different `seq` values. So design commands so that applying them twice is harmless:

| Bad | Good | Why |
|---|---|---|
| `TOGGLE_PAUSE` | `PAUSE`, `RESUME` | twice paused is still paused |
| `ADD_THROTTLE +0.1` | `SET_THROTTLE 0.6` | absolute values do not accumulate |
| `NEXT_WAYPOINT` | `GOTO_WAYPOINT 7` | the target is named, not counted |

The lab's pause button sends PAUSE or RESUME depending on the PAUSED flag of the newest pose. It decides once and sends an absolute command.

STEP is the exception: "advance one frame" is inherently relative. That is acceptable only because the bridge guarantees exactly-once delivery. In Module 5's lock-step mode, a duplicated STEP would silently skip a frame of your dataset. It is the strongest argument for the de-duplication code.

## Reliable is not ordered

Each command is delivered, but resends can reorder them:

```
t=0 ms    send PAUSE  (seq 57)  ── X lost
t=50 ms   send RESUME (seq 58)  ──────────▶ applied: running
t=100 ms  resend PAUSE (seq 57) ──────────▶ applied: PAUSED   ← the user's last action was RESUME
```

Three ways to handle it, from simplest:

1. **Do not send a new state command while one is pending.** In the UI, grey out the button while `bridge.pending_commands() > 0`. With 100 ms resends, nobody notices.
2. **Ignore stale state commands on the physics side.** Remember the `seq` of the last applied PAUSE/RESUME and drop an older one. Compare with wrap-around: `newer = ((a - b) & 0xFFFFFFFF) < 2**31`.
3. **Use TCP for commands** if you need a strict order of many commands ([02](02_udp_basics.md#alternatives-and-when-to-choose-them)).

The lab's scenario has no ordering guard, so its automated check sends commands 1 s apart, ten times the resend period. [Stretch goal 2](lab.md#stretch-goals) adds the guard.

## Unreliable commands

Stick input is a stream: at 50 Hz, the next value replaces the previous one 20 ms later. Resending an old stick position after 100 ms would be **wrong**, not just useless. So `send_command_unreliable` sends the packet once and forgets it, and physics treats the newest value as current. Add a timeout on the physics side: if no stick packet arrives for, say, 0.5 s, the vehicle should hold or land instead of flying on with the last input. That is the HEARTBEAT command's job (cmd 0).

## Try it

- Run the lab with `--ack-loss 1.0`. What happens to `waiting for ACK` in the viewer, and to the command count in Python? Is the command applied?
- Remove the `if msg["seq"] in self._seen_cmds: continue` line, run with `--ack-loss 0.5`, and count how often RESET is applied. Put it back.
- Reproduce the reorder trace above with `--cmd-loss 0.8` and quick PAUSE / RESUME presses. Then implement option 1 in the viewer.
- Why does the ACK carry its own `seq` in the header in addition to `acked_seq`? (Hint: what else uses the physics side's `seq`?)

## References

- [Protocol: reliability table](../reference/protocol.md#reliability)
- "Exactly-once" is really at-least-once delivery plus idempotent or de-duplicated processing. Martin Kleppmann, *Designing Data-Intensive Applications*, chapter 11.
- Glenn Fiedler, "Reliable ordered messages": <https://gafferongames.com/post/reliable_ordered_messages/>
