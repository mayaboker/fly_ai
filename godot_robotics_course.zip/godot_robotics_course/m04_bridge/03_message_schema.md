# 03 Message schema: fixed layouts, magic, version, seq and t_sim

A packet is just bytes. Both sides must agree, byte for byte, on what those bytes mean, and they must keep agreeing as the project grows. This page designs the robosim v1 format from first principles. The finished spec is the [protocol page](../reference/protocol.md).

## Why fixed binary layouts, not JSON?

JSON is readable and flexible. For a 60 Hz pose stream it has three problems:

| | JSON | fixed `struct` layout |
|---|---|---|
| Size of one POSE (measured) | 210 bytes | 60 bytes |
| Decode time in Python (measured, this machine) | about 8 µs | about 1.5 µs |
| Typos in a field name | silently become a missing key | impossible, there are no names |
| Same layout in GDScript | `JSON.parse_string` + dictionary checks | `decode_float(offset)` |
| Readability in a packet dump | high | low, so you write a golden-bytes test instead |

The decisive argument is not speed. It is that a fixed layout **cannot drift**: a field is at offset 20 or it is not. JSON lets two sides disagree quietly. If you need flexibility later, add a new message type or a new version ([Changing the protocol](#changing-the-protocol)).

## The header: 16 bytes on every packet

```
offset  0   1   2   3   4   5   6   7   8  ...                15
      ┌───┬───┬───┬───┬───────────────┬───────────────────────────┐
      │'R'│'S'│ver│typ│   seq (u32)   │       t_sim (f64)         │
      └───┴───┴───┴───┴───────────────┴───────────────────────────┘
Python struct: "<2sBBId"     "<" = little-endian, no padding
```

| Field | Why it exists |
|---|---|
| **magic** `"RS"` | Rejects stray traffic. Anything can arrive on a UDP port: a port scanner, an old test script, a different program. Two fixed bytes make an accidental match unlikely, and the check costs nothing. |
| **version** `1` | Rejects a peer that speaks a different layout. Without it, a v2 pose with an extra field would decode as garbage numbers instead of being dropped. |
| **type** | Tells the receiver which body layout follows. |
| **seq** `u32` | Per-sender counter, +1 on every packet. It detects loss (gaps), identifies commands for ACKs and de-duplication ([04](04_reliable_commands.md)), and helps when you read packet logs. |
| **t_sim** `f64` | Simulation time in seconds, the physics clock. See below. |

**Little-endian** (`<`) because x86 and ARM are both little-endian, so packing is a plain copy, and because Godot's `PackedByteArray.encode_*` / `decode_*` methods are little-endian. The `<` also turns off C-style alignment padding, so the layout is exactly the sum of the field sizes. Without it, `struct` may insert padding and Python and Godot would disagree.

## Sim time, not wall time

Two clocks exist, and confusing them is the most common timing bug in co-simulation:

| Clock | Who owns it | Moves when | Used for |
|---|---|---|---|
| **t_sim** | physics | physics steps (stops on pause, runs 4× when you run 4×, jumps to 0 on reset) | stamping data, joining logs, interpolation |
| **wall time** | the OS | always, at 1 s per second | measuring latency and staleness only |

Every packet carries `t_sim`. A pose says "this is where the body was at simulation time 12.3 s", whenever it happens to arrive. On viewer → physics packets, `t_sim` is the sim time **of the pose the data was computed from** ([06](06_sensor_back_channel.md)).

Physics computes `t_sim = step_count × dt`, never `t += dt`. Adding 1/240 a million times accumulates rounding error, while a multiplication is exact to the last bit every time. It also makes `t_sim` values comparable with `==` across runs.

Why `f64`? A float32 time has 24 bits of mantissa. At t = 100 000 s (28 hours, a realistic batch run at 100× speed) its resolution is 7.8 ms, about half a pose period. A float64 is good to nanoseconds for centuries.

## Vehicle ids

Every vehicle-specific body starts with `vehicle_id u16`. The receiver keeps one buffer per id and does not care how many vehicles exist. Ids are fixed course-wide: 1 rover, 2 quadcopter, 3 fixed-wing, 4 quadplane, 10 and up for test bodies (the lab uses 10 and 11). Matching by id, not by order or node name, lets you add a vehicle without touching the viewer's code.

## The POSE body: 44 bytes

```
offset 16   18   20          32               48          60
     ┌────┬────┬───────────┬────────────────┬───────────┐
     │ id │flag│ pos 3×f32 │ quat 4×f32     │ vel 3×f32 │
     │u16 │u16 │  x  y  z  │  x  y  z  w    │  x  y  z  │
     └────┴────┴───────────┴────────────────┴───────────┘
Python struct: "<HH3f4f3f"            total packet 16 + 44 = 60 bytes
```

- **Float32 positions** are good to about 1 mm at 10 km from the origin (the spacing of float32 values near 10 000 is 2⁻¹⁰ m). That is enough for a test range a few kilometers wide. Godot itself stores transforms in float32.
- **Quaternion order (x, y, z, w)**, the same as PyBullet and Godot ([frames](../reference/frames.md#quaternion-order-the-most-common-bug)). The receiver normalizes it after decoding, because float32 rounding leaves it slightly off unit length.
- **Velocity** is optional for display, but it makes bounded extrapolation possible in Module 5 at a cost of 12 bytes.
- **flags**: `1 = RESET` (first pose after a reset, so the viewer clears its buffers), `2 = PAUSED`.

Packing in Python:

```python
HEADER = struct.Struct("<2sBBId")
POSE = struct.Struct("<HH3f4f3f")

def pack_pose(seq, t_sim, vehicle_id, pos, quat, vel=(0, 0, 0), flags=0):
    return (HEADER.pack(b"RS", 1, MSG_POSE, seq & 0xFFFFFFFF, t_sim)
            + POSE.pack(vehicle_id, flags, *pos, *quat, *vel))
```

Decoding the same bytes in GDScript, with offsets taken from the diagram:

```gdscript
static func unpack(data: PackedByteArray) -> Dictionary:
	if data.size() < 16 or data.decode_u8(0) != 0x52 or data.decode_u8(1) != 0x53:
		return {}                              # not ours
	if data.decode_u8(2) != VERSION:
		return {}                              # another protocol version: drop it
	var msg := {"type": data.decode_u8(3), "seq": data.decode_u32(4), "t_sim": data.decode_double(8)}
	if msg.type == MSG_POSE:
		if data.size() < 16 + 44:
			return {}                              # truncated: drop, never read past the end
		msg.vehicle_id = data.decode_u16(16)
		msg.flags = data.decode_u16(18)
		msg.pos = Vector3(data.decode_float(20), data.decode_float(24), data.decode_float(28))
		msg.quat = Quaternion(data.decode_float(32), data.decode_float(36),
				data.decode_float(40), data.decode_float(44))
		msg.vel = Vector3(data.decode_float(48), data.decode_float(52), data.decode_float(56))
	return msg
```

This is [`RsProtocol.unpack`](../reference/code/godot/bridge/protocol.gd), slightly shortened. Note the three ways a packet is rejected: wrong magic, wrong version, too short. The Python `unpack` does the same and returns `None`. A receiver must **never** raise on a bad packet. It drops it and carries on.

## The other messages

| Type | Id | Body | Total |
|---|---|---|---|
| HELLO | 1 | none | 16 B |
| BYE | 2 | none | 16 B |
| POSE | 3 | above | 60 B |
| COMMAND | 4 | `vehicle_id u16, cmd u16, args 8×f32` | 52 B |
| ACK | 5 | `acked_seq u32` | 20 B |
| SENSOR | 6 | `vehicle_id u16, sensor u16, count u16, reserved u16, count×f32` | 24 + 4n B |

COMMAND always carries 8 float arguments, used or not. A fixed size is simpler than a variable one, and 32 bytes do not matter. SENSOR is the one variable-length message. Its `count` field says how many floats follow, and the decoder checks that the packet really holds that many. `reserved` keeps the floats 4-byte aligned and leaves room for a future flag without a new version.

## Golden bytes: proving both sides agree

Python and GDScript are two independent implementations of one layout. A round trip inside one language proves nothing about the other. The fix is a **golden packet**: one set of bytes, generated once by Python and pasted into both test files.

```
pack_pose(seq=42, t_sim=1.5, vehicle_id=10, pos=(1,-2,3), quat=(0,0,0,1), vel=(0.5,0,-1.5), flags=RESET)

52 53 01 03 2a 00 00 00 00 00 00 00 00 00 f8 3f   'R' 'S' v1 POSE  seq 42   t_sim 1.5
0a 00 01 00                                       vehicle 10, flags 1
00 00 80 3f 00 00 00 c0 00 00 40 40               pos 1.0, -2.0, 3.0
00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3f   quat 0, 0, 0, 1
00 00 00 3f 00 00 00 00 00 00 c0 bf               vel 0.5, 0.0, -1.5
```

`test_protocol.py` checks that Python still produces exactly these bytes. `test_protocol.gd` checks that Godot decodes them to the right values, and that Godot's `pack_command` and `pack_sensor` produce byte-identical copies of Python's. If anyone ever changes a layout on one side, one of the two tests fails.

## Changing the protocol

Rules (also on the [protocol page](../reference/protocol.md#changing-the-protocol)):

1. **Never change an existing layout in place.** Old recordings, old scripts and a teammate's older viewer would decode garbage without any error.
2. **To add data, add a message type.** For example, a `POSE_EXT` type 7 with an extra angular-velocity field. Old receivers ignore unknown types, so they keep working.
3. **To change something fundamental, bump the version.** Old and new peers then refuse each other loudly instead of misreading each other quietly. A version-1 viewer drops every version-2 packet, which `test_version_mismatch_rejected` checks.
4. Use command ids 100–199 for your own experiments, so they never collide with the course's.

## Try it

- Decode the golden packet by hand from the hex dump: what is `t_sim` as a float64? (Hint: `3f f8 00 … 00` big-end-first.)
- Compare `struct.calcsize("BId")` with `struct.calcsize("<BId")` (16 vs 13 bytes). Explain where the 3 extra bytes come from. Our header happens to be the same size either way, because its fields are already aligned, but byte order would still be the machine's, not the protocol's.
- Extend `test_protocol.py` with your own case: a SENSOR packet whose `count` claims more floats than the packet holds must return `None`. (It is already there; read it and break the decoder to see the test fail.)
- Sketch the layout of a hypothetical `POSE_EXT` (type 7) that adds angular velocity. Which offsets change, and why is that harmless for old viewers?

## References

- Python `struct` (format characters, byte order): <https://docs.python.org/3/library/struct.html>
- Godot `PackedByteArray` (`encode_*`, `decode_*`, `hex_encode`): <https://docs.godotengine.org/en/stable/classes/class_packedbytearray.html>
- [Bridge protocol v1](../reference/protocol.md)
- Float precision tables: <https://en.wikipedia.org/wiki/Single-precision_floating-point_format>
