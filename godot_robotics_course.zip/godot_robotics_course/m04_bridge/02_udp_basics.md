# 02 UDP basics, and why poses use it

Both processes run on the same machine and talk over the loopback interface, `127.0.0.1`. The bridge uses **UDP**: each `send` is one packet, the packet arrives whole or not at all, and nothing is resent automatically. This page shows the minimum code on both sides, and explains why that is exactly the behavior you want for poses.

## UDP vs TCP in one table

| Property | UDP | TCP |
|---|---|---|
| Unit | datagram (one packet = one message) | byte stream (you must frame messages yourself) |
| Delivery | maybe; no resend | guaranteed, in order |
| What happens after a loss | the next packet just arrives | everything waits until the lost bytes are resent (*head-of-line blocking*) |
| Connection | none; either side can start or stop at any time | connect / accept; a restart breaks the connection |
| Typical latency on localhost | tens of microseconds | similar, until a loss or a full buffer |

For a **pose stream**, a resent pose is useless: by the time it arrives, a newer pose exists. TCP's guarantee turns into a cost: one lost segment holds back all the newer poses behind it. UDP gives you what you need: the newest packet, as soon as it exists.

For **commands** the opposite holds: a lost RESET must not be forgotten. The bridge adds a small reliability layer on top of UDP for commands only ([04](04_reliable_commands.md)). Using one transport for both keeps the code small.

## Ports

| Port | Who binds it (receives) | Who sends to it |
|---|---|---|
| 9001 | Godot viewer | physics process (POSE, ACK) |
| 9002 | physics process | Godot viewer (COMMAND, SENSOR, HELLO, BYE) |

Each side **binds** the port it reads from and **sends** to the other port. Neither side needs the other to be running: sending to a port nobody listens on just loses the packet. That property is what makes restarts painless.

## Python side

```python
import socket

rx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
rx.bind(("127.0.0.1", 9002))      # receive viewer -> physics traffic here
rx.setblocking(False)             # never wait for a packet
tx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
viewer = ("127.0.0.1", 9001)

def drain():
    """Return every packet waiting right now, then return immediately."""
    out = []
    while True:
        try:
            data, _addr = rx.recvfrom(65536)
        except BlockingIOError:   # nothing more is waiting
            return out
        out.append(data)

tx.sendto(b"hello", viewer)       # fire and forget
```

This is what [`PhysicsBridge`](../reference/code/python/robosim/bridge.py) does inside `__init__` and `poll()`. Two details matter:

- `setblocking(False)` turns "no packet" into an exception you catch, instead of a wait. The physics loop must never stall on the network.
- `tx` is never `connect()`ed. A connected UDP socket on Linux reports `ConnectionRefusedError` on the next call after the peer was not listening. An unconnected `sendto` just drops the packet.

## Godot side: `PacketPeerUDP`

```gdscript
var _udp := PacketPeerUDP.new()

func _ready() -> void:
	var err := _udp.bind(9001, "127.0.0.1")         # receive physics -> viewer traffic
	if err != OK:
		push_error("cannot bind UDP 9001: %s" % error_string(err))
	_udp.set_dest_address("127.0.0.1", 9002)        # where put_packet() sends

func _process(_delta: float) -> void:
	while _udp.get_available_packet_count() > 0:    # drain everything that is waiting
		var data: PackedByteArray = _udp.get_packet()
		_handle(data)

func send(pkt: PackedByteArray) -> void:
	_udp.put_packet(pkt)
```

This is the core of [`SimBridge`](../reference/code/godot/bridge/sim_bridge.gd). `get_available_packet_count()` returns at once, so the frame never waits. `set_dest_address` only sets the destination, it does not connect, so it behaves like Python's `sendto`.

A common error message the first time: `cannot bind UDP 9001 (Already in use)`. Another program, often a second copy of the viewer, still holds the port. Close it.

## Latest wins

The kernel keeps arriving packets in a receive buffer until you read them. At 60 poses/s and 60 fps, there is usually one new pose per vehicle per frame. After a hiccup (the window was dragged, the garbage collector ran, a disk write blocked), there may be ten. **Drain all of them and keep only the newest per vehicle.** Do not apply them one per frame: that would show the past in slow motion, and the viewer would never catch up.

```
packets waiting after a 150 ms stall:   p41 p42 p43 p44 p45 p46 p47 p48 p49
wrong (queue): show p41 this frame, p42 next frame, ...   → 150 ms behind, forever
right (latest wins): read all nine, show p49              → caught up in one frame
```

`SimBridge` stores every pose in a short per-vehicle buffer (Module 5 needs a few recent ones for interpolation). In this module the viewer shows `bridge.latest_transform(id)`, the newest one.

Loss on localhost is rare, but it happens: when a receive buffer overflows because the reader stalled, the kernel drops the newest packets. On a real network, loss is normal. The lab adds a deliberate loss injector so you can test this on purpose instead of waiting for it.

## Packet size

Keep each message well under the 1500-byte Ethernet MTU, even on localhost. Then nothing changes when the viewer moves to another machine. Our largest regular packet, POSE, is 60 bytes. A lidar scan as SENSOR is 24 + 4·n bytes: 360 rays is 1464 bytes, right at the limit, so a bigger scan gets split over several packets. Camera images never go through this bridge (Module 7 uses shared memory).

## Alternatives, and when to choose them

| Option | What it gives you | Choose it when |
|---|---|---|
| **TCP for commands** (UDP for poses) | built-in reliability and order; no ACK code | commands are rare, you never restart one side alone, and you are willing to handle reconnects |
| **ZeroMQ** (PUB/SUB for poses, REQ/REP or DEALER/ROUTER for commands) | message framing, reconnects, many-to-many, the CONFLATE option for latest-wins | several consumers (logger, viewer, dashboard) or machines; you can add a GDExtension or a Python relay on the Godot side, since Godot has no built-in ZeroMQ |
| **msgpack / protobuf / FlatBuffers** instead of `struct` | self-describing or schema-checked messages; easy optional fields | messages change often, or many languages read them; costs a library on both sides (Godot needs an addon) |
| **ROS 2 (DDS)** | discovery, QoS profiles, the whole ecosystem | the rest of your stack is already ROS 2 |
| **Shared memory** | no copy, fixed latency | large data on one machine: images (Module 7) |

This course stays with raw UDP + `struct` because both sides need only standard libraries, every byte is visible, and you can test it from the Python prompt. Nothing in the protocol design (fixed headers, sequence numbers, sim-time stamps, ACKs) depends on that choice. You would keep all of it on top of ZeroMQ or DDS.

## Try it

- In a Python prompt, bind a socket to 9001, start `spin_bodies.py`, and call `recvfrom` in a loop. Print `len(data)` and the first two bytes. You should see `60` and `b'RS'`.
- Stall a receiver on purpose: `time.sleep(1)` between two drains. How many packets did the second drain return? (At 2 vehicles × 60 Hz, expect about 120.)
- Start two viewers. Read the error message of the second one, then explain why only one process can bind a port.
- Measure the round trip on your machine: send 1000 packets to an echo loop and time it. Write the number down. Do not assume.

## References

- Python `socket` docs: <https://docs.python.org/3/library/socket.html>
- Godot `PacketPeerUDP`: <https://docs.godotengine.org/en/stable/classes/class_packetpeerudp.html>
- Godot high-level vs low-level networking: <https://docs.godotengine.org/en/stable/tutorials/networking/high_level_multiplayer.html> (the course uses the low level)
- ZeroMQ guide, "Pub-Sub Message Envelopes" and `ZMQ_CONFLATE`: <https://zguide.zeromq.org/>
- Glenn Fiedler, "UDP vs. TCP" (game networking, the same reasoning): <https://gafferongames.com/post/udp_vs_tcp/>
