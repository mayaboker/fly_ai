# Module 4: External simulator bridge (8 h)

## What you will build

You will build the bridge that every later module uses. A Python process runs PyBullet and streams poses for two bodies to Godot over UDP. Godot sends reliable PAUSE / RESUME / RESET commands back, plus a sensor reading tagged with the sim time it belongs to. Then you break it on purpose: you drop packets, kill either process and restart it, and show that the viewer never freezes and that every command is applied exactly once.

The finished result is the course's reference bridge ([protocol.py](../reference/code/python/robosim/protocol.py), [bridge.py](../reference/code/python/robosim/bridge.py), [protocol.gd](../reference/code/godot/bridge/protocol.gd), [sim_bridge.gd](../reference/code/godot/bridge/sim_bridge.gd)). Interpolation (`SimBridge.sample`) waits for [Module 5](../m05_time_rates/README.md). This module explains every piece and why it exists, including two restart bugs that earlier versions of it had.

## Prerequisites

- [Module 1](../m01_editor_gdscript/README.md) (scenes, signals, `_process`) and [Module 3](../m03_frames/README.md) (the wire carries Godot-frame meters and an (x, y, z, w) quaternion).
- [00_setup](../00_setup/README.md) done: `robosim/physics/robosim/` and `robosim/godot/bridge/` copied from `reference/code`.
- Python: `socket`, `struct`, `argparse`. Basic networking words: port, packet, localhost.
- Keep the [protocol page](../reference/protocol.md) open. This module derives it.

## Sub-topics

| File | Topic | Time |
|---|---|---:|
| [01_process_separation.md](01_process_separation.md) | Two processes, one physics owner. What crosses the boundary and what never does | 45 min |
| [02_udp_basics.md](02_udp_basics.md) | UDP in Python and in Godot (`PacketPeerUDP`). Why poses use UDP and latest-wins. TCP, ZeroMQ, msgpack | 1 h |
| [03_message_schema.md](03_message_schema.md) | Fixed binary layouts, magic, version, `seq`, `t_sim` vs wall time, vehicle ids, golden bytes | 1 h 15 |
| [04_reliable_commands.md](04_reliable_commands.md) | ACK, resend, de-duplicate by `seq`. Idempotent commands. Reliable is not ordered | 1 h |
| [05_handshake_and_failures.md](05_handshake_and_failures.md) | HELLO / BYE, stale detection, physics and viewer restarts, two bugs and their fixes | 1 h |
| [06_sensor_back_channel.md](06_sensor_back_channel.md) | SENSOR packets from Godot, tagged with the pose's `t_sim`. Measuring the cost of a wrong tag | 45 min |
| [lab.md](lab.md) | `spin_bodies.py`, the spin viewer, stale indicator, commands, loss injector, `test_protocol.py` | 2 h 15 |

## Deliverables

1. `physics/tests/test_protocol.py`: round trip of every message, invalid packets rejected, version mismatch rejected, golden bytes, ACK + de-duplication over real sockets, viewer-restart case.
2. `godot/tests/test_protocol.gd`: Godot decodes Python's golden bytes and produces the same bytes Python does.
3. `physics/sims/spin_bodies.py`: PyBullet in DIRECT mode, bodies 10 (spinning cube) and 11 (bouncing sphere), physics 240 Hz, poses 60 Hz, obeys PAUSE / RESUME / RESET, drops packets on request (`--loss`, `--ack-loss`, `--cmd-loss`).
4. `godot/spin_viewer.tscn`: both bodies, a LIVE / PAUSED / STALE indicator, buttons and keys for the commands, and a RANGE sensor sent back to Python.
5. You can point to the two restart rules from [05](05_handshake_and_failures.md) in your `physics/robosim/bridge.py` (new viewer session) and `godot/bridge/sim_bridge.gd` (when HELLO is sent). The reference copies from 00 Setup already have them.

## Check

The module is done when all of the following are true. `tools/check_m04.sh` runs scenarios 2–5 for you (see the [lab](lab.md#9-run-the-whole-check)).

1. `python tests/test_protocol.py` prints `protocol: 7/7 tests pass`. `godot --headless --script res://tests/test_protocol.gd` prints `protocol.gd: all tests pass`.
2. **Packet loss.** With `--loss 0.2 --ack-loss 0.5 --cmd-loss 0.3` and 10 commands sent from the viewer, the physics summary shows **more** command packets received than commands sent (resends happened), `commands applied` adds up to **exactly 10**, and the viewer ends with `still waiting for ACK 0`. In our run: 21 command packets in (5 dropped), 6 ACKs dropped, applied `{'PAUSE': 4, 'RESUME': 4, 'RESET': 2}`.
3. **Physics crash.** Kill the Python process with `kill -9`. Within about 0.25 s the indicator turns STALE and the last pose stays on screen. Median frame time stays 16.7 ms (60 fps): the UI never blocks. Restart Python: the viewer shows `physics_reset`, then LIVE, and a PAUSE sent afterwards is applied.
4. **Viewer restart.** Restart the viewer twice while physics keeps running. Python prints `viewer said HELLO` for each session, and every command from both sessions is applied, **even when the second session reuses the first session's `seq` numbers** (in our run both sessions sent PAUSE as seq 121 and RESUME as seq 182).
5. **Sensor tag.** Python's summary shows the RANGE error at the tagged `t_sim` below 0.001 mm, while the same reading compared with the newest physics state is off by centimeters (ours: 0.0000 mm vs 24.7 mm mean).

## Common mistakes

- **Blocking reads.** A `recvfrom` without `setblocking(False)` (Python) or a `while` loop that waits for a packet (Godot) freezes the program the moment the other side dies. Drain what is there, then get on with the frame.
- **Queuing poses.** Applying every pose in arrival order makes the viewer fall further behind after any hiccup. Poses are state, not events: the newest one wins.
- **Using the tick count or wall time as the timestamp.** Every packet carries `t_sim`, the physics clock. Wall time is only for measuring latency and staleness.
- **Toggle commands.** A `TOGGLE_PAUSE` that arrives twice (a resend, a double click) undoes itself. Send absolute states (PAUSE, RESUME) and make every command safe to apply twice, even though the bridge de-duplicates.
- **Forgetting that a restarted peer counts from 1 again.** De-duplication by `seq` must be reset when a new session starts, or new commands get silently dropped as "duplicates". See [05](05_handshake_and_failures.md#a-new-viewer-looks-like-a-resend).
- **Tagging sensor data with "now".** A ray cast from a pose at `t_sim = 4.000` and tagged with whatever time Python has reached when it arrives is wrong by one or two pose periods. Tag with the pose's own `t_sim`.
