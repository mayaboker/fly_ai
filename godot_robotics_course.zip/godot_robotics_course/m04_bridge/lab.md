# Lab 4: Two bodies over the bridge, and breaking it on purpose (about 2 h 15)

You will write a PyBullet scenario that streams two bodies to Godot, a viewer that shows them with a stale-data indicator and command buttons, and a RANGE sensor that goes back the other way. Then you will test the bridge the way it will fail in real use: lost packets, a crashed physics process, a restarted viewer.

## Files added or changed

| File in `robosim/` | Status | Purpose |
|---|---|---|
| `physics/robosim/bridge.py` | read, not changed | new viewer session: a HELLO with a lower `seq`, or a BYE |
| `godot/bridge/sim_bridge.gd` | read, not changed | HELLO at start-up and on each physics session's first pose |
| `physics/tests/test_protocol.py` | **new** | Python protocol tests |
| `godot/tests/test_protocol.gd` | **new** | Godot protocol tests against Python's golden bytes |
| `physics/sims/spin_bodies.py` | **new** | the scenario: cube 10, sphere 11, commands, loss injector, sensor check |
| `godot/spin_viewer.tscn`, `spin_viewer.gd` | **new** | the viewer |
| `godot/ui/bridge_status.gd` | **new** | `BridgeStatus`: WAITING / LIVE / PAUSED / STALE label, reused later |
| `godot/tests/check_m04.gd`, `tools/check_m04.sh` | **new** | the automated Check |

`protocol.py`, `protocol.gd` and `frames.py` are not changed. The finished files are in [code/](code/README.md). Try each step before you look.

## 1. Read your bridge copies (10 min)

Read [05](05_handshake_and_failures.md#a-new-viewer-looks-like-a-resend) first. Then open `physics/robosim/bridge.py`, find `poll()`, and find the lines that forget the old command `seq` numbers: on BYE, and on a HELLO whose `seq` is lower than the highest seen. Open `godot/bridge/sim_bridge.gd` and find the three places that send HELLO (`_ready()`, the 0.5 s repeat in `_process()`, and `_on_pose()`). The copies from 00 Setup already contain all of this, so there is nothing to add. If yours differ, copy both files from `code/`.

After step 2, break the session rule on purpose (see the last-but-one exercise in [05](05_handshake_and_failures.md#try-it)) and watch `test_bridge_ack_and_dedup` fail.

## 2. Protocol tests (25 min)

Write `physics/tests/test_protocol.py` before you read the finished one. It needs these tests:

| Test | What it proves |
|---|---|
| `test_round_trip` | every message type survives pack → unpack, with all fields |
| `test_sizes` | 16 / 60 / 52 / 20 / 24+4n bytes, as on the protocol page |
| `test_seq_wraps` | `seq = 2³² + 5` arrives as 5 |
| `test_invalid_rejected` | empty, short, wrong magic, truncated POSE / COMMAND, SENSOR whose `count` lies, random text: all return `None` |
| `test_version_mismatch_rejected` | version byte 2 or 0 returns `None` |
| `test_golden_bytes` | Python still produces the exact bytes Godot's test decodes |
| `test_bridge_ack_and_dedup` | real sockets: a command sent 3× is ACKed 3× and returned once; after a new viewer's HELLO (`seq` 1 again), a new command with a reused `seq` is returned; a resend that arrives after newer packets of the same session is not |

Start the file with the path line that every course script uses, so it runs from `physics/`:

```python
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from robosim import protocol as P
from robosim.bridge import PhysicsBridge
```

The version test, for example:

```python
def test_version_mismatch_rejected():
    pkt = bytearray(P.pack_pose(1, 0.5, 10, (1, 2, 3), (0, 0, 0, 1)))
    pkt[2] = 2                                                # a future version 2 sender
    assert P.unpack(bytes(pkt)) is None
```

The bridge test uses ports 9198/9199 so it never collides with a running scenario. Then copy `godot/tests/test_protocol.gd` from `code/` and read it: it decodes the golden POSE and checks that Godot packs COMMAND and SENSOR byte for byte like Python.

```bash
cd ~/robosim/physics
python tests/test_protocol.py
cd ~/robosim/godot
godot --headless --import                         # once, so the RsProtocol class is known
godot --headless --script res://tests/test_protocol.gd
```

Expected:

```
PASS test_bridge_ack_and_dedup
PASS test_golden_bytes
PASS test_invalid_rejected
PASS test_round_trip
PASS test_seq_wraps
PASS test_sizes
PASS test_version_mismatch_rejected
protocol: 7/7 tests pass
protocol.gd: all tests pass
```

## 3. The physics scenario (30 min)

Create `physics/sims/spin_bodies.py`. Keep the world and the networking apart. The world class knows nothing about UDP:

```python
class SpinWorld:
    def __init__(self, physics_hz, seed):
        self.cid = pb.connect(pb.DIRECT)          # no window: physics never needs graphics
        self.dt = 1.0 / physics_hz
        self.seed = seed
        self.build()

    def build(self):                              # also used by RESET
        pb.resetSimulation(physicsClientId=self.cid)
        pb.setGravity(0, 0, -9.81, physicsClientId=self.cid)
        pb.setTimeStep(self.dt, physicsClientId=self.cid)
        rng = np.random.default_rng(self.seed)    # every random choice comes from the seed
        # ground plane (restitution 0.9)
        # cube 0.6 m, mass 1, pinned at (0, 0, 1.5) with a JOINT_POINT2POINT constraint,
        #   damping 0, spinning at 0.5 rev/s about a random tilted axis
        # sphere r = 0.25 m, mass 1, at (1.5, 0, h), h random in [1.5, 2.5], restitution 0.9
        self.step_count = 0

    @property
    def t_sim(self):
        return self.step_count * self.dt          # exact, never accumulated

    def pose_godot(self, body):
        p, q = pb.getBasePositionAndOrientation(body, physicsClientId=self.cid)
        v, _ = pb.getBaseVelocity(body, physicsClientId=self.cid)
        pos, quat = enu_flu_to_godot(p, q)        # convert ONCE, here (Module 3)
        return pos, quat, enu_to_godot_pos(v)
```

Two details in `step()`: PyBullet loses a little energy per bounce, so when the sphere has settled (`z < r + 0.02` and `|vz| < 0.3`), kick it up again with `resetBaseVelocity(..., [0, 0, 6.0], ...)`. And the cube needs `linearDamping=0, angularDamping=0`, or PyBullet's default damping slowly stops the spin.

The main loop runs once per pose period (60 Hz). It does 4 physics steps (240 / 60), sends both poses, and sleeps until the next tick:

```python
period = 1.0 / a.pose_hz
next_tick = time.monotonic()
while True:
    for msg in br.poll(world.t_sim):              # commands arrive ACKed and de-duplicated
        handle(msg)
    if not paused:
        for _ in range(steps_per_pose):
            world.step()
    send_poses()                                  # while paused: same pose, PAUSED flag
    next_tick += period                           # fixed schedule, so no drift
    now = time.monotonic()
    if now - next_tick > 0.25:                    # far behind (debugger, suspend): re-anchor
        next_tick = now
    time.sleep(max(0.0, next_tick - now))
```

`next_tick += period` keeps the average rate exactly 60 Hz even when one sleep oversleeps. `sleep(period)` would drift slower and slower. Module 5 looks at pacing in detail.

Run it alone first, and look at the packets with a 5-line sniffer:

```bash
cd ~/robosim/physics
python sims/spin_bodies.py
# second terminal:
python -c "
import socket, sys; sys.path.insert(0, '.'); from robosim import protocol as P
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.bind(('127.0.0.1', 9001))
for _ in range(6): m = P.unpack(s.recv(100)); print(m['seq'], round(m['t_sim'], 4), m['vehicle_id'], m['flags'], [round(x, 2) for x in m['pos']])"
```

You should see pairs of poses (ids 10 and 11) with the same `t_sim`, 1/60 s apart, the cube at `[0.0, 1.5, 0.0]`, and the sphere's y changing. If you start the sniffer before the scenario, the very first pose has `flags = 1` (RESET). Stop the sniffer before you start Godot, since both bind 9001.

## 4. The viewer scene (30 min)

In the Godot editor, create `spin_viewer.tscn` with this tree:

```
SpinViewer (Node3D)                 script: spin_viewer.gd
├── SimBridge (Node)                script: res://bridge/sim_bridge.gd (sets its own process priority)
├── WorldEnvironment                any Environment; ambient light so shadows are not black
├── Sun (DirectionalLight3D)        rotated down about 50°, shadows on
├── Camera3D                        position (0.75, 1.6, 5), rotation x = -7°
├── Floor (StaticBody3D)
│   ├── Mesh (MeshInstance3D)       PlaneMesh 10 × 10
│   └── Shape (CollisionShape3D)    BoxShape3D 20 × 0.2 × 20, position y = -0.1
├── Cube (Node3D)
│   ├── Mesh (MeshInstance3D)       BoxMesh 0.6 m, blue
│   └── Nose (MeshInstance3D)       BoxMesh 0.12 × 0.12 × 0.3 at z = -0.4, red (model forward = -Z)
├── Sphere (MeshInstance3D)         SphereMesh radius 0.25, height 0.5
└── UI (CanvasLayer)
    ├── Info (Label)                top left
    ├── Status (Label)              top right; script: ui/bridge_status.gd; Bridge = SimBridge
    └── Buttons (HBoxContainer)     bottom left
        ├── Pause (Button)          text "Pause / Resume (P)", Focus ▸ Mode = None
        └── Reset (Button)          text "Reset (R)", Focus ▸ Mode = None
```

Why these settings:

- **SimBridge runs first.** Godot calls `_process` in priority order (lower first), and in tree order (parent first) within a priority. Without help, `SpinViewer._process` would run before `SimBridge` has read this frame's packets, and every pose would be shown one frame late. `SimBridge` therefore sets `process_priority = -100` in its own `_ready()`, so you do not set anything in the Inspector. [Module 5](../m05_time_rates/03_interpolation.md) measures this delay.
- **Only the floor has a collision shape.** Physics owns the cube and the sphere, so in Godot they are pictures only. The floor's shape exists for the RANGE ray in step 7.
- **Focus mode None** on the buttons, so the P and R keys still reach `_unhandled_input` after you click a button.

The core of `spin_viewer.gd` is short, because `SimBridge` does the work:

```gdscript
extends Node3D

const CUBE := 10
const SPHERE := 11

@onready var bridge: SimBridge = $SimBridge
@onready var cube: Node3D = $Cube
@onready var sphere: Node3D = $Sphere

func _process(_delta: float) -> void:
	# Latest wins: show the newest pose. If the stream stops, the bodies stay
	# where they are and the Status label says STALE. Nothing here ever waits.
	if bridge.has_vehicle(CUBE):
		cube.transform = bridge.latest_transform(CUBE)
	if bridge.has_vehicle(SPHERE):
		sphere.transform = bridge.latest_transform(SPHERE)
```

The finished script also reads `--listen-port=` and `--physics-port=` from the command line in `_enter_tree`. That runs **before** the children's `_ready`, so `SimBridge` binds the right port. The automated check uses this. Run it, with Python running in the other terminal:

```bash
godot --path ~/robosim/godot res://spin_viewer.tscn      # or open the scene and press F6
```

![The spin viewer, LIVE](code/screenshots/m04_live.png)

## 5. The stale indicator (10 min)

`ui/bridge_status.gd` is a `Label` with a `SimBridge` export. It listens to `pose_received` for the PAUSED flag and decides its text every frame:

```gdscript
func _process(_delta: float) -> void:
	if bridge.latest_seq < 0:
		_show("WAITING for physics", Color(0.7, 0.7, 0.7))
	elif bridge.is_stale():
		_show("STALE  (last t_sim %.2f s)" % bridge.latest_t_sim, Color(1.0, 0.25, 0.2))
	elif _paused:
		_show("PAUSED", Color(1.0, 0.85, 0.2))
	else:
		_show("LIVE", Color(0.3, 1.0, 0.4))
```

Test it by hand: stop Python with Ctrl-C. The label turns red within a quarter of a second, the bodies stay where they were, and the window still responds. Start Python again: the label goes green, and the sphere starts from its initial height (the RESET flag cleared the viewer's buffers).

## 6. Commands (15 min)

Viewer side, in `spin_viewer.gd`:

```gdscript
var paused := false            ## from the PAUSED flag of the newest pose

func toggle_pause() -> void:
	# Decide once, send an ABSOLUTE command: PAUSE or RESUME, never "toggle".
	bridge.send_command(CUBE, RsProtocol.CMD_RESUME if paused else RsProtocol.CMD_PAUSE)

func reset() -> void:
	bridge.send_command(CUBE, RsProtocol.CMD_RESET)
```

Connect the buttons in `_ready` and the keys in `_unhandled_input` (P, R). The commands act on the whole world, so `spin_bodies.py` ignores the vehicle id.

Physics side, in `handle(msg)`:

```python
if msg["cmd"] == P.CMD_PAUSE:
    paused = True
elif msg["cmd"] == P.CMD_RESUME:
    paused = False
elif msg["cmd"] == P.CMD_RESET:
    world.build()                 # same seed: the same initial state
    br.mark_reset()               # the next pose carries the RESET flag
```

While paused, the loop keeps calling `send_poses()` with `paused=True`. The viewer then shows PAUSED, not STALE. Count every applied command in a dict and print the dict on exit. That count is the exactly-once evidence in step 9.

## 7. The RANGE sensor (10 min)

Add the `_physics_process` ray from [06](06_sensor_back_channel.md#godot-side) to the viewer, and the truth history lookup to Python. Python prints the mean error every 2 s:

```
[t_sim   2.017] poses sent 242, dropped 0, viewer alive, range err 0.000 mm (naive 25.6 mm)
```

## 8. The loss injector (15 min)

Real loss is rare on localhost, so cause it on purpose. Wrap the bridge's sockets in an object with the same `sendto` / `recvfrom` methods, which drops packets by type:

```python
class LossySocket:
    def __init__(self, sock, rng, loss=0.0, ack_loss=0.0, cmd_loss=0.0):
        self.sock, self.rng = sock, rng
        self.loss = {P.MSG_POSE: loss, P.MSG_ACK: ack_loss, P.MSG_COMMAND: cmd_loss}
        self.dropped = {P.MSG_POSE: 0, P.MSG_ACK: 0, P.MSG_COMMAND: 0}

    def _drop(self, data):
        p = self.loss.get(data[3] if len(data) > 3 else -1, 0.0)   # byte 3 = message type
        if p > 0 and self.rng.random() < p:
            self.dropped[data[3]] += 1
            return True
        return False

    def sendto(self, data, addr):
        return len(data) if self._drop(data) else self.sock.sendto(data, addr)

    def recvfrom(self, n):
        while True:
            data, addr = self.sock.recvfrom(n)    # raises BlockingIOError when empty
            if not self._drop(data):
                return data, addr

br.tx = LossySocket(br.tx, loss_rng, loss=a.loss, ack_loss=a.ack_loss)
br.rx = LossySocket(br.rx, loss_rng, cmd_loss=a.cmd_loss)
```

Two design points:

- A dropped pose still consumed a `seq` number, as on a real network. The viewer can count the gaps.
- `loss_rng` is a **separate** random generator (`seed + 1000`). The loss pattern never touches the physics' random numbers, so a lossy run and a clean run simulate exactly the same motion. Module 5 proves that by comparing logs.

Run `python sims/spin_bodies.py --loss 0.2` and watch the viewer. The motion gets visibly jerkier, because some frames show no new pose, but nothing freezes and nothing jumps backwards. Module 5's interpolation smooths it.

## 9. Run the whole Check

`tools/check_m04.sh` runs the protocol tests and the three failure scenarios headless, with a scripted plan of commands (`godot/tests/check_m04.gd`):

```bash
cd ~/robosim
GODOT=~/tools/godot bash tools/check_m04.sh
```

Expected output (from our runs, shortened; your timings differ by a few tens of ms):

```
=== A: protocol tests
protocol: 7/7 tests pass
protocol.gd: all tests pass
=== B: packet loss and reliable commands
[wall  14.01] SUMMARY commands sent 10, still waiting for ACK 0, resets seen 2, distinct t_sim while paused 4, frames 833, max frame dt 142.7 ms
[wall  14.01] frame dt ms: median 16.7  p99 18.1  max 142.7
summary: poses sent 2382, pose packets dropped 487, acks dropped 6, command packets in 21 (dropped 5), commands applied {'PAUSE': 4, 'RESUME': 4, 'RESET': 2}, sensor packets matched 654
=== C: physics crash and restart
(physics killed at ~3 s)
(physics restarted at ~6 s)
[wall   0.04] LIVE (t_sim 0.033)
[wall   2.65] STALE (t_sim 2.400)
[wall   5.62] physics_reset signal (t_sim now 2.400)
[wall   5.63] LIVE (t_sim 0.017)
[wall  11.02] SUMMARY commands sent 2, still waiting for ACK 0, resets seen 1, distinct t_sim while paused 1, frames 650, max frame dt 136.3 ms
[wall  11.02] frame dt ms: median 16.7  p99 16.7  max 136.3
[t_sim   2.400] applied PAUSE (seq 287)
[t_sim   2.400] applied RESUME (seq 348)
=== D: viewer restarts
[wall   5.01] SUMMARY commands sent 2, still waiting for ACK 0, ...
[wall   5.01] SUMMARY commands sent 2, still waiting for ACK 0, ...
viewer said HELLO
viewer said HELLO
[t_sim   3.050] applied PAUSE (seq 121)
[t_sim   3.050] applied RESUME (seq 182)
viewer said HELLO
viewer said HELLO
[t_sim   8.433] applied PAUSE (seq 121)
[t_sim   8.433] applied RESUME (seq 182)
```

Each viewer session says HELLO twice: once in `_ready()` and once when its first pose arrives.

How to read it against the [Check](README.md#check):

| Check item | Evidence in the output |
|---|---|
| 1 tests | `7/7`, `all tests pass` |
| 2 loss, exactly once | 10 sent; 21 packets in (> 10, resends happened); applied 4 + 4 + 2 = 10; 0 waiting |
| 3 physics crash | STALE about 0.25 s after the last pose; median frame 16.7 ms; reset, LIVE, PAUSE applied after restart |
| 4 viewer restart | HELLOs from both sessions; the second session reused seq 121 and 182, and all four commands were applied |
| 5 sensor tag | step 7 / the `range error at tagged t_sim` line when you stop `spin_bodies.py` |

The single long frames (136–143 ms) appeared when a new Python process started on our busy 2-core test machine. They are CPU contention, not the bridge. Run the check on your machine and write down your own numbers.

To see the viewer itself in each scenario, run the same commands without `--headless`, or interactively: start `spin_bodies.py --loss 0.2 --ack-loss 0.5 --cmd-loss 0.3`, press P and R a few times, and compare the viewer's counter with Python's `commands applied` when you stop it.

## Stretch goals

1. **Packet-loss estimate in the viewer.** Count gaps in the POSE `seq` (remember that ACKs share the physics side's counter) or in `t_sim` per vehicle, and show the loss percentage next to the status label.
2. **Ordering guard.** Make `spin_bodies.py` ignore a PAUSE or RESUME whose `seq` is older than the last applied one, with wrap-around comparison. Reproduce the reorder bug from [04](04_reliable_commands.md#reliable-is-not-ordered) with `--cmd-loss 0.8` first, then show the guard fixes it.
3. **Disable while pending.** Grey out the Pause button while `bridge.pending_commands() > 0`.
4. **Viewer on another machine.** Change both `127.0.0.1` addresses to real IPs (bind `0.0.0.0` on the receivers) and measure latency and loss over Wi-Fi. What changes in [05](05_handshake_and_failures.md#physics-restarts) about `t_sim` going backwards?
5. **CONTACT sensor.** Put a box in the sphere's path in Godot only, detect overlap with `intersect_shape`, and send CONTACT packets. Physics prints them. It should not move the sphere: who owns the box?
