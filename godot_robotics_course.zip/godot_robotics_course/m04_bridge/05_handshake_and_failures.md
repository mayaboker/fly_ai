# 05 Handshake, stale data, and restarts

The two processes start, stop and crash independently. A good bridge makes every one of those events boring: the viewer says what is happening, nothing hangs, and when the missing side comes back, everything resumes without a restart of the other side. This page goes through each event, including two restart bugs that earlier versions of the reference code had, and how the final code avoids them.

## HELLO and BYE

UDP has no connection, so neither side knows whether the other exists. Two small messages give each side what it needs:

| Message | Sent by | When | What the receiver does |
|---|---|---|---|
| HELLO | viewer | once at start-up, every 0.5 s until the first pose arrives, and again on the first pose of every physics session | sets `viewer_alive = True` (so does any other valid packet); a HELLO from a **new** viewer starts a new command session (see below) |
| BYE | either | on clean exit (`_exit_tree`, Ctrl-C) | marks the peer gone |

The physics process does **not** need HELLO to start sending. It sends poses from its first step, so a viewer that starts later sees the vehicle immediately. HELLO matters for two things: scenarios that wait for a viewer (`PhysicsBridge.wait_for_viewer()`, used when you want a recording to start with the viewer attached), and the start of a new command session. `wait_for_viewer(send_idle_pose=...)` works in either start order: if the viewer started first and its early HELLOs went nowhere, the first idle pose it receives makes it say HELLO again.

BYE is a courtesy, not a requirement. A crash (`kill -9`, segfault, power loss) sends no BYE, so every behavior below must also work without it.

## Stale data: never freeze, always say so

The viewer decides staleness with **wall time**, because sim time stops when physics stops:

```gdscript
@export var stale_after_s := 0.25        ## wall-clock seconds without a pose = stale

func is_stale() -> bool:
	return _last_rx_wall < 0.0 or _wall() - _last_rx_wall > stale_after_s
```

0.25 s is 15 missed poses at 60 Hz. That is long enough not to flicker under normal loss and short enough that a human notices within a blink. When the data is stale:

- **Keep drawing the last pose.** Do not hide the vehicle and do not snap it to the origin. The last known state is the most useful picture, as long as it is labeled.
- **Label it loudly.** The lab's `BridgeStatus` label turns red and reads `STALE (last t_sim 2.78 s)`.
- **Keep the UI responsive.** Buttons still work. Commands queue and resend until physics answers.

Pausing must not look like dying. While paused, physics keeps sending the same pose at the pose rate, with the `PAUSED` flag set. So the viewer can show three different states:

| Indicator | Condition |
|---|---|
| WAITING (grey) | no pose ever received |
| LIVE (green) | poses arriving, PAUSED flag clear |
| PAUSED (yellow) | poses arriving, PAUSED flag set |
| STALE (red) | no pose for 0.25 s |

![Stale indicator after the physics process was killed](code/screenshots/m04_stale.png)

## Physics restarts

A new physics process starts at `t_sim = 0` with a fresh world. The viewer must not interpolate between the old world at t = 47 s and the new one at t = 0. Two signals tell it:

1. The **RESET flag** on the new process's first pose (`PhysicsBridge` sets it automatically, and again after `mark_reset()`).
2. **`t_sim` going backwards.** It also catches the case where the RESET pose itself was lost.

Either one makes `SimBridge` clear all pose buffers and emit `physics_reset`:

```gdscript
func _on_pose(msg: Dictionary) -> void:
	var first := _last_rx_wall < 0.0
	_last_rx_wall = _wall()
	var restarted: bool = msg.flags & RsProtocol.POSE_FLAG_RESET or msg.t_sim < latest_t_sim
	if first or restarted:
		# answer a (re)started physics process: it may be waiting in wait_for_viewer()
		_send(RsProtocol.pack_simple(RsProtocol.MSG_HELLO, _next_seq(), msg.t_sim))
	if restarted:
		_buffers.clear()                          # physics restarted or reset
		physics_reset.emit()
	...
```

The same path handles a RESET **command**: the physics process rebuilds its world, calls `bridge.mark_reset()`, and the next pose carries the flag.

On a real network, UDP packets can arrive out of order, and an old pose arriving late would look like "t_sim went backwards". On localhost this does not happen. On a network, compare `seq` first and drop packets older than the newest one before applying the backwards-time rule.

Commands still waiting for an ACK when physics dies are resent to the new process, which applies them. For PAUSE that is what the user wanted. For a RESET it is harmless, because the new world is already fresh. If that matters for your own commands, clear `_pending` in a `physics_reset` handler.

Measured in the lab (physics killed with `kill -9`, restarted 3 s later):

```
[wall   2.02] t_sim 2.017  poses cube 120 sphere 120  ...
[wall   2.65] STALE (t_sim 2.400)
[wall   5.62] physics_reset signal (t_sim now 2.400)
[wall   5.63] LIVE (t_sim 0.017)
[wall  11.02] frame dt ms: median 16.7  p99 16.7  max 136.3
```

The frame time stayed at 16.7 ms (60 fps) throughout, apart from one 136 ms frame when the new Python process started. That frame came from CPU contention: importing PyBullet on a busy 2-core machine, not from waiting on the network.

## Viewer restarts

The physics process does not care: it keeps stepping and sending. The new viewer binds the port, drains the poses waiting in it, and is LIVE within one frame. It also sends HELLO, which matters for the next point.

## A new viewer looks like a resend

`PhysicsBridge` remembers the `seq` of every command it has applied, to drop resends. The viewer's `seq` counter starts at 1 in every session. So a **restarted** viewer sends brand-new commands with numbers the physics process has already seen. Without a session rule, they are ACKed (the viewer is satisfied) and then **silently dropped** as duplicates.

How likely is a collision? Each viewer increments `seq` for every packet it sends, including one RANGE sensor packet per pose. Two sessions that do the same thing at the same pace produce very similar numbers. In one of our automated runs, the second viewer sent PAUSE as seq 121 and RESUME as seq 182, exactly the numbers of the first session.

So the physics side must notice that a **new** viewer session started, and forget the old `seq` numbers. Getting "new session" right took the course three attempts, and each wrong one is instructive:

| Rule for "new session" | What goes wrong |
|---|---|
| "every HELLO" | The viewer also says HELLO after a physics reset. If the ACK of a RESET command was lost, its resend (same `seq`) arrives after that HELLO, looks new, and would reset the world a second time. |
| "any packet whose `seq` is lower than the last one" | A resend **always** carries an older `seq` than the sensor packets sent since. Under ACK loss every resend cleared the table and was applied again (we saw 13 PAUSEs for 4 sent). |
| "a HELLO whose `seq` is lower than the highest seen, or a BYE" | Correct. A new viewer's first packet is a HELLO with a small `seq`; the old viewer's HELLOs only ever count up. |

The final rule, in `PhysicsBridge.poll()`:

```python
if msg["type"] == P.MSG_BYE:
    self.viewer_alive = False
    self._seen_cmds.clear()                       # the session ended cleanly
    self._viewer_max_seq = -1
    ...
self.viewer_alive = True                          # any valid packet from the viewer
if msg["type"] == P.MSG_HELLO and msg["seq"] < self._viewer_max_seq:
    self._seen_cmds.clear()                       # a NEW viewer: it counts seq from 1 again
    self._viewer_max_seq = msg["seq"]
self._viewer_max_seq = max(self._viewer_max_seq, msg["seq"])
```

`test_protocol.py` checks both sides of it deterministically (`test_bridge_ack_and_dedup`): a restarted viewer's command with a reused `seq` is applied, and a resend that arrives after newer packets of the same session is not.

## The HELLO that never came

The rule above relies on the new viewer saying HELLO. An earlier `SimBridge` sent HELLO only while `_last_rx_wall < 0`, that is, "until the first pose arrives", and it checked that **after** draining the socket. When physics was already running, poses were waiting in the socket on the viewer's first frame, so the viewer marked itself connected and **never said HELLO**. Whether HELLO went out depended on a race between the first frame and the first packet. The mirror image was a deadlock: a physics process that waits in `wait_for_viewer()` while sending idle poses never heard the viewer's HELLOs if they went out before it started listening, and the viewer stopped saying HELLO as soon as the idle poses arrived.

The reference `SimBridge` now closes both holes. It always says HELLO once in `_ready()`, repeats it every 0.5 s until the first pose, and says it again on the first pose of every physics session (the `_on_pose` code above):

```gdscript
func _ready() -> void:
	process_priority = -100                       # read packets before every other script
	var err := _udp.bind(listen_port, "127.0.0.1")
	...
	_udp.set_dest_address("127.0.0.1", physics_port)
	# Always say HELLO once at start-up, even if poses are already waiting: it tells
	# a running physics process that this is a NEW viewer session.
	_send(RsProtocol.pack_simple(RsProtocol.MSG_HELLO, _next_seq(), 0.0))
	_last_hello_wall = _wall()
```

On localhost a packet sent before the first command arrives first, so the session reset happens before any new command is processed.

Both rules are in the reference code that 00 Setup copied (`physics/robosim/bridge.py`, `godot/bridge/sim_bridge.gd`), and in this module's [code/](code/README.md). An alternative, common in network protocols, is a random **session id** in every packet. That needs a new protocol version, so the course uses the HELLO rule instead.

## The failure table

| Event | Viewer | Physics |
|---|---|---|
| Physics not started yet | WAITING; HELLO every 0.5 s | — |
| Physics stops or crashes | STALE after 0.25 s; last pose stays; UI responsive | — |
| Physics paused | PAUSED; poses keep arriving | sends the same pose with the PAUSED flag |
| Physics restarts | RESET flag or backwards `t_sim` → clear buffers, `physics_reset`, answer with HELLO | sends RESET on its first pose |
| Viewer restarts | HELLO at start-up (`seq` starts at 1 again); LIVE within a frame | sees a HELLO with a lower `seq`, clears the command session; keeps sending |
| Packet loss | newest pose wins (Module 5 interpolates over gaps) | resends nothing, except ACKs for resent commands |

## Try it

- Start the viewer, then start and stop `spin_bodies.py` five times with Ctrl-C. Check that the indicator follows LIVE → STALE every time. Python sends BYE on Ctrl-C, but `SimBridge` ignores it and goes STALE by wall time alone. Explain why that is the better design.
- Set `stale_after_s = 0.02` in the inspector. Run with `--loss 0.2`. Describe the flicker and explain it with the inter-arrival times.
- Remove the `self._seen_cmds.clear()` line in the HELLO branch and run `tests/test_protocol.py`. Read the failure message. Then try the "every HELLO" rule from the table (drop the `seq` comparison) and read that failure too. Put the original back.
- Design question: should a viewer that receives poses from **two** physics processes (a rover sim and a drone sim) treat a RESET from one as a reset of everything? What would you change in `_on_pose`?

## References

- [Protocol: failure behavior](../reference/protocol.md#failure-behavior-module-4-tests-these)
- [`sim_bridge.gd`](../reference/code/godot/bridge/sim_bridge.gd), [`bridge.py`](../reference/code/python/robosim/bridge.py)
- Godot `Node._exit_tree` and notifications (where BYE is sent): <https://docs.godotengine.org/en/stable/classes/class_node.html>
