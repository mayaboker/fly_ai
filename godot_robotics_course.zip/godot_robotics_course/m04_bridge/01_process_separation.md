# 01 Two processes, one physics owner

Up to now, Godot has been the only program running. From this module on there are two: a Python process that owns the physics, and Godot, which shows it. This page explains why the course splits them, and what is allowed to cross between them.

## Why not simulate in Godot?

Godot has a physics engine (Godot Physics or Jolt), so the question is fair. There are four reasons to keep vehicle dynamics in Python:

| Reason | Detail |
|---|---|
| **The robotics tools live in Python** | PyBullet, JSBSim, numpy, your controllers, your estimators and your learning code. Rewriting a flight model in GDScript throws away tested work. |
| **Physics must be deterministic and fixed-step** | A robotics simulation steps at a fixed `dt` (240 Hz for PyBullet here, 120 Hz for JSBSim) and must produce the same result twice. A game engine prioritizes frame rate. If rendering is slow, its physics is either slowed down or stepped more coarsely. |
| **Physics must run without graphics** | For tests, batch runs and training you run the physics at 10× or 100× real time with no window. Our `spin_bodies.py` runs 60 s of simulated time in about 0.5 s of wall time. |
| **Crashes stay contained** | When the viewer crashes, the experiment keeps running and logging. When physics crashes, the viewer shows that, and it does not hang. |

The price is a network boundary. Everything on this page and in the rest of the module is about paying that price carefully.

## The one-physics-owner rule

> **Exactly one process integrates the motion of a given vehicle. Everybody else only displays or measures it.**

If Godot also moved the vehicle, for example with a `RigidBody3D` or by integrating velocity in `_process`, you would have two answers to "where is the drone?". They drift apart within seconds. Worse, collisions resolved in Godot would never reach the physics that logs the run.

So in Godot, vehicle nodes are plain `Node3D` (or `MeshInstance3D`) whose `transform` is **set** from received poses. Nothing in the viewer moves on its own.

```
 Python physics process                       Godot viewer
 ┌────────────────────────────┐               ┌────────────────────────────┐
 │ PyBullet / JSBSim          │   POSE  ───▶  │ set node.transform         │
 │ fixed dt, owns t_sim       │   ACK   ───▶  │ draw, cameras, UI          │
 │ controllers, vehicle-state │  ◀── COMMAND  │ keys, buttons, gamepad     │
 │ sensors (IMU, GPS)         │  ◀── SENSOR   │ rays, lidar, contact,      │
 │ logs                       │  ◀── HELLO/BYE│ camera-derived detections  │
 └────────────────────────────┘               └────────────────────────────┘
```

## What crosses the boundary

| Data | Direction | Why it lives on that side |
|---|---|---|
| Pose (position, orientation, velocity) | physics → viewer | physics computes it |
| Commands (pause, reset, setpoints) | viewer → physics | the user interface is in Godot, the effect is in physics |
| Acknowledgements | physics → viewer | the viewer must know a command arrived |
| World-geometry sensor data | viewer → physics | Godot has the walls, terrain and meshes |
| Vehicle-state sensor data (IMU, GPS, baro) | stays in physics | it depends only on the vehicle state |

The last two rows are the **sensor ownership rule** from the course spec: *would the reading change if I moved a wall?* A lidar return would, so Godot computes it from its scene. An accelerometer would not, so physics computes it from the state it already has. [06](06_sensor_back_channel.md) builds the first kind of sensor.

## What never crosses

- **Frames and units other than Godot-world meters.** The physics side converts once ([frames](../reference/frames.md)). The viewer never sees ENU, NED, feet or degrees.
- **Godot's own clock as a timestamp.** Godot's frame counter and `delta` say nothing about simulation time. Every packet carries `t_sim`, the physics clock ([03](03_message_schema.md)).
- **Scene structure.** Python does not know node names, and Godot does not know PyBullet body ids. Both speak only in **vehicle ids** (1 = rover, 2 = quad, 3 = plane, 4 = quadplane, 10+ = test bodies).

## Two processes, two loops

Each process runs its own loop at its own rate, and neither waits for the other:

```
physics loop (Python)                     render loop (Godot, ~60 fps)
──────────────────────                    ──────────────────────────────
every 1/240 s of sim time:                every frame:
   read commands (non-blocking)              read all waiting packets (non-blocking)
   step physics                              set node transforms from the newest poses
   every 4th step: send POSE                 draw
   sleep until the next tick (real time)     send commands from input
```

"Neither waits" is the property that keeps the UI alive when physics dies, and keeps physics on schedule when rendering stutters. [Module 5](../m05_time_rates/README.md) adds a *lock-step* mode that deliberately breaks this rule for dataset generation, and shows what that costs.

## When two processes is the wrong choice

- A small game-like demo where nobody cares about the physics: use Godot's `RigidBody3D` and skip the bridge.
- Very tight hardware-in-the-loop timing (sub-millisecond): you would use shared memory or run everything in one native process. Module 7 uses shared memory for images, where the data is large.
- Physics that needs the render, for example a camera inside the control loop at every step: that is lock-step (Module 5), or a different architecture.

## Try it

- Start Godot with `spin_viewer.tscn` (from the [lab](lab.md)) **before** you start Python. What does the screen show while no physics runs? What does that tell you about who owns the vehicle?
- In your own words, write down where a "wheel touching a curb" event should be detected for the rover of Module 9, using the wall rule. Then check your answer against [Module 8](../m08_sensors/README.md).
- List three things in your own robotics work that would break if two processes integrated the same vehicle.

## References

- [Course README: the one architectural rule](../README.md#the-one-architectural-rule)
- [Bridge protocol](../reference/protocol.md)
- PyBullet quickstart guide (DIRECT vs GUI mode): <https://pybullet.org>
- Godot docs, Physics introduction (to see what you are *not* using for vehicles): <https://docs.godotengine.org/en/stable/tutorials/physics/physics_introduction.html>
