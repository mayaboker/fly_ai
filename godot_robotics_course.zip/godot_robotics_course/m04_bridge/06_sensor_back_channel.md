# 06 The sensor back channel

Some sensors need the world's geometry: a range finder needs the wall, a lidar needs the terrain, a contact sensor needs the curb. Godot has that geometry, and physics does not. So Godot computes these readings and sends them back as SENSOR packets. This page shows how to do that, and why the timestamp on those packets matters more than anything else in them.

## Who computes what

The course rule: **would the reading change if I moved a wall?**

| Sensor | Moves with a wall? | Computed in | Travels as |
|---|---|---|---|
| IMU, GPS, barometer, airspeed | no | physics | logged / used directly in Python |
| range finder, lidar | yes | Godot (raycasts) | SENSOR, type RANGE |
| bumper / contact | yes | Godot (shape queries) | SENSOR, type CONTACT |
| "target visible in camera" box | yes | Godot (camera projection) | SENSOR, type TARGET_BOX |

[Module 8](../m08_sensors/README.md) builds the full sensor set. This page builds the smallest useful one: a downward ray from the bouncing sphere, which measures the gap between the sphere and the floor.

## The packet

```
header (16 B)                     t_sim = sim time of the POSE the ray was cast from
vehicle_id u16, sensor u16, count u16, reserved u16
count × f32 values
```

| sensor | Name | values |
|---|---|---|
| 1 | CONTACT | hit 0/1, nx, ny, nz, depth m (normal in Godot world frame) |
| 2 | RANGE | one distance per ray, m (`inf` = no hit) |
| 3 | TARGET_BOX | visible 0/1, cx, cy (−1…1, **+cx right, +cy down**, the image convention), w_px, h_px |

SENSOR is unreliable. A lost reading is replaced by the next one, exactly like a pose.

## The timestamp is the measurement

When Godot casts a ray, it uses a pose that physics sent some time ago. By the time the SENSOR packet reaches Python, physics has moved on, typically by one or two pose periods. If Python compares the reading with its **current** state, it sees an error that is really just latency.

```
physics:  t=4.000 POSE ──▶ ...       t=4.017 step   t=4.033 step   reads SENSOR
viewer:                  ray cast from the t=4.000 pose ── SENSOR(t_sim=4.000) ──▶
                                                                    compare with state at 4.000: correct
                                                                    compare with state at 4.033: wrong by v·Δt
```

So the rule is: **tag a SENSOR packet with the `t_sim` of the pose it was computed from**, not with `bridge.latest_t_sim` at send time and never with wall time. `SimBridge.send_sensor(t_sim, ...)` takes the tag as its first argument, so you have to decide.

## Godot side

The viewer keeps the newest raw pose of the sphere from the `pose_received` signal. Then it casts one ray per received pose in `_physics_process`, the safe place to query Godot's physics space:

```gdscript
var _sphere_pose := {}         ## newest raw pose of the sphere

func _on_pose(vehicle_id: int, msg: Dictionary) -> void:
	if vehicle_id == SPHERE:
		_sphere_pose = msg

func _physics_process(_delta: float) -> void:
	if _sphere_pose.is_empty() or bridge.is_stale():
		return
	var origin: Vector3 = _sphere_pose.pos
	var q := PhysicsRayQueryParameters3D.create(origin, origin + Vector3.DOWN * 20.0)
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	var range_m := INF
	if not hit.is_empty():
		range_m = origin.distance_to(hit.position) - SPHERE_R
	# Tag with the sim time of the pose we used, NOT with "now".
	bridge.send_sensor(_sphere_pose.t_sim, SPHERE, RsProtocol.SENSOR_RANGE, PackedFloat32Array([range_m]))
	_sphere_pose = {}          # one measurement per received pose
```

Details that matter:

- The floor is a `StaticBody3D` with a `CollisionShape3D`. Rays only hit collision shapes, not meshes.
- The sphere itself has **no** collision shape in Godot. Physics owns the sphere. In Godot it is only a picture, so the ray cannot hit it by accident.
- The ray is cast from the **raw** received pose, not from the node's transform. In Module 5 the node shows an *interpolated* pose that has no single `t_sim` physics knows about. [Module 8](../m08_sensors/04_godot_range_lidar_contact.md) repeats this rule.
- Godot's `_physics_process` tick (60 Hz by default) only schedules the query. It does not simulate anything that matters.

## Python side

The scenario keeps a short history of the truth, keyed by `t_sim`, and looks up the tagged time:

```python
truth = deque(maxlen=240)                     # (t_sim, sphere bottom height), about 4 s at 60 Hz

def send_poses():
    ...
    truth.append((world.t_sim, world.pose_godot(world.sphere)[0][1] - SPHERE_R))

# in handle(msg):
elif msg["type"] == P.MSG_SENSOR and msg["sensor"] == P.SENSOR_RANGE and msg["vehicle_id"] == SPHERE:
    measured = msg["values"][0]
    for t, h in truth:
        if t == msg["t_sim"]:                 # exact match: both are the same f64
            range_err.append(abs(measured - h))
            range_err_naive.append(abs(measured - truth[-1][1]))
            break
```

The `==` on floats is deliberate. The viewer echoes the exact 8 bytes of `t_sim` it received, so the value comes back bit for bit. This is one more reason to compute `t_sim = step × dt` ([03](03_message_schema.md#sim-time-not-wall-time)).

## Measured

From our lab runs (for example a 14 s run with 654 RANGE packets matched):

| Comparison | Mean error |
|---|---|
| reading vs truth **at the tagged `t_sim`** | 0.0000 mm (max 0.0002 mm, float32 rounding) |
| reading vs the **newest** physics state | 24.7 mm (24.7–29.1 mm across our runs) |

The 25 mm is not sensor noise. It is the sphere's speed (up to about 7 m/s) times the 1–2 pose periods of transport and scheduling delay. Feed the naive version to an estimator and it will "learn" a bias that does not exist.

## Other sensors use the same pattern

A CONTACT sensor on the rover's bumper would run a shape query (`intersect_shape`) at the received pose and send `hit, nx, ny, nz, depth`, tagged the same way. Physics then decides what to do with it, for example apply a response force at the next step. Physics stays the owner of the motion. Godot only reports what it found.

## Try it

- Change the tag to `bridge.latest_t_sim` and rerun. How many packets still match a truth entry exactly? What does that tell you?
- Move the floor's `CollisionShape3D` 10 cm down in the editor (not the mesh). Which number changes in Python's summary, and by how much? This is the wall rule in action.
- Add a second ray, tilted 30° from vertical, and send both values in one RANGE packet (`count = 2`). Update the Python side.
- Measure how many SENSOR packets arrive per second, and compare with the pose rate. Explain any difference.

## References

- Godot ray-casting tutorial: <https://docs.godotengine.org/en/stable/tutorials/physics/ray-casting.html>
- `PhysicsDirectSpaceState3D.intersect_ray`: <https://docs.godotengine.org/en/stable/classes/class_physicsdirectspacestate3d.html>
- [Protocol: SENSOR](../reference/protocol.md#messages)
