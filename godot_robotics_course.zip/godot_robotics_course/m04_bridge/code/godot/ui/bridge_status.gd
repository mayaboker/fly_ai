class_name BridgeStatus
extends Label
## Stale-data indicator. Shows LIVE (green), PAUSED (yellow), STALE (red) or
## WAITING (grey, no pose yet) for the SimBridge it points at.
## The last pose stays on screen when the stream stops: the label is the only
## thing that tells you the picture is old.

@export var bridge: SimBridge

var _paused := false


func _ready() -> void:
	bridge.pose_received.connect(func(_id: int, msg: Dictionary) -> void:
		_paused = (msg.flags & RsProtocol.POSE_FLAG_PAUSED) != 0)


func _process(_delta: float) -> void:
	if bridge.latest_seq < 0:
		_show("WAITING for physics", Color(0.7, 0.7, 0.7))
	elif bridge.is_stale():
		_show("STALE  (last t_sim %.2f s)" % bridge.latest_t_sim, Color(1.0, 0.25, 0.2))
	elif _paused:
		_show("PAUSED", Color(1.0, 0.85, 0.2))
	else:
		_show("LIVE", Color(0.3, 1.0, 0.4))


func _show(t: String, c: Color) -> void:
	text = t
	add_theme_color_override("font_color", c)
