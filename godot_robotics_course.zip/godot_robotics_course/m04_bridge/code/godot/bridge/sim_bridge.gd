class_name SimBridge
extends Node
## Viewer side of the robosim bridge (Module 4 builds it, Module 5 adds interpolation).
##  - receives POSE packets, keeps a short timestamped buffer per vehicle
##  - sample(): interpolated Transform3D at a render time ~one pose period in the past
##  - send_command(): resent every RESEND_S until the physics process ACKs it
##  - send_sensor(): fire-and-forget, tagged with the sim time of the pose it used
## Physics owns time and dynamics. This node never moves anything by itself.

signal pose_received(vehicle_id: int, msg: Dictionary)
signal physics_reset

@export var listen_port := RsProtocol.PORT_TO_VIEWER
@export var physics_port := RsProtocol.PORT_TO_PHYSICS
@export var stale_after_s := 0.25        ## wall-clock seconds without a pose = stale
@export var max_extrapolate_s := 0.05    ## never extrapolate further than this
@export var buffer_len := 32

const RESEND_S := 0.1

var _udp := PacketPeerUDP.new()
var _seq := 0
var _buffers := {}            # vehicle_id -> Array of {t, pos, quat, vel}
var _last_rx_wall := -1.0
var _pending := {}            # seq -> {packet, sent_at}
var _last_hello_wall := -10.0
var latest_t_sim := 0.0       ## newest sim time received
var latest_seq := -1


func _ready() -> void:
	# Run before every other node each frame, so scripts that read the newest pose
	# see this frame's packets, not last frame's (measured: 4-10 ms less latency).
	process_priority = -100
	var err := _udp.bind(listen_port, "127.0.0.1")
	if err != OK:
		push_error("SimBridge: cannot bind UDP %d (%s)" % [listen_port, error_string(err)])
	_udp.set_dest_address("127.0.0.1", physics_port)
	# Always say HELLO once at start-up, even if poses are already waiting: it tells
	# a running physics process that this is a NEW viewer session.
	_send(RsProtocol.pack_simple(RsProtocol.MSG_HELLO, _next_seq(), 0.0))
	_last_hello_wall = _wall()


func _process(_delta: float) -> void:
	while _udp.get_available_packet_count() > 0:
		var msg := RsProtocol.unpack(_udp.get_packet())
		if msg.is_empty():
			continue
		match msg.type:
			RsProtocol.MSG_POSE:
				_on_pose(msg)
			RsProtocol.MSG_ACK:
				_pending.erase(msg.acked_seq)
	var now := _wall()
	if _last_rx_wall < 0.0 and now - _last_hello_wall > 0.5:   # say HELLO until physics answers
		_send(RsProtocol.pack_simple(RsProtocol.MSG_HELLO, _next_seq(), 0.0))
		_last_hello_wall = now
	for s in _pending.keys():                     # resend unacknowledged commands
		if now - _pending[s].sent_at > RESEND_S:
			_send(_pending[s].packet)
			_pending[s].sent_at = now


func _on_pose(msg: Dictionary) -> void:
	var first := _last_rx_wall < 0.0
	_last_rx_wall = _wall()
	var restarted: bool = msg.flags & RsProtocol.POSE_FLAG_RESET or msg.t_sim < latest_t_sim
	if first or restarted:
		# Answer a (re)started physics process with HELLO: if it is waiting in
		# wait_for_viewer() while sending idle poses, our earlier HELLOs may have
		# gone out before it was listening.
		_send(RsProtocol.pack_simple(RsProtocol.MSG_HELLO, _next_seq(), msg.t_sim))
	if restarted:
		_buffers.clear()                          # physics restarted or reset
		physics_reset.emit()
	latest_t_sim = msg.t_sim
	latest_seq = msg.seq
	var buf: Array = _buffers.get(msg.vehicle_id, [])
	buf.append({"t": msg.t_sim, "pos": msg.pos, "quat": msg.quat.normalized(), "vel": msg.vel})
	if buf.size() > buffer_len:
		buf.pop_front()
	_buffers[msg.vehicle_id] = buf
	pose_received.emit(msg.vehicle_id, msg)


## True when no pose arrived for stale_after_s (physics paused, crashed or gone).
func is_stale() -> bool:
	return _last_rx_wall < 0.0 or _wall() - _last_rx_wall > stale_after_s


func has_vehicle(vehicle_id: int) -> bool:
	return _buffers.has(vehicle_id) and not _buffers[vehicle_id].is_empty()


## Newest raw pose (no interpolation) as a Transform3D.
func latest_transform(vehicle_id: int) -> Transform3D:
	var p: Dictionary = _buffers[vehicle_id].back()
	return Transform3D(Basis(p.quat), p.pos)


## Interpolated pose at sim time t. Between samples: lerp + slerp.
## After the newest sample: extrapolate with velocity for at most max_extrapolate_s.
func sample(vehicle_id: int, t: float) -> Transform3D:
	var buf: Array = _buffers[vehicle_id]
	if t <= buf[0].t:
		return Transform3D(Basis(buf[0].quat), buf[0].pos)
	for i in range(buf.size() - 1, 0, -1):
		var a: Dictionary = buf[i - 1]
		var b: Dictionary = buf[i]
		if t >= a.t and t <= b.t:
			var w: float = 0.0 if b.t == a.t else (t - a.t) / (b.t - a.t)
			return Transform3D(Basis(a.quat.slerp(b.quat, w)), a.pos.lerp(b.pos, w))
	var last: Dictionary = buf.back()
	var dt: float = minf(t - last.t, max_extrapolate_s)
	return Transform3D(Basis(last.quat), last.pos + last.vel * dt)


## Reliable command: resent until the physics process acknowledges it.
func send_command(vehicle_id: int, cmd: int, args: Array = []) -> int:
	var s := _next_seq()
	var pkt := RsProtocol.pack_command(s, latest_t_sim, vehicle_id, cmd, args)
	_pending[s] = {"packet": pkt, "sent_at": _wall()}
	_send(pkt)
	return s


## Unreliable, latest-wins stream (e.g. stick input at 50 Hz): no ACK needed.
func send_command_unreliable(vehicle_id: int, cmd: int, args: Array = []) -> void:
	_send(RsProtocol.pack_command(_next_seq(), latest_t_sim, vehicle_id, cmd, args))


## Sensor data computed from the pose at sim time t_sim.
func send_sensor(t_sim: float, vehicle_id: int, sensor: int, values: PackedFloat32Array) -> void:
	_send(RsProtocol.pack_sensor(_next_seq(), t_sim, vehicle_id, sensor, values))


func pending_commands() -> int:
	return _pending.size()


func _exit_tree() -> void:
	_send(RsProtocol.pack_simple(RsProtocol.MSG_BYE, _next_seq(), latest_t_sim))
	_udp.close()


func _next_seq() -> int:
	_seq = (_seq + 1) & 0xFFFFFFFF
	return _seq


func _send(pkt: PackedByteArray) -> void:
	_udp.put_packet(pkt)


func _wall() -> float:
	return Time.get_ticks_usec() / 1e6
