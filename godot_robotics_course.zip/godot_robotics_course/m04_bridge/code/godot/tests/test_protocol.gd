extends SceneTree
## Godot side of the protocol tests (Module 4). The byte strings were produced by
## Python's robosim/protocol.py, so passing here proves both sides agree byte for byte.
## Run:  godot --headless --path godot --script res://tests/test_protocol.gd

const GOLDEN_POSE := "525301032a000000000000000000f83f0a0001000000803f000000c000004040" \
		+ "0000000000000000000000000000803f0000003f000000000000c0bf"
const GOLDEN_COMMAND := "525301040500000000000000000000400a000a000000a040000000c00000f041" \
		+ "0000003f00000000000000000000000000000000"
const GOLDEN_SENSOR := "525301060600000000000000000000400b000200020000000000c03f0000803e"

var _failed := 0


func _initialize() -> void:
	var m := RsProtocol.unpack(GOLDEN_POSE.hex_decode())
	_check(m.type == RsProtocol.MSG_POSE and m.seq == 42 and m.t_sim == 1.5, "pose header")
	_check(m.vehicle_id == 10 and m.flags == RsProtocol.POSE_FLAG_RESET, "pose id/flags")
	_check(m.pos.is_equal_approx(Vector3(1, -2, 3)), "pose pos")
	_check(m.quat.is_equal_approx(Quaternion(0, 0, 0, 1)), "pose quat (x,y,z,w order)")
	_check(m.vel.is_equal_approx(Vector3(0.5, 0, -1.5)), "pose vel")

	var cmd := RsProtocol.pack_command(5, 2.0, 10, RsProtocol.CMD_ATTITUDE, [5.0, -2.0, 30.0, 0.5])
	_check(cmd.size() == 52, "command size 52")
	_check(cmd.hex_encode() == GOLDEN_COMMAND, "command bytes equal Python's")
	var sen := RsProtocol.pack_sensor(6, 2.0, 11, RsProtocol.SENSOR_RANGE, PackedFloat32Array([1.5, 0.25]))
	_check(sen.hex_encode() == GOLDEN_SENSOR, "sensor bytes equal Python's")
	_check(RsProtocol.pack_simple(RsProtocol.MSG_HELLO, 1, 0.0).size() == 16, "hello size 16")

	var bad := GOLDEN_POSE.hex_decode()
	bad[2] = 2
	_check(RsProtocol.unpack(bad).is_empty(), "version 2 rejected")
	bad = GOLDEN_POSE.hex_decode()
	bad[0] = 0x58
	_check(RsProtocol.unpack(bad).is_empty(), "wrong magic rejected")
	_check(RsProtocol.unpack(GOLDEN_POSE.hex_decode().slice(0, 40)).is_empty(), "truncated pose rejected")
	_check(RsProtocol.unpack(PackedByteArray([1, 2, 3])).is_empty(), "short packet rejected")

	print("protocol.gd: %s" % ("all tests pass" if _failed == 0 else "%d FAILED" % _failed))
	quit(1 if _failed else 0)


func _check(ok: bool, what: String) -> void:
	if not ok:
		_failed += 1
		print("FAIL ", what)
