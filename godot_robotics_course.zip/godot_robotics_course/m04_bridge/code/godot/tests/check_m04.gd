extends SceneTree
## Automated Module 4 check. Runs the spin viewer, sends a timed plan of commands,
## and prints what it observed. Start physics/sims/spin_bodies.py first (or not: the
## check also shows what happens while physics is missing).
##
##   godot --headless --path godot --script res://tests/check_m04.gd -- \
##         --plan=pause@3,resume@5,reset@7 --duration=12
##
## Other options: --listen-port=N --physics-port=N --screenshot=/abs/path.png@4
## (screenshots need a real or virtual display, not --headless).

var viewer: Node
var bridge: SimBridge
var plan := []                 # [[t_wall, "pause"], ...]
var duration := 10.0
var shot_path := ""
var shot_at := -1.0
var t0 := 0.0
var last_print := 0.0
var max_frame_dt := 0.0
var frame_dts := PackedFloat32Array()
var frames := 0
var was_stale := true
var poses := {10: 0, 11: 0}
var paused_t_sims := {}        # t_sim values seen while the PAUSED flag was set
var resets := 0


func _initialize() -> void:
	Engine.max_fps = 60
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--plan="):
			for item in arg.get_slice("=", 1).split(",", false):
				plan.append([float(item.get_slice("@", 1)), item.get_slice("@", 0)])
		elif arg.begins_with("--duration="):
			duration = float(arg.get_slice("=", 1))
		elif arg.begins_with("--screenshot="):
			var v := arg.get_slice("=", 1)
			shot_path = v.get_slice("@", 0)
			shot_at = float(v.get_slice("@", 1))
	viewer = load("res://spin_viewer.tscn").instantiate()
	root.add_child(viewer)
	bridge = viewer.get_node("SimBridge")
	bridge.pose_received.connect(_on_pose)
	bridge.physics_reset.connect(func() -> void:
		resets += 1
		_log("physics_reset signal (t_sim now %.3f)" % bridge.latest_t_sim))
	t0 = _now()


func _on_pose(id: int, msg: Dictionary) -> void:
	poses[id] = poses.get(id, 0) + 1
	if msg.flags & RsProtocol.POSE_FLAG_PAUSED:
		paused_t_sims[msg.t_sim] = true


func _process(delta: float) -> bool:
	frames += 1
	var t := _now() - t0
	if frames == 1:
		_log("viewer started, listening on %d, physics on %d" % [bridge.listen_port, bridge.physics_port])
	if frames > 5:
		max_frame_dt = maxf(max_frame_dt, delta)
		frame_dts.append(delta)
	while not plan.is_empty() and t >= plan[0][0]:
		var what: String = plan.pop_front()[1]
		match what:
			"pause":
				bridge.send_command(10, RsProtocol.CMD_PAUSE)
			"resume":
				bridge.send_command(10, RsProtocol.CMD_RESUME)
			"reset":
				bridge.send_command(10, RsProtocol.CMD_RESET)
		viewer.commands_sent += 1
		_log("sent %s" % what.to_upper())
	var stale := bridge.is_stale()
	if stale != was_stale:
		_log("%s (t_sim %.3f)" % ["STALE" if stale else "LIVE", bridge.latest_t_sim])
		was_stale = stale
	if t - last_print >= 1.0:
		last_print = t
		_log("t_sim %.3f  poses cube %d sphere %d  pending %d  paused %s  max frame dt %.1f ms" % [
				bridge.latest_t_sim, poses[10], poses[11], bridge.pending_commands(), viewer.paused,
				max_frame_dt * 1000.0])
	if shot_path != "" and t >= shot_at:
		root.get_viewport().get_texture().get_image().save_png(shot_path)
		_log("screenshot saved to " + shot_path)
		shot_path = ""
	if t >= duration:
		_log("SUMMARY commands sent %d, still waiting for ACK %d, resets seen %d, " % [
				viewer.commands_sent, bridge.pending_commands(), resets]
				+ "distinct t_sim while paused %d, frames %d, max frame dt %.1f ms" % [
				paused_t_sims.size(), frames, max_frame_dt * 1000.0])
		frame_dts.sort()
		_log("frame dt ms: median %.1f  p99 %.1f  max %.1f" % [frame_dts[frame_dts.size() / 2] * 1000.0,
				frame_dts[int(frame_dts.size() * 0.99)] * 1000.0, max_frame_dt * 1000.0])
		quit()
	return false


func _log(s: String) -> void:
	print("[wall %6.2f] %s" % [_now() - t0, s])


func _now() -> float:
	return Time.get_ticks_usec() / 1e6
