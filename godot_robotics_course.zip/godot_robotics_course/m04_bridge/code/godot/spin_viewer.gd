extends Node3D
## Module 4 viewer for physics/sims/spin_bodies.py.
##  - places the cube (id 10) and the sphere (id 11) at the NEWEST pose (no interpolation yet)
##  - P toggles PAUSE/RESUME, R sends RESET (reliable commands); buttons do the same
##  - measures the sphere's height above the floor with a ray and sends it back as a
##    RANGE sensor packet, tagged with the t_sim of the pose it was computed from
## Optional command-line ports (after "--"):  --listen-port=9001 --physics-port=9002

const CUBE := 10
const SPHERE := 11
const SPHERE_R := 0.25

@onready var bridge: SimBridge = $SimBridge
@onready var cube: Node3D = $Cube
@onready var sphere: Node3D = $Sphere
@onready var info: Label = $UI/Info

var paused := false            ## from the PAUSED flag of the newest pose
var commands_sent := 0
var resets_seen := 0
var _sphere_pose := {}         ## newest raw pose of the sphere (for the range sensor)


func _enter_tree() -> void:
	# Runs BEFORE the children's _ready, so SimBridge binds the ports we set here.
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--listen-port="):
			$SimBridge.listen_port = int(arg.get_slice("=", 1))
		elif arg.begins_with("--physics-port="):
			$SimBridge.physics_port = int(arg.get_slice("=", 1))


func _ready() -> void:
	bridge.pose_received.connect(_on_pose)
	bridge.physics_reset.connect(func() -> void: resets_seen += 1)
	$UI/Buttons/Pause.pressed.connect(toggle_pause)
	$UI/Buttons/Reset.pressed.connect(reset)


func _on_pose(vehicle_id: int, msg: Dictionary) -> void:
	paused = (msg.flags & RsProtocol.POSE_FLAG_PAUSED) != 0
	if vehicle_id == SPHERE:
		_sphere_pose = msg


func _process(_delta: float) -> void:
	# Latest wins: show the newest pose we have. If the stream stops, the bodies
	# simply stay where they are and BridgeStatus says STALE. Nothing blocks.
	if bridge.has_vehicle(CUBE):
		cube.transform = bridge.latest_transform(CUBE)
	if bridge.has_vehicle(SPHERE):
		sphere.transform = bridge.latest_transform(SPHERE)
	info.text = "t_sim %.3f s   seq %d   commands waiting for ACK: %d   resets seen: %d\n[P] pause/resume   [R] reset" % [
		bridge.latest_t_sim, bridge.latest_seq, bridge.pending_commands(), resets_seen]


func _physics_process(_delta: float) -> void:
	# A world-geometry sensor belongs to Godot ("would it change if I moved a wall?" yes).
	if _sphere_pose.is_empty() or bridge.is_stale():
		return
	var origin: Vector3 = _sphere_pose.pos
	var q := PhysicsRayQueryParameters3D.create(origin, origin + Vector3.DOWN * 20.0)
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	var range_m := INF
	if not hit.is_empty():
		range_m = origin.distance_to(hit.position) - SPHERE_R
	# Tag with the sim time of the pose we used, NOT with "now".
	bridge.send_sensor(_sphere_pose.t_sim, SPHERE, RsProtocol.SENSOR_RANGE, PackedFloat32Array([range_m]))
	_sphere_pose = {}          # one measurement per received pose


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_P:
				toggle_pause()
			KEY_R:
				reset()


func toggle_pause() -> void:
	bridge.send_command(CUBE, RsProtocol.CMD_RESUME if paused else RsProtocol.CMD_PAUSE)
	commands_sent += 1


func reset() -> void:
	bridge.send_command(CUBE, RsProtocol.CMD_RESET)
	commands_sent += 1
