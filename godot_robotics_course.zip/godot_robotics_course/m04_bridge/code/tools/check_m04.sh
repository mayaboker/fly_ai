#!/bin/bash
# check_m04.sh - the Module 4 Check, automated. Run from the robosim/ folder:
#     GODOT=~/tools/godot bash tools/check_m04.sh
# Optional: VIEWER_PORT=9001 PHYSICS_PORT=9002 (defaults), PY=python3
# Runs four scenarios and prints what the viewer and the physics process saw:
#   A  protocol unit tests (Python and Godot)
#   B  20 % pose loss, 50 % ACK loss, 30 % command loss: commands applied exactly once
#   C  physics killed (kill -9) and restarted while the viewer keeps running
#   D  viewer restarted twice while physics keeps running
set -u
GODOT=${GODOT:-godot}
PY=${PY:-python3}
VP=${VIEWER_PORT:-9001}
PP=${PHYSICS_PORT:-9002}
ROOT=$(cd "$(dirname "$0")/.." && pwd)
OUT=$(mktemp -d)
GD="$GODOT --headless --path $ROOT/godot --script res://tests/check_m04.gd -- --listen-port=$VP --physics-port=$PP"
SIM="$PY $ROOT/physics/sims/spin_bodies.py --viewer-port $VP --listen-port $PP"

echo "=== A: protocol tests"
(cd "$ROOT/physics" && $PY tests/test_protocol.py | tail -1)
$GODOT --headless --path "$ROOT/godot" --script res://tests/test_protocol.gd 2>&1 | grep "protocol.gd"

echo "=== B: packet loss and reliable commands"
timeout -s INT 20 $SIM --loss 0.2 --ack-loss 0.5 --cmd-loss 0.3 > "$OUT/b.txt" 2>&1 &
sleep 1
$GD --plan=pause@2,resume@3,pause@4,resume@5,reset@6,pause@7,resume@8,reset@9,pause@10,resume@11 \
    --duration=14 2>&1 | grep -E "SUMMARY|frame dt ms"
wait
grep summary "$OUT/b.txt"

echo "=== C: physics crash and restart"
$SIM > "$OUT/c1.txt" 2>&1 &
P1=$!
$GD --plan=pause@8,resume@9 --duration=11 2>&1 | grep -E "STALE|LIVE|physics_reset|SUMMARY|frame dt ms" > "$OUT/c.txt" &
G1=$!
sleep 3; kill -9 $P1; echo "(physics killed at ~3 s)"
sleep 3; timeout -s INT 6 $SIM > "$OUT/c2.txt" 2>&1 &
echo "(physics restarted at ~6 s)"
wait $G1; wait
cat "$OUT/c.txt"
grep -E "applied" "$OUT/c2.txt"

echo "=== D: viewer restarts"
timeout -s INT 16 $SIM > "$OUT/d.txt" 2>&1 &
sleep 1
for i in 1 2; do
  $GD --plan=pause@2,resume@3 --duration=5 2>&1 | grep SUMMARY
  sleep 1
done
wait
grep -E "applied|HELLO" "$OUT/d.txt"
rm -rf "$OUT"
