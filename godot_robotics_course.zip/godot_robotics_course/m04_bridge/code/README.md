# Module 4 reference code

The finished files for [lab.md](../lab.md). Paths mirror `robosim/`.

| File | Copy to | Note |
|---|---|---|
| `physics/robosim/bridge.py` | `robosim/physics/robosim/` | the reference `bridge.py`, with the corrected session rule (only a HELLO with a lower `seq`, or a BYE, starts a new command session; see 05) |
| `physics/sims/spin_bodies.py` | `robosim/physics/sims/` | Module 4 version; Module 5 replaces it with a superset |
| `physics/tests/test_protocol.py` | `robosim/physics/tests/` | 7 tests; `test_bridge_ack_and_dedup` covers viewer restart and late resends |
| `godot/bridge/sim_bridge.gd` | `robosim/godot/bridge/` | identical to the reference `sim_bridge.gd` (HELLO at start-up, until the first pose, and on each physics session's first pose; `process_priority = -100`) |
| `godot/spin_viewer.tscn`, `spin_viewer.gd` | `robosim/godot/` | the viewer (raw poses; Module 5 adds interpolation) |
| `godot/ui/bridge_status.gd` | `robosim/godot/ui/` | `BridgeStatus` label |
| `godot/tests/test_protocol.gd` | `robosim/godot/tests/` | Godot side of the golden-bytes test |
| `godot/tests/check_m04.gd` | `robosim/godot/tests/` | scripted viewer for the automated Check |
| `tools/check_m04.sh` | `robosim/tools/` | runs the whole Check |
| `screenshots/m04_live.png`, `m04_stale.png` | — | from our test run, for comparison |

`protocol.py`, `protocol.gd`, `frames.py` and `logger.py` are used unchanged from `reference/code` (copied in 00_setup).

## Run

```bash
cd ~/robosim/godot && godot --headless --import            # once: registers RsProtocol, SimBridge, BridgeStatus

# tests
cd ~/robosim/physics && python tests/test_protocol.py
cd ~/robosim/godot && godot --headless --script res://tests/test_protocol.gd

# the lab, two terminals
cd ~/robosim/physics && python sims/spin_bodies.py [--loss 0.2] [--ack-loss 0.5] [--cmd-loss 0.3]
godot --path ~/robosim/godot res://spin_viewer.tscn

# the whole Check, headless
cd ~/robosim && GODOT=~/tools/godot bash tools/check_m04.sh
```

`spin_bodies.py` options: `--physics-hz 240`, `--pose-hz 60`, `--seed 1`, `--loss`, `--ack-loss`, `--cmd-loss`, `--duration` (sim s), `--viewer-port 9001`, `--listen-port 9002`.
Viewer options after `--`: `--listen-port=N --physics-port=N`.
`check_m04.gd` options after `--`: `--plan=pause@3,resume@5,reset@7` (wall seconds), `--duration=S`, `--screenshot=/abs/path.png@S` (needs a display; we used `xvfb-run`), plus the port options.
`check_m04.sh` environment: `GODOT`, `PY`, `VIEWER_PORT`, `PHYSICS_PORT`.

## What was verified (Godot 4.7.2, Python 3.11, PyBullet 3.2.x, Linux, shared 2-core VM)

All runs used a throwaway copy of `robosim/` built as in 00_setup, with ports 9140/9141 so they would not collide with other tests. The final `check_m04.sh` run used a fresh project assembled only from `reference/code` and this folder.

| Test | Result |
|---|---|
| `test_protocol.py` | 7/7 pass. With the "any packet whose seq goes backwards" rule or the "every HELLO" rule, `test_bridge_ack_and_dedup` fails, as intended |
| `test_protocol.gd` (headless) | all pass: Godot decodes Python's golden POSE; COMMAND and SENSOR bytes identical to Python's |
| Scenario B, loss 20 % poses / 50 % ACKs / 30 % commands, 10 commands | applied exactly 10 (4 PAUSE, 4 RESUME, 2 RESET) in three runs: 21, 16 and 40 command packets received; 0 left pending |
| Scenario C, `kill -9` physics, restart after 3 s | STALE about 0.25 s after the last pose, last pose kept, `physics_reset` and LIVE after restart, commands applied by the new process; median frame time 16.7 ms |
| Scenario D, viewer restarted twice | both sessions' commands applied; in one run the second session reused seq 121 and 182 |
| RANGE sensor | error at the tagged `t_sim`: mean 0.0000 mm, max 0.0002 mm; against the newest state: 24.7–29.1 mm mean |
| Rendering (`xvfb-run`, `--rendering-driver opengl3`) | screenshots in `screenshots/` |
| `SimBridge` HELLO without the start-up HELLO | with physics already running, the viewer sometimes sent no HELLO at all (a race with the first packet); with it, HELLO is always logged by Python (twice per session: start-up and first pose) |

Re-run after the reference bridge change (HELLO on each physics session's first pose, `process_priority = -100`, session rule): `check_m04.sh` with a fresh project from `reference/code` + this folder, ports 9300/9301. A–D pass; B applied exactly `{'PAUSE': 4, 'RESUME': 4, 'RESET': 2}` (36 command packets in, 16 dropped, 10 ACKs dropped). With the intermediate "any packet whose seq goes backwards" rule, B applied 13 PAUSEs and 8 RESUMEs for 4 + 4 sent. A viewer killed with `kill -9` (no BYE) and restarted: both sessions' commands applied.

Not tested here: the interactive buttons and keys with a real mouse and keyboard (the automated check calls the same functions), and Windows/macOS. `check_m04.sh` uses `timeout` and `kill`, so it needs Linux or macOS with coreutils.
