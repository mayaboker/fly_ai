"""
bridge.py - physics side of the robosim bridge.

    br = PhysicsBridge()
    br.wait_for_viewer()                # optional handshake
    ...
    for msg in br.poll():               # commands (already ACKed) and sensors
        ...
    br.send_pose(t_sim, vehicle_id, pos_godot, quat_godot, vel_godot)
"""
import socket, time
from . import protocol as P


class PhysicsBridge:
    def __init__(self, viewer_port=P.PORT_TO_VIEWER, listen_port=P.PORT_TO_PHYSICS, host="127.0.0.1"):
        self.tx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.rx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.rx.bind((host, listen_port))
        self.rx.setblocking(False)
        self.viewer = (host, viewer_port)
        self.seq = 0
        self.viewer_alive = False
        self._seen_cmds = {}           # seq -> time, to drop resent duplicates
        self._viewer_max_seq = -1      # highest seq seen from the current viewer session
        self._reset_flag = True        # first pose carries RESET

    def _next(self):
        self.seq = (self.seq + 1) & 0xFFFFFFFF
        return self.seq

    def send_pose(self, t_sim, vehicle_id, pos, quat, vel=(0, 0, 0), paused=False):
        flags = (P.POSE_FLAG_RESET if self._reset_flag else 0) | (P.POSE_FLAG_PAUSED if paused else 0)
        self._reset_flag = False
        self.tx.sendto(P.pack_pose(self._next(), t_sim, vehicle_id, pos, quat, vel, flags), self.viewer)

    def mark_reset(self):
        """Call after resetting the simulation: the next pose tells the viewer to clear buffers."""
        self._reset_flag = True

    def poll(self, t_sim=0.0):
        """Return new messages. COMMANDs are ACKed and de-duplicated here."""
        out = []
        while True:
            try:
                data, _ = self.rx.recvfrom(65536)
            except BlockingIOError:
                break
            msg = P.unpack(data)
            if msg is None:
                continue
            if msg["type"] == P.MSG_BYE:
                self.viewer_alive = False
                self._seen_cmds.clear()
                self._viewer_max_seq = -1
                out.append(msg)
                continue
            # Any valid packet from the viewer means it is alive (not only HELLO).
            self.viewer_alive = True
            if msg["type"] == P.MSG_HELLO and msg["seq"] < self._viewer_max_seq:
                # A HELLO whose counter went backwards: a NEW viewer session started
                # (it counts from 1 again). Forget the old session's command seqs,
                # otherwise its new commands would be ACKed and silently dropped.
                # (Only HELLO: a resent COMMAND legitimately carries an older seq.)
                self._seen_cmds.clear()
                self._viewer_max_seq = msg["seq"]
            self._viewer_max_seq = max(self._viewer_max_seq, msg["seq"])
            if msg["type"] == P.MSG_COMMAND:
                self.tx.sendto(P.pack_ack(self._next(), t_sim, msg["seq"]), self.viewer)
                if msg["seq"] in self._seen_cmds:
                    continue                      # a resend of something we already handled
                self._seen_cmds[msg["seq"]] = time.monotonic()
                if len(self._seen_cmds) > 1000:
                    for k in sorted(self._seen_cmds)[:500]:
                        del self._seen_cmds[k]
            out.append(msg)
        return out

    def wait_for_viewer(self, timeout=None, send_idle_pose=None):
        """Block until the viewer says HELLO (or sends anything). send_idle_pose() is called
        every 0.1 s meanwhile so a viewer that started first still sees the vehicle."""
        t0 = time.monotonic()
        while not self.viewer_alive:
            self.poll()
            if send_idle_pose:
                send_idle_pose()
            if timeout and time.monotonic() - t0 > timeout:
                return False
            time.sleep(0.1)
        return True
