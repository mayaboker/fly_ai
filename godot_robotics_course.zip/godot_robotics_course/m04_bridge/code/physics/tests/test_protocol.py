"""test_protocol.py - tests for the robosim bridge protocol v1 (Module 4).

Run from the physics/ folder:
    python tests/test_protocol.py        (plain Python)
    python -m pytest tests/test_protocol.py   (if you use pytest)

What is tested:
  1. every message type survives a pack -> unpack round trip
  2. packet sizes match the table in reference/protocol.md
  3. invalid packets are rejected: short, wrong magic, truncated body
  4. a packet with another protocol version is rejected
  5. the golden bytes of one POSE packet (the Godot test checks the same bytes)
  6. PhysicsBridge over real UDP sockets: commands are ACKed every time but
     returned only once, and a restarted viewer (seq starts again at 1) is not
     mistaken for a resend
"""
import math
import os
import socket
import struct
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from robosim import protocol as P            # noqa: E402
from robosim.bridge import PhysicsBridge      # noqa: E402

# The POSE that tests/test_protocol.gd decodes on the Godot side.
GOLDEN_POSE_HEX = ("525301032a000000000000000000f83f"   # header: RS, v1, POSE, seq 42, t 1.5
                   "0a000100"                           # vehicle 10, flags RESET
                   "0000803f000000c000004040"           # pos 1, -2, 3
                   "0000000000000000000000000000803f"   # quat 0, 0, 0, 1
                   "0000003f000000000000c0bf")          # vel 0.5, 0, -1.5


def close(a, b, tol=1e-6):
    return all(abs(x - y) <= tol for x, y in zip(a, b))


def test_round_trip():
    m = P.unpack(P.pack_pose(7, 1.25, 10, (1.0, 2.5, -3.0), (0.0, 0.0, 0.7071068, 0.7071068),
                             (0.1, 0.2, 0.3), flags=P.POSE_FLAG_RESET))
    assert m["type"] == P.MSG_POSE and m["seq"] == 7 and m["t_sim"] == 1.25
    assert m["vehicle_id"] == 10 and m["flags"] == P.POSE_FLAG_RESET
    assert close(m["pos"], (1.0, 2.5, -3.0)) and close(m["vel"], (0.1, 0.2, 0.3))
    assert close(m["quat"], (0.0, 0.0, 0.7071068, 0.7071068))

    m = P.unpack(P.pack_command(8, 2.0, 11, P.CMD_ATTITUDE, [5.0, -2.0, 30.0, 0.6]))
    assert m["type"] == P.MSG_COMMAND and m["cmd"] == P.CMD_ATTITUDE and m["vehicle_id"] == 11
    assert close(m["args"], (5.0, -2.0, 30.0, 0.6, 0, 0, 0, 0))

    m = P.unpack(P.pack_ack(9, 3.0, 4_000_000_000))
    assert m["type"] == P.MSG_ACK and m["acked_seq"] == 4_000_000_000

    m = P.unpack(P.pack_sensor(10, 4.0, 11, P.SENSOR_RANGE, [1.5, math.inf, 0.25]))
    assert m["type"] == P.MSG_SENSOR and m["sensor"] == P.SENSOR_RANGE
    assert m["values"][0] == 1.5 and math.isinf(m["values"][1]) and m["values"][2] == 0.25

    for typ in (P.MSG_HELLO, P.MSG_BYE):
        m = P.unpack(P.pack_simple(typ, 11, 5.0))
        assert m == {"type": typ, "seq": 11, "t_sim": 5.0}


def test_sizes():
    assert len(P.pack_simple(P.MSG_HELLO, 1, 0.0)) == 16
    assert len(P.pack_pose(1, 0.0, 1, (0, 0, 0), (0, 0, 0, 1))) == 60
    assert len(P.pack_command(1, 0.0, 1, P.CMD_PAUSE)) == 52
    assert len(P.pack_ack(1, 0.0, 5)) == 20
    assert len(P.pack_sensor(1, 0.0, 1, P.SENSOR_CONTACT, [1, 0, 1, 0, 0.01])) == 24 + 4 * 5


def test_seq_wraps():
    m = P.unpack(P.pack_pose(2**32 + 5, 0.0, 1, (0, 0, 0), (0, 0, 0, 1)))
    assert m["seq"] == 5


def test_invalid_rejected():
    good = P.pack_pose(1, 0.5, 10, (1, 2, 3), (0, 0, 0, 1))
    assert P.unpack(b"") is None
    assert P.unpack(good[:15]) is None                       # shorter than the header
    assert P.unpack(b"XX" + good[2:]) is None                 # wrong magic
    assert P.unpack(good[:40]) is None                        # truncated POSE body
    assert P.unpack(P.pack_command(1, 0, 1, 1)[:30]) is None  # truncated COMMAND body
    bad_sensor = bytearray(P.pack_sensor(1, 0, 1, P.SENSOR_RANGE, [1.0, 2.0]))
    struct.pack_into("<H", bad_sensor, 16 + 4, 50)           # claims 50 values, carries 2
    assert P.unpack(bytes(bad_sensor)) is None
    assert P.unpack(b"hello world, not a robosim packet") is None


def test_version_mismatch_rejected():
    pkt = bytearray(P.pack_pose(1, 0.5, 10, (1, 2, 3), (0, 0, 0, 1)))
    pkt[2] = 2                                                # a future version 2 sender
    assert P.unpack(bytes(pkt)) is None
    pkt[2] = 0
    assert P.unpack(bytes(pkt)) is None


def test_golden_bytes():
    pkt = P.pack_pose(42, 1.5, 10, (1.0, -2.0, 3.0), (0.0, 0.0, 0.0, 1.0), (0.5, 0.0, -1.5),
                      flags=P.POSE_FLAG_RESET)
    assert pkt.hex() == GOLDEN_POSE_HEX, pkt.hex()


def _viewer_socket(port):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(("127.0.0.1", port))
    s.settimeout(0.5)
    return s


def _poll_for(br, seconds=0.2):
    out, t0 = [], time.monotonic()
    while time.monotonic() - t0 < seconds:
        out += br.poll()
        time.sleep(0.005)
    return out


def test_bridge_ack_and_dedup(viewer_port=9198, physics_port=9199):
    br = PhysicsBridge(viewer_port=viewer_port, listen_port=physics_port)
    viewer = _viewer_socket(viewer_port)
    try:
        dest = ("127.0.0.1", physics_port)
        viewer.sendto(P.pack_simple(P.MSG_HELLO, 1, 0.0), dest)
        cmd = P.pack_command(2, 0.0, 10, P.CMD_PAUSE)
        for _ in range(3):                                   # one original + two resends
            viewer.sendto(cmd, dest)
        msgs = _poll_for(br)
        cmds = [m for m in msgs if m["type"] == P.MSG_COMMAND]
        assert len(cmds) == 1, f"command returned {len(cmds)} times, expected once"
        acks = [P.unpack(viewer.recv(100)) for _ in range(3)]
        assert all(a["type"] == P.MSG_ACK and a["acked_seq"] == 2 for a in acks)

        # The viewer restarts: its seq counter starts again at 1. HELLO comes first,
        # then a NEW command that happens to reuse seq 2. It must not be dropped.
        viewer.sendto(P.pack_simple(P.MSG_HELLO, 1, 0.0), dest)
        viewer.sendto(P.pack_command(2, 0.0, 10, P.CMD_RESUME), dest)
        cmds = [m for m in _poll_for(br) if m["type"] == P.MSG_COMMAND]
        assert len(cmds) == 1 and cmds[0]["cmd"] == P.CMD_RESUME, \
            "a command from a restarted viewer was treated as a duplicate (see Module 4, bridge fix)"

        # Same session: newer packets (a SENSOR, and the HELLO a viewer sends after a physics
        # reset) arrive, THEN a resend of the RESUME whose ACK was lost. The resend carries the
        # old, lower seq 2. It is still a duplicate and must not be applied twice.
        viewer.sendto(P.pack_sensor(3, 0.0, 10, P.SENSOR_RANGE, [1.0]), dest)
        viewer.sendto(P.pack_simple(P.MSG_HELLO, 4, 0.0), dest)
        viewer.sendto(P.pack_command(2, 0.0, 10, P.CMD_RESUME), dest)
        cmds = [m for m in _poll_for(br) if m["type"] == P.MSG_COMMAND]
        assert not cmds, "a resent command (older seq, same viewer session) was applied again"
    finally:
        viewer.close()
        br.rx.close()
        br.tx.close()


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
            print(f"PASS {t.__name__}")
        except AssertionError as e:
            failed += 1
            print(f"FAIL {t.__name__}: {e}")
    print(f"protocol: {len(tests) - failed}/{len(tests)} tests pass")
    sys.exit(1 if failed else 0)
