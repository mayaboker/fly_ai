#!/usr/bin/env python3
"""spin_bodies.py - Module 4 test scenario: two bodies streamed to the Godot viewer.

    id 10  cube   spins about a tilted axis, pinned at its center 1.5 m above the ground
    id 11  sphere bounces on the ground (and is kicked up again when it settles)

PyBullet runs in DIRECT mode (no window) at --physics-hz (240). Poses go out at
--pose-hz (60), already converted to the Godot frame. The viewer can send
PAUSE / RESUME / RESET as reliable commands and RANGE sensor packets.

Run from the physics/ folder:
    python sims/spin_bodies.py                 # ports 9001 / 9002
    python sims/spin_bodies.py --loss 0.2      # drop 20 % of POSE packets on purpose
    python sims/spin_bodies.py --ack-loss 0.5 --cmd-loss 0.3   # stress the reliable channel
"""
import argparse
import math
import os
import sys
import time
from collections import deque

import numpy as np
import pybullet as pb

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from robosim import protocol as P                         # noqa: E402
from robosim.bridge import PhysicsBridge                   # noqa: E402
from robosim.frames import enu_flu_to_godot, enu_to_godot_pos  # noqa: E402

CUBE, SPHERE = 10, 11
CUBE_HALF, SPHERE_R = 0.3, 0.25
CMD_NAMES = {P.CMD_HEARTBEAT: "HEARTBEAT", P.CMD_PAUSE: "PAUSE", P.CMD_RESUME: "RESUME",
             P.CMD_STEP: "STEP", P.CMD_RESET: "RESET"}


class SpinWorld:
    """The PyBullet world. Knows nothing about networking."""

    def __init__(self, physics_hz, seed):
        self.cid = pb.connect(pb.DIRECT)
        self.dt = 1.0 / physics_hz
        self.seed = seed
        self.build()

    def build(self):
        c = self.cid
        pb.resetSimulation(physicsClientId=c)
        pb.setGravity(0, 0, -9.81, physicsClientId=c)
        pb.setTimeStep(self.dt, physicsClientId=c)
        rng = np.random.default_rng(self.seed)          # every random choice comes from the seed

        ground = pb.createMultiBody(0, pb.createCollisionShape(pb.GEOM_PLANE, physicsClientId=c),
                                    physicsClientId=c)
        pb.changeDynamics(ground, -1, restitution=0.9, physicsClientId=c)

        box = pb.createCollisionShape(pb.GEOM_BOX, halfExtents=[CUBE_HALF] * 3, physicsClientId=c)
        self.cube = pb.createMultiBody(1.0, box, basePosition=[0, 0, 1.5], physicsClientId=c)
        pb.createConstraint(self.cube, -1, -1, -1, pb.JOINT_POINT2POINT, [0, 0, 0],
                            [0, 0, 0], [0, 0, 1.5], physicsClientId=c)   # pin the center
        axis = rng.normal(size=3) + np.array([0, 0, 2.0])
        axis /= np.linalg.norm(axis)
        pb.changeDynamics(self.cube, -1, linearDamping=0, angularDamping=0, physicsClientId=c)
        pb.resetBaseVelocity(self.cube, [0, 0, 0], list(axis * 2 * math.pi * 0.5),
                             physicsClientId=c)         # 0.5 rev/s

        ball = pb.createCollisionShape(pb.GEOM_SPHERE, radius=SPHERE_R, physicsClientId=c)
        h = float(rng.uniform(1.5, 2.5))
        self.sphere = pb.createMultiBody(1.0, ball, basePosition=[1.5, 0, h], physicsClientId=c)
        pb.changeDynamics(self.sphere, -1, restitution=0.9, linearDamping=0, physicsClientId=c)

        self.step_count = 0

    @property
    def t_sim(self):
        return self.step_count * self.dt                # exact multiple of dt, never accumulated

    def step(self):
        pb.stepSimulation(physicsClientId=self.cid)
        self.step_count += 1
        (x, y, z), _ = pb.getBasePositionAndOrientation(self.sphere, physicsClientId=self.cid)
        v, _ = pb.getBaseVelocity(self.sphere, physicsClientId=self.cid)
        if z < SPHERE_R + 0.02 and abs(v[2]) < 0.3:     # settled: kick it up again
            pb.resetBaseVelocity(self.sphere, [0, 0, 6.0], [0, 0, 0], physicsClientId=self.cid)

    def pose_godot(self, body):
        """(pos, quat, vel) of a body, converted once to the Godot frame."""
        p, q = pb.getBasePositionAndOrientation(body, physicsClientId=self.cid)
        v, _ = pb.getBaseVelocity(body, physicsClientId=self.cid)
        pos, quat = enu_flu_to_godot(p, q)
        return pos, quat, enu_to_godot_pos(v)


class LossySocket:
    """Wraps a UDP socket and drops packets on purpose, to test loss handling.
    Sending side: drops POSE packets (loss) and ACK packets (ack_loss).
    Receiving side: drops COMMAND packets (cmd_loss)."""

    def __init__(self, sock, rng, loss=0.0, ack_loss=0.0, cmd_loss=0.0):
        self.sock, self.rng = sock, rng
        self.loss = {P.MSG_POSE: loss, P.MSG_ACK: ack_loss, P.MSG_COMMAND: cmd_loss}
        self.dropped = {P.MSG_POSE: 0, P.MSG_ACK: 0, P.MSG_COMMAND: 0}
        self.cmd_packets_in = 0

    def _drop(self, data):
        typ = data[3] if len(data) > 3 else -1
        p = self.loss.get(typ, 0.0)
        if p > 0 and self.rng.random() < p:
            self.dropped[typ] += 1
            return True
        return False

    def sendto(self, data, addr):
        if self._drop(data):
            return len(data)                            # pretend it was sent
        return self.sock.sendto(data, addr)

    def recvfrom(self, n):
        while True:
            data, addr = self.sock.recvfrom(n)          # raises BlockingIOError when empty
            if len(data) > 3 and data[3] == P.MSG_COMMAND:
                self.cmd_packets_in += 1
            if not self._drop(data):
                return data, addr


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--physics-hz", type=int, default=240)
    ap.add_argument("--pose-hz", type=int, default=60)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--loss", type=float, default=0.0, help="fraction of POSE packets to drop")
    ap.add_argument("--ack-loss", type=float, default=0.0, help="fraction of ACK packets to drop")
    ap.add_argument("--cmd-loss", type=float, default=0.0, help="fraction of incoming COMMANDs to drop")
    ap.add_argument("--duration", type=float, default=0.0, help="stop after this many sim seconds (0 = never)")
    ap.add_argument("--viewer-port", type=int, default=P.PORT_TO_VIEWER)
    ap.add_argument("--listen-port", type=int, default=P.PORT_TO_PHYSICS)
    a = ap.parse_args()
    if a.physics_hz % a.pose_hz:
        sys.exit("physics-hz must be a multiple of pose-hz")
    steps_per_pose = a.physics_hz // a.pose_hz

    world = SpinWorld(a.physics_hz, a.seed)
    br = PhysicsBridge(viewer_port=a.viewer_port, listen_port=a.listen_port)
    loss_rng = np.random.default_rng(a.seed + 1000)    # separate stream: loss never changes physics
    br.tx = LossySocket(br.tx, loss_rng, loss=a.loss, ack_loss=a.ack_loss)
    br.rx = LossySocket(br.rx, loss_rng, cmd_loss=a.cmd_loss)

    paused = False
    applied = {}                                        # command name -> times applied
    truth = deque(maxlen=240)                           # (t_sim, sphere bottom height) for SENSOR checks
    range_err, range_err_naive = [], []
    poses_sent = 0

    def send_poses():
        nonlocal poses_sent
        for vid, body in ((CUBE, world.cube), (SPHERE, world.sphere)):
            pos, quat, vel = world.pose_godot(body)
            br.send_pose(world.t_sim, vid, pos, quat, vel, paused=paused)
            poses_sent += 1
        truth.append((world.t_sim, world.pose_godot(world.sphere)[0][1] - SPHERE_R))

    def handle(msg):
        nonlocal paused
        if msg["type"] == P.MSG_COMMAND:
            name = CMD_NAMES.get(msg["cmd"], f"cmd{msg['cmd']}")
            if msg["cmd"] == P.CMD_PAUSE:
                paused = True
            elif msg["cmd"] == P.CMD_RESUME:
                paused = False
            elif msg["cmd"] == P.CMD_RESET:
                world.build()
                truth.clear()
                br.mark_reset()                         # next pose carries the RESET flag
            else:
                print(f"ignored command {name}")
                return
            applied[name] = applied.get(name, 0) + 1
            print(f"[t_sim {world.t_sim:7.3f}] applied {name} (seq {msg['seq']})", flush=True)
        elif msg["type"] == P.MSG_SENSOR and msg["sensor"] == P.SENSOR_RANGE and msg["vehicle_id"] == SPHERE:
            measured = msg["values"][0]
            for t, h in truth:                          # look up truth at the TAGGED sim time
                if t == msg["t_sim"]:
                    range_err.append(abs(measured - h))
                    range_err_naive.append(abs(measured - truth[-1][1]))
                    break
        elif msg["type"] == P.MSG_HELLO:
            print("viewer said HELLO", flush=True)
        elif msg["type"] == P.MSG_BYE:
            print("viewer said BYE", flush=True)

    print(f"spin_bodies: physics {a.physics_hz} Hz, poses {a.pose_hz} Hz, seed {a.seed}, "
          f"sending to {a.viewer_port}, listening on {a.listen_port}", flush=True)
    period = 1.0 / a.pose_hz
    next_tick = time.monotonic()
    next_report = next_tick + 2.0
    try:
        while not (a.duration and world.t_sim >= a.duration):
            for msg in br.poll(world.t_sim):
                handle(msg)
            if not paused:
                for _ in range(steps_per_pose):
                    world.step()
            send_poses()                                # while paused: same pose, PAUSED flag set
            next_tick += period                         # real-time pacing on a fixed schedule
            now = time.monotonic()
            if now - next_tick > 0.25:                  # fell far behind (debugger, suspend): re-anchor
                next_tick = now
            time.sleep(max(0.0, next_tick - now))
            if now > next_report:
                next_report += 2.0
                err = f"{np.mean(range_err) * 1000:.3f} mm (naive {np.mean(range_err_naive) * 1000:.1f} mm)" \
                    if range_err else "no sensor data"
                print(f"[t_sim {world.t_sim:7.3f}] poses sent {poses_sent}, dropped "
                      f"{br.tx.dropped[P.MSG_POSE]}, viewer {'alive' if br.viewer_alive else 'unknown'}, "
                      f"range err {err}", flush=True)
    except KeyboardInterrupt:
        pass
    br.tx.sendto(P.pack_simple(P.MSG_BYE, br._next(), world.t_sim), br.viewer)
    print(f"summary: poses sent {poses_sent}, pose packets dropped {br.tx.dropped[P.MSG_POSE]}, "
          f"acks dropped {br.tx.dropped[P.MSG_ACK]}, command packets in {br.rx.cmd_packets_in} "
          f"(dropped {br.rx.dropped[P.MSG_COMMAND]}), commands applied {applied}, "
          f"sensor packets matched {len(range_err)}", flush=True)
    if range_err:
        print(f"range error at tagged t_sim: mean {np.mean(range_err) * 1000:.4f} mm, "
              f"max {np.max(range_err) * 1000:.4f} mm; using newest state instead: "
              f"mean {np.mean(range_err_naive) * 1000:.1f} mm", flush=True)


if __name__ == "__main__":
    main()
