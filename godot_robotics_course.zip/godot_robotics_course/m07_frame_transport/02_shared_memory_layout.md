# 02 Shared memory: layout, seqlock and buffering

A 1280×720 RGB stream at 30 Hz is 83 MB/s. You could push that through a socket, but every byte would be copied into the kernel and out again, and sockets bring packet sizes and buffers with them. On one Linux machine there is a simpler way: put the frames in **shared memory**, a piece of RAM that both processes see. The writer stores the pixels once; the reader copies them out once. This page designs the layout and, more importantly, the rules that stop the reader from seeing half-written frames.

## /dev/shm is RAM that looks like a file

On Linux, `/dev/shm` is a `tmpfs` file system: its files live in RAM, never on disk. A file there is exactly what the POSIX `shm_open()` call creates, and what Python's `multiprocessing.shared_memory` uses. Two ways to use it:

| Side | How it accesses `/dev/shm/robosim_cam_fpv` |
|---|---|
| Godot (GDScript has no `mmap`) | `FileAccess`: `seek()`, `store_buffer()`, `flush()`. Each `flush()` is a `write()` system call straight into the shared pages. |
| Python | `mmap.mmap(fd, size, prot=PROT_READ)`: the file's pages appear as a `bytes`-like object; `numpy.frombuffer` views them without copying. |

Both sides touch the same physical pages. Data written by Godot's `write()` is visible to the Python mapping as soon as the system call returns. No disk, no socket.

## What can go wrong without rules

The writer replaces a frame 30 times per second. The reader copies a frame whenever it is ready. If they meet in the same memory:

```
 writer:  [header f41][rows 0..359 of f41]          [header f42][rows 0..179 of f42 ...
 reader:                         copy rows 0..359 ────────────────▶
                                 got: rows 0..179 of f42 + rows 180..359 of f41  = TORN FRAME
```

A torn frame looks fine at a glance and wrecks a tracker. Worse, its header says f41 while half of its pixels are f42. Two tools prevent it: a **sequence counter** per slot (a seqlock) and **more than one slot**.

## The layout

One file, a 64-byte file header, then `n_slots` slots. Each slot is a 64-byte header followed by the pixel rows. All integers little-endian.

```
 offset 0                 64                    64 + S              64 + 2S
 ┌──────────────────────┬─────────────────────┬─────────────────────┬────────────
 │ file header (64 B)   │ slot 0              │ slot 1              │ slot 2 ...
 └──────────────────────┴─────────────────────┴─────────────────────┴────────────
                          │ slot header 64 B │ W·H·C pixel bytes │
                          S = slot_bytes = 64 + max_w · max_h · channels
```

**File header**

| Offset | Field | Type | Meaning |
|---:|---|---|---|
| 0 | magic | 4 bytes | `RSFB` (robosim frame buffer) |
| 4 | version | u32 | 1 |
| 8 | n_slots | u32 | ring size: 3 = triple buffering |
| 12 | slot_bytes | u32 | S, size of one slot |
| 16 | max_width | u32 | |
| 20 | max_height | u32 | |
| 24 | channels | u32 | 3 = RGB8, 4 = RGBA8 |
| 32 | latest_pub | u64 | publish number of the newest **complete** frame (1, 2, 3, …); 0 = none yet. Written last. |

**Slot header**

| Offset | Field | Type | Meaning |
|---:|---|---|---|
| 0 | seq | u32 | seqlock counter: **odd while the slot is being written, even when stable** |
| 4 | width | u32 | this frame's width |
| 8 | height | u32 | |
| 12 | channels | u32 | |
| 16 | frame_id | u64 | camera tick number, starts at 1. A gap means a tick without a frame. |
| 24 | t_sim | f64 | sim time of the pose the image was rendered from |
| 32 | t_capture_wall | f64 | Unix time (s) when the pixels reached CPU memory |
| 40 | pose_seq | u32 | bridge sequence number of that pose packet |
| 44 | data_bytes | u32 | W·H·C |
| 48 | readback_ms | f32 | time inside `get_image()` |
| 52 | convert_ms | f32 | time for `convert` + `get_data` |
| 56 | n_published | u32 | this frame's publish number (frames written so far, this one included) |

Frames go into the slots strictly in turn: the frame with publish number k is in slot `k % n_slots`, so the newest is in slot `latest_pub % n_slots`. Python reads the slot header with one `struct` format: `"<IIIIQddIIffI"` (60 bytes; 4 reserved).

`t_sim` and `pose_seq` are what make a frame useful for robotics: they tie the pixels to a physics state. `t_capture_wall` is for measuring latency. `n_published` lets the reader tell apart frames Godot never rendered from frames the reader missed (sub-topic 04).

## The seqlock

The writer of a slot does, in this order:

```
1. seq ← seq + 1        (now odd: "I am writing")          write() + flush
2. header fields, pixels                                    write() + flush
3. seq ← seq + 1        (now even: "stable")                write() + flush
4. latest_pub ← k       (announce)                          write() + flush
```

The reader does:

```
1. s1 ← seq             if s1 is odd: the writer is inside, try again shortly
2. copy header and pixels out of the slot
3. s2 ← seq             if s2 ≠ s1: the writer came in while we copied → throw the copy away
4. if header.n_published ≠ the k we wanted: the slot already holds a newer frame → skip
```

If `s1` is even and `s2 == s1`, nobody wrote the slot during the copy, so header and pixels belong together. The writer never waits for the reader. A slow reader only loses frames; it never blocks the simulation.

The sequence counter is written **last** in step 3 and the announcement after it in step 4. That ordering is the whole trick: a reader that sees the new `latest_pub` is guaranteed to find a stable, complete slot behind it. On the Godot side the order is enforced by calling `flush()` after each step, which turns each step into its own `write()` system call. Without `flush()`, `FileAccess` may hold the bytes in a buffer and write them in any grouping it likes.

## Why more than one slot

With one slot, the writer overwrites the frame the reader is copying. With three, the slot being written is never the newest complete one, and the newest one stays untouched until two more frames have been written.

```
 publish number k:  41        42        43        44
 slot k % 3:        2         0         1         2      ← frame 41's slot is reused only by frame 44
```

Why the publish number and not `frame_id`? `frame_id` counts camera ticks and skips when Godot misses a tick. With `frame_id % 3`, ticks 41, 43, 44 would put 41 and 44 in the same slot after only two writes. The first version of this code did exactly that; the publish counter uses the slots strictly in turn.

[torn_demo.py](code/tools/torn_demo.py) makes the reader deliberately slow: it reads `seq`, waits 50 ms (as if processing the frame in place), then reads `seq` again. Camera at 30 Hz, 640×360, reference machine:

| n_slots | Reads | Seq changed during the read | Share |
|---:|---:|---:|---:|
| 1 | 159 | 159 | 100 % |
| 2 | 159 | 82 | 52 % |
| 3 | 159 | 1 | 1 % (two runs, 1 each) |
| 4 | 158 | 0 | 0 % |

With one slot, every slow read would have been torn; the seqlock rejects them all, so the reader gets nothing. With three slots almost all were safe, but not all. A slot is safe for `n_slots − 1` *publications*, and two publications can come as close as one render frame (16.7 ms at 60 FPS) when Godot catches up after a slow frame. So 3 slots protect a hold of about 33 ms in the worst case, not 67 ms; 50 ms was just over the edge. The rule of thumb: **copy first, process later**, and use `n_slots ≥ 3`. Copying a 1280×720 RGB frame (2.8 MB) out of shared memory with numpy took 0.22 ms (median) on the reference machine, far less than a 33 ms frame period.

Naming: "double buffering" (2 slots) and "triple buffering" (3 slots) come from graphics, where the GPU draws into one buffer while the screen shows another.

## Reader races, one by one

| Race | What happens | Defence in `frame_reader.py` |
|---|---|---|
| Writer enters the slot during the copy | torn frame | seqlock: compare `seq` before and after |
| Slot overwritten between reading `latest_pub` and reading the slot | a newer frame than the one announced | check `n_published` in the slot header |
| Reader starts before Godot | file missing or empty | wait until the file exists and the magic is `RSFB` |
| Godot restarts | new file; old mapping is stale | writer deletes and recreates the file (new inode); reader notices `latest_pub` going backwards or the inode changing, and re-maps |
| File truncated under a mapping | **SIGBUS crash** in the reader | never truncate in place (the writer deletes first) |
| Resolution changes | different W, H | W, H, C are read per frame from the slot header |

### A note on memory ordering

On x86 CPUs, writes become visible to other cores in program order, and each system call is a full barrier anyway. On ARM (Jetson, Raspberry Pi) the system calls between the steps also act as barriers, so the GDScript writer stays correct. If you rewrite the writer in C++ with a direct `mmap`, you must add explicit memory fences (`std::atomic_thread_fence(std::memory_order_release)` before step 3), which is the textbook seqlock.

## The reader's core

From [frame_reader.py](code/tools/frame_reader.py):

```python
SLOT_HDR = struct.Struct("<IIIIQddIIffI")

def read(self, pub, retries=3):
    base = FILE_HEADER + (pub % self.n_slots) * self.slot_bytes
    for _ in range(retries):
        s1 = self._seq(base)
        if s1 & 1:                         # writer is inside this slot right now
            self.torn += 1
            time.sleep(0.0002)
            continue
        seq, w, h, c, fid, t_sim, t_cap, pose_seq, nbytes, rb_ms, cv_ms, n_pub = \
            SLOT_HDR.unpack_from(self.mm, base)
        if n_pub != (pub & 0xFFFFFFFF):
            return None                    # slot already holds a newer frame
        img = np.frombuffer(self.mm, np.uint8, nbytes, base + 64).reshape(h, w, c).copy()
        if self._seq(base) == s1:          # nobody wrote while we copied
            return dict(frame_id=fid, t_sim=t_sim, pose_seq=pose_seq, ...), img
        self.torn += 1
    return None
```

`np.frombuffer(...)` is a view into shared memory; `.copy()` is the one copy the reader makes. Return the copy, never the view: the view's contents change under you.

## Try it

- Draw the file for `n_slots = 3`, 640×360 RGB: compute every slot's start offset and the total file size. Check with `ls -l /dev/shm/robosim_cam_fpv` while the lab runs (expected 2 073 856 bytes: 64 + 3 × (64 + 691 200)).
- Run `torn_demo.py` with `--hold-ms 20` and `--hold-ms 50` against 1, 2 and 3 slots. Explain why 20 ms gives almost no tears even with one slot at 30 Hz (reference: 1 of 241 reads), and when it would give more.
- Remove the `flush()` after step 1 in the writer. Can you produce a torn frame that the reader accepts? (It may be hard to trigger; explain why it is still wrong.)

## References

- Linux man pages: [shm_overview(7)](https://man7.org/linux/man-pages/man7/shm_overview.7.html), [mmap(2)](https://man7.org/linux/man-pages/man2/mmap.2.html)
- Python docs: [mmap](https://docs.python.org/3/library/mmap.html), [struct](https://docs.python.org/3/library/struct.html)
- Godot docs: [FileAccess](https://docs.godotengine.org/en/4.7/classes/class_fileaccess.html) (`flush`, `resize`, `store_buffer`)
- Seqlocks: Linux kernel documentation, [Sequence counters and sequential locks](https://docs.kernel.org/locking/seqlock.html)
