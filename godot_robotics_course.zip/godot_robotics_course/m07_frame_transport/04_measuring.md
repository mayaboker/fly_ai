# 04 Measuring: FPS, drops, latency, bandwidth

"The video works" is not a result. A controller that steers by camera needs to know how old each image is, how many it will get per second, and whether some go missing. This page defines four measurements precisely, shows how the lab's tools compute them, and gives the reference numbers, with a clear warning about where those numbers came from.

## Four measurements

| Measurement | Definition | Computed from |
|---|---|---|
| **Delivered FPS** | frames the consumer actually received per second | (N − 1) / (t_read,last − t_read,first) |
| **Dropped frames** | camera ticks that did not reach the consumer, split by cause (below) | gaps in `frame_id` and `n_published` |
| **Latency** | age of the information when the consumer gets it; several spans (below) | timestamps on one clock |
| **Bandwidth** | bytes per second through the transport | delivered FPS × bytes per frame |

### Two kinds of drops

`frame_id` counts camera ticks; `n_published` counts frames Godot actually wrote. Over a measurement window:

```
ticks        = frame_id_last − frame_id_first + 1        what the camera rate asked for
published    = n_published_last − n_published_first + 1  what Godot rendered and wrote
received     = frames the reader got

not_rendered  = ticks − published       Godot's loop was slower than the camera rate
reader_missed = published − received    written, but overwritten before the reader got it
```

The two causes need opposite fixes. `not_rendered` means the renderer is the bottleneck: lower resolution, fewer cameras, cheaper effects, a faster GPU. `reader_missed` means the consumer is: copy faster, process on another thread, or add slots.

### Latency spans

All timestamps are Unix wall-clock seconds on **one machine** (`time.time()` in Python, `Time.get_unix_time_from_system()` in Godot), so they can be subtracted directly:

```
 physics                   Godot                                         Python reader
 ───────                   ─────                                         ─────────────
 t_send ──UDP──▶ pose arrives, waits for next frame
                 _process: vehicle placed, tick
                 render
                 frame_post_draw: get_image ── t_capture ── convert, write ──▶ t_read
 │◀──────────────────────── pose → read ───────────────────────────────────────────▶│
                                            │◀────────── capture → read ───────────▶│
                                 readback_ms │◀─▶│
```

| Span | Meaning | Where the timestamps come from |
|---|---|---|
| readback | time inside `get_image()` | slot header `readback_ms` |
| capture → read | convert + shared-memory write + reader polling + copy | `t_read − t_capture_wall` |
| **pose → read** | end to end: from the moment physics sent the pose to the moment Python holds the image of it | `t_read − t_send_unix[pose_seq]`, using `pose.csv` |

Pose → read is the number that matters for control. It is what a camera-based controller sees as sensor delay.

On two machines, the clocks differ by more than the latencies you are measuring. Synchronise them (chrony, or PTP on a LAN) or measure round trips instead.

## The tools

| Tool | Role |
|---|---|
| `physics/sims/camera_orbit.py` | plays the physics process: 240 Hz step, 60 Hz poses of the quad on a circle, logs `pose_seq` and `t_send_unix` for every pose |
| `godot/cameras/frame_lab.tscn` | renders the FPV camera, publishes frames, prints `GODOT_STATS` (readback, convert, write times) at the end |
| `tools/frame_reader.py` | reads frames, computes everything above, appends a row to `logs/frame_perf.csv` |
| `tools/run_frame_perf.sh` | starts all three for one configuration |

`frame_reader.py` ignores the first 2 s (`--warmup`): the first frames include shader compilation and are not typical.

## Reference results

**Read this first.** These numbers come from a 2-core Xeon VM with **no GPU**. Godot ran the Compatibility renderer on Mesa llvmpipe, which renders on the CPU, under a virtual X server; the Python processes shared the same two cores. They show that the pipeline works and how the measurements behave. They say nothing reliable about your GPU. **Re-measure on your machine** and report your hardware with your table.

Camera requested at 30 Hz, `Engine.max_fps = 60`, 15 s measured per cell, RGB8, 3 slots, no recording. Each configuration was run twice, at different times; each cell shows **run A / run B**. The VM was shared with other jobs, which is why the two runs differ. (Run A used an earlier version of the writer that chose slots by `frame_id`; the per-frame work was identical. Run B is the code in `code/`.)

| | 640×360 | 1280×720 | 640×360, no shadows | 1280×720, no shadows |
|---|---:|---:|---:|---:|
| Camera ticks | 452 / 451 | 449 / 451 | 451 / 451 | 450 / 442 |
| Frames published = received | 333 / 296 | 189 / 138 | 451 / 451 | 434 / 321 |
| Not rendered (Godot too slow) | 119 / 155 | 260 / 313 | 0 / 0 | 16 / 121 |
| Missed by reader | 0 / 0 | 0 / 0 | 0 / 0 | 0 / 0 |
| **Delivered FPS** | **22.1 / 19.7** | **12.6 / 9.1** | **30.0 / 30.0** | **28.9 / 21.3** |
| Readback `get_image()` mean (ms) | 1.29 / 1.20 | 4.47 / 4.18 | 1.20 / 1.25 | 4.42 / 5.32 |
| Readback p95 (ms) | 1.81 / 1.63 | 5.85 / 4.72 | 1.68 / 1.74 | 6.81 / 9.14 |
| Convert + get_data mean (ms) | 0.44 / 0.41 | 1.83 / 1.70 | 0.39 / 0.42 | 1.73 / 2.41 |
| Shared-memory write mean (ms) | 0.21 / 0.23 | 0.67 / 0.72 | 0.21 / 0.23 | 0.75 / 0.83 |
| **Capture → read** p50 (ms) | 1.09 / 1.08 | 3.18 / 3.14 | 0.99 / 1.14 | 3.08 / 3.25 |
| Capture → read p95 (ms) | 1.96 / 2.09 | 4.92 / 4.52 | 1.77 / 2.36 | 6.58 / 8.30 |
| **Pose → read** p50 (ms) | 51.3 / 54.9 | 82.7 / 119.9 | 22.7 / 23.8 | 40.5 / 44.0 |
| Pose → read p95 (ms) | 75.0 / 85.4 | 131.0 / 137.2 | 29.6 / 33.6 | 52.5 / 92.2 |
| **Bandwidth** (MB/s) | 15.3 / 13.6 | 34.7 / 25.2 | 20.7 / 20.7 | 79.9 / 58.9 |
| Torn copies rejected | 0 / 0 | 0 / 0 | 0 / 0 | 0 / 0 |

RGBA8 (no conversion in Godot), 1280×720, no shadows, runs A / B: 29.4 / 28.3 FPS, 0 / 0 missed by the reader, convert 0.01 / 0.01 ms, capture → read p50 1.84 / 1.95 ms, pose → read p50 35.9 / 37.3 ms, 108.3 / 104.5 MB/s.

### Reading the table

- **The transport is not the bottleneck.** In every run the reader missed nothing, no copy was torn, and capture → read stayed at 1–3.3 ms (p50) even at 80 MB/s. Shared memory does its job.
- **Rendering is.** With the default scene (sun shadows on), llvmpipe could not render 30 frames per second: 119–313 ticks were never rendered. Turning shadows off brought 640×360 to 30 FPS in both runs, and 1280×720 to 29 or 21 FPS depending on what else the VM was doing. On a GPU, shadows are much cheaper; expect the first two columns to look like the last two (an expectation, not a measurement).
- **Readback scales with pixels.** 4× the pixels cost about 3.5–4× the readback time (1.2 → 4.2–5.3 ms) and the conversion time.
- **Pose → read is dominated by the frame loop**, not by transport. At 60 render FPS the pose waits on average half a frame (8 ms) for `_process`; readback and conversion take about 2 ms and transport about 1 ms (measured). The remaining ~12 ms of the 22.7–23.8 ms median are the frame's own processing and rendering (inferred from the difference, not measured separately). When the loop slows to 20–22 FPS (shadows on), every part of that grows, and pose → read more than doubles.
- **Order matters.** Back-to-back runs (640×360, no shadows) with the bridge running *after* the vehicle code instead of before it gave pose → read medians of 35.2 and 32.2 ms instead of 24.7 and 28.5 ms. One `process_priority` line is worth 4–10 ms; `SimBridge` now sets it (−100) in its own `_ready()`, so you get this for free.

### What to expect on a GPU

Estimates only, to know whether your numbers are plausible. A desktop GPU should render this scene at hundreds of FPS, so `not_rendered` should be 0 at both sizes. Readback on a discrete GPU is often 1–5 ms at 1280×720 but can spike when the GPU is busy; watch the p95. Pose → read should approach one or two render frames. Measure and replace these guesses with your numbers.

## Sanity checks for your own measurements

- `ticks ≈ seconds × rate_hz`. If not, the wall clock or the rate is wrong.
- `bandwidth ≈ FPS × W × H × channels`. 30 × 640 × 360 × 3 = 20.7 MB/s.
- `capture → read` should be well below one frame period. If it is not, the reader is polling too slowly or the machine is overloaded.
- `pose → read` cannot be smaller than capture → read. If it is, the clocks are not the same clock.
- Run each configuration twice. If the two differ by more than your effect, you have measured noise. (Run A and run B above differ by up to 30 % in FPS on a shared VM.)

## Try it

- Run the four configurations on your machine and fill in the table. State GPU, driver, renderer (Forward+/Mobile/Compatibility), OS and whether the window was visible.
- Add `--rate=60`. Which column changes first: `not_rendered` or `reader_missed`?
- Make the reader slow on purpose: add `time.sleep(0.05)` after each frame in `frame_reader.py`. Which drop counter grows? Does `pose → read` change?

## References

- [Log format](../reference/logging.md) (`t_sim` vs `t_wall`, one run per folder)
- Brendan Gregg, *Systems Performance*, 2nd ed., chapter 2 (methodology: latency, utilisation, percentiles)
