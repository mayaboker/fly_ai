# 03 The writer in Godot, the reader in Python

This page puts sub-topics 01 and 02 into code: a GDScript class that writes slots, a node that captures a camera at a fixed rate and labels each frame with its pose, and a Python class that hands you numpy arrays. At the end, OpenCV runs on the frames.

```
 Godot                                                       Python
 ─────────────────────────────────────────────               ─────────────────────────────
 SimBridge (priority -100) ─ newest pose ─┐
 vehicle placed in _process (priority 0) ─┤ t_sim, pose_seq
 CameraRig copies the mount (1000)        │
 FrameCapture._process (1001): tick due?  ┘ → UPDATE_ONCE
 ── render ──
 frame_post_draw → get_image → RGB8 → ShmFrameWriter ─▶ /dev/shm ─▶ ShmFrameReader.wait_next()
                                                                   → numpy (H, W, 3) → OpenCV
```

## ShmFrameWriter (GDScript)

[shm_frame_writer.gd](code/godot/cameras/shm_frame_writer.gd) is a `RefCounted` class with two methods that matter.

`open()` creates the file. It deletes an old one first (so a reader's old mapping stays valid, see sub-topic 02), sizes it with `FileAccess.resize()`, which fills it with zeros, and writes the file header:

```gdscript
func open(p_path: String, p_max_w: int, p_max_h: int, p_channels := 3, p_slots := 3) -> Error:
	...
	slot_bytes = SLOT_HEADER + max_w * max_h * channels
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(path)
	_f = FileAccess.open(path, FileAccess.WRITE_READ)
	if _f == null:
		return FileAccess.get_open_error()
	var err := _f.resize(FILE_HEADER + n_slots * slot_bytes)
	...   # magic, version, n_slots, slot_bytes, max_w, max_h, channels; then flush()
```

`write_frame()` is the seqlock writer from sub-topic 02, step by step:

```gdscript
	_published += 1                         # publish number k: slots are used strictly in turn
	var slot := _published % n_slots
	var base := FILE_HEADER + slot * slot_bytes
	_seq[slot] += 1                         # 1. odd: writing
	_f.seek(base)
	_f.store_32(_seq[slot] & 0xFFFFFFFF)
	_f.flush()
	... fill _hdr (width, height, channels, frame_id, t_sim, t_capture, pose_seq, ..., k)
	_f.seek(base + 4)
	_f.store_buffer(_hdr.slice(4))          # 2. header (without seq) and pixels
	_f.store_buffer(pixels)
	_f.flush()
	_seq[slot] += 1                         # 3. even: stable
	_f.seek(base)
	_f.store_32(_seq[slot] & 0xFFFFFFFF)
	_f.flush()
	_f.seek(32)                             # 4. announce: latest_pub = k
	_f.store_64(_published)
	_f.flush()
```

Four `flush()` calls per frame are four system calls: cheap. Measured mean time for the whole `write_frame()` on the reference machine, over several runs: 0.21–0.23 ms at 640×360 and 0.67–0.83 ms at 1280×720 (RGB8).

## FrameCapture: rate, timing and labels

[frame_capture.gd](code/godot/cameras/frame_capture.gd) owns a `ShmFrameWriter` and points at one `CameraRig`.

### Camera rate

The render loop runs at whatever rate the display or `Engine.max_fps` allows (60 in the lab). The camera has its own rate, 30 Hz by default (course convention). `_process` accumulates time and decides when a frame is due:

```gdscript
func _process(delta: float) -> void:
	_acc += delta
	var period := 1.0 / rate_hz
	if _acc < period:
		return
	var n := int(_acc / period)
	_acc -= n * period
	_tick += n
	skipped_ticks += n - 1          # the loop was too slow to serve every tick
	_pending = true
	_meta = {"frame_id": _tick, "t_sim": t_sim, "pose_seq": pose_seq}
	if on_demand:
		rig.viewport.render_target_update_mode = SubViewport.UPDATE_ONCE
```

Three design choices are hidden here:

| Choice | Why |
|---|---|
| `frame_id` = tick number, not a frame counter | if the render loop misses a tick, the id jumps by 2: the reader sees the drop |
| `on_demand = true`: the viewport is `DISABLED` and set to `UPDATE_ONCE` only when a frame is due | a 30 Hz camera then costs 30 renders per second, not 60 |
| `process_priority = 1001` | runs after the vehicle (0) and the rig (1000), so `t_sim`/`pose_seq` are this frame's |

With `on_demand`, a `TextureRect` showing that camera also updates only at the camera rate. Turn it off if you want a smooth on-screen preview, and accept the extra render cost.

The ticks use wall-clock time. That is right when physics runs in real time. In lock-step or faster-than-real-time runs (Module 5), trigger on sim time instead: capture when `t_sim` crosses the next multiple of `1/rate_hz` (a stretch goal in the lab).

### Reading after the draw

The pixels are read in the `frame_post_draw` handler (sub-topic 01), so the image and the `_meta` recorded in `_process` belong to the same frame:

```gdscript
func _on_frame_post_draw() -> void:
	if not _pending:
		return
	_pending = false
	var t0 := Time.get_ticks_usec()
	var img := rig.get_image()                       # GPU -> CPU
	var t1 := Time.get_ticks_usec()
	var t_capture := Time.get_unix_time_from_system()
	var fmt := Image.FORMAT_RGBA8 if rgba else Image.FORMAT_RGB8
	if img.get_format() != fmt:
		img.convert(fmt)
	var data := img.get_data()
	var t2 := Time.get_ticks_usec()
	writer.write_frame(_meta.frame_id, img.get_width(), img.get_height(), data,
			_meta.t_sim, _meta.pose_seq, t_capture, (t1 - t0) / 1000.0, (t2 - t1) / 1000.0)
	frame_ready.emit(_meta.frame_id, img, meta)      # for other outputs (UDP, recording)
```

`Time.get_unix_time_from_system()` returns Unix seconds with microsecond resolution, the same clock as Python's `time.time()`. That is what lets you subtract a Godot timestamp from a Python one on the same machine.

### Labelling frames with the pose

`FrameCapture` does not know where the pose came from. Whoever places the vehicle tells it. In [frame_lab.gd](code/godot/cameras/frame_lab.gd):

```gdscript
func _process(delta: float) -> void:
	if bridge.has_vehicle(VEHICLE_ID):
		vehicle.global_transform = bridge.latest_transform(VEHICLE_ID)
		capture.t_sim = bridge.latest_t_sim
		capture.pose_seq = bridge.latest_seq
```

This only works if the bridge reads this frame's packets **before** this code uses them. `SimBridge` takes care of that itself: it sets `process_priority = -100` in its `_ready()`. If it ran after the lab script, the vehicle would use last frame's pose (sub-topic 04 measures the difference).

If you place vehicles with Module 5's interpolation (`bridge.sample(id, t_render)`), set `capture.t_sim = t_render` and `pose_seq` to the seq of the newest pose used. The frame then shows an interpolated pose, and its `t_sim` says exactly which instant.

## ShmFrameReader (Python)

[frame_reader.py](code/tools/frame_reader.py) is both a library and a measuring tool. As a library:

```python
import sys; sys.path.insert(0, "tools")
from frame_reader import ShmFrameReader

rd = ShmFrameReader("/dev/shm/robosim_cam_fpv")    # waits up to 30 s for Godot
last = 0
while True:
    r = rd.wait_next(last)          # newest frame published after `last`, or None after 2 s
    if r is None:
        continue
    meta, rgb = r                   # rgb: numpy uint8 (H, W, 3), RGB, top row first
    last = meta["n_published"]
    print(meta["frame_id"], meta["t_sim"], meta["pose_seq"], rgb.shape)
```

`wait_next()` polls `latest_pub` every 0.5 ms. Polling costs a little CPU, but it is simple and adds at most 0.5 ms of latency. (A blocking alternative is a small UDP "frame ready" datagram from Godot; not needed here.)

It always returns the **newest** frame. If your processing is slower than the camera, you skip frames rather than fall behind. That is usually what a controller wants. If you need every frame (recording), keep up or use more slots.

## OpenCV

The array is RGB; OpenCV's conventions are BGR. Convert once at the boundary. [cv_red_box.py](code/tools/cv_red_box.py) finds the red board in every frame:

```python
meta, rgb = r
bgr = cv2.cvtColor(rgb[..., :3], cv2.COLOR_RGB2BGR)       # works for RGB and RGBA
hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
mask = cv2.inRange(hsv, (0, 200, 150), (5, 255, 255)) | cv2.inRange(hsv, (175, 200, 150), (180, 255, 255))
x, y, w, h = cv2.boundingRect(mask)
```

Reference output while the quad orbits (every 15th frame):

```
frame     64 t_sim    2.450 pose_seq    147 red box x=277 y=207 w=39 h=64
frame     79 t_sim    2.950 pose_seq    177 red box x=326 y=211 w=47 h=82
frame     94 t_sim    3.450 pose_seq    207 red box x=386 y=220 w=68 h=113
frame    109 t_sim    3.967 pose_seq    238 red box x=479 y=236 w=139 h=124
frame    124 t_sim    4.467 pose_seq    268 red box x=0 y=0 w=0 h=0
...
152 frames, OpenCV work 1.59 ms/frame
```

The board grows as the quad approaches and leaves the image as it turns away (`w = 0`). Every detection carries `t_sim` and `pose_seq`, so you can compare it with Module 6's ideal box for the same pose.

## Try it

- Start the reader before Godot, then start Godot. Stop Godot and start it again while the reader runs. Does the reader recover? (It should: watch `reopened`.)
- Set `rate_hz = 10` and then `rate_hz = 60` (with `Engine.max_fps = 60`). How many frames per second arrive, and how many ticks are skipped?
- Measure `wait_next()` latency with `poll_s = 0.0005` and `poll_s = 0.005`. How much CPU does the reader use in each case (`top`)?

## References

- Godot docs: [FileAccess](https://docs.godotengine.org/en/4.7/classes/class_fileaccess.html), [Time](https://docs.godotengine.org/en/4.7/classes/class_time.html), [SubViewport](https://docs.godotengine.org/en/4.7/classes/class_subviewport.html) (`UPDATE_ONCE`)
- Python docs: [mmap](https://docs.python.org/3/library/mmap.html); NumPy: [frombuffer](https://numpy.org/doc/stable/reference/generated/numpy.frombuffer.html)
- OpenCV docs: [Changing colour spaces](https://docs.opencv.org/4.x/df/d9d/tutorial_py_colorspaces.html)
