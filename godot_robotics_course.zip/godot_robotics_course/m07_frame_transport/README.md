# Module 7: RGB frame transport and measurement (8 h)

## What you will build

A video path from Godot to Python: the FPV camera's pixels are read back from the GPU, written into a ring of slots in shared memory (`/dev/shm`) with a header that carries `frame_id`, `t_sim` and `pose_seq`, and read in Python as numpy arrays ready for OpenCV. Then you measure it (delivered FPS, dropped frames, latency, bandwidth) at 640×360 and 1280×720, and record a short image sequence that can be matched pose by pose.

## Prerequisites

- [Module 6](../m06_cameras/README.md): `CameraRig`, `camera_lab.gd` (this module's lab scene extends it).
- Modules 4–5: the bridge (`SimBridge`, `PhysicsBridge`) and the [log format](../reference/logging.md).
- Linux for shared memory. On Windows/macOS use the UDP fallback in sub-topic 05.
- Python with `numpy` and `opencv-python`.

## Sub-topics

| File | Topic | Time |
|---|---|---:|
| [01_readback.md](01_readback.md) | `ViewportTexture.get_image()`, GPU→CPU readback and why it stalls, which frame you get, RGB8 vs RGBA8, `convert`, `get_data` | 1 h |
| [02_shared_memory_layout.md](02_shared_memory_layout.md) | `/dev/shm`, the slot layout and header, seqlock, double/triple buffering, reader races | 1.25 h |
| [03_writer_and_reader.md](03_writer_and_reader.md) | The GDScript writer and capture node, camera rate, the Python mmap/numpy reader, OpenCV | 1.25 h |
| [04_measuring.md](04_measuring.md) | Delivered FPS, dropped frames, end-to-end latency, bandwidth: definitions and method | 1 h |
| [05_fallback_and_recording.md](05_fallback_and_recording.md) | UDP chunks and ZeroMQ for Windows/macOS; saving an image sequence with `frames.csv` | 0.75 h |
| [lab.md](lab.md) | Writer + reader + recording + performance report | 2.75 h |

## Deliverables

- `godot/cameras/shm_frame_writer.gd`, `frame_capture.gd`, `frame_lab.gd/.tscn` (and `udp_frame_sender.gd` if you are not on Linux).
- `physics/sims/camera_orbit.py`, `tools/frame_reader.py`, `tools/check_frames.py`.
- One run folder with `pose.csv`, `frames/frames.csv` and the PNGs.
- `logs/frame_perf.csv` and a performance table for 640×360 and 1280×720 **measured on your machine**.

## Check

1. **Performance table.** For 640×360 and 1280×720 at a requested 30 Hz, a table with: delivered FPS, camera ticks, frames published, frames received, frames not rendered, frames missed by the reader, readback time (mean, p95), capture→read latency (p50, p95), pose→read latency (p50, p95), and bandwidth in MB/s. State GPU, driver and renderer.
2. **No transport losses.** `reader_missed = 0` and `torn_retries` small (reference: 0) at both resolutions while the reader only copies frames.
3. **Frames match poses.** `tools/check_frames.py <run>` reports every recorded frame matched to a pose in `pose.csv` with the same `t_sim` (reference: 91 of 91), and the median `t_sim` step between frames is 1/30 s (reference: 84 of 90 steps exactly 1/30 s).
4. **You can explain** any gap between requested and delivered FPS: which of "not rendered" (Godot too slow) and "reader missed" (Python too slow) it is.

Reference numbers (software rendering, **not** representative of a GPU) are in [04_measuring.md](04_measuring.md) and [lab.md](lab.md). Expect your GPU to be very different; that is why you measure.

## Common mistakes

- **Reading pixels in `_process`.** You get the previous frame's image and tag it with this frame's pose: one frame of hidden latency and a mismatched label. Read in `RenderingServer.frame_post_draw` (measured: 39 of 39 frames one frame stale in `_process`, 38 of 38 current in `frame_post_draw`).
- **Using the pose before the bridge has read it.** If your vehicle script runs before `SimBridge._process`, every frame uses last frame's pose. `SimBridge` prevents this by setting `process_priority = -100` in its `_ready()`; do not raise it above your scripts' priority. In back-to-back reference runs this lowered the median pose→read latency by 4–10 ms (35.2 → 24.7 ms and 32.2 → 28.5 ms).
- **A single shared buffer.** With one slot, a reader that held a frame for 50 ms would have read a torn frame every time (100 %); with three slots 1 %, with four 0 %. Copy first, process later, and always check the sequence counter before *and* after copying.
- **Forgetting `flush()`** on the Godot side. `FileAccess` buffers writes; without `flush()` the reader may see old or partial data, and the seqlock ordering is no longer guaranteed.
- **Choosing the slot by `frame_id`.** Camera ticks can be skipped, so `frame_id % n_slots` can reuse a slot after only two writes. Use a publish counter (our first version had this bug).
- **Reporting llvmpipe or laptop numbers as "the" numbers.** Readback cost depends on GPU, driver, renderer and resolution. Always state the hardware with the table.
