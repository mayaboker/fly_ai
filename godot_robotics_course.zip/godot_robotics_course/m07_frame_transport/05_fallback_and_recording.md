# 05 Cross-platform fallback and recording

Shared memory through `/dev/shm` is a Linux feature. On Windows and macOS, or when the consumer runs on another computer, frames must travel over a network socket instead. This page gives a UDP fallback that works everywhere, says when ZeroMQ is worth the extra setup, and then covers the other way to move frames: to disk, as an image sequence that later code can match pose by pose.

## Options

| Transport | Platforms | Extra install | Good for | Watch out for |
|---|---|---|---|---|
| Shared memory (`/dev/shm`) | Linux | none | full-size video, lowest latency | same machine only |
| **UDP chunks** (this page) | all | none (Godot `PacketPeerUDP`) | small images, or JPEG; other machines on a LAN | no retransmission: one lost chunk loses the frame |
| TCP stream (`StreamPeerTCP`) | all | none | reliable delivery | a lost packet delays every later frame (head-of-line blocking) |
| ZeroMQ | all | a GDExtension on the Godot side, `pyzmq` in Python | many consumers, queues, multi-machine | not built into Godot; not tested in this course |

The course supports shared memory and UDP. TCP and ZeroMQ are mentioned so you know they exist.

## UDP chunks

A UDP datagram can carry at most about 65 000 bytes, and a 640×360 RGB frame is 691 200 bytes. So the sender cuts each frame into chunks, each with a small header that says which frame and which piece it is:

| Offset | Field | Type |
|---:|---|---|
| 0 | magic `RF` | 2 bytes |
| 2 | version (1) | u8 |
| 3 | encoding: 0 = raw RGB8, 1 = JPEG | u8 |
| 4 | frame_id | u32 |
| 8 | chunk index | u16 |
| 10 | number of chunks | u16 |
| 12 | width, height | 2 × u16 |
| 16 | t_sim | f64 |
| 24 | t_capture_wall | f64 |
| 32 | pose_seq | u32 |
| 36 | total payload bytes | u32 |
| 40 | payload | up to `chunk_bytes` |

The same metadata as the shared-memory slot travels in every chunk, so a frame stays matchable to its pose. Python format: `"<2sBBIHHHHddII"`.

[udp_frame_sender.gd](code/godot/cameras/udp_frame_sender.gd) connects to `FrameCapture.frame_ready`, so it works next to or instead of shared memory:

```gdscript
var udp := UdpFrameSender.new()
udp.port = 9005
udp.jpeg = false                    # true: Image.save_jpg_to_buffer(quality)
add_child(udp)
capture.frame_ready.connect(udp.send_frame)
```

`chunk_bytes = 60000` suits the loopback interface. On a real network, use about 1400, so each chunk fits in one Ethernet frame. Larger datagrams are split by the IP layer, and losing any piece loses the whole datagram.

[udp_frame_receiver.py](code/tools/udp_frame_receiver.py) reassembles chunks per `frame_id`. When a chunk of a newer frame arrives before the current frame is complete, the incomplete frame is dropped and counted. It also raises the socket's receive buffer to 8 MB; with the default buffer (a few hundred KB on Linux), a burst of chunks from one large frame can overflow it.

### Reference results (loopback)

Same machine and caveats as sub-topic 04 (software rendering, 2 cores). Shadows off, shared memory disabled (`--shm=`), 8 s per row:

| Image | Encoding | FPS | Incomplete frames | Capture → receive p50 / p95 | Bandwidth |
|---|---|---:|---:|---:|---:|
| 320×180 | raw RGB8 | 30.3 | 0 | 0.5 / 0.7 ms | 5.2 MB/s |
| 640×360 | raw RGB8 | 30.2 | 0 | 1.6 / 3.0 ms | 20.9 MB/s |
| 640×360 | JPEG, quality 0.85 | 30.3 | 0 | 4.4 / 8.1 ms | 0.75 MB/s |
| 1280×720 | raw RGB8 | 29.3 | 0 | 5.9 / 7.5 ms | 81.1 MB/s |
| 1280×720 | JPEG, quality 0.85 | 23.9 | 0 | 17.3 / 30.5 ms | 1.75 MB/s |

What it shows:

- On loopback, raw UDP kept up even at 1280×720, with more latency than shared memory: p50 1.6 ms vs 1.0–1.1 ms at 640×360, and 5.9 ms vs 3.1–3.3 ms at 1280×720 (sub-topic 04).
- JPEG cuts bandwidth by about 28× at 640×360 and 46× at 1280×720, at the price of encode/decode time and lossy pixels. At 1280×720 the encoding in Godot's main thread slowed the render loop to 24 FPS on this machine.
- **Rule:** over a real network (Wi-Fi especially) send small raw images (320×180) or JPEG. Do not expect 80 MB/s of UDP to survive Wi-Fi.
- JPEG changes pixel values. Never run the Module 6 size check on JPEG frames with exact colour thresholds.

### ZeroMQ

ZeroMQ adds message framing, queues and patterns (publish/subscribe, request/reply) on top of TCP or IPC. It is a good choice when several programs on several machines consume the video. Godot has no built-in ZeroMQ; you need a third-party GDExtension or a small native helper. Python has `pyzmq`. This course does not test that path. If you build it, keep the same metadata (`frame_id, t_sim, pose_seq, t_capture_wall, width, height, encoding`) in a header frame, and measure it with the method of sub-topic 04.

## Recording an image sequence

For offline work (training data, debugging a detector, replaying a flight) save frames to disk. The [log format](../reference/logging.md) fixes the layout:

```
logs/20261001T063836Z_camera_orbit/
├── run.json
├── pose.csv              ← t_sim, t_wall, pose_seq, t_send_unix, x, y, z
└── frames/
    ├── frames.csv        ← frame_id, t_sim, pose_seq, t_capture_wall, width, height
    ├── 000113.png
    ├── 000114.png
    └── ...
```

File names are the `frame_id`, zero-padded to 6 digits so they sort correctly. `frames.csv` has exactly the columns the log format lists. `t_capture_wall` is Unix time.

`frame_reader.py --record --run-dir <run>` writes them. PNG encoding is slow compared with reading (measured with `cv2.imwrite`: 2.9 ms at 640×360, 11 ms at 1280×720), so it runs in a background thread with a bounded queue. If the queue fills, frames are not recorded and `record_queue_full` counts them:

```python
def recorder():                       # PNG encoding off the reading thread
    while True:
        item = rec_q.get()
        if item is None:
            break
        m, img = item
        cv2.imwrite(os.path.join(frames_dir, f"{m['frame_id']:06d}.png"),
                    cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
        w_csv.writerow([m["frame_id"], f"{m['t_sim']:.6f}", m["pose_seq"],
                        f"{m['t_capture_wall']:.6f}", m["width"], m["height"]])
```

Record in Python, not in Godot: Godot's `Image.save_png()` would run in the render loop and slow every frame.

### Proving the frames match the poses

[check_frames.py](code/tools/check_frames.py) joins `frames.csv` with `pose.csv` on `pose_seq` and checks that each frame's `t_sim` equals that pose's `t_sim`, and that each PNG exists with the right size. It also reports how evenly the frames are spaced in sim time. Reference run (640×360, no shadows, 3 s, machine lightly loaded):

```
91 frames, 91 matched to a pose with equal t_sim, 0 bad
t_sim step between frames: median 0.0333 s, min 0.0167 s, max 0.0500 s; 84 of 90 steps are exactly 1/30 s
```

```
frame_id,t_sim,pose_seq,t_capture_wall,width,height
110,4.133333,248,1790838346.234220,640,360
111,4.166667,250,1790838346.273089,640,360
112,4.200000,252,1790838346.307455,640,360
```

The pose stream is 60 Hz and the camera 30 Hz, so consecutive frames normally use every second pose (`pose_seq` 248, 250, 252). The 6 irregular steps (1/60 s or 1/20 s) happen because the camera ticks on the wall clock and takes whatever pose is newest; small timing jitter moves it by one pose. On the same machine under heavy load from other jobs, a second recording matched 72 of 72 frames but only 36 of 71 steps were 1/30 s, with steps from 0 s (two frames showing the same pose) up to 0.4 s (a stall). The labels were still correct, which is the point: **use each frame's `t_sim`, never assume `frame_id / 30`**. If you need evenly spaced sim times, trigger the camera on sim time (lab stretch goal). `pose.csv` logs the position (Godot frame); the orientation follows from it, because the quad's nose always points along the circle (`pose_enu()` in `camera_orbit.py`). With that pose and `T_body_cam` from the intrinsics JSON, you have the exact camera pose for every image: ground truth for visual odometry.

## Try it

- Run the lab with `--shm= --udp-port=9005` and `udp_frame_receiver.py` at 320×180. Then set `chunk_bytes = 1400`. How many chunks per frame now, and does anything get lost on loopback?
- Record 5 s at 1280×720. Is `record_queue_full` still 0? How many MB per second does the PNG sequence take on disk?
- Use `pose.csv` and `logs/intrinsics_fpv_640x360.json` to project the red board's centre into a recorded frame that shows the board (it is in view for about 5 s of each 20 s lap, around `t_sim` = 0–4.4 s, 20–24.4 s, ...). Does it land on the red pixels?

## References

- Godot docs: [PacketPeerUDP](https://docs.godotengine.org/en/4.7/classes/class_packetpeerudp.html), [Image.save_jpg_to_buffer](https://docs.godotengine.org/en/4.7/classes/class_image.html), [StreamPeerTCP](https://docs.godotengine.org/en/4.7/classes/class_streampeertcp.html)
- ZeroMQ guide: <https://zguide.zeromq.org/>; Python binding: `pyzmq`
- [Log format](../reference/logging.md)
