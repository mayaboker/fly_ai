# 01 Getting pixels: GPU → CPU readback

In Module 6 the camera images lived on the GPU, where Godot drew them. A vision algorithm in Python needs them in CPU memory, as bytes. Copying an image from the GPU back to the CPU is called **readback**. It is the most expensive and least predictable step of the whole video path, so it is worth understanding before you write any transport code.

## The call

```gdscript
var img: Image = rig.viewport.get_texture().get_image()
```

`get_texture()` returns a `ViewportTexture`, a handle to the GPU image. `get_image()` copies it into a new `Image` in CPU memory. One line; a lot happens behind it.

## Why readback stalls

Normally the CPU and GPU work in parallel, like a production line:

```
 time ─────────────────────────────────────────────────────▶
 CPU   │ prepare frame N │ prepare frame N+1 │ prepare N+2 │
 GPU                   │   draw frame N    │  draw N+1   │ ...
```

The CPU records drawing commands; the GPU executes them a little later. Neither waits for the other. `get_image()` breaks this:

```
 CPU   │ prepare N │ get_image() ── wait ────────┐ copy │ prepare N+1 │
 GPU             │   draw frame N              ──┘      │ (idle)      │ draw N+1
```

1. The CPU asks for the texture of frame N.
2. The driver must first **finish every queued command** that writes that texture: a synchronisation point. The CPU sits idle.
3. Then the pixels travel from GPU memory to CPU memory (over PCIe on a desktop: about 2.8 MB for 1280×720 RGBA8 at several GB/s, so roughly a millisecond; an estimate).
4. Meanwhile the GPU has nothing queued, so it idles too.

The cost is therefore not just the copy; it is the lost overlap. It grows with resolution and with how much work was queued in front of the copy. Measure it on your machine; do not guess.

Reference measurement (Compatibility renderer, Mesa llvmpipe, i.e. software rendering on a 2-core VM), time spent inside `get_image()`, range over 4 runs per size:

| Image | Mean | p95 |
|---|---:|---:|
| 640×360 | 1.2–1.3 ms | 1.6–1.8 ms |
| 1280×720 | 4.2–5.3 ms | 4.7–9.1 ms |

On llvmpipe the "GPU" is the CPU, so this is mostly a memory copy plus format work. On a real GPU expect a different number and more variation, because the wait for the GPU dominates.

### Avoiding the stall (advanced)

The Forward+ and Mobile renderers expose `RenderingDevice.texture_get_data_async(texture, layer, callback)`, which queues the copy and calls you back a frame or two later, without stopping the pipeline. That trades latency for throughput. We could not test it here (it needs the RenderingDevice renderers, and our test machine only had OpenGL), so the course uses the simple synchronous `get_image()`. If readback turns out to be your bottleneck, that is the next thing to try:

```gdscript
# Forward+/Mobile only. NOT tested in this course; check the docs for your Godot version.
var rd := RenderingServer.get_rendering_device()
var tex_rid := RenderingServer.texture_get_rd_texture(rig.viewport.get_texture().get_rid())
rd.texture_get_data_async(tex_rid, 0, func(data: PackedByteArray) -> void:
	pass)   # raw texture bytes; remember which frame you asked for
```

## Which frame do you get?

The order inside one Godot frame is:

```
 ┌─ one main-loop iteration ─────────────────────────────────────────────┐
 │ _physics_process (0..n times) → _process (all nodes, by priority)     │
 │ → render all viewports → RenderingServer.frame_post_draw signal       │
 └───────────────────────────────────────────────────────────────────────┘
```

If you set the vehicle pose in `_process` and call `get_image()` right there, the viewport has **not yet been drawn with that pose**. You get the image of the previous iteration. If you call it in a `frame_post_draw` handler, you get the image that was just drawn with this iteration's pose.

[capture_timing_test.gd](code/godot/cameras/capture_timing_test.gd) proves it. A red board jumps to a new, known x position every frame. The test reads the image both ways, finds the board in the pixels, and asks which frame's x it shows:

```
read in _process:          lag (frames) = { 1: 39 }
read in frame_post_draw:   lag (frames) = { 0: 38 }
```

Every image read in `_process` was exactly one frame old. Every image read in `frame_post_draw` was current. One frame is 16.7 ms at 60 FPS. That is a hidden latency, and worse, a wrong label: the frame would be tagged with a pose it does not show. `FrameCapture` therefore reads in `frame_post_draw`:

```gdscript
func _ready() -> void:
	RenderingServer.frame_post_draw.connect(_on_frame_post_draw)

func _on_frame_post_draw() -> void:
	if not _pending:
		return
	_pending = false
	var img := rig.get_image()          # this frame's pixels
```

## Pixel formats: RGBA8 vs RGB8

`get_image()` returned `Image.FORMAT_RGBA8` in our tests: 4 bytes per pixel, red-green-blue-alpha, rows from top to bottom. Alpha is 255 everywhere unless the viewport has `transparent_bg = true`. Most vision code wants 3 channels.

| Format | Bytes per pixel | 640×360 frame | 1280×720 frame |
|---|---:|---:|---:|
| `FORMAT_RGBA8` | 4 | 921 600 B | 3 686 400 B |
| `FORMAT_RGB8` | 3 | 691 200 B | 2 764 800 B |
| `FORMAT_L8` (grey) | 1 | 230 400 B | 921 600 B |

You can convert in Godot or in Python:

```gdscript
if img.get_format() != Image.FORMAT_RGB8:
	img.convert(Image.FORMAT_RGB8)        # in place; allocates a new buffer
var data: PackedByteArray = img.get_data()   # width * height * 3 bytes, row-major, top row first
```

```python
rgb = rgba[..., :3]                       # numpy view, no copy; cv2 accepts it
bgr = cv2.cvtColor(rgba, cv2.COLOR_RGBA2BGR)
```

Which is better depends on where your CPU time is cheaper. Measured on the reference machine at 1280×720, no shadows, two runs each (A / B; sub-topic 04 has the full table):

| Conversion | `convert` + `get_data` in Godot | Bandwidth | capture→read latency (p50) |
|---|---:|---:|---:|
| RGB8 (convert in Godot) | 1.73 / 2.41 ms | 79.9 / 58.9 MB/s | 3.08 / 3.25 ms |
| RGBA8 (send as is) | 0.01 / 0.01 ms | 108.3 / 104.5 MB/s | 1.84 / 1.95 ms |

Here sending RGBA was faster end to end, because converting cost more than copying 33 % more bytes through shared memory. Over a network the answer flips: bytes are expensive there. `FrameCapture` has an `rgba` switch so you can measure both.

Two details:

- `get_data()` returns a copy of the bytes as a `PackedByteArray`. That is one more copy of the frame; at 1280×720 it is part of the 1.7–2.4 ms above.
- Godot's `Image` rows are top to bottom, matching numpy and OpenCV. No vertical flip is needed (an OpenGL `glReadPixels` would give bottom-up rows; Godot handles that for you).

## Try it

- Run `capture_timing_test.tscn` on your machine. Do you get the same `{1: …}` and `{0: …}`? If your GPU driver queues frames, the `_process` lag could be larger; note what you see.
- Time `get_image()` with `Time.get_ticks_usec()` at 320×180, 640×360, 1280×720 and 1920×1080 on your GPU. Plot time against pixel count. Is it linear?
- Convert to `FORMAT_L8` (greyscale) and compare `convert` time and bytes with RGB8.

## References

- Godot docs: [ViewportTexture](https://docs.godotengine.org/en/4.7/classes/class_viewporttexture.html), [Image](https://docs.godotengine.org/en/4.7/classes/class_image.html) (`get_data`, `convert`, formats)
- Godot docs: [RenderingServer](https://docs.godotengine.org/en/4.7/classes/class_renderingserver.html) (`frame_post_draw`), [RenderingDevice](https://docs.godotengine.org/en/4.7/classes/class_renderingdevice.html) (`texture_get_data_async`)
