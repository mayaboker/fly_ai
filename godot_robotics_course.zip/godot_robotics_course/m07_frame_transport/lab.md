# Lab 7: Shared-memory video, a recording and a performance report (2.75 h)

You will stream the quad's FPV camera from Godot into Python through shared memory, prove that each frame can be matched to the pose it shows, record a short sequence in the course log format, and measure the pipeline at 640×360 and 1280×720 on your own machine.

## Files

| robosim path | Status | From |
|---|---|---|
| `godot/cameras/shm_frame_writer.gd` | new | [code/godot/cameras/](code/godot/cameras/shm_frame_writer.gd) |
| `godot/cameras/frame_capture.gd` | new | [code/godot/cameras/](code/godot/cameras/frame_capture.gd) |
| `godot/cameras/frame_lab.gd`, `frame_lab.tscn` | new (extends Module 6's `camera_lab.gd`) | [code/godot/cameras/](code/godot/cameras/frame_lab.gd) |
| `godot/cameras/capture_timing_test.gd`, `.tscn` | new (test) | [code/godot/cameras/](code/godot/cameras/capture_timing_test.gd) |
| `godot/cameras/udp_frame_sender.gd` | new (fallback) | [code/godot/cameras/](code/godot/cameras/udp_frame_sender.gd) |
| `physics/sims/camera_orbit.py` | new | [code/physics/sims/](code/physics/sims/camera_orbit.py) |
| `tools/frame_reader.py`, `check_frames.py`, `torn_demo.py`, `cv_red_box.py`, `udp_frame_receiver.py`, `run_frame_perf.sh` | new | [code/tools/](code/tools/frame_reader.py) |
| `godot/bridge/*`, `physics/robosim/*` | unchanged | Module 4/5 |

Write `shm_frame_writer.gd` and the `read()` method of the reader yourself from sub-topic 02 before you look at the reference. They are short, and the ordering details are the point of the module.

## Step 1: Copy and import

From `robosim/`:

```bash
cp <course>/m07_frame_transport/code/godot/cameras/* godot/cameras/
cp <course>/m07_frame_transport/code/physics/sims/camera_orbit.py physics/sims/
cp <course>/m07_frame_transport/code/tools/* tools/
chmod +x tools/run_frame_perf.sh
godot --headless --path godot --import          # registers ShmFrameWriter, FrameCapture, UdpFrameSender
```

## Step 2: Which frame does `get_image()` return?

```bash
godot --path godot res://cameras/capture_timing_test.tscn
```

Expected (reference):

```
read in _process:          lag (frames) = { 1: 39 }
read in frame_post_draw:   lag (frames) = { 0: 38 }
```

Write down your result. If your `_process` lag is larger than 1, your driver queues frames; `FrameCapture` is still correct because it reads in `frame_post_draw`.

## Step 3: Run the three processes by hand

Use three terminals in `robosim/`, all with the venv active.

```bash
# terminal 1: the viewer, FPV camera at 640x360 / 30 Hz into /dev/shm/robosim_cam_fpv
godot --path godot res://cameras/frame_lab.tscn

# terminal 2: the "physics" process: quad flying a 6 m circle at 3 m, poses at 60 Hz
python physics/sims/camera_orbit.py --seconds 60

# terminal 3: the reader, 10 s of measurement
python tools/frame_reader.py --seconds 10 --run-dir logs/<the run dir printed by terminal 2>
```

While it runs, check the shared file:

```bash
ls -l /dev/shm/robosim_cam_fpv        # 2073856 bytes = 64 + 3 * (64 + 640*360*3)
```

The reader prints a summary like this (reference machine, 15 s run, software rendering, default scene with shadows):

```
label                    640x360
ticks                    451
published                296
received                 296
not_rendered             155
reader_missed            0
fps                      19.7
MB_per_s                 13.6
readback_ms_mean         1.2
...
pose_to_read_ms_p50      54.9
pose_to_read_ms_p95      85.4
torn_retries             0
```

Close the Godot window to stop it.

## Step 4: Record a short sequence and check it

`run_frame_perf.sh` starts all three processes for you. With `RECORD=1` the reader also saves PNGs and `frames.csv` into the run folder:

```bash
RECORD=1 tools/run_frame_perf.sh 640x360 3
python tools/check_frames.py logs/<newest>_camera_orbit
```

Expected:

```
91 frames, 91 matched to a pose with equal t_sim, 0 bad
t_sim step between frames: median 0.0333 s, min 0.0167 s, max 0.0500 s; 84 of 90 steps are exactly 1/30 s
```

(Your frame count depends on your delivered FPS. If many steps are not 1/30 s, your machine was busy; sub-topic 05 explains why the labels are still right.) Open a few PNGs: the quad circles and the red board drifts across the view.

## Step 5: The performance report

Run each configuration for 15 s:

```bash
tools/run_frame_perf.sh 640x360 15
tools/run_frame_perf.sh 1280x720 15
tools/run_frame_perf.sh 640x360 15 --shadows=false
tools/run_frame_perf.sh 1280x720 15 --shadows=false
tools/run_frame_perf.sh 1280x720 15 --shadows=false --rgba
```

Each run appends a row to `logs/frame_perf.csv` and prints Godot's own timing (`GODOT_STATS`). Environment variables: `GODOT` (command to start Godot), `PY` (Python), `LISTEN_PORT`, `PHYSICS_PORT`, `SHM`, `RECORD`.

Build your table in the format of [04_measuring.md](04_measuring.md). Start it with one line describing the machine: CPU, GPU, driver, OS, renderer (*Project Settings → Rendering → Renderer*), window visible or not.

Reference table, for comparison only (run B of [04_measuring.md](04_measuring.md), made with exactly the code in `code/`). It was measured on a 2-core VM **without a GPU** (Mesa llvmpipe software rendering, Compatibility renderer, under Xvfb), shared with other jobs. **These are software-rendering numbers. Your GPU numbers will differ; re-measure.**

| | 640×360 | 1280×720 | 640×360 no shadows | 1280×720 no shadows |
|---|---:|---:|---:|---:|
| Delivered FPS (30 requested) | 19.7 | 9.1 | 30.0 | 21.3 |
| Ticks / published / received | 451 / 296 / 296 | 451 / 138 / 138 | 451 / 451 / 451 | 442 / 321 / 321 |
| Not rendered / missed by reader | 155 / 0 | 313 / 0 | 0 / 0 | 121 / 0 |
| Readback mean / p95 (ms) | 1.20 / 1.63 | 4.18 / 4.72 | 1.25 / 1.74 | 5.32 / 9.14 |
| Capture → read p50 / p95 (ms) | 1.08 / 2.09 | 3.14 / 4.52 | 1.14 / 2.36 | 3.25 / 8.30 |
| Pose → read p50 / p95 (ms) | 54.9 / 85.4 | 119.9 / 137.2 | 23.8 / 33.6 | 44.0 / 92.2 |
| Bandwidth (MB/s) | 13.6 | 25.2 | 20.7 | 58.9 |

Then answer in 3–5 sentences: is your bottleneck rendering (`not_rendered > 0`) or reading (`reader_missed > 0`)? What is your pose → read latency at 30 Hz, and how many control periods of a 50 Hz controller is that?

## Step 6: See the seqlock work

Start Godot with one slot, then with three, and run the slow reader against each:

```bash
godot --path godot res://cameras/frame_lab.tscn -- --slots=1 --shadows=false &
python tools/torn_demo.py --seconds 8 --hold-ms 50
# close Godot, then the same with --slots=3
```

Reference: 1 slot → 100 % of slow reads would have been torn; 2 slots → 52 %; 3 slots → 1 %; 4 slots → 0 %. Sub-topic 02 explains why 3 slots do not fully cover a 50 ms hold.

## Step 7: OpenCV on live frames

With Godot and `camera_orbit.py` running:

```bash
python tools/cv_red_box.py --seconds 25
```

You get the red board's box with `t_sim` and `pose_seq` every 15 frames, and the OpenCV time per frame (reference: 1.59 ms at 640×360). The board is in view only for about 5 s of each 20 s lap (around `t_sim` = 0–4.4 s, 19.5–24.4 s, ...); the rest of the time the box is `w=0 h=0`, which is correct. That is why the run is 25 s long.

## Step 8 (Windows/macOS): UDP fallback

If you are not on Linux, `/dev/shm` does not exist; disable shared memory and send UDP instead:

```bash
godot --path godot res://cameras/frame_lab.tscn -- --size=320x180 --shm= --udp-port=9005
python tools/udp_frame_receiver.py --port 9005 --seconds 10
```

Then try `--size=640x360 --jpeg`. Fill the same performance table from the receiver's output (sub-topic 05).

## Check

- [ ] Performance table for 640×360 and 1280×720 at 30 Hz, from **your** machine, with: delivered FPS, ticks, published, received, not rendered, missed by reader, readback mean/p95, capture → read p50/p95, pose → read p50/p95, MB/s, and the hardware line.
- [ ] `reader_missed = 0` at both resolutions (the transport loses nothing while the reader only copies).
- [ ] `check_frames.py` reports every recorded frame matched to a pose with equal `t_sim`, and a median `t_sim` step of 1/30 s.
- [ ] `frames/frames.csv` has exactly the columns `frame_id, t_sim, pose_seq, t_capture_wall, width, height`.
- [ ] Your bottleneck statement (Step 5) names the cause of every missing frame.

## Stretch goals

- **Sim-time triggering.** Change `FrameCapture` to capture when `t_sim` crosses the next multiple of `1/rate_hz` instead of using wall-clock ticks. Run the physics at half real time; you should still get one frame per 1/30 s of *sim* time.
- **Grayscale.** Add a `FORMAT_L8` option (1 byte per pixel). How do readback, convert and bandwidth change?
- **Async readback.** On Forward+ or Mobile, replace `get_image()` with `RenderingDevice.texture_get_data_async()` (sub-topic 01). Measure delivered FPS and pose → read latency. What did you trade?
- **Two cameras.** Publish the downward camera too, to `/dev/shm/robosim_cam_down`, and read both in one Python process. Do frames from the two cameras with the same `frame_id` have the same `t_sim`?
- **Ground truth per frame.** Add the Module 6 `TargetBox` result to the slot header (4 floats in the reserved bytes would not fit; bump the format to version 2 with a 96-byte slot header) and compare it with `cv_red_box.py` frame by frame.
