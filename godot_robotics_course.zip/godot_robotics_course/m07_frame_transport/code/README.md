# Module 7 reference code

Copy into `robosim/` (paths mirror it). Module 6's `godot/cameras/` files must already be there: `frame_lab.gd` extends `camera_lab.gd` and uses `CameraRig`.

| File | What it is |
|---|---|
| `godot/cameras/shm_frame_writer.gd` | `ShmFrameWriter`: slot ring in `/dev/shm` with a seqlock per slot (layout in the file's header comment and in sub-topic 02) |
| `godot/cameras/frame_capture.gd` | `FrameCapture`: camera rate, on-demand rendering, readback in `frame_post_draw`, RGB8/RGBA8, timing stats, `frame_ready` signal |
| `godot/cameras/udp_frame_sender.gd` | `UdpFrameSender`: cross-platform fallback, chunked UDP, raw or JPEG |
| `godot/cameras/frame_lab.gd` + `.tscn` | lab scene: Module 6 world + bridge-driven quad + FPV capture; options after `--` |
| `godot/cameras/capture_timing_test.gd` + `.tscn` | shows which frame `get_image()` returns in `_process` vs `frame_post_draw` |
| `physics/sims/camera_orbit.py` | pose source: quad on a 6 m circle, 240 Hz step, 60 Hz poses, `pose.csv` with `pose_seq` and `t_send_unix` |
| `tools/frame_reader.py` | `ShmFrameReader` library + measuring/recording command line |
| `tools/run_frame_perf.sh` | runs Godot + pose source + reader for one configuration, appends to `logs/frame_perf.csv` |
| `tools/check_frames.py` | checks a recording: every frame matched to its pose; sim-time spacing |
| `tools/torn_demo.py` | slow reader that counts how often the seqlock would reject a read |
| `tools/cv_red_box.py` | OpenCV on live frames: red board box per frame with `t_sim`/`pose_seq` |
| `tools/udp_frame_receiver.py` | receiver and statistics for the UDP fallback |

## How to run

From `robosim/`, venv active, after copying and `godot --headless --path godot --import`:

```bash
godot --path godot res://cameras/capture_timing_test.tscn          # prints the two lag histograms
tools/run_frame_perf.sh 640x360 15                                  # one measured configuration
tools/run_frame_perf.sh 1280x720 15
RECORD=1 tools/run_frame_perf.sh 640x360 3 && python tools/check_frames.py logs/<newest run>
```

Or by hand: `godot --path godot res://cameras/frame_lab.tscn`, `python physics/sims/camera_orbit.py`, `python tools/frame_reader.py --run-dir logs/<run>` (see lab.md).

Without a display: `GODOT="xvfb-run -a -s '-screen 0 1280x720x24' godot --rendering-driver opengl3" tools/run_frame_perf.sh ...`. If your Python is called `python3`, set `PY=python3`.

## What was verified

Godot 4.7.2-stable (official Linux build), Python 3.11.15, numpy 2.4.4, OpenCV 4.13, on a 2-core Xeon VM **without a GPU**: Compatibility renderer on Mesa llvmpipe 25.2.8 (software) under Xvfb, with other jobs sharing the VM. Tests used ports 9170/9171 (the course text uses 9001/9002) and a UDP frame port of 9172 (the course text uses 9005). Final runs were made from a clean `robosim/` built only from the reference code and the Module 6 and 7 `code/` folders.

| Test | Result |
|---|---|
| `capture_timing_test.tscn` | `_process`: 39 of 39 frames one frame stale; `frame_post_draw`: 38 of 38 current |
| Full pipeline, 640×360 and 1280×720, shadows on/off, RGB8 and RGBA8 (2 runs each) | 0 frames missed by the reader, 0 torn copies; numbers in `04_measuring.md` |
| `RECORD=1` + `check_frames.py` | 91 of 91 frames matched to their pose (light load); 72 of 72 under heavy load |
| `torn_demo.py`, 50 ms hold | 1 slot 100 %, 2 slots 52 %, 3 slots 1 %, 4 slots 0 % of reads would have been torn |
| Reader started before Godot, Godot restarted while reading | reader waited, then re-mapped the new file (`reopened = 1`) and continued |
| `cv_red_box.py` | ran on live frames; 1.6–1.7 ms of OpenCV work per 640×360 frame |
| UDP fallback 320×180 … 1280×720, raw and JPEG | 0 incomplete frames on loopback; table in sub-topic 05 |
| Shared file size, 640×360, 3 slots | 2 073 856 bytes as computed |
| GDScript warnings | none printed |

## Not tested here

- **Any real GPU**, and the Forward+/Mobile renderers. All performance numbers are software-rendering numbers. The student must re-measure.
- `RenderingDevice.texture_get_data_async()` (mentioned in sub-topic 01): needs Forward+/Mobile.
- **Windows and macOS.** The UDP fallback uses only `PacketPeerUDP` and Python sockets and should work there, but it was tested on Linux loopback only. Shared memory is Linux-only by design.
- ZeroMQ and TCP transports (described, not implemented).
- UDP over a real network or Wi-Fi.
- `frame_reader.py --show` (OpenCV window): the test machine had no display; the code path is a plain `cv2.imshow`.
