"""
udp_frame_receiver.py - Module 7 fallback reader for godot/cameras/udp_frame_sender.gd.

    python tools/udp_frame_receiver.py --port 9005 --seconds 10 [--show]

Reassembles chunks into frames; a frame with a missing chunk is dropped (UDP gives no
retransmission). Prints delivered FPS, incomplete frames, capture->receive latency, bandwidth.
"""
import argparse, socket, struct, time
import numpy as np

HDR = struct.Struct("<2sBBIHHHHddII")       # 40 bytes, see udp_frame_sender.gd


def frames(sock):
    """Generator of (meta, rgb ndarray) for complete frames."""
    import cv2
    parts, cur = {}, None
    while True:
        data = sock.recv(65536)
        magic, ver, enc, fid, chunk, n, w, h, t_sim, t_cap, pose_seq, total = HDR.unpack_from(data)
        if magic != b"RF" or ver != 1:
            continue
        if cur is not None and fid != cur:
            if fid < cur:
                continue                    # late chunk of an older frame
            yield None                      # previous frame never completed
            parts = {}
        cur = fid
        parts[chunk] = data[HDR.size:]
        if len(parts) == n:
            buf = b"".join(parts[i] for i in range(n))
            if enc == 1:
                img = cv2.cvtColor(cv2.imdecode(np.frombuffer(buf, np.uint8), cv2.IMREAD_COLOR), cv2.COLOR_BGR2RGB)
            else:
                img = np.frombuffer(buf, np.uint8).reshape(h, w, 3)
            yield dict(frame_id=fid, t_sim=t_sim, t_capture_wall=t_cap, pose_seq=pose_seq,
                       width=w, height=h, bytes=total, t_recv=time.time()), img
            parts, cur = {}, None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=9005)
    ap.add_argument("--seconds", type=float, default=10.0)
    ap.add_argument("--show", action="store_true")
    a = ap.parse_args()
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 8 * 1024 * 1024)
    s.bind(("127.0.0.1", a.port))
    s.settimeout(5.0)
    got, incomplete, lat, nbytes, ids = 0, 0, [], 0, []
    t0 = None
    for r in frames(s):
        if r is None:
            incomplete += 1
            continue
        m, img = r
        t0 = t0 or time.monotonic()
        got += 1
        ids.append(m["frame_id"])
        lat.append((m["t_recv"] - m["t_capture_wall"]) * 1000)
        nbytes += m["bytes"]
        if a.show:
            import cv2
            cv2.imshow("udp", cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
            cv2.waitKey(1)
        if time.monotonic() - t0 > a.seconds:
            break
    span = time.monotonic() - t0
    print(f"frames {got}, incomplete {incomplete}, id gaps {ids[-1] - ids[0] + 1 - got}, "
          f"fps {got / span:.1f}, latency p50 {np.percentile(lat, 50):.1f} ms p95 {np.percentile(lat, 95):.1f} ms, "
          f"{nbytes / span / 1e6:.2f} MB/s, last image {img.shape}")


if __name__ == "__main__":
    main()
