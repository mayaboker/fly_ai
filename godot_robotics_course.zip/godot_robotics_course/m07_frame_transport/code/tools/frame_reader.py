"""
frame_reader.py - Module 7: read camera frames that Godot writes to /dev/shm.

Library use:
    from frame_reader import ShmFrameReader
    rd = ShmFrameReader("/dev/shm/robosim_cam_fpv")
    meta, rgb = rd.wait_next()          # rgb: numpy (H, W, 3) uint8, RGB order, top row first
    meta, rgb = rd.wait_next(meta["n_published"])    # the next newer one

Command line (measure, optionally record and show):
    python tools/frame_reader.py --seconds 10 --run-dir logs/<run>  [--record] [--show]
        --run-dir  a run folder with pose.csv (from sims/camera_orbit.py): enables pose->frame
                   latency and puts recordings in <run>/frames/
        --record   save <frame_id>.png + frames.csv (logging.md format) in <run>/frames/
        --report   CSV file that gets one summary row per run (default logs/frame_perf.csv)

Layout: see godot/cameras/shm_frame_writer.gd (same offsets as the structs below).
"""
import argparse, csv, mmap, os, queue, struct, sys, threading, time
import numpy as np

FILE_HDR = struct.Struct("<4sIIIIIII")     # magic, version, n_slots, slot_bytes, max_w, max_h, channels, reserved
LATEST = struct.Struct("<Q")               # latest_pub, at offset 32
SLOT_HDR = struct.Struct("<IIIIQddIIffI")  # seq, w, h, c, frame_id, t_sim, t_capture, pose_seq, data_bytes,
                                           # readback_ms, convert_ms, n_published
FILE_HEADER, SLOT_HEADER = 64, 64


class ShmFrameReader:
    def __init__(self, path="/dev/shm/robosim_cam_fpv", wait_s=30.0, poll_s=0.0005):
        self.path, self.poll_s = path, poll_s
        self.torn = 0          # copies thrown away because the writer was inside the slot
        self.reopened = 0
        t0 = time.monotonic()
        while not self._open():
            if time.monotonic() - t0 > wait_s:
                raise TimeoutError(f"no frame file at {path} (is Godot running?)")
            time.sleep(0.1)

    def _open(self):
        try:
            fd = os.open(self.path, os.O_RDONLY)
        except FileNotFoundError:
            return False
        try:
            st = os.fstat(fd)
            if st.st_size < FILE_HEADER:
                return False
            mm = mmap.mmap(fd, st.st_size, prot=mmap.PROT_READ)
        finally:
            os.close(fd)                       # the mapping stays valid after close
        magic, ver, n, slot_bytes, mw, mh, ch, _ = FILE_HDR.unpack_from(mm, 0)
        if magic != b"RSFB" or ver != 1 or st.st_size < FILE_HEADER + n * slot_bytes:
            mm.close()
            return False
        self.mm, self.ino = mm, st.st_ino
        self.n_slots, self.slot_bytes, self.channels = n, slot_bytes, ch
        return True

    def latest_pub(self):
        """Publish number of the newest complete frame (0 = none yet)."""
        return LATEST.unpack_from(self.mm, 32)[0]

    def _seq(self, base):
        return struct.unpack_from("<I", self.mm, base)[0]

    def read(self, pub, retries=3):
        """Copy the frame with publish number `pub` out of its slot. None if already overwritten."""
        base = FILE_HEADER + (pub % self.n_slots) * self.slot_bytes
        for _ in range(retries):
            s1 = self._seq(base)
            if s1 & 1:                         # writer is inside this slot right now
                self.torn += 1
                time.sleep(0.0002)
                continue
            seq, w, h, c, fid, t_sim, t_cap, pose_seq, nbytes, rb_ms, cv_ms, n_pub = SLOT_HDR.unpack_from(self.mm, base)
            if n_pub != (pub & 0xFFFFFFFF):
                return None                    # slot already holds a newer frame
            img = np.frombuffer(self.mm, np.uint8, nbytes, base + SLOT_HEADER).reshape(h, w, c).copy()
            if self._seq(base) == s1:          # nobody wrote while we copied: consistent
                return dict(frame_id=fid, t_sim=t_sim, pose_seq=pose_seq, t_capture_wall=t_cap,
                            width=w, height=h, channels=c, readback_ms=rb_ms, convert_ms=cv_ms,
                            n_published=n_pub), img
            self.torn += 1
        return None

    def wait_next(self, last_pub=0, timeout=2.0):
        """Block until a frame newer than publish number last_pub exists (pass the previous
        meta["n_published"]); return (meta, image) of the NEWEST one, or None on timeout."""
        t0 = time.monotonic()
        while True:
            pub = self.latest_pub()
            if pub > last_pub:
                r = self.read(pub)
                if r:
                    return r
            elif pub < last_pub or (time.monotonic() - t0 > 0.5 and self._replaced()):
                self._reopen()                 # Godot restarted: new file
                last_pub = 0
            if time.monotonic() - t0 > timeout:
                return None
            time.sleep(self.poll_s)

    def _replaced(self):
        try:
            return os.stat(self.path).st_ino != self.ino
        except FileNotFoundError:
            return False

    def _reopen(self):
        old = self.mm
        if self._open():
            old.close()
            self.reopened += 1


def load_pose_send_times(run_dir):
    """pose_seq -> Unix send time, from pose.csv written by sims/camera_orbit.py."""
    out = {}
    p = os.path.join(run_dir, "pose.csv")
    if os.path.exists(p):
        for row in csv.DictReader(open(p)):
            out[int(row["pose_seq"])] = float(row["t_send_unix"])
    return out


def pct(a, q):
    return float(np.percentile(a, q)) if len(a) else float("nan")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--shm", default="/dev/shm/robosim_cam_fpv")
    ap.add_argument("--seconds", type=float, default=10.0)
    ap.add_argument("--warmup", type=float, default=1.0, help="ignore the first seconds")
    ap.add_argument("--run-dir", default="")
    ap.add_argument("--record", action="store_true")
    ap.add_argument("--show", action="store_true")
    ap.add_argument("--label", default="")
    ap.add_argument("--report", default="")
    a = ap.parse_args()

    rd = ShmFrameReader(a.shm)
    rec_q, rec_thread, frames_dir = None, None, None
    if a.record:
        import cv2
        frames_dir = os.path.join(a.run_dir or ".", "frames")
        os.makedirs(frames_dir, exist_ok=True)
        rec_q = queue.Queue(maxsize=256)
        f_csv = open(os.path.join(frames_dir, "frames.csv"), "w", newline="")
        w_csv = csv.writer(f_csv)
        w_csv.writerow(["frame_id", "t_sim", "pose_seq", "t_capture_wall", "width", "height"])

        def recorder():                       # PNG encoding off the reading thread
            while True:
                item = rec_q.get()
                if item is None:
                    break
                m, img = item
                cv2.imwrite(os.path.join(frames_dir, f"{m['frame_id']:06d}.png"),
                            cv2.cvtColor(img, cv2.COLOR_RGB2BGR if img.shape[2] == 3 else cv2.COLOR_RGBA2BGRA))
                w_csv.writerow([m["frame_id"], f"{m['t_sim']:.6f}", m["pose_seq"],
                                f"{m['t_capture_wall']:.6f}", m["width"], m["height"]])
        rec_thread = threading.Thread(target=recorder, daemon=True)
        rec_thread.start()
    if a.show:
        import cv2

    rows, last, rec_dropped = [], 0, 0
    t_start = time.monotonic()
    while time.monotonic() - t_start < a.seconds + a.warmup:
        r = rd.wait_next(last)
        if r is None:
            continue
        t_read = time.time()
        meta, img = r
        last = meta["n_published"]
        if time.monotonic() - t_start < a.warmup:
            continue
        rows.append((meta["frame_id"], meta["t_sim"], meta["pose_seq"], meta["t_capture_wall"], t_read,
                     meta["readback_ms"], meta["convert_ms"], img.nbytes, meta["n_published"]))
        if rec_q is not None:
            try:
                rec_q.put_nowait((meta, img))
            except queue.Full:
                rec_dropped += 1
        if a.show:
            cv2.imshow("fpv", cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
            if cv2.waitKey(1) == 27:
                break
    if rec_q is not None:
        rec_q.put(None)
        rec_thread.join()
        f_csv.close()
    if len(rows) < 2:
        print("too few frames received")
        sys.exit(1)

    A = np.array(rows, dtype=float)
    fid, t_cap, t_read, rb, cv, nbytes, npub = A[:, 0], A[:, 3], A[:, 4], A[:, 5], A[:, 6], A[:, 7], A[:, 8]
    span = t_read[-1] - t_read[0]
    fps = (len(rows) - 1) / span
    expected = int(fid[-1] - fid[0] + 1)           # camera ticks in the window
    published = int(npub[-1] - npub[0] + 1)        # frames Godot actually wrote
    not_rendered = expected - published            # Godot's loop was slower than the camera rate
    reader_missed = published - len(rows)          # written, but overwritten before we read it
    lat_cap = (t_read - t_cap) * 1000
    sends = load_pose_send_times(a.run_dir) if a.run_dir else {}
    lat_pose = np.array([(r[4] - sends[int(r[2])]) * 1000 for r in rows if int(r[2]) in sends])
    mbps = fps * nbytes.mean() / 1e6
    summary = {
        "label": a.label or f"{int(A[0, 7])}B",
        "ticks": expected, "published": published, "received": len(rows),
        "not_rendered": not_rendered, "reader_missed": reader_missed,
        "fps": round(fps, 2), "MB_per_s": round(mbps, 1),
        "readback_ms_mean": round(rb.mean(), 2), "readback_ms_p95": round(pct(rb, 95), 2),
        "convert_ms_mean": round(cv.mean(), 2),
        "capture_to_read_ms_p50": round(pct(lat_cap, 50), 2), "capture_to_read_ms_p95": round(pct(lat_cap, 95), 2),
        "pose_to_read_ms_p50": round(pct(lat_pose, 50), 1), "pose_to_read_ms_p95": round(pct(lat_pose, 95), 1),
        "torn_retries": rd.torn, "record_queue_full": rec_dropped,
    }
    for k, v in summary.items():
        print(f"{k:24s} {v}")
    report = a.report or os.path.join(os.path.dirname(a.run_dir.rstrip("/")) if a.run_dir else ".", "frame_perf.csv")
    new = not os.path.exists(report)
    with open(report, "a", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(summary.keys()))
        if new:
            wr.writeheader()
        wr.writerow(summary)
    print("appended to", report)


if __name__ == "__main__":
    main()
