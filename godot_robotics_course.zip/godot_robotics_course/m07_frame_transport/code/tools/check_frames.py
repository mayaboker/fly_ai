"""
check_frames.py - Module 7 check: every recorded frame can be matched to its pose.

    python tools/check_frames.py logs/<run>

For each row of <run>/frames/frames.csv: the PNG exists with the right size, its pose_seq
is in <run>/pose.csv, and the t_sim stored with the frame equals that pose's t_sim.
It also prints how evenly the frames are spaced in sim time (wall-clock camera ticks
sample whatever pose is newest, so under load the spacing becomes irregular).
"""
import csv, os, sys
import cv2

run = sys.argv[1]
poses = {int(r["pose_seq"]): r for r in csv.DictReader(open(os.path.join(run, "pose.csv")))}
frames = list(csv.DictReader(open(os.path.join(run, "frames", "frames.csv"))))
bad = 0
for f in frames:
    img = cv2.imread(os.path.join(run, "frames", f"{int(f['frame_id']):06d}.png"))
    p = poses.get(int(f["pose_seq"]))
    ok = (img is not None and img.shape[1] == int(f["width"]) and img.shape[0] == int(f["height"])
          and p is not None and abs(float(p["t_sim"]) - float(f["t_sim"])) < 1e-5)
    bad += not ok
dt = sorted(float(b["t_sim"]) - float(a["t_sim"]) for a, b in zip(frames, frames[1:]))
on_rate = sum(1 for d in dt if abs(d - 1 / 30) < 1e-4)
print(f"{len(frames)} frames, {len(frames) - bad} matched to a pose with equal t_sim, {bad} bad")
print(f"t_sim step between frames: median {dt[len(dt) // 2]:.4f} s, min {dt[0]:.4f} s, max {dt[-1]:.4f} s; "
      f"{on_rate} of {len(dt)} steps are exactly 1/30 s")
sys.exit(1 if bad or not frames else 0)
