"""
cv_red_box.py - Module 7: OpenCV on frames straight from shared memory.
Finds the red target board in every frame and prints its box with the frame's t_sim.

    python tools/cv_red_box.py [--shm /dev/shm/robosim_cam_fpv] [--seconds 5]
"""
import argparse, time
import cv2
import numpy as np
from frame_reader import ShmFrameReader

ap = argparse.ArgumentParser()
ap.add_argument("--shm", default="/dev/shm/robosim_cam_fpv")
ap.add_argument("--seconds", type=float, default=5.0)
a = ap.parse_args()

rd = ShmFrameReader(a.shm)
last, t0, n, ms = 0, time.monotonic(), 0, []
while time.monotonic() - t0 < a.seconds:
    r = rd.wait_next(last)
    if r is None:
        continue
    meta, rgb = r
    last = meta["n_published"]
    t = time.perf_counter()
    bgr = cv2.cvtColor(rgb[..., :3], cv2.COLOR_RGB2BGR)          # OpenCV wants BGR
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, (0, 200, 150), (5, 255, 255)) | cv2.inRange(hsv, (175, 200, 150), (180, 255, 255))
    x, y, w, h = cv2.boundingRect(mask)                         # (0,0,0,0) if nothing red
    ms.append((time.perf_counter() - t) * 1000)
    n += 1
    if n % 15 == 0:
        print(f"frame {meta['frame_id']:6d} t_sim {meta['t_sim']:8.3f} pose_seq {meta['pose_seq']:6d} "
              f"red box x={x} y={y} w={w} h={h}")
print(f"{n} frames, OpenCV work {np.mean(ms):.2f} ms/frame")
