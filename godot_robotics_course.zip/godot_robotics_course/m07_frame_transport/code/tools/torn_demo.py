"""
torn_demo.py - Module 7: why the seqlock and the extra slots matter.

A deliberately slow reader: it reads the slot, then waits --hold-ms before checking the
sequence counter again (as if it ran a detector directly on the shared memory instead of
copying first). It counts how often the writer changed the slot underneath it.

    python tools/torn_demo.py --seconds 10 --hold-ms 20
Run it once with Godot started with --slots=1 and once with --slots=3.
"""
import argparse, struct, time
from frame_reader import ShmFrameReader, FILE_HEADER

ap = argparse.ArgumentParser()
ap.add_argument("--shm", default="/dev/shm/robosim_cam_fpv")
ap.add_argument("--seconds", type=float, default=10.0)
ap.add_argument("--hold-ms", type=float, default=20.0)
a = ap.parse_args()

rd = ShmFrameReader(a.shm)
reads = changed = 0
last = 0
t0 = time.monotonic()
while time.monotonic() - t0 < a.seconds:
    pub = rd.latest_pub()
    if pub == last:
        time.sleep(0.0005)
        continue
    last = pub
    base = FILE_HEADER + (pub % rd.n_slots) * rd.slot_bytes
    s1 = struct.unpack_from("<I", rd.mm, base)[0]
    time.sleep(a.hold_ms / 1000)          # "processing in place"
    s2 = struct.unpack_from("<I", rd.mm, base)[0]
    reads += 1
    if s1 != s2 or s1 & 1:
        changed += 1
print(f"slots={rd.n_slots} hold={a.hold_ms} ms: {reads} reads, {changed} would have been torn "
      f"({100 * changed / max(1, reads):.0f} %) - the seqlock check rejects exactly these")
