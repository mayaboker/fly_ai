#!/usr/bin/env bash
# Module 7: one measured run = Godot frame_lab + pose sender + shared-memory reader.
#   tools/run_frame_perf.sh 640x360 10            # size, measured seconds
#   tools/run_frame_perf.sh 1280x720 10 --shadows=false
# Environment overrides:
#   GODOT="godot"   (headless servers: GODOT="xvfb-run -a -s '-screen 0 1280x720x24' godot --rendering-driver opengl3")
#   PY=python  LISTEN_PORT=9001  PHYSICS_PORT=9002  SHM=/dev/shm/robosim_cam_fpv  RECORD=0
set -euo pipefail
SIZE=${1:-640x360}; SECS=${2:-10}; shift $(( $# < 2 ? $# : 2 ))
ROOT=$(cd "$(dirname "$0")/.." && pwd)
GODOT=${GODOT:-godot}; PY=${PY:-python}
LP=${LISTEN_PORT:-9001}; PP=${PHYSICS_PORT:-9002}; SHM=${SHM:-/dev/shm/robosim_cam_fpv}
mkdir -p "$ROOT/logs"
eval "$GODOT --path '$ROOT/godot' res://cameras/frame_lab.tscn -- --size=$SIZE --seconds=$((SECS + 6)) \
    --listen-port=$LP --physics-port=$PP --shm=$SHM $*" > "$ROOT/logs/godot_$SIZE.log" 2>&1 &
GPID=$!
$PY "$ROOT/physics/sims/camera_orbit.py" --seconds $((SECS + 8)) --viewer-port $LP --listen-port $PP \
    --logs "$ROOT/logs" > "$ROOT/logs/orbit_$SIZE.log" 2>&1 &
OPID=$!
sleep 2
RUN=$(grep -m1 "run dir:" "$ROOT/logs/orbit_$SIZE.log" | cut -d' ' -f3)
REC=""; [ "${RECORD:-0}" = "1" ] && REC="--record"
$PY "$ROOT/tools/frame_reader.py" --shm "$SHM" --seconds "$SECS" --warmup 2 --run-dir "$RUN" $REC \
    --label "$SIZE $*" --report "$ROOT/logs/frame_perf.csv"
wait $GPID $OPID || true
grep GODOT_STATS "$ROOT/logs/godot_$SIZE.log" || echo "(no Godot stats: see logs/godot_$SIZE.log)"
