"""
camera_orbit.py - Module 7 pose source: the quad (vehicle 2) flies a slow circle.

    python sims/camera_orbit.py [--seconds 20] [--viewer-port 9001] [--listen-port 9002]

No dynamics here (the motion is prescribed) because Module 7 measures frame transport, not
flight. It still behaves like a physics process: fixed 240 Hz step, poses at 60 Hz, and a
pose.csv log with the seq and the Unix send time of every pose, so the frame reader can
match each frame to its pose and measure pose-to-pixels latency.
"""
import argparse, math, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from robosim.bridge import PhysicsBridge
from robosim.logger import RunLogger
from robosim import frames as F

PHYSICS_HZ, POSE_HZ = 240, 60
R, ALT, PERIOD = 6.0, 3.0, 20.0          # circle radius m, altitude m, seconds per lap


def pose_enu(t):
    """Position (ENU), velocity (ENU) and yaw (rad, 0 = east, CCW) on the circle, nose along the path."""
    a = 2 * math.pi * t / PERIOD
    w = 2 * math.pi / PERIOD
    return (R * math.cos(a), R * math.sin(a), ALT), (-R * w * math.sin(a), R * w * math.cos(a), 0.0), a + math.pi / 2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seconds", type=float, default=20.0)
    ap.add_argument("--viewer-port", type=int, default=9001)
    ap.add_argument("--listen-port", type=int, default=9002)
    ap.add_argument("--logs", default=os.path.join(os.path.dirname(__file__), "..", "..", "logs"))
    a = ap.parse_args()
    br = PhysicsBridge(viewer_port=a.viewer_port, listen_port=a.listen_port)
    log = RunLogger(a.logs, run_name="camera_orbit", seed=0,
                    meta={"physics": "prescribed circle", "physics_hz": PHYSICS_HZ, "pose_hz": POSE_HZ,
                          "vehicle_id": 2, "t_send_unix": "time.time() just before sendto"})
    print("run dir:", os.path.abspath(log.dir), flush=True)
    dt, n_sub = 1.0 / PHYSICS_HZ, PHYSICS_HZ // POSE_HZ
    t, step, t0 = 0.0, 0, time.monotonic()
    while t < a.seconds:
        br.poll(t)
        step += 1
        t = step * dt              # (a real sim would call p.stepSimulation() / fdm.run() here)
        if step % n_sub == 0:
            p, v, yaw = pose_enu(t)
            q_enu_flu = F.matrix_to_quat(F.euler_zyx_to_matrix(0.0, 0.0, yaw))
            pos_g, quat_g = F.enu_flu_to_godot(p, q_enu_flu)      # convert once, here
            t_send = time.time()
            br.send_pose(t, 2, pos_g, quat_g, F.enu_to_godot_pos(v))
            log.write("pose", t, pose_seq=br.seq, t_send_unix=f"{t_send:.6f}",
                      x=round(pos_g[0], 4), y=round(pos_g[1], 4), z=round(pos_g[2], 4))
        # real time: sleep until this step's wall time
        lag = t - (time.monotonic() - t0)
        if lag > 0:
            time.sleep(lag)
    log.close()


if __name__ == "__main__":
    main()
