extends "res://cameras/camera_lab.gd"
## Module 7 lab: the Module 6 world + quad, driven by the bridge, with the FPV camera
## published to shared memory by FrameCapture.
##   godot --path godot res://cameras/frame_lab.tscn                      (defaults)
##   godot --path godot res://cameras/frame_lab.tscn -- --size=1280x720 --rate=30 --seconds=20
## Options after "--": --size=WxH --rate=HZ --seconds=S (0 = run until closed)
##   --shm=/dev/shm/robosim_cam_fpv --listen-port=9001 --physics-port=9002 --slots=3 --rgba
##   --shadows=false   --udp-port=9005 [--jpeg]   (also send frames over UDP; --shm= to disable shm)

const VEHICLE_ID := 2                    # quadcopter

var bridge: SimBridge
var capture: FrameCapture
var opts := {"size": "640x360", "rate": "30", "seconds": "0", "shm": "/dev/shm/robosim_cam_fpv",
		"listen-port": str(RsProtocol.PORT_TO_VIEWER), "physics-port": str(RsProtocol.PORT_TO_PHYSICS),
		"slots": "3", "rgba": "false", "shadows": "true", "udp-port": "0", "jpeg": "false"}
var _t_run := 0.0


func _ready() -> void:
	for a in OS.get_cmdline_user_args():          # everything after "--"
		var kv := a.trim_prefix("--").split("=", true, 1)
		opts[kv[0]] = kv[1] if kv.size() > 1 else "true"
	Engine.max_fps = 60
	out_dir = ProjectSettings.globalize_path("res://").path_join("../logs").simplify_path()
	bridge = SimBridge.new()
	bridge.listen_port = int(opts["listen-port"])
	bridge.physics_port = int(opts["physics-port"])
	# SimBridge sets process_priority = -100 itself: it reads this frame's poses BEFORE we use them
	add_child(bridge)
	_build_world()
	if opts["shadows"] == "false":
		for c in get_children():
			if c is DirectionalLight3D:
				c.shadow_enabled = false
	_build_vehicle()
	_build_board()
	board.position = Vector3(0.0, 2.0, -8.0)     # something red to look at
	var wh: PackedStringArray = opts["size"].split("x")
	var fpv: CameraRig = rigs["fpv"]
	fpv.viewport.size = Vector2i(int(wh[0]), int(wh[1]))
	for n in ["gimbal", "down", "chase"]:         # only the FPV camera renders in this lab
		rigs[n].viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
	capture = FrameCapture.new()
	capture.rig = fpv
	capture.rate_hz = float(opts["rate"])
	capture.shm_path = opts["shm"]
	capture.n_slots = int(opts["slots"])
	capture.rgba = opts["rgba"] == "true"
	add_child(capture)
	if int(opts["udp-port"]) > 0:                 # cross-platform fallback (sub-topic 05)
		var udp := UdpFrameSender.new()
		udp.port = int(opts["udp-port"])
		udp.jpeg = opts["jpeg"] == "true"
		add_child(udp)
		capture.frame_ready.connect(udp.send_frame)
	fpv.save_intrinsics(out_dir.path_join("intrinsics_fpv_%s.json" % opts["size"]))
	print("frame_lab: %s @ %s Hz -> %s, bridge %s/%s" % [opts["size"], opts["rate"], opts["shm"],
			opts["listen-port"], opts["physics-port"]])


func _process(delta: float) -> void:
	# Place the vehicle from the newest pose and tell the capture which pose that was.
	# (If you use Module 5's interpolated sample(), pass the render time you sampled at.)
	if bridge.has_vehicle(VEHICLE_ID):
		vehicle.global_transform = bridge.latest_transform(VEHICLE_ID)
		capture.t_sim = bridge.latest_t_sim
		capture.pose_seq = bridge.latest_seq
	_t_run += delta
	var secs := float(opts["seconds"])
	if secs > 0.0 and _t_run > secs:
		_finish()


func _finish() -> void:
	set_process(false)
	var s := capture.stats()
	s["size"] = opts["size"]
	s["rate_hz"] = capture.rate_hz
	s["seconds"] = _t_run
	s["render_fps"] = Engine.get_frames_per_second()
	print("GODOT_STATS ", JSON.stringify(s))
	var f := FileAccess.open(out_dir.path_join("godot_capture_stats_%s.json" % opts["size"]), FileAccess.WRITE)
	f.store_string(JSON.stringify(s, "  "))
	f.close()
	get_tree().quit()
