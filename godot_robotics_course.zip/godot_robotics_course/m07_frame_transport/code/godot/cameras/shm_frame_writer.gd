class_name ShmFrameWriter
extends RefCounted
## Writes camera frames into a file in /dev/shm (RAM) using a slot ring (Module 7).
## Reader: tools/frame_reader.py. Layout (little-endian), all offsets in bytes:
##
## File header (64 B)
##   0  magic        4s   "RSFB"
##   4  version      u32  1
##   8  n_slots      u32  ring size (3 = triple buffering)
##   12 slot_bytes   u32  64 + max_width * max_height * channels
##   16 max_width    u32
##   20 max_height   u32
##   24 channels     u32  3 (RGB8) or 4 (RGBA8)
##   28 reserved     u32
##   32 latest_pub   u64  n_published of the newest COMPLETE frame (written last; 0 = none yet)
##   40 reserved     24 B
## Frame number k (k = 1, 2, 3, ... in publish order) lives in slot k % n_slots, so the newest
## frame is in slot latest_pub % n_slots. Slots are used strictly in turn, even when camera
## ticks are skipped, so a slot is rewritten only after n_slots - 1 newer frames.
## Slot i starts at 64 + i * slot_bytes. Slot header (64 B), then pixel rows (top row first):
##   0  seq          u32  seqlock: odd while writing, even when stable (written first AND last)
##   4  width        u32
##   8  height       u32
##   12 channels     u32
##   16 frame_id     u64  camera tick index, starts at 1; a gap = a tick without a frame
##   24 t_sim        f64  sim time of the pose the image was rendered from
##   32 t_capture    f64  wall clock (Unix s) when the pixels reached CPU memory
##   40 pose_seq     u32  bridge seq of that pose packet
##   44 data_bytes   u32
##   48 readback_ms  f32  time spent in get_image() (GPU -> CPU)
##   52 convert_ms   f32  Image.convert + get_data (before the copy into shared memory)
##   56 n_published  u32  frames published so far, this one included (1, 2, 3, ...)
##   60 reserved     4 B
## frame_id gaps that n_published does NOT show were never rendered (Godot too slow);
## n_published gaps were rendered but overwritten before the reader got them (reader too slow).

const MAGIC := "RSFB"
const VERSION := 1
const FILE_HEADER := 64
const SLOT_HEADER := 64

var path := ""
var n_slots := 3
var max_w := 0
var max_h := 0
var channels := 3
var slot_bytes := 0
var _f: FileAccess
var _seq: PackedInt64Array = []        # per-slot seqlock counter
var _hdr := PackedByteArray()
var _published := 0


## Create (or truncate) the shared-memory file. Returns OK or an error code.
func open(p_path: String, p_max_w: int, p_max_h: int, p_channels := 3, p_slots := 3) -> Error:
	path = p_path
	max_w = p_max_w
	max_h = p_max_h
	channels = p_channels
	n_slots = p_slots
	slot_bytes = SLOT_HEADER + max_w * max_h * channels
	# Remove the old file first: a reader that still maps it keeps a valid (orphaned) mapping
	# and notices the new inode, instead of crashing on a file truncated under its feet.
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(path)
	_f = FileAccess.open(path, FileAccess.WRITE_READ)     # creates the file
	if _f == null:
		return FileAccess.get_open_error()
	var err := _f.resize(FILE_HEADER + n_slots * slot_bytes)   # zero-filled
	if err != OK:
		return err
	var h := PackedByteArray()
	h.resize(FILE_HEADER)
	h.encode_u8(0, MAGIC.unicode_at(0))
	h.encode_u8(1, MAGIC.unicode_at(1))
	h.encode_u8(2, MAGIC.unicode_at(2))
	h.encode_u8(3, MAGIC.unicode_at(3))
	h.encode_u32(4, VERSION)
	h.encode_u32(8, n_slots)
	h.encode_u32(12, slot_bytes)
	h.encode_u32(16, max_w)
	h.encode_u32(20, max_h)
	h.encode_u32(24, channels)
	_f.seek(0)
	_f.store_buffer(h)
	_f.flush()
	_seq.resize(n_slots)
	_seq.fill(0)
	_hdr.resize(SLOT_HEADER)
	return OK


## Publish one frame. `pixels` = width*height*channels bytes, rows top to bottom.
func write_frame(frame_id: int, width: int, height: int, pixels: PackedByteArray,
		t_sim: float, pose_seq: int, t_capture: float, readback_ms: float, convert_ms: float) -> void:
	if _f == null or width > max_w or height > max_h or pixels.size() != width * height * channels:
		push_error("ShmFrameWriter: bad frame %dx%d (%d bytes)" % [width, height, pixels.size()])
		return
	_published += 1
	var slot := _published % n_slots
	var base := FILE_HEADER + slot * slot_bytes
	# 1. seq -> odd: "slot is being written". flush() pushes it out of the stdio buffer
	#    with a write() system call, so it reaches the shared page before the pixels do.
	_seq[slot] += 1
	_f.seek(base)
	_f.store_32(_seq[slot] & 0xFFFFFFFF)
	_f.flush()
	# 2. header fields (except seq) and pixels
	_hdr.fill(0)
	_hdr.encode_u32(4, width)
	_hdr.encode_u32(8, height)
	_hdr.encode_u32(12, channels)
	_hdr.encode_u64(16, frame_id)
	_hdr.encode_double(24, t_sim)
	_hdr.encode_double(32, t_capture)
	_hdr.encode_u32(40, pose_seq & 0xFFFFFFFF)
	_hdr.encode_u32(44, pixels.size())
	_hdr.encode_float(48, readback_ms)
	_hdr.encode_float(52, convert_ms)
	_hdr.encode_u32(56, _published & 0xFFFFFFFF)
	_f.seek(base + 4)
	_f.store_buffer(_hdr.slice(4))
	_f.store_buffer(pixels)
	_f.flush()
	# 3. seq -> even: "slot is stable". Written LAST for this slot.
	_seq[slot] += 1
	_f.seek(base)
	_f.store_32(_seq[slot] & 0xFFFFFFFF)
	_f.flush()
	# 4. announce it: the reader polls latest_pub and reads slot latest_pub % n_slots
	_f.seek(32)
	_f.store_64(_published)
	_f.flush()


func close(remove_file := false) -> void:
	if _f:
		_f.close()
		_f = null
	if remove_file and path != "":
		DirAccess.remove_absolute(path)
