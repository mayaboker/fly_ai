class_name UdpFrameSender
extends Node
## Cross-platform fallback for Module 7: send frames as UDP chunks (Windows/macOS, or another
## machine). Connect it to FrameCapture.frame_ready. Reader: tools/udp_frame_receiver.py.
## Use it for SMALL images (e.g. 320x180 raw) or JPEG; shared memory is far cheaper on Linux.
##
## Chunk = 40-byte header + payload (little-endian):
##   0 magic "RF" | 2 version u8 = 1 | 3 encoding u8 (0 = raw RGB8, 1 = JPEG)
##   4 frame_id u32 | 8 chunk u16 | 10 n_chunks u16 | 12 width u16 | 14 height u16
##   16 t_sim f64 | 24 t_capture f64 (Unix s) | 32 pose_seq u32 | 36 total_bytes u32

const HEADER := 40

@export var host := "127.0.0.1"
@export var port := 9005
@export var jpeg := false
@export_range(0.1, 1.0) var jpeg_quality := 0.85
@export var chunk_bytes := 60000         ## loopback: up to ~65000; real networks: 1400 avoids IP fragments

var _udp := PacketPeerUDP.new()
var encode_ms := 0.0                     ## last frame's JPEG encode time


func _ready() -> void:
	_udp.set_dest_address(host, port)


func send_frame(frame_id: int, image: Image, meta: Dictionary) -> void:
	var payload: PackedByteArray
	var t0 := Time.get_ticks_usec()
	if jpeg:
		payload = image.save_jpg_to_buffer(jpeg_quality)
	else:
		if image.get_format() != Image.FORMAT_RGB8:
			image.convert(Image.FORMAT_RGB8)
		payload = image.get_data()
	encode_ms = (Time.get_ticks_usec() - t0) / 1000.0
	var n := ceili(float(payload.size()) / chunk_bytes)
	var h := PackedByteArray()
	h.resize(HEADER)
	h.encode_u8(0, 0x52)                  # 'R'
	h.encode_u8(1, 0x46)                  # 'F'
	h.encode_u8(2, 1)
	h.encode_u8(3, 1 if jpeg else 0)
	h.encode_u32(4, frame_id & 0xFFFFFFFF)
	h.encode_u16(10, n)
	h.encode_u16(12, image.get_width())
	h.encode_u16(14, image.get_height())
	h.encode_double(16, meta.t_sim)
	h.encode_double(24, meta.t_capture_wall)
	h.encode_u32(32, int(meta.pose_seq) & 0xFFFFFFFF)
	h.encode_u32(36, payload.size())
	for i in n:
		h.encode_u16(8, i)
		var pkt := h.duplicate()
		pkt.append_array(payload.slice(i * chunk_bytes, mini((i + 1) * chunk_bytes, payload.size())))
		_udp.put_packet(pkt)
