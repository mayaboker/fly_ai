extends Node3D
## Module 7 test: WHICH pose is in the image you read back?
## A red board jumps to a new x every frame. We read the image (a) in _process, the naive way,
## and (b) in RenderingServer.frame_post_draw (what FrameCapture does), then find the board in
## the pixels and compare its x with the x we set in each frame.
## Run with rendering, from robosim/:  godot --path godot res://cameras/capture_timing_test.tscn

const N := 40
var vp: SubViewport
var cam: Camera3D
var board: MeshInstance3D
var frame := 0
var x_set := {}          # frame -> board x set in that frame's _process
var naive_lag := []
var post_lag := []


func _ready() -> void:
	vp = SubViewport.new()
	vp.size = Vector2i(320, 180)
	vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(vp)
	cam = Camera3D.new()
	cam.fov = 60.0
	vp.add_child(cam)
	board = MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.3, 0.3, 0.01)
	board.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(1, 0, 0)
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	board.material_override = m
	add_child(board)
	RenderingServer.frame_post_draw.connect(_on_post_draw)


func _x_for(f: int) -> float:
	return -2.0 + 0.4 * float(f % 11)        # 11 distinct positions, 0.4 m apart, at 5 m


func _process(_d: float) -> void:
	frame += 1
	board.position = Vector3(_x_for(frame), 0, -5)
	x_set[frame] = board.position.x
	# (a) naive: set the pose, then read the image in the same _process
	if frame > 2:
		naive_lag.append(_lag(vp.get_texture().get_image(), frame))
	if frame > N:
		print("read in _process:          lag (frames) = ", _hist(naive_lag))
		print("read in frame_post_draw:   lag (frames) = ", _hist(post_lag))
		get_tree().quit()


func _on_post_draw() -> void:
	# (b) after this frame's draw: should show the x set in THIS frame's _process
	if frame > 2:
		post_lag.append(_lag(vp.get_texture().get_image(), frame))


## How many frames old is the board position visible in img, relative to frame f?
func _lag(img: Image, f: int) -> int:
	var sum := 0.0
	var n := 0
	for x in img.get_width():
		var c := img.get_pixel(x, 90)
		if c.r > 0.9 and c.g < 0.1:
			sum += x + 0.5
			n += 1
	if n == 0:
		return -99
	var u := sum / n
	var fy := 90.0 / tan(deg_to_rad(30.0))
	var x_seen := (u - 160.0) / fy * 5.0
	for lag in 4:
		if x_set.has(f - lag) and absf(x_set[f - lag] - x_seen) < 0.1:
			return lag
	return -1


func _hist(a: Array) -> Dictionary:
	var h := {}
	for v in a:
		h[v] = h.get(v, 0) + 1
	return h
