class_name FrameCapture
extends Node
## Captures one CameraRig at a fixed rate and publishes RGB frames (Module 7).
##  - rate_hz ticks on the wall clock; frame_id = tick index, so a skipped tick leaves a gap
##  - on_demand: the SubViewport renders ONLY when a frame is due (UPDATE_ONCE), which saves
##    GPU time when the camera rate is lower than the display rate
##  - pixels are read in RenderingServer.frame_post_draw, i.e. in the same frame they were
##    rendered, so t_sim / pose_seq describe exactly the pose that is in the image
##  - set t_sim and pose_seq every frame from whatever placed the vehicle (see frame_lab.gd)

signal frame_ready(frame_id: int, image: Image, meta: Dictionary)

@export var rig: CameraRig
@export var rate_hz := 30.0
@export var on_demand := true
@export var shm_path := "/dev/shm/robosim_cam_fpv"   ## "" = no shared memory output
@export var n_slots := 3
@export var rgba := false                            ## false: RGB8 (3 B/px), true: RGBA8

var t_sim := 0.0           ## sim time of the pose used for this frame's render
var pose_seq := 0          ## bridge seq of that pose
var writer: ShmFrameWriter

var frames := 0            ## frames published
var skipped_ticks := 0     ## ticks that passed without a capture (render loop too slow)
var readback_ms: PackedFloat32Array = []
var convert_ms: PackedFloat32Array = []
var write_ms: PackedFloat32Array = []

var _acc := 0.0
var _tick := 0
var _pending := false
var _meta := {}


func _ready() -> void:
	process_priority = 1001          # after the vehicle (default 0) and the CameraRig (1000)
	if rig == null:
		push_error("FrameCapture: set 'rig'")
		return
	if on_demand:
		rig.viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
	if shm_path != "":
		writer = ShmFrameWriter.new()
		var sz: Vector2i = rig.viewport.size
		var err := writer.open(shm_path, sz.x, sz.y, 4 if rgba else 3, n_slots)
		if err != OK:
			push_error("FrameCapture: cannot open %s (%s)" % [shm_path, error_string(err)])
			writer = null
	RenderingServer.frame_post_draw.connect(_on_frame_post_draw)


func _process(delta: float) -> void:
	_acc += delta
	var period := 1.0 / rate_hz
	if _acc < period:
		return
	var n := int(_acc / period)
	_acc -= n * period
	_tick += n
	skipped_ticks += n - 1
	if _pending:                     # the last request was never drawn
		skipped_ticks += 1
	_pending = true
	_meta = {"frame_id": _tick, "t_sim": t_sim, "pose_seq": pose_seq}
	if on_demand:
		rig.viewport.render_target_update_mode = SubViewport.UPDATE_ONCE


func _on_frame_post_draw() -> void:
	if not _pending:
		return
	_pending = false
	var t0 := Time.get_ticks_usec()
	var img := rig.get_image()                       # GPU -> CPU: waits for the GPU
	var t1 := Time.get_ticks_usec()
	var t_capture := Time.get_unix_time_from_system()
	var fmt := Image.FORMAT_RGBA8 if rgba else Image.FORMAT_RGB8
	if img.get_format() != fmt:
		img.convert(fmt)
	var data := img.get_data()
	var t2 := Time.get_ticks_usec()
	var rb := (t1 - t0) / 1000.0
	var cv := (t2 - t1) / 1000.0
	if writer:
		writer.write_frame(_meta.frame_id, img.get_width(), img.get_height(), data,
				_meta.t_sim, _meta.pose_seq, t_capture, rb, cv)
	var t3 := Time.get_ticks_usec()
	frames += 1
	readback_ms.append(rb)
	convert_ms.append(cv)
	write_ms.append((t3 - t2) / 1000.0)
	var meta := _meta.duplicate()
	meta["t_capture_wall"] = t_capture
	frame_ready.emit(_meta.frame_id, img, meta)


## Summary of the Godot-side costs (mean and 95th percentile, ms).
func stats() -> Dictionary:
	return {"frames": frames, "skipped_ticks": skipped_ticks,
			"readback_ms": _summ(readback_ms), "convert_ms": _summ(convert_ms),
			"write_ms": _summ(write_ms)}


static func _summ(a: PackedFloat32Array) -> Dictionary:
	if a.is_empty():
		return {"mean": 0.0, "p95": 0.0, "max": 0.0}
	var s := a.duplicate()
	s.sort()
	var total := 0.0
	for v in s:
		total += v
	return {"mean": total / s.size(), "p95": s[int(0.95 * (s.size() - 1))], "max": s[-1]}


func _exit_tree() -> void:
	if writer:
		writer.close()
