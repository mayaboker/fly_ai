# Lab: sensors on the rover, end to end (2.75 h)

You will give the rover (vehicle id 1) both kinds of sensors and record one run with everything in it:

```
 physics/sims/sensors_pybullet.py                         godot/sensors_demo.tscn
 ────────────────────────────────                         ───────────────────────────────
 PyBullet box, 240 Hz, slalom toward a wall   ── POSE 60 Hz ──▶  rover node + 3 sensors
 IMU 240 Hz, baro 50, mag 50, GPS 5 (150 ms)                     RsRangeSensor  20 Hz  1 ray
 PoseHistory: t_sim -> pose                                      RsLidar2D      10 Hz  180 rays
 RangeNoise on Godot's ideal ranges          ◀─ SENSOR (t_sim of the pose) ─ RsContactSensor 30 Hz
 RunLogger: truth | measured | expected
```

The wall, the four pillars and the low curb exist **only in Godot**. PyBullet knows only the ground. That is the point: the rover's range, lidar and contact sensors see things that the physics engine has never heard of. For each Godot sample, Python finds the pose Godot used, computes analytically what the reading should be, and logs all of it.

## Files

| File | Status |
|---|---|
| `physics/robosim/sensors.py` | **new**: error models, IMU/baro/mag/GPS/air data, `RangeNoise`, `PoseHistory` |
| `physics/tests/test_sensors.py` | **new**: 16 tests, including the stationary convention |
| `physics/sims/sensors_pybullet.py` | **new**: the lab scenario |
| `physics/sims/imu_jsbsim.py` | **new**: the same sensor models on JSBSim `quad_rpy` |
| `godot/sensors/sensor_clock.gd`, `range_sensor.gd`, `lidar_2d.gd`, `contact_sensor.gd` | **new** |
| `godot/sensors/ray_bench.gd` + `.tscn` | **new**: ray-cast cost on your machine |
| `godot/sensors_demo.gd` + `.tscn` | **new**: the sensor test range (its own scene, so it cannot break `main.tscn`) |
| `tools/plot_sensors.py`, `tools/compare_runs.py` | **new** |
| `godot/bridge/*`, `physics/robosim/{frames,protocol,bridge,logger}.py` | unchanged |

The finished files are in [`code/`](code/README.md). Try each step yourself first.

## Step 1: the physics-side models (40 min)

1. Create `physics/robosim/sensors.py`. Write it yourself from [01](01_truth_and_error_models.md)–[03](03_baro_mag_gps_air.md), or start from `code/physics/robosim/sensors.py` and read every class before you go on. It has no dependencies beyond NumPy.
2. Copy `code/physics/tests/test_sensors.py` to `physics/tests/` and run it from `physics/`:

   ```bash
   cd ~/robosim/physics
   python tests/test_sensors.py
   ```

   ```
     ok  test_airdata_alpha
     ok  test_baro
     ...
     ok  test_stationary_accel_jsbsim
     ok  test_stationary_accel_pybullet_level
     ok  test_stationary_accel_pybullet_on_side
     ...
   sensors: all 16 tests pass
   ```

   The JSBSim test needs `physics/aircraft/quad_rpy/` (copy `reference/code/aircraft/quad_rpy` there, as in [project layout](../reference/project_layout.md)).
3. Break the convention on purpose: in `ImuTruthFD.update`, change `a - self.g_world` to `a + self.g_world`. Run the tests. The run must stop with an `AssertionError`. Three tests guard this convention: the two PyBullet resting tests and the free-fall test. pytest would report all three. Undo the change.

## Step 2: the Godot sensors (40 min)

1. Create `godot/sensors/` and add `sensor_clock.gd`, `range_sensor.gd`, `lidar_2d.gd` and `contact_sensor.gd` ([04](04_godot_range_lidar_contact.md) explains each one). Use typed GDScript with TAB indentation.
2. Add `sensors_demo.gd` and `sensors_demo.tscn` to `godot/`. The demo builds its world in code, so you can read every coordinate:

   | Object | ENU position | Godot layer |
   |---|---|---|
   | floor, 60 × 60 m, top at U = 0 | centered at origin | 1 (terrain) |
   | wall, 0.2 m thick, 20 m long, 2 m high | west face at **E = 14.9** | 2 (obstacles) |
   | 4 pillars, r = 0.3 m | (5, ±5), (9, ±5) | 2 |
   | curb, 0.1 m high | E 4…14, N 0.30…0.65 | 2 |

   The rover node gets three children. Their **local transforms are the mounts**, in the Godot model frame (x right, y up, −z forward):

   | Sensor | Mount (model frame) | Same mount in FLU (Python) | Mask |
   |---|---|---|---|
   | `RsRangeSensor` | (0, 0.05, −0.3): nose | (0.3, 0, 0.05) | 0b11 |
   | `RsLidar2D` | (0, 0.2, 0): roof | (0, 0, 0.2) | 0b11 |
   | `RsContactSensor` + box 0.4 × 0.3 × 0.6 | (0, 0, 0) | (0, 0, 0) | 0b10 |

   On your own rover in `main.tscn`, do the same in the editor. Add the three nodes as **direct children** of the rover node, and set *Bridge Path* to your `SimBridge`. For the contact sensor, add a `CollisionShape3D` child. Then name the physics layers in *Project Settings → Layer Names → 3D Physics*.
3. Build the class cache and do a dry run. It should print nothing alarming and wait for poses:

   ```bash
   ~/tools/godot --headless --path ~/robosim/godot --import
   ~/tools/godot --headless --path ~/robosim/godot res://sensors_demo.tscn   # Ctrl+C to stop
   ```

4. Measure ray cost on your machine and keep the numbers:

   ```bash
   ~/tools/godot --headless --path ~/robosim/godot res://sensors/ray_bench.tscn
   ```

   ```
   physics engine setting: DEFAULT
   BENCH range scene (6 shapes)   hits= 219/1000  intersect_ray    623 us/1000   RayCast3D    417 us/1000   ShapeCast3D(5 m sphere)   1807 us/1000
   BENCH range + 500 boxes        hits= 960/1000  intersect_ray   6386 us/1000   RayCast3D   5295 us/1000   ShapeCast3D(5 m sphere)  16844 us/1000
   BENCH heightmap 257x257        hits=1000/1000  intersect_ray   2651 us/1000   RayCast3D   1438 us/1000   ShapeCast3D(5 m sphere)  45002 us/1000
   ```

   (These are the numbers from the course test machine. Yours will differ.)

## Step 3: the scenario script (45 min)

Read `code/physics/sims/sensors_pybullet.py` from top to bottom. The parts that matter:

1. **The rover** is a 0.6 × 0.4 × 0.3 m box on a frictionless plane. Each step, the script sets its velocity along its current heading (`profile(t)`): accelerate at 0.5 m/s² for 3 s, cruise at 1.5 m/s with a ±14° slalom, brake for 3 s, stand still for 2 s. This is kinematic driving: good enough to exercise the sensors. Module 9 builds a real differential drive.
2. **Truth after every step**: `ImuTruthFD` gives the specific force and body rates. Then each physics-side sensor's `step()` is called, and every delivered sample is logged with truth at its `t_valid`.
3. **Every 4th step** (60 Hz), the pose is sent and also stored: `history.add(t, pos_enu, quat)`.
4. **`handle(msg)`** does three things for every SENSOR packet. It looks up `history.exact(msg["t_sim"])`. It computes the expected reading from that pose (`expected_range`, `expected_scan` and `expected_curb_overlap` are a few lines of 2D geometry against the same wall, pillars and curb). Then it logs Godot's ideal value, the noisy value and the expected one. It tells the range sensor and the lidar apart by the number of values (1 vs 180).
5. **The viewer handshake.** `br.wait_for_viewer(send_idle_pose=...)` sends an idle pose every 0.1 s until Godot answers, so either start order works. Afterwards the script drains packets for 0.3 s: Godot may have sampled the idle pose, which also has `t_sim = 0`, and those late samples would otherwise be logged as extra rows and shift the noise streams (Check 2 would then say `different`).

## Step 4: run it (20 min)

Terminal 1 (either order works):

```bash
~/tools/godot --path ~/robosim/godot res://sensors_demo.tscn -- --quit-when-stale
```

Terminal 2:

```bash
cd ~/robosim/physics
python sims/sensors_pybullet.py --seed 42
```

Godot's window shows the rover slaloming toward the wall. The run takes 12 s of sim time in real time. Then Python prints `summary.json`, and Godot quits on its own once the poses stop. Expected output:

```
{
  "seed": 42,
  "imu_rest_true_flu": [0.0, 0.0, 9.8066],
  "imu_rest_meas_flu": [-0.0417, 0.0611, 9.912],
  "gps_samples": 60,
  "gps_rms_h_m": 1.958,
  "range_samples": 241,
  "range_max_abs_err_matched_m": 2.16e-06,
  "range_rms_err_if_latest_pose_m": 0.0185,
  "range_max_err_if_latest_pose_m": 0.0351,
  "lidar_scans": 121,
  "lidar_max_abs_err_m": 2.31e-05,
  "lidar_hit_mismatch_rays": 0,
  "contact_samples": 361,
  "contact_hits": 45,
  "contact_disagree_beyond_5mm": 0,
  "sensor_delay_sim_s_mean": 0.0248,
  "sensor_delay_sim_s_max": 0.0292,
  "unmatched_sensor_packets": 0
}
```

and in Godot's console:

```
SENSORS lidar_scans=122  mean_scan_ms=0.291  us_per_ray=1.62  us_per_1000_rays=1619
SENSORS area_body_entered_signals=1
SENSORS last_range=4.271 at t_sim=12.0000
```

What the numbers mean:

- `imu_rest_meas_flu` is not exactly (0, 0, 9.81). That is the accelerometer's turn-on bias and scale factor for seed 42. `imu_rest_true_flu` is exact.
- `range_samples` 241 = 20 Hz × 12 s + 1 (the sample at t = 0), and `lidar_scans` 121 = 10 Hz × 12 s + 1. The sensor clocks run on sim time. (Godot counts 122 scans because it also scanned an idle pose before the run started.)
- `range_max_abs_err_matched_m` ≈ 2 × 10⁻⁶ m: Godot's `RayCast3D` and Python's geometry agree to float32 precision once the right pose is used. `range_*_if_latest_pose_m` (2–7 cm) is the price of matching by arrival instead.
- The timing numbers (`sensor_delay_*`, `range_*_latest`) vary from run to run. The geometry numbers do not.

Run `python sims/sensors_pybullet.py --no-viewer` to exercise only the physics-side sensors. Add `--fast` to skip real-time pacing.

## Step 5: plot it (15 min)

```bash
cd ~/robosim
python tools/plot_sensors.py logs/<run>          # writes logs/<run>/sensors.png
```

![Expected plot](img/sensors_expected.png)

Read the six panels:

- **Accelerometer x**: truth is a clean staircase (+0.5, 0, −0.5, 0 m/s²). Measured is offset by the bias and fuzzed by noise.
- **Gyro z**: the slalom's yaw rate. The noise is hard to see at this scale.
- **Baro**: about 0.3 m of bias and ±0.15 m of noise around a constant true altitude.
- **GPS error**: a slow wander of 1–2 m, not white noise. Each point is plotted at its time of validity.
- **Forward range**: Godot's ideal range falls from about 14.6 m to 4.27 m as the rover approaches the wall.
- **Lidar**: one scan at t = 6 s, drawn from the pose matched by `t_sim`. The wall points sit exactly on the true wall face, and two pillars show up as short arcs.

## Step 6: reproducibility and the JSBSim variant (15 min)

1. Run the scenario a second time with `--seed 42` (with the viewer), then compare:

   ```bash
   python tools/compare_runs.py logs/<run A> logs/<run B>
   ```

   ```
     baro.csv        601 rows  identical
     contact.csv     361 rows  identical
     gps.csv          60 rows  identical
     imu.csv        2880 rows  identical
     lidar.csv       121 rows  identical
     mag.csv         601 rows  identical
     pose.csv        720 rows  identical
     range.csv       241 rows  identical
   RESULT: identical
   ```

   Run once more with `--seed 7` and compare. `imu`, `baro`, `mag` and `gps` must be `DIFFERENT`, and `pose` must stay `identical`, because noise never feeds back into the dynamics. (Two runs started in the same second get a `_2` suffix, so no run is overwritten.)

2. Run the JSBSim variant. It needs no viewer:

   ```bash
   python sims/imu_jsbsim.py
   ```

   ```
   t= 1.51  thr=0.00  h=  0.08 m  phi=   0.0 deg  f_true=( -0.00,  0.00,  9.80)  p_true= 0.000 rad/s
   t= 2.51  thr=0.60  h=  0.30 m  phi=  -0.0 deg  f_true=( -0.00, -0.00, 12.77)  p_true= 0.000 rad/s
   t= 6.51  thr=0.47  h= 17.37 m  phi=   9.3 deg  f_true=( -0.00, -0.02,  9.54)  p_true= 0.061 rad/s
   ...
   { "a_pilot_z_at_rest_ftps2": -32.136, "accel_z_at_rest_flu_mps2": 9.795, ... }
   ```

   The same `Imu`, `Barometer`, `Magnetometer` and `Gps` classes run unchanged. Only the truth source differs (`imu_truth_jsbsim(fdm)` and `GeoOrigin.to_enu`).

## Check

| # | Test | Pass when |
|---|---|---|
| 1 | `python tests/test_sensors.py` | `sensors: all 16 tests pass`. This includes the stationary accelerometer convention: +g up in FLU (PyBullet level and on its side), 0 in free fall, `a-pilot-z` −32.0…−32.3 ft/s² in JSBSim |
| 2 | two runs with `--seed 42` → `compare_runs.py` | `RESULT: identical`; with `--seed 7`: sensor CSVs `DIFFERENT`, `pose.csv` identical |
| 3 | `summary.json` of a run with the viewer | `unmatched_sensor_packets` = 0, `range_max_abs_err_matched_m` < 0.001, `lidar_max_abs_err_m` < 0.001, `lidar_hit_mismatch_rays` = 0, `contact_disagree_beyond_5mm` = 0 |
| 4 | `range_rms_err_if_latest_pose_m` | clearly larger than the matched error (cm vs µm). You can explain it as speed × delay |
| 5 | `ray_bench.tscn` | you wrote down µs per 1000 rays for your machine |
| 6 | `sensors.png` | all six panels present; truth and measurement both visible |

## Stretch goals

- **Per-sample noise.** Make `RangeNoise` derive each scan's noise from `make_rng(seed, f"lidar:{t_sim!r}")`. That way, a dropped UDP packet cannot shift the noise of later scans. Show that `lidar.csv` still reproduces when you drop every 10th packet on purpose.
- **Downward range from Godot.** Add a fourth sensor, a `RsRangeSensor` mounted looking down. Place a 0.5 m box on the floor that only Godot has, and compare its reading with `terrain_range_down` from Python. Where do they disagree, and which one is right?
- **3D lidar cost.** Make `RsLidar2D` scan 16 elevation rings (−15° to +15°) and measure `us_per_ray` and scan time at 10 Hz. At what ray count does Godot's frame rate drop below 60 FPS on your machine?
- **Instance ids.** The SENSOR header has a `reserved` u16. Propose (in writing, as a protocol v2 or a new message type) using it as a sensor instance id, so two lidars on one vehicle can be told apart.
- **Lever arm.** Mount the IMU 0.2 m ahead of the COM and add `ω × (ω × r)`. How big is the extra `ay` in the slalom?
