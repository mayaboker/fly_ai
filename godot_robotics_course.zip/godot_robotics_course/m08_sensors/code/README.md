# Module 8 reference code

These files mirror the `robosim/` layout. Copy them into your project:

| Here | Into `~/robosim/` |
|---|---|
| `physics/robosim/sensors.py` | `physics/robosim/sensors.py` (new module in the shared package) |
| `physics/tests/test_sensors.py` | `physics/tests/` |
| `physics/sims/sensors_pybullet.py`, `imu_jsbsim.py` | `physics/sims/` |
| `godot/sensors/*.gd`, `ray_bench.tscn` | `godot/sensors/` |
| `godot/sensors_demo.gd`, `sensors_demo.tscn` | `godot/` |
| `tools/plot_sensors.py`, `compare_runs.py` | `tools/` |

The scripts expect the Module 4/5 files to be present already: `physics/robosim/{frames,protocol,bridge,logger}.py`, `godot/bridge/{protocol.gd,sim_bridge.gd}`, and `physics/aircraft/quad_rpy/` (from `reference/code/aircraft`).

## How to run

```bash
cd ~/robosim/godot && ~/tools/godot --headless --path . --import          # once, for the class_name scripts
cd ~/robosim/physics && python tests/test_sensors.py                      # 16 tests
~/tools/godot --path ~/robosim/godot res://sensors_demo.tscn -- --quit-when-stale   # terminal 1
cd ~/robosim/physics && python sims/sensors_pybullet.py --seed 42                   # terminal 2
cd ~/robosim && python tools/plot_sensors.py logs/<run>
python tools/compare_runs.py logs/<runA> logs/<runB>
cd ~/robosim/physics && python sims/imu_jsbsim.py
~/tools/godot --headless --path ~/robosim/godot res://sensors/ray_bench.tscn
```

`sensors_demo.tscn` accepts `-- --listen=PORT --physics=PORT` and `sensors_pybullet.py` accepts `--viewer-port/--listen-port`, so you can run it next to another scenario. The defaults are 9001/9002.

## What was verified (Godot 4.7.2 headless, Python 3.11, PyBullet 3.2.x, JSBSim 1.3.1, numpy 2.4)

All of the following ran on the course test machine (Intel Xeon 2.1 GHz, 2 cores), with ports 9180/9181:

- `test_sensors.py`: 16/16 pass. A PyBullet box at rest read (0.000002, −0.00008, 9.80665) m/s² in FLU, and the same box on its side read (−0.00002, 9.80665, 0.0002). JSBSim `quad_rpy` on the ground read `a-pilot-z` = −32.136 ft/s² (+9.795 m/s² FLU).
- Full run, Godot headless + `sensors_pybullet.py`, both start orders (Godot first, Python first), five runs, the last one from a fresh copy assembled from reference/ + this folder:
  - 241 range samples, 121 lidar scans, 361 contact samples per run; 0 unmatched packets
  - matched range error 2.2 × 10⁻⁶ m; lidar max error 2.3 × 10⁻⁵ m, 0 hit/miss mismatches out of 21 780 rays
  - range error with the newest pose instead: 1.9 cm RMS, 3.5–7.4 cm max (1.5 m/s)
  - sensor packets arrived 21–32 ms (mean) after their pose, max 29–117 ms (sim time)
  - contact: 45 hits, 0 disagreements with the analytic rover/curb overlap; depth equal to the analytic overlap within 1 × 10⁻⁶ m; `Area3D.body_entered` fired once, matching one 0→1 transition in the packets
  - lidar cost 1.6–2.9 µs per ray (0.29–0.53 ms per 180-ray scan; the slowest was a run right after a fresh import)
- `compare_runs.py`: two seed-42 runs with the viewer were identical in all 8 streams (ignoring `t_wall`, `t_arrive`, `range_expected_latest`). Seed 7 vs 42: imu, baro, mag and gps different, pose identical.
- `ray_bench.tscn`: the numbers in [04](../04_godot_range_lidar_contact.md), with Godot Physics and with Jolt (set by adding `3d/physics_engine` under `[physics]` in a copy of `project.godot`).
- The `ShapeCast3D` snippet in 04 and the JSBSim `<accelerometer>`/`<gyro>` XML in 02 were tested in throwaway projects; they are not part of these files. The battery/RPM snippet in 03 was run once standalone.
- `plot_sensors.py` produced `../img/sensors_expected.png` from a real run.

## Not tested here

- Running `sensors_demo.tscn` with a window: only headless runs were automated. The demo's camera and light are untested visually.
- Adding the sensors to a `main.tscn` from Modules 1–5 in the editor: the scripts make no assumption about that scene except that each sensor is a direct child of the vehicle node and that *Bridge Path* points to a `SimBridge`.
- pytest: not installed on the test machine. The test file is pytest-compatible (plain `test_*` functions) but was only run with `python tests/test_sensors.py`.
