class_name RsRangeSensor
extends Node3D
## Forward rangefinder: one RayCast3D, fired at the EXACT pose the physics process sent.
## Put this node as a direct child of the vehicle node. Its local transform is the mount:
## the ray starts at its origin and points along its -Z (like a camera).
## Publishes SENSOR_RANGE [distance_m] (inf = no hit), tagged with the pose's t_sim.

@export var bridge_path: NodePath
@export var vehicle_id := 1
@export var rate_hz := 20.0
@export var max_range := 30.0
@export_flags_3d_physics var collision_mask := 0b11    ## layer 1 terrain, layer 2 obstacles

var last_range := INF            ## newest ideal distance, for the HUD
var last_t_sim := -1.0

var _bridge: SimBridge
var _clock: RsSensorClock
var _queue: Array[Dictionary] = []
var _ray := RayCast3D.new()


func _ready() -> void:
	_bridge = get_node(bridge_path) as SimBridge
	_clock = RsSensorClock.new(rate_hz)
	_bridge.pose_received.connect(_on_pose)
	_bridge.physics_reset.connect(_on_reset)
	_ray.top_level = true                     # we place it ourselves, at the physics pose
	_ray.enabled = false                      # no automatic update; we call force_raycast_update()
	_ray.target_position = Vector3(0, 0, -max_range)
	_ray.collision_mask = collision_mask
	add_child(_ray)


func _on_reset() -> void:
	_clock.reset()
	_queue.clear()


func _on_pose(id: int, msg: Dictionary) -> void:
	if id == vehicle_id and _clock.due(msg.t_sim):
		_queue.append(msg)                    # query in _physics_process, where the space is safe to use


func _physics_process(_delta: float) -> void:
	for msg in _queue:
		var vehicle_xf := Transform3D(Basis(msg.quat), msg.pos)
		_ray.global_transform = vehicle_xf * transform          # pose * mount
		_ray.force_raycast_update()
		var d := INF
		if _ray.is_colliding():
			d = _ray.global_position.distance_to(_ray.get_collision_point())
		last_range = d
		last_t_sim = msg.t_sim
		_bridge.send_sensor(msg.t_sim, vehicle_id, RsProtocol.SENSOR_RANGE, PackedFloat32Array([d]))
	_queue.clear()
