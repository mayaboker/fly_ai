class_name RsContactSensor
extends Area3D
## Bumper / contact sensor for obstacles that exist ONLY in Godot (the physics engine
## does not know about them). Give it a CollisionShape3D child, like any Area3D.
## Every 1/rate_hz of sim time it asks the physics space "does my shape, placed at the exact
## physics pose, touch anything?" and publishes SENSOR_CONTACT [hit, nx, ny, nz, depth_m]
## (normal in the Godot world frame), tagged with the pose's t_sim.
## The Area3D's own body_entered/body_exited signals still work (for UI, sounds);
## they are not used for the packet because they arrive one physics step later.

@export var bridge_path: NodePath
@export var vehicle_id := 1
@export var rate_hz := 30.0
@export_flags_3d_physics var obstacle_mask := 0b10    ## layer 2 obstacles (not the ground)

var in_contact := false

var _bridge: SimBridge
var _clock: RsSensorClock
var _queue: Array[Dictionary] = []
var _mount := Transform3D.IDENTITY
var _shape_node: CollisionShape3D
var _params := PhysicsShapeQueryParameters3D.new()


func _ready() -> void:
	_bridge = get_node(bridge_path) as SimBridge
	_clock = RsSensorClock.new(rate_hz)
	_bridge.pose_received.connect(_on_pose)
	_bridge.physics_reset.connect(func() -> void: _clock.reset(); _queue.clear())
	for c in get_children():
		if c is CollisionShape3D:
			_shape_node = c
	assert(_shape_node != null, "RsContactSensor needs a CollisionShape3D child")
	_mount = transform              # remember the mount, then place ourselves in world coordinates
	top_level = true
	collision_layer = 0             # nothing should detect the sensor itself
	collision_mask = obstacle_mask
	_params.shape = _shape_node.shape
	_params.collision_mask = obstacle_mask
	_params.margin = 0.0


func _on_pose(id: int, msg: Dictionary) -> void:
	if id == vehicle_id and _clock.due(msg.t_sim):
		_queue.append(msg)


func _physics_process(_delta: float) -> void:
	if _queue.is_empty():
		return
	var space := get_world_3d().direct_space_state
	for msg in _queue:
		global_transform = Transform3D(Basis(msg.quat), msg.pos) * _mount   # keeps the signals in sync too
		_params.transform = global_transform * _shape_node.transform
		var values := PackedFloat32Array([0, 0, 0, 0, 0])
		var info := space.get_rest_info(_params)
		if not info.is_empty():
			var depth := 0.0
			var pts := space.collide_shape(_params, 8)      # pairs: point on our shape, point on obstacle
			for k in range(0, pts.size() - 1, 2):
				depth = maxf(depth, pts[k].distance_to(pts[k + 1]))
			var n: Vector3 = info.normal
			values = PackedFloat32Array([1, n.x, n.y, n.z, depth])
		in_contact = values[0] > 0.5
		_bridge.send_sensor(msg.t_sim, vehicle_id, RsProtocol.SENSOR_CONTACT, values)
	_queue.clear()
