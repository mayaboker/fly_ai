class_name RsLidar2D
extends Node3D
## Planar lidar: n_rays rays in this node's local XZ plane, fired at the EXACT physics pose.
## Ray i points at angle a_i = -fov/2 + (i + 0.5) * fov / n_rays, measured from -Z (forward)
## and positive toward -X (left), like a ROS LaserScan (counter-clockwise seen from above).
## Publishes SENSOR_RANGE with n_rays distances (inf = no hit), tagged with the pose's t_sim.

@export var bridge_path: NodePath
@export var vehicle_id := 1
@export var rate_hz := 10.0
@export var n_rays := 180
@export var fov_deg := 180.0
@export var max_range := 30.0
@export_flags_3d_physics var collision_mask := 0b11

var last_scan := PackedFloat32Array()
var last_t_sim := -1.0
var scans := 0
var total_usec := 0              ## time spent in intersect_ray loops, for the cost report

var _bridge: SimBridge
var _clock: RsSensorClock
var _queue: Array[Dictionary] = []
var _dirs: Array[Vector3] = []   # unit ray directions in the sensor frame
var _query := PhysicsRayQueryParameters3D.new()


func _ready() -> void:
	_bridge = get_node(bridge_path) as SimBridge
	_clock = RsSensorClock.new(rate_hz)
	_bridge.pose_received.connect(_on_pose)
	_bridge.physics_reset.connect(func() -> void: _clock.reset(); _queue.clear())
	var fov := deg_to_rad(fov_deg)
	for i in n_rays:
		var a := -fov / 2.0 + (i + 0.5) * fov / n_rays
		_dirs.append(Vector3(-sin(a), 0.0, -cos(a)))
	_query.collision_mask = collision_mask
	last_scan.resize(n_rays)


func _on_pose(id: int, msg: Dictionary) -> void:
	if id == vehicle_id and _clock.due(msg.t_sim):
		_queue.append(msg)


func _physics_process(_delta: float) -> void:
	if _queue.is_empty():
		return
	var space := get_world_3d().direct_space_state
	for msg in _queue:
		var xf := Transform3D(Basis(msg.quat), msg.pos) * transform      # pose * mount
		var t0 := Time.get_ticks_usec()
		for i in n_rays:
			_query.from = xf.origin
			_query.to = xf.origin + xf.basis * (_dirs[i] * max_range)
			var hit := space.intersect_ray(_query)
			last_scan[i] = INF if hit.is_empty() else xf.origin.distance_to(hit.position)
		total_usec += Time.get_ticks_usec() - t0
		scans += 1
		last_t_sim = msg.t_sim
		_bridge.send_sensor(msg.t_sim, vehicle_id, RsProtocol.SENSOR_RANGE, last_scan)
	_queue.clear()
