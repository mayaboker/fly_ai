class_name RsSensorClock
extends RefCounted
## Decides which incoming poses a sensor samples, using SIM time (t_sim), not wall time.
## Sample instants are k / rate_hz, so a 20 Hz sensor fires on every 3rd pose of a 60 Hz stream
## no matter how fast or slow Godot renders.

var rate_hz: float
var _next_t := 0.0


func _init(hz: float) -> void:
	rate_hz = hz


## True when this pose should be sampled. Call once per received pose.
func due(t_sim: float) -> bool:
	if t_sim + 1e-9 < _next_t:
		return false
	_next_t = (floorf(t_sim * rate_hz + 1e-6) + 1.0) / rate_hz
	return true


## Call when the physics process resets (sim time jumps back).
func reset() -> void:
	_next_t = 0.0
