extends Node3D
## Ray-cast cost on THIS machine. Run headless:
##   godot --headless --path godot res://sensors/ray_bench.tscn
## Prints microseconds per 1000 queries for intersect_ray, RayCast3D and ShapeCast3D
## against three worlds: the sensor range, the range plus 500 boxes, and a 257x257 heightmap.
## Treat the numbers as a rough indicator: they change with CPU, physics engine and scene.

const N := 1000
const REPEAT := 5


func _ready() -> void:
	print("physics engine setting: ", ProjectSettings.get_setting("physics/3d/physics_engine"))
	var rng := RandomNumberGenerator.new()
	rng.seed = 1
	# world 1: floor + wall + 4 pillars (like sensors_demo)
	_add(_box(Vector3(60, 0.2, 60)), Vector3(0, -0.1, 0))
	_add(_box(Vector3(0.2, 2, 20)), Vector3(15, 1, 0))
	for p in [Vector3(5, 1, -5), Vector3(5, 1, 5), Vector3(9, 1, -5), Vector3(9, 1, 5)]:
		var c := CylinderShape3D.new()
		c.radius = 0.3
		_add(c, p)
	await _settle()
	_bench("range scene (6 shapes)", rng)
	# world 2: + 500 random boxes
	for i in 500:
		_add(_box(Vector3(0.5, 1, 0.5)), Vector3(rng.randf_range(-28, 28), 0.5, rng.randf_range(-28, 28)))
	await _settle()
	_bench("range + 500 boxes", rng)
	# world 3: heightmap terrain only
	for c in get_children():
		c.queue_free()
	var hm := HeightMapShape3D.new()
	hm.map_width = 257
	hm.map_depth = 257
	var data := PackedFloat32Array()
	data.resize(257 * 257)
	for r in 257:
		for q in 257:
			data[r * 257 + q] = 5.0 * sin(q * 0.05) * cos(r * 0.07) + 5.0
	hm.map_data = data
	_add(hm, Vector3.ZERO)
	await _settle()
	_bench("heightmap 257x257", rng)
	get_tree().quit()


func _box(s: Vector3) -> BoxShape3D:
	var b := BoxShape3D.new()
	b.size = s
	return b


func _add(shape: Shape3D, pos: Vector3) -> void:
	var body := StaticBody3D.new()
	body.position = pos
	var cs := CollisionShape3D.new()
	cs.shape = shape
	body.add_child(cs)
	add_child(body)


func _settle() -> void:
	for i in 3:
		await get_tree().physics_frame


func _bench(label: String, rng: RandomNumberGenerator) -> void:
	var space := get_world_3d().direct_space_state
	# random horizontal rays from near the middle, 30 m long, 0.3 m above the ground (lidar-like)
	var from := []
	var to := []
	for i in N:
		var o := Vector3(rng.randf_range(-3, 3), 11.0 if label.begins_with("height") else 0.3, rng.randf_range(-3, 3))
		var a := rng.randf_range(0, TAU)
		var d := Vector3(cos(a), -0.4 if label.begins_with("height") else 0.0, sin(a)).normalized()
		from.append(o)
		to.append(o + d * 30.0)
	var q := PhysicsRayQueryParameters3D.new()
	var best := INF
	var hits := 0
	for rep in REPEAT:
		hits = 0
		var t0 := Time.get_ticks_usec()
		for i in N:
			q.from = from[i]
			q.to = to[i]
			if not space.intersect_ray(q).is_empty():
				hits += 1
		best = minf(best, Time.get_ticks_usec() - t0)
	var ray_us := best
	# RayCast3D node, moved and forced each time
	var rc := RayCast3D.new()
	rc.enabled = false
	add_child(rc)
	best = INF
	for rep in REPEAT:
		var t0 := Time.get_ticks_usec()
		for i in N:
			rc.global_position = from[i]
			rc.target_position = to[i] - from[i]
			rc.force_raycast_update()
		best = minf(best, Time.get_ticks_usec() - t0)
	var rc_us := best
	rc.queue_free()
	# ShapeCast3D, 0.25 m sphere swept 5 m (proximity sensor)
	var sc := ShapeCast3D.new()
	var sph := SphereShape3D.new()
	sph.radius = 0.25
	sc.shape = sph
	sc.enabled = false
	add_child(sc)
	best = INF
	for rep in REPEAT:
		var t0 := Time.get_ticks_usec()
		for i in N:
			sc.global_position = from[i]
			sc.target_position = (to[i] - from[i]) / 6.0
			sc.force_shapecast_update()
		best = minf(best, Time.get_ticks_usec() - t0)
	var sc_us := best
	sc.queue_free()
	print("BENCH %-24s hits=%4d/1000  intersect_ray %6.0f us/1000   RayCast3D %6.0f us/1000   ShapeCast3D(5 m sphere) %6.0f us/1000" % [
			label, hits, ray_us, rc_us, sc_us])
