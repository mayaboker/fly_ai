extends Node3D
## Module 8 sensor range: a floor, a wall, four pillars and a low curb, plus a rover
## (vehicle id 1) that carries a forward range sensor, a 2D lidar and a contact sensor.
## The rover's pose comes from the physics process; the sensors answer over the bridge.
## Run:  godot --path godot res://sensors_demo.tscn   [-- --listen=9001 --physics=9002 --quit-when-stale]

const LAYER_TERRAIN := 1
const LAYER_OBSTACLE := 2

var bridge: SimBridge
var rover: Node3D
var lidar: RsLidar2D
var range_sensor: RsRangeSensor
var contact: RsContactSensor
var _quit_when_stale := false
var _seen_pose := false
var _area_enters := 0           # Area3D signal count, for comparison with the packets


func _ready() -> void:
	var listen := RsProtocol.PORT_TO_VIEWER
	var physics := RsProtocol.PORT_TO_PHYSICS
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--listen="):
			listen = int(a.get_slice("=", 1))
		elif a.begins_with("--physics="):
			physics = int(a.get_slice("=", 1))
		elif a == "--quit-when-stale":
			_quit_when_stale = true
	Engine.max_fps = 60

	bridge = SimBridge.new()
	bridge.name = "SimBridge"
	bridge.listen_port = listen            # exports must be set before the node enters the tree
	bridge.physics_port = physics
	add_child(bridge)

	_build_world()
	_build_rover()
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-50, 30, 0)
	add_child(light)
	var cam := Camera3D.new()
	cam.position = Vector3(6, 14, 10)
	add_child(cam)
	cam.look_at(Vector3(8, 0, 0))


## ENU (east, north, up) -> Godot (x, y, z) = (E, U, -N). See reference/frames.md.
static func enu(e: float, n: float, u: float) -> Vector3:
	return Vector3(e, u, -n)


func _add_static(shape: Shape3D, pos: Vector3, layer: int, color: Color) -> void:
	var body := StaticBody3D.new()
	body.collision_layer = layer
	body.collision_mask = 0
	body.position = pos
	var cs := CollisionShape3D.new()
	cs.shape = shape
	body.add_child(cs)
	var mi := MeshInstance3D.new()
	if shape is BoxShape3D:
		var m := BoxMesh.new()
		m.size = shape.size
		mi.mesh = m
	elif shape is CylinderShape3D:
		var m := CylinderMesh.new()
		m.top_radius = shape.radius
		m.bottom_radius = shape.radius
		m.height = shape.height
		mi.mesh = m
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mi.material_override = mat
	body.add_child(mi)
	add_child(body)


func _box(size: Vector3) -> BoxShape3D:
	var b := BoxShape3D.new()
	b.size = size
	return b


func _build_world() -> void:
	_add_static(_box(Vector3(60, 0.2, 60)), Vector3(0, -0.1, 0), LAYER_TERRAIN, Color(0.4, 0.5, 0.35))
	# wall: 0.2 m thick, its west face at E = 14.9
	_add_static(_box(Vector3(0.2, 2, 20)), enu(15, 0, 1), LAYER_OBSTACLE, Color(0.7, 0.7, 0.7))
	for p in [Vector2(5, 5), Vector2(5, -5), Vector2(9, 5), Vector2(9, -5)]:
		var c := CylinderShape3D.new()
		c.radius = 0.3
		c.height = 2.0
		_add_static(c, enu(p.x, p.y, 1), LAYER_OBSTACLE, Color(0.8, 0.4, 0.2))
	# curb: E 4..14, N 0.30..0.65, 0.1 m high (below the range and lidar rays)
	_add_static(_box(Vector3(10, 0.1, 0.35)), enu(9, 0.475, 0.05), LAYER_OBSTACLE, Color(0.9, 0.9, 0.2))


func _build_rover() -> void:
	rover = Node3D.new()
	rover.name = "Rover"
	add_child(rover)
	var body := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.4, 0.3, 0.6)      # model frame: x right, y up, z back
	body.mesh = bm
	rover.add_child(body)

	range_sensor = RsRangeSensor.new()
	range_sensor.position = Vector3(0, 0.05, -0.3)     # nose, looking along -Z (forward)
	range_sensor.bridge_path = bridge.get_path()
	rover.add_child(range_sensor)

	lidar = RsLidar2D.new()
	lidar.position = Vector3(0, 0.2, 0)                 # on the roof
	lidar.bridge_path = bridge.get_path()
	rover.add_child(lidar)

	contact = RsContactSensor.new()
	contact.bridge_path = bridge.get_path()
	var cs := CollisionShape3D.new()
	cs.shape = _box(Vector3(0.4, 0.3, 0.6))            # the rover's own box
	contact.add_child(cs)
	rover.add_child(contact)
	contact.body_entered.connect(func(_b: Node3D) -> void: _area_enters += 1)


func _process(_delta: float) -> void:
	if bridge.has_vehicle(1):
		_seen_pose = true
		rover.transform = bridge.sample(1, bridge.latest_t_sim - 1.0 / 60.0)   # visuals only
	if _quit_when_stale and _seen_pose and bridge.is_stale():
		_report()
		get_tree().quit()


func _report() -> void:
	if lidar.scans > 0:
		var per_ray := float(lidar.total_usec) / (lidar.scans * lidar.n_rays)
		print("SENSORS lidar_scans=%d  mean_scan_ms=%.3f  us_per_ray=%.2f  us_per_1000_rays=%.0f" % [
				lidar.scans, lidar.total_usec / 1000.0 / lidar.scans, per_ray, per_ray * 1000.0])
	print("SENSORS area_body_entered_signals=%d" % _area_enters)
	print("SENSORS last_range=%.3f at t_sim=%.4f" % [range_sensor.last_range, range_sensor.last_t_sim])
