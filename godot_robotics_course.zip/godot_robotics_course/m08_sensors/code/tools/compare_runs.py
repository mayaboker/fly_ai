"""
compare_runs.py - are two runs bit-identical? (Module 8 Check: same seed -> same measurements)

    python tools/compare_runs.py logs/<run A> logs/<run B>

Columns that depend on WALL time (t_wall, t_arrive, range_expected_latest) are ignored:
they change with machine load, not with the seed.
"""
import csv, os, sys

IGNORE = {"t_wall", "t_arrive", "range_expected_latest"}


def rows(run, stream):
    with open(os.path.join(run, stream)) as f:
        return [{k: v for k, v in r.items() if k not in IGNORE} for r in csv.DictReader(f)]


def main(a, b):
    same = True
    for stream in sorted(f for f in os.listdir(a) if f.endswith(".csv")):
        if not os.path.exists(os.path.join(b, stream)):
            print(f"  {stream:12s} missing in B"); same = False; continue
        ra, rb = rows(a, stream), rows(b, stream)
        ok = ra == rb
        same &= ok
        print(f"  {stream:12s} {len(ra):6d} rows  {'identical' if ok else 'DIFFERENT'}")
    print("RESULT:", "identical" if same else "different")
    return 0 if same else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2]))
