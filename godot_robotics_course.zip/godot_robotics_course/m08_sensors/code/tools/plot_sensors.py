"""
plot_sensors.py - truth vs measurement for one Module 8 run.

    python tools/plot_sensors.py logs/<run>          # writes logs/<run>/sensors.png
"""
import math, os, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

TRUTH, MEAS, ACCENT = "#52514e", "#2a78d6", "#eb6834"


def load(run, stream):
    return np.genfromtxt(os.path.join(run, f"{stream}.csv"), delimiter=",", names=True)


def style(ax, title, ylabel):
    ax.set_title(title, fontsize=10, loc="left")
    ax.set_ylabel(ylabel, fontsize=9)
    ax.grid(True, color="#e4e3df", linewidth=0.6)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.tick_params(labelsize=8)


def main(run):
    imu, baro, gps = load(run, "imu"), load(run, "baro"), load(run, "gps")
    fig, axs = plt.subplots(3, 2, figsize=(11, 9.5))
    a = axs[0, 0]
    a.plot(imu["t_sim"], imu["ax_meas"], color=MEAS, lw=0.6, label="measured")
    a.plot(imu["t_sim"], imu["ax_true"], color=TRUTH, lw=1.5, label="truth")
    style(a, "Accelerometer, forward (x, FLU)", "m/s²"); a.legend(fontsize=8, frameon=False)
    a = axs[0, 1]
    a.plot(imu["t_sim"], imu["gz_meas"], color=MEAS, lw=0.6, label="measured")
    a.plot(imu["t_sim"], imu["gz_true"], color=TRUTH, lw=1.5, label="truth")
    style(a, "Gyro, yaw rate (z, FLU)", "rad/s"); a.legend(fontsize=8, frameon=False)
    a = axs[1, 0]
    a.plot(baro["t_sim"], baro["alt_meas"], color=MEAS, lw=0.8, label="measured")
    a.plot(baro["t_sim"], baro["alt_true"], color=TRUTH, lw=1.5, label="truth")
    style(a, "Barometric altitude (bias + noise)", "m"); a.legend(fontsize=8, frameon=False)
    a = axs[1, 1]
    a.plot(gps["t_sim"], gps["e_meas"] - gps["e_true"], "o-", ms=3, lw=0.8, color=MEAS, label="east error")
    a.plot(gps["t_sim"], gps["n_meas"] - gps["n_true"], "s-", ms=3, lw=0.8, color=ACCENT, label="north error")
    a.axhline(0, color=TRUTH, lw=0.8)
    style(a, "GPS error at time of validity (5 Hz, 150 ms late)", "m"); a.legend(fontsize=8, frameon=False)
    if os.path.exists(os.path.join(run, "range.csv")):
        rng = load(run, "range")
        a = axs[2, 0]
        a.plot(rng["t_sim"], rng["range_meas"], "o", ms=2.5, color=MEAS, label="measured (noise added)")
        a.plot(rng["t_sim"], rng["range_true"], color=TRUTH, lw=1.5, label="Godot ideal (truth)")
        style(a, "Forward range sensor (Godot RayCast3D)", "m"); a.set_xlabel("t_sim (s)", fontsize=9)
        a.legend(fontsize=8, frameon=False)
    if os.path.exists(os.path.join(run, "lidar.csv")):
        lid, pose = load(run, "lidar"), load(run, "pose")
        k = int(np.argmin(np.abs(lid["t_sim"] - 6.0)))           # one scan, near t = 6 s
        t = lid["t_sim"][k]
        j = int(np.argmin(np.abs(pose["t_sim"] - t)))
        e0, n0, yaw = pose["e"][j], pose["n"][j], math.radians(pose["yaw_deg"][j])
        n = 180
        ang = -math.pi / 2 + (np.arange(n) + 0.5) * math.pi / n
        r = np.array([lid[f"r{i:03d}_meas"][k] for i in range(n)])
        ok = np.isfinite(r)
        a = axs[2, 1]
        a.plot(e0 + r[ok] * np.cos(yaw + ang[ok]), n0 + r[ok] * np.sin(yaw + ang[ok]), ".", ms=3, color=MEAS,
               label=f"lidar hits, t_sim = {t:.2f} s")
        a.plot([e0], [n0], "^", ms=8, color=ACCENT, label="rover (pose matched by t_sim)")
        a.plot([14.9, 14.9], [-10, 10], color=TRUTH, lw=1.0, label="wall face (ground truth)")
        for cx, cy in [(5, 5), (5, -5), (9, 5), (9, -5)]:
            a.add_patch(plt.Circle((cx, cy), 0.3, fill=False, color=TRUTH, lw=1.0))
        a.set_aspect("equal"); a.set_xlim(-12, 17); a.set_ylim(-11, 11)
        style(a, "2D lidar scan, top view (ENU)", "north (m)"); a.set_xlabel("east (m)", fontsize=9)
        a.legend(fontsize=7, frameon=False, loc="center left")
    fig.tight_layout()
    out = os.path.join(run, "sensors.png")
    fig.savefig(out, dpi=110)
    print("wrote", out)


if __name__ == "__main__":
    main(sys.argv[1])
