"""
test_sensors.py - Module 8 checks for robosim/sensors.py.

Run from the physics/ folder:   python tests/test_sensors.py      (or: pytest tests/test_sensors.py)
"""
import os, sys, math
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PHYS = os.path.dirname(HERE)
sys.path.insert(0, PHYS)
from robosim.sensors import (Imu, RangeNoise, ImuTruthFD, imu_truth_jsbsim, Barometer, Magnetometer, Gps, AirData,
                             ErrorModel, PoseHistory, interp_series, isa_pressure, isa_altitude, make_rng,
                             terrain_range_down, G0)
from robosim.frames import quat_to_matrix


# ------------------------------------------------------------------ helpers
def _pybullet_resting_imu(start_orn, seconds=1.5):
    """Drop a box on a plane, let it settle, return the mean ideal IMU reading (FLU)."""
    import pybullet as p
    cid = p.connect(p.DIRECT)
    p.setGravity(0, 0, -G0, physicsClientId=cid)
    p.setTimeStep(1 / 240, physicsClientId=cid)
    plane = p.createCollisionShape(p.GEOM_PLANE, physicsClientId=cid)
    p.createMultiBody(0, plane, physicsClientId=cid)
    box = p.createCollisionShape(p.GEOM_BOX, halfExtents=[0.3, 0.2, 0.15], physicsClientId=cid)
    body = p.createMultiBody(2.0, box, basePosition=[0, 0, 0.5], baseOrientation=start_orn,
                             physicsClientId=cid)
    imu, f_all, w_all = ImuTruthFD(), [], []
    n = int(seconds * 240)
    for k in range(1, n + 1):
        p.stepSimulation(physicsClientId=cid)
        t = k / 240
        _, q = p.getBasePositionAndOrientation(body, physicsClientId=cid)
        v, w = p.getBaseVelocity(body, physicsClientId=cid)
        f, wb = imu.update(t, v, w, quat_to_matrix(q))
        if t > seconds - 0.5:
            f_all.append(f); w_all.append(wb)
    p.disconnect(cid)
    return np.mean(f_all, axis=0), np.mean(w_all, axis=0)


def _trajectory_run(seed, extra_sensor=False):
    """Feed a synthetic trajectory through every sensor; return all measurements as one array."""
    imu, baro = Imu(seed), Barometer(seed)
    mag, gps, air = Magnetometer(seed), Gps(seed), AirData(seed)
    if extra_sensor:
        Imu(seed, name="imu2")          # a second IMU must not disturb the first
    out = []
    for k in range(240 * 5):
        t = k / 240
        R = np.eye(3)
        f = np.array([0.1 * math.sin(t), 0.0, G0])
        w = np.array([0.0, 0.0, 0.2])
        for _, s in imu.step(t, f, w):
            out += list(s["acc"]) + list(s["gyr"])
        for _, s in baro.step(t, 10 + t):
            out.append(s["p_pa"])
        for _, s in mag.step(t, R):
            out += list(s["mag_uT"])
        for tv, s in gps.step(t, [t, 0, 10], [1, 0, 0]):
            out += [tv] + list(s["pos_enu"])
        for _, s in air.step(t, [15, 0, -1]):
            out += [s["airspeed_mps"], s["alpha_rad"]]
    return np.array(out)


# ------------------------------------------------------------------ the Check
def test_stationary_accel_pybullet_level():
    """At rest the accelerometer reads +g UP: (0, 0, +9.81) in FLU."""
    f, w = _pybullet_resting_imu([0, 0, 0, 1])
    assert np.allclose(f, [0, 0, G0], atol=0.02), f
    assert np.allclose(w, 0, atol=1e-3), w


def test_stationary_accel_pybullet_on_side():
    """Box rolled +90 deg about its x axis: body +y now points up, so +g shows on y."""
    s = math.sin(math.pi / 4)
    f, _ = _pybullet_resting_imu([s, 0, 0, s])
    assert np.allclose(f, [0, G0, 0], atol=0.02), f


def test_free_fall_reads_zero():
    """In free fall the specific force is zero (the IMU cannot feel gravity)."""
    imu = ImuTruthFD()
    g = np.array([0, 0, -G0])
    for k in range(1, 50):
        t = k / 240
        f, _ = imu.update(t, g * t, [0, 0, 0], np.eye(3))
    assert np.allclose(f, 0, atol=1e-9), f


def test_stationary_accel_jsbsim():
    """JSBSim quad_rpy on the ground: a-pilot-z about -32.1 ft/s^2 (FRD), i.e. +9.8 m/s^2 up in FLU."""
    import jsbsim
    fdm = jsbsim.FGFDMExec(PHYS)            # aircraft/quad_rpy lives under physics/
    fdm.set_debug_level(0)
    fdm.load_model("quad_rpy")
    fdm.load_ic("ground", True)
    fdm.set_dt(1 / 120)
    fdm.run_ic()
    for _ in range(240):
        fdm.run()
    az = fdm["accelerations/a-pilot-z-ft_sec2"]
    assert -32.3 < az < -32.0, az
    f, w = imu_truth_jsbsim(fdm)
    assert abs(f[2] - 9.79) < 0.03 and abs(f[0]) < 0.01 and abs(f[1]) < 0.01, f
    assert np.allclose(w, 0, atol=1e-5), w


def test_seed_reproducible():
    a, b, c = _trajectory_run(42), _trajectory_run(42), _trajectory_run(43)
    assert a.size > 1000
    assert np.array_equal(a, b), "same seed must give bit-identical measurements"
    assert not np.array_equal(a, c), "different seed must give different measurements"
    assert np.array_equal(a, _trajectory_run(42, extra_sensor=True)), "adding a sensor changed another"


# ------------------------------------------------------------------ error-model sanity
def test_white_noise_std():
    imu = Imu(1, accel=dict(sigma=0.05), gyro=dict(sigma=0.003))
    acc = np.array([s["acc"] for k in range(20000) for _, s in imu.step(k / 240, [0, 0, G0], [0, 0, 0])])
    assert np.allclose(acc.mean(0), [0, 0, G0], atol=0.003)
    assert np.allclose(acc.std(0), 0.05, rtol=0.05), acc.std(0)


def test_bias_random_walk_growth():
    """Bias random walk: std after T seconds = bias_rw * sqrt(T)."""
    rng, T, dt, runs = make_rng(7, "rw"), 10.0, 0.01, 400
    finals = []
    for _ in range(runs):
        m = ErrorModel(rng, 1, bias_rw=0.01)
        for _ in range(int(T / dt)):
            m.apply([0.0], dt)
        finals.append(m.bias[0])
    assert abs(np.std(finals) / (0.01 * math.sqrt(T)) - 1) < 0.12, np.std(finals)


def test_quantization():
    m = ErrorModel(make_rng(3, "q"), 3, sigma=0.1, quant=0.01)
    y = m.apply([1.23456, -2.0, 0.0], 0.01)
    assert np.allclose(np.round(y / 0.01) * 0.01, y, atol=1e-12)


def test_gps_rate_and_latency():
    gps = Gps(5, rate_hz=5.0, latency_s=0.15)
    got = []
    for k in range(240 * 10 + 1):
        t = k / 240
        for tv, s in gps.step(t, [0, 0, 0], [0, 0, 0]):
            got.append((t, tv, s["pos_enu"]))
    assert len(got) == 50, len(got)                       # 5 Hz for 10 s (last one still in flight)
    delays = np.array([t - tv for t, tv, _ in got])
    assert np.all(delays >= 0.15 - 1e-9) and np.all(delays < 0.15 + 1 / 240 + 1e-9), delays
    assert np.allclose(np.diff([tv for _, tv, _ in got]), 0.2)
    err = np.array([p for *_, p in got])
    assert np.all(np.abs(err[:, :2]) < 8.0)               # a few sigma of 1.5 m


def test_baro():
    assert abs(isa_pressure(0) - 101325) < 1e-6
    assert abs(isa_altitude(isa_pressure(1234.5)) - 1234.5) < 1e-6
    b = Barometer(9, bias_sigma_pa=0, bias_rw_pa=0)
    alts = np.array([s["alt_m"] for k in range(5000) for _, s in b.step(k / 50, 100.0)])
    assert abs(alts.mean() - 100) < 0.02 and 0.08 < alts.std() < 0.18, (alts.mean(), alts.std())


def test_mag_heading():
    """Identity pose = nose EAST (PyBullet convention): north is on the body's left (+y).
    Yaw +90 deg about ENU z = nose NORTH: north is straight ahead (+x). Down part stays on -z."""
    m = Magnetometer(1, sigma_uT=0, hard_iron_uT=0, scale_sigma=0, field_enu=[0, 20, -40])
    (_, s), = m.step(0.0, np.eye(3))
    assert np.allclose(s["mag_uT"], [0, 20, -40]), s
    R = np.array([[0, -1, 0], [1, 0, 0], [0, 0, 1]], float)     # yaw +90: body x -> ENU north
    (_, s), = m.step(1.0, R)
    assert np.allclose(s["mag_uT"], [20, 0, -40]), s


def test_airdata_alpha():
    a = AirData(1, sigma_mps=0, sigma_ang_rad=0)
    (_, s), = a.step(0.0, [20 * math.cos(0.1), 0, -20 * math.sin(0.1)])   # FLU: air coming from below
    assert abs(s["airspeed_mps"] - 20) < 1e-9 and abs(s["alpha_rad"] - 0.1) < 1e-9, s


def test_range_noise():
    a = RangeNoise(4, sigma_m=0.02, quant_m=0.01).apply([5.0] * 5000 + [math.inf])
    assert math.isinf(a[-1]) and abs(a[:-1].mean() - 5) < 0.002 and 0.018 < a[:-1].std() < 0.023
    b = RangeNoise(4, sigma_m=0.02, quant_m=0.01).apply([5.0] * 5000 + [math.inf])
    assert np.array_equal(a, b)


def test_terrain_rangefinder():
    flat = lambda e, n: 2.0
    assert abs(terrain_range_down([0, 0, 12], np.eye(3), flat) - 10.0) < 1e-4
    c, s = math.cos(0.3), math.sin(0.3)                            # rolled 0.3 rad
    R = np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
    assert abs(terrain_range_down([0, 0, 12], R, flat) - 10.0 / c) < 1e-4


def test_pose_history():
    h = PoseHistory()
    for k in range(10):
        h.add(k / 60, [k, 0, 0], [0, 0, 0, 1])
    pos, _ = h.exact(5 / 60)
    assert pos[0] == 5
    assert h.exact(5.0001 / 60) is None
    pos, q = h.interp(5.5 / 60)
    assert abs(pos[0] - 5.5) < 1e-9 and np.allclose(q, [0, 0, 0, 1])


def test_interp_series():
    t = np.arange(0, 1.0001, 1 / 240)
    x = np.stack([2 * t, -t], axis=1)
    tq = np.array([0.0333, 0.5, 0.99])
    assert np.allclose(interp_series(tq, t, x), np.stack([2 * tq, -tq], axis=1))


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    for name, fn in tests:
        fn()
        print(f"  ok  {name}")
    print(f"sensors: all {len(tests)} tests pass")
