"""
sensors.py - synthetic vehicle-state sensors for the physics process (Module 8).

Rule of ownership: "would the reading change if I moved a wall?"
  no  -> the sensor lives HERE, in the physics process (IMU, baro, mag, GPS, airspeed)
  yes -> the sensor lives in Godot (range, lidar, contact, cameras)

Every model turns a TRUE value into a MEASURED value:
    meas = (1 + scale_err) * truth + bias(t) + white_noise, then quantized,
    sampled at its own rate and delivered after its own latency.
Truth stays untouched, so you can log both side by side.

Frames: world = ENU, body = FLU (see reference/frames.md). Units: SI.
Stationary convention: an accelerometer at rest reads +g UP (specific force),
i.e. about (0, 0, +9.81) m/s^2 in FLU, and about -32.2 ft/s^2 on z in JSBSim's FRD.

Randomness: every sensor owns its OWN numpy Generator, derived from (seed, sensor name).
Same seed -> bit-identical measurements. Adding a sensor does not change the others.
"""
import math, zlib
from collections import deque
import numpy as np

G0 = 9.80665                 # m/s^2, standard gravity
FT = 0.3048


def make_rng(seed, name):
    """Independent, reproducible random stream for one sensor."""
    return np.random.default_rng([int(seed), zlib.crc32(name.encode())])


# --------------------------------------------------------------------------- error model
class ErrorModel:
    """Error model for an n-axis channel.

    sigma       white noise standard deviation (units of the channel)
    bias_sigma  turn-on bias, drawn once per run: N(0, bias_sigma)
    bias_rw     bias random walk, units per sqrt(second): the bias drifts by N(0, bias_rw*sqrt(dt))
    scale_sigma scale-factor error, drawn once per run: (1 + N(0, scale_sigma))
    quant       quantization step (0 = off), e.g. one LSB of an ADC
    """
    def __init__(self, rng, n=3, sigma=0.0, bias_sigma=0.0, bias_rw=0.0, scale_sigma=0.0, quant=0.0):
        self.rng, self.n = rng, n
        self.sigma, self.bias_rw, self.quant = sigma, bias_rw, quant
        # draw the per-run constants FIRST, in a fixed order -> reproducible
        self.bias = rng.normal(0.0, bias_sigma, n) if bias_sigma > 0 else np.zeros(n)
        self.scale = 1.0 + (rng.normal(0.0, scale_sigma, n) if scale_sigma > 0 else np.zeros(n))

    def apply(self, truth, dt):
        truth = np.asarray(truth, float)
        if self.bias_rw > 0 and dt > 0:
            self.bias = self.bias + self.rng.normal(0.0, self.bias_rw * math.sqrt(dt), self.n)
        y = self.scale * truth + self.bias
        if self.sigma > 0:
            y = y + self.rng.normal(0.0, self.sigma, self.n)
        if self.quant > 0:
            y = np.round(y / self.quant) * self.quant
        return y


# --------------------------------------------------------------------------- rate + latency
class Sampler:
    """Decides WHEN a sensor samples (its own rate) and WHEN the sample is delivered
    (after latency_s). Sample instants are k / rate_hz exactly, so they never drift."""
    def __init__(self, rate_hz, latency_s=0.0):
        self.rate_hz, self.latency_s = rate_hz, latency_s
        self._k = 0
        self._queue = deque()          # (t_deliver, t_valid, value)

    def due(self, t):
        """True once per sample period. Call every physics step with the current t_sim."""
        if t + 1e-9 >= self._k / self.rate_hz:
            self._k = math.floor(t * self.rate_hz + 1e-6) + 1
            return True
        return False

    def push(self, t_valid, value):
        self._queue.append((t_valid + self.latency_s, t_valid, value))

    def pop_ready(self, t):
        """Samples whose delivery time has come: list of (t_valid, value)."""
        out = []
        while self._queue and self._queue[0][0] <= t + 1e-9:
            _, tv, v = self._queue.popleft()
            out.append((tv, v))
        return out


class _Sensor:
    def __init__(self, name, seed, rate_hz, latency_s):
        self.name = name
        self.rng = make_rng(seed, name)
        self.sampler = Sampler(rate_hz, latency_s)
        self._t_last = None

    def _dt(self, t):
        dt = 0.0 if self._t_last is None else t - self._t_last
        self._t_last = t
        return dt

    def step(self, t, *truth):
        """Call every physics step. Returns a list of delivered samples (t_valid, dict).
        Each sample carries the time it is VALID for, not the time it arrived."""
        if self.sampler.due(t):
            self.sampler.push(t, self._measure(t, self._dt(t), *truth))
        return self.sampler.pop_ready(t)


# --------------------------------------------------------------------------- IMU
class Imu(_Sensor):
    """Accelerometer (specific force, m/s^2) + gyro (rad/s), both in the body FLU frame.
    Defaults are roughly a consumer MEMS IMU (MPU-6000 / ICM-42688 class)."""
    def __init__(self, seed, rate_hz=240.0, latency_s=0.0, name="imu",
                 accel=dict(sigma=0.05, bias_sigma=0.05, bias_rw=0.001, scale_sigma=0.005, quant=0.0024),
                 gyro=dict(sigma=0.003, bias_sigma=0.005, bias_rw=0.0001, scale_sigma=0.005, quant=0.0011)):
        super().__init__(name, seed, rate_hz, latency_s)
        self.accel = ErrorModel(self.rng, 3, **accel)
        self.gyro = ErrorModel(self.rng, 3, **gyro)

    def _measure(self, t, dt, f_flu, w_flu):
        return {"acc": self.accel.apply(f_flu, dt), "gyr": self.gyro.apply(w_flu, dt)}


class ImuTruthFD:
    """Ideal IMU from PyBullet truth by finite differences.

    PyBullet gives world (ENU) linear velocity and world angular velocity.
        a_world = (v_k - v_{k-1}) / dt          kinematic acceleration
        f_world = a_world - g_world             specific force, g_world = (0, 0, -g)
        f_body  = R_enu_flu^T f_world           rotate into the body
        w_body  = R_enu_flu^T w_world
    At rest a_world = 0, so f_body = R^T (0, 0, +g): +g on the body's up axis."""
    def __init__(self, g=G0):
        self.g_world = np.array([0.0, 0.0, -g])
        self._v_prev = None
        self._t_prev = None

    def update(self, t, v_world, w_world, R_enu_flu):
        v = np.asarray(v_world, float)
        if self._v_prev is None or t <= self._t_prev:
            a = np.zeros(3)
        else:
            a = (v - self._v_prev) / (t - self._t_prev)
        self._v_prev, self._t_prev = v, t
        Rt = np.asarray(R_enu_flu).T
        return Rt @ (a - self.g_world), Rt @ np.asarray(w_world, float)


def imu_truth_jsbsim(fdm):
    """Ideal IMU from JSBSim properties, converted FRD ft/s^2 -> FLU m/s^2.
    a-pilot-* is the specific force at the pilot eyepoint (set EYEPOINT to the IMU spot)."""
    f_frd = np.array([fdm["accelerations/a-pilot-x-ft_sec2"], fdm["accelerations/a-pilot-y-ft_sec2"],
                      fdm["accelerations/a-pilot-z-ft_sec2"]]) * FT
    w_frd = np.array([fdm["velocities/p-rad_sec"], fdm["velocities/q-rad_sec"], fdm["velocities/r-rad_sec"]])
    flip = np.array([1.0, -1.0, -1.0])           # FRD <-> FLU
    return f_frd * flip, w_frd * flip


# --------------------------------------------------------------------------- barometer
def isa_pressure(h_m):
    """ISA troposphere (h < 11 km): static pressure in Pa at geometric-ish altitude h."""
    return 101325.0 * (1.0 - 2.25577e-5 * h_m) ** 5.25588


def isa_altitude(p_pa):
    """Inverse of isa_pressure."""
    return (1.0 - (p_pa / 101325.0) ** (1.0 / 5.25588)) / 2.25577e-5


class Barometer(_Sensor):
    """Static pressure sensor (BMP388 / MS5611 class). Noise ~ 1.5 Pa (~0.12 m),
    a slow drift (weather, temperature) and a quantized readout."""
    def __init__(self, seed, rate_hz=50.0, latency_s=0.0, name="baro",
                 sigma_pa=1.5, bias_sigma_pa=10.0, bias_rw_pa=0.5, quant_pa=0.25):
        super().__init__(name, seed, rate_hz, latency_s)
        self.err = ErrorModel(self.rng, 1, sigma=sigma_pa, bias_sigma=bias_sigma_pa,
                              bias_rw=bias_rw_pa, quant=quant_pa)

    def _measure(self, t, dt, alt_m):
        p = float(self.err.apply([isa_pressure(alt_m)], dt)[0])
        return {"p_pa": p, "alt_m": isa_altitude(p)}


# --------------------------------------------------------------------------- magnetometer
def earth_field_enu(total_uT=45.0, inclination_deg=50.0, declination_deg=4.0):
    """Earth field vector in ENU. Inclination > 0 points DOWN (northern hemisphere).
    Look up real values for your site (NOAA WMM calculator)."""
    I, D = math.radians(inclination_deg), math.radians(declination_deg)
    h = total_uT * math.cos(I)
    return np.array([h * math.sin(D), h * math.cos(D), -total_uT * math.sin(I)])


class Magnetometer(_Sensor):
    """3-axis magnetometer in body FLU, microtesla. hard_iron = constant offset from
    the vehicle's own magnets and currents (a turn-on bias here)."""
    def __init__(self, seed, rate_hz=50.0, latency_s=0.0, name="mag",
                 field_enu=None, sigma_uT=0.3, hard_iron_uT=2.0, scale_sigma=0.01):
        super().__init__(name, seed, rate_hz, latency_s)
        self.field_enu = earth_field_enu() if field_enu is None else np.asarray(field_enu, float)
        self.err = ErrorModel(self.rng, 3, sigma=sigma_uT, bias_sigma=hard_iron_uT, scale_sigma=scale_sigma)

    def _measure(self, t, dt, R_enu_flu):
        return {"mag_uT": self.err.apply(np.asarray(R_enu_flu).T @ self.field_enu, dt)}


# --------------------------------------------------------------------------- GPS
class Gps(_Sensor):
    """GNSS receiver: ENU position + velocity at 5-10 Hz, delivered ~150 ms late.
    Position error = slow Gauss-Markov wander (time constant tau_s) + small white noise.
    Real GPS error is correlated in time; pure white noise would be too easy to filter."""
    def __init__(self, seed, rate_hz=5.0, latency_s=0.15, name="gps",
                 sigma_h_m=1.5, sigma_v_m=3.0, tau_s=30.0, white_m=0.2, sigma_vel=0.1):
        super().__init__(name, seed, rate_hz, latency_s)
        self.sig = np.array([sigma_h_m, sigma_h_m, sigma_v_m])
        self.tau, self.white, self.sigma_vel = tau_s, white_m, sigma_vel
        self.wander = self.rng.normal(0.0, 1.0, 3) * self.sig       # start in steady state

    def _measure(self, t, dt, p_enu, v_enu):
        # first-order Gauss-Markov: stationary std = sig, correlation time = tau
        phi = math.exp(-dt / self.tau) if dt > 0 else 1.0
        self.wander = phi * self.wander + math.sqrt(1 - phi * phi) * self.sig * self.rng.normal(0, 1, 3)
        p = np.asarray(p_enu, float) + self.wander + self.rng.normal(0, self.white, 3)
        v = np.asarray(v_enu, float) + self.rng.normal(0, self.sigma_vel, 3)
        return {"pos_enu": p, "vel_enu": v}


# --------------------------------------------------------------------------- air data
class AirData(_Sensor):
    """Pitot airspeed plus alpha/beta vanes. Input: body-frame air-relative velocity
    v_air_flu = R^T (v_world - wind_world). Pitot reads ~0 below a few m/s."""
    def __init__(self, seed, rate_hz=50.0, latency_s=0.0, name="air",
                 sigma_mps=0.3, sigma_ang_rad=math.radians(0.5), min_speed=3.0):
        super().__init__(name, seed, rate_hz, latency_s)
        self.err = ErrorModel(self.rng, 3, sigma=1.0)      # unit normals, scaled below
        self.s_v, self.s_a, self.vmin = sigma_mps, sigma_ang_rad, min_speed

    def _measure(self, t, dt, v_air_flu):
        u, v, w = np.asarray(v_air_flu, float) * np.array([1, -1, -1])     # -> FRD u v w
        V = math.sqrt(u * u + v * v + w * w)
        n = self.err.apply(np.zeros(3), dt)
        alpha = math.atan2(w, u) if V > self.vmin else 0.0
        beta = math.asin(v / V) if V > self.vmin else 0.0
        return {"airspeed_mps": max(0.0, V + self.s_v * n[0]) if V > self.vmin else 0.0,
                "alpha_rad": alpha + self.s_a * n[1], "beta_rad": beta + self.s_a * n[2]}


# --------------------------------------------------------------------------- downward rangefinder
def terrain_range_down(p_enu, R_enu_flu, height_fn, max_range=40.0):
    """Ideal downward rangefinder (body -z) over TERRAIN ONLY, ray-marched on height_fn(e, n).
    Terrain is shared data both processes own (reference/terrain.md); obstacles are not -> Godot."""
    p = np.asarray(p_enu, float)
    d = np.asarray(R_enu_flu) @ np.array([0.0, 0.0, -1.0])
    if d[2] > -1e-3:
        return math.inf
    s, step = 0.0, 0.25
    while s < max_range:
        q = p + s * d
        if q[2] <= height_fn(q[0], q[1]):
            lo, hi = s - step, s                    # refine by bisection
            for _ in range(20):
                mid = 0.5 * (lo + hi)
                q = p + mid * d
                lo, hi = (lo, mid) if q[2] <= height_fn(q[0], q[1]) else (mid, hi)
            return 0.5 * (lo + hi)
        s += step
    return math.inf


# --------------------------------------------------------------------------- noise for Godot ranges
class RangeNoise:
    """Error model for distances that Godot computed (range sensor, lidar).
    Godot sends the IDEAL geometric distance; the physics process adds the noise here, so all
    seeds live in one place (run.json) and truth and measurement land in the same log row.
    inf (no hit) stays inf; a dropout turns a hit into inf, like a dark or shiny surface."""
    def __init__(self, seed, name="range", sigma_m=0.02, sigma_frac=0.0, dropout=0.0,
                 quant_m=0.01, max_range=30.0):
        self.rng = make_rng(seed, name)
        self.sigma_m, self.sigma_frac, self.dropout = sigma_m, sigma_frac, dropout
        self.quant_m, self.max_range = quant_m, max_range

    def apply(self, ranges):
        r = np.asarray(ranges, float).copy()
        noise = self.rng.normal(0.0, 1.0, r.shape)          # drawn for every ray -> stable stream
        drop = self.rng.random(r.shape) < self.dropout
        hit = np.isfinite(r)
        r[hit] = r[hit] + noise[hit] * (self.sigma_m + self.sigma_frac * r[hit])
        if self.quant_m > 0:
            r[hit] = np.round(r[hit] / self.quant_m) * self.quant_m
        r[drop | (r > self.max_range)] = math.inf
        return r


# --------------------------------------------------------------------------- pose history
class PoseHistory:
    """The poses the physics process SENT, keyed by t_sim. A SENSOR packet from Godot
    carries the t_sim of the pose it was computed from: look that pose up here."""
    def __init__(self, maxlen=2000):
        self.t, self.pos, self.quat = deque(maxlen=maxlen), deque(maxlen=maxlen), deque(maxlen=maxlen)
        self._by_t = {}

    def add(self, t, pos, quat):
        if len(self.t) == self.t.maxlen:
            self._by_t.pop(self.t[0], None)
        pos, quat = np.asarray(pos, float), np.asarray(quat, float)
        self.t.append(t); self.pos.append(pos); self.quat.append(quat)
        self._by_t[t] = (pos, quat)

    def exact(self, t):
        """(pos, quat) of the pose sent with exactly this t_sim, or None.
        t_sim travels as f64 both ways, so equality is exact."""
        return self._by_t.get(t)

    def interp(self, t):
        """Pose at any t inside the history: lerp position, slerp quaternion (x,y,z,w)."""
        ts = self.t
        if not ts or t < ts[0] or t > ts[-1]:
            return None
        j = int(np.searchsorted(np.asarray(ts), t))
        if ts[j] == t:
            return self.pos[j], self.quat[j]
        a, b = j - 1, j
        w = (t - ts[a]) / (ts[b] - ts[a])
        return (1 - w) * self.pos[a] + w * self.pos[b], slerp(self.quat[a], self.quat[b], w)


def slerp(q0, q1, w):
    q0, q1 = np.asarray(q0, float), np.asarray(q1, float)
    d = float(np.dot(q0, q1))
    if d < 0:
        q1, d = -q1, -d
    if d > 0.9995:
        q = q0 + w * (q1 - q0)
        return q / np.linalg.norm(q)
    th = math.acos(d)
    return (math.sin((1 - w) * th) * q0 + math.sin(w * th) * q1) / math.sin(th)


def interp_series(t_query, t, values):
    """Resample a logged series (t, values[N, k]) at t_query (linear). Use it to put
    truth at 240 Hz next to a measurement at 30 Hz before you subtract them."""
    values = np.asarray(values, float)
    if values.ndim == 1:
        return np.interp(t_query, t, values)
    return np.stack([np.interp(t_query, t, values[:, i]) for i in range(values.shape[1])], axis=-1)
