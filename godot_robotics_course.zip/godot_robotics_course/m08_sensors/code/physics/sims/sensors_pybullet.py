"""
sensors_pybullet.py - Module 8 lab: one rover, two kinds of sensors, one log.

  physics side (this file):  IMU, barometer, magnetometer, GPS        (robosim/sensors.py)
  Godot side (sensors_demo): forward range, 2D lidar, contact         (godot/sensors/*.gd)

The rover (vehicle id 1) is a PyBullet box driven kinematically along a slalom toward
a wall that exists ONLY in Godot. Godot answers with ideal ranges tagged with the t_sim
of the pose it used; this script finds that pose, computes what the range SHOULD be,
adds the range noise model and logs truth and measurement side by side.

Run from physics/ (start Godot first or second, either works):
    python sims/sensors_pybullet.py                       # waits for the viewer
    python sims/sensors_pybullet.py --seed 7 --no-viewer  # physics-side sensors only
"""
import argparse, json, math, os, sys, time
import numpy as np
import pybullet as p

PHYS = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PHYS)
from robosim import protocol as P
from robosim.bridge import PhysicsBridge
from robosim.frames import enu_flu_to_godot, quat_to_matrix
from robosim.logger import RunLogger
from robosim.sensors import (Imu, ImuTruthFD, Barometer, Magnetometer, Gps, RangeNoise,
                             PoseHistory, G0)

PHYSICS_HZ, POSE_HZ = 240, 60
ROVER_ID = 1
HALF = (0.3, 0.2, 0.15)                  # rover half extents, FLU (forward, left, up)
# Godot-only world (must match godot/sensors_demo.gd), ENU meters
WALL_E, WALL_N = 14.9, 10.0              # west face of the wall, half length
PILLARS = [(5, 5), (5, -5), (9, 5), (9, -5)]
PILLAR_R = 0.3
CURB = (4.0, 14.0, 0.30, 0.65)           # E min, E max, N min, N max
# sensor mounts, converted from the Godot model frame (x right, y up, z back) to FLU
RANGE_MOUNT = np.array([0.3, 0.0, 0.05])     # model (0, 0.05, -0.3)
LIDAR_MOUNT = np.array([0.0, 0.0, 0.20])     # model (0, 0.2, 0)
N_RAYS, FOV, MAX_RANGE = 180, math.pi, 30.0
LIDAR_ANGLES = -FOV / 2 + (np.arange(N_RAYS) + 0.5) * FOV / N_RAYS


def profile(t):
    """Commanded speed (m/s) and yaw rate (rad/s): accelerate, slalom, brake, stand still."""
    if t < 3:
        v = 0.5 * t
    elif t < 7:
        v = 1.5
    elif t < 10:
        v = 1.5 - 0.5 * (t - 7)
    else:
        v = 0.0
    w = 0.25 * (2 * math.pi / 4) * math.cos(2 * math.pi * t / 4) if t < 10 else 0.0
    return v, w


# ---------------------------------------------------------------- expected Godot readings
def ray_2d(o, d, max_range=MAX_RANGE):
    """Distance along a horizontal ray (ENU, d unit in E-N) to the wall or a pillar; inf if none."""
    best = math.inf
    if d[0] > 1e-9:
        s = (WALL_E - o[0]) / d[0]
        if 0 < s and abs(o[1] + s * d[1]) <= WALL_N:
            best = s
    for cx, cy in PILLARS:
        fx, fy = o[0] - cx, o[1] - cy
        b = fx * d[0] + fy * d[1]
        c = fx * fx + fy * fy - PILLAR_R ** 2
        disc = b * b - c
        if disc >= 0:
            s = -b - math.sqrt(disc)
            if 0 < s < best:
                best = s
    return best if best <= max_range else math.inf


def expected_range(pos, quat):
    R = quat_to_matrix(quat)
    o = np.asarray(pos) + R @ RANGE_MOUNT
    d = R @ np.array([1.0, 0, 0])
    h = math.hypot(d[0], d[1])
    return ray_2d(o, d[:2] / h) / h


def expected_scan(pos, quat):
    R = quat_to_matrix(quat)
    o = np.asarray(pos) + R @ LIDAR_MOUNT
    yaw = math.atan2(R[1, 0], R[0, 0])
    return np.array([ray_2d(o, (math.cos(yaw + a), math.sin(yaw + a))) for a in LIDAR_ANGLES])


def expected_curb_overlap(pos, quat):
    """Separating-axis test: rover footprint (rotated rectangle) vs curb (axis-aligned).
    Returns the smallest overlap in meters (> 0 = touching)."""
    R = quat_to_matrix(quat)
    c = np.asarray(pos[:2])
    ax = [R[:2, 0] / np.linalg.norm(R[:2, 0]), R[:2, 1] / np.linalg.norm(R[:2, 1])]
    rover = [c + sx * HALF[0] * ax[0] + sy * HALF[1] * ax[1] for sx in (-1, 1) for sy in (-1, 1)]
    e0, e1, n0, n1 = CURB
    curb = [np.array([e, n]) for e in (e0, e1) for n in (n0, n1)]
    overlap = math.inf
    for axis in [np.array([1.0, 0]), np.array([0, 1.0])] + ax:
        a = [float(axis @ q) for q in rover]
        b = [float(axis @ q) for q in curb]
        overlap = min(overlap, min(max(a), max(b)) - max(min(a), min(b)))
    return overlap


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--duration", type=float, default=12.0)
    ap.add_argument("--viewer-port", type=int, default=P.PORT_TO_VIEWER)
    ap.add_argument("--listen-port", type=int, default=P.PORT_TO_PHYSICS)
    ap.add_argument("--no-viewer", action="store_true", help="do not wait for Godot")
    ap.add_argument("--fast", action="store_true", help="do not pace to wall time (no viewer only)")
    ap.add_argument("--logs", default=os.path.join(PHYS, "..", "logs"))
    args = ap.parse_args()

    # --- PyBullet world: a frictionless plane and a box we drive by setting its velocity
    cid = p.connect(p.DIRECT)
    p.setGravity(0, 0, -G0)
    p.setTimeStep(1 / PHYSICS_HZ)
    plane = p.createMultiBody(0, p.createCollisionShape(p.GEOM_PLANE))
    rover = p.createMultiBody(2.0, p.createCollisionShape(p.GEOM_BOX, halfExtents=HALF),
                              basePosition=[0, 0, HALF[2]])
    for b in (plane, rover):
        p.changeDynamics(b, -1, lateralFriction=0.0)
    for _ in range(PHYSICS_HZ // 2):          # settle on the ground before t = 0
        p.stepSimulation()

    # --- sensors: one seed for the run, one independent stream per sensor
    imu, baro = Imu(args.seed), Barometer(args.seed)
    mag, gps = Magnetometer(args.seed), Gps(args.seed)
    range_noise = RangeNoise(args.seed, "range", sigma_m=0.02, quant_m=0.01)
    lidar_noise = RangeNoise(args.seed, "lidar", sigma_m=0.03, dropout=0.01, quant_m=0.01)
    truth_imu = ImuTruthFD()

    log = RunLogger(args.logs, run_name="sensors", seed=args.seed,
                    meta={"physics": "pybullet", "physics_hz": PHYSICS_HZ, "pose_hz": POSE_HZ,
                          "imu_hz": imu.sampler.rate_hz, "gps_hz": gps.sampler.rate_hz,
                          "gps_latency_s": gps.sampler.latency_s, "lidar_rays": N_RAYS,
                          "range_mount_flu": RANGE_MOUNT.tolist(), "lidar_mount_flu": LIDAR_MOUNT.tolist()})

    br = PhysicsBridge(viewer_port=args.viewer_port, listen_port=args.listen_port)
    history = PoseHistory()

    def send_pose(t):
        pos, q = p.getBasePositionAndOrientation(rover)
        v, _ = p.getBaseVelocity(rover)
        gp, gq = enu_flu_to_godot(pos, q)
        br.send_pose(t, ROVER_ID, gp, gq, (v[0], v[2], -v[1]))
        history.add(t, pos, q)
        return pos, q

    if not args.no_viewer:
        print("waiting for the Godot viewer (sensors_demo.tscn) ...")
        if not br.wait_for_viewer(timeout=60.0, send_idle_pose=lambda: br.send_pose(0.0, ROVER_ID, *enu_flu_to_godot(
                p.getBasePositionAndOrientation(rover)[0], (0, 0, 0, 1)))):
            sys.exit("no viewer after 60 s")
        t_end = time.monotonic() + 0.3               # drop samples Godot may still send for the idle
        while time.monotonic() < t_end:              # pose (it also has t_sim = 0, so they would be
            br.poll()                                # logged as extra rows and shift the noise streams)
            time.sleep(0.02)
        br.mark_reset()                              # the first real pose clears Godot's buffers

    stats = {"range": [], "range_latest": [], "lidar_err": [], "lidar_mismatch": 0, "lidar_rays": 0,
             "contact": [], "unmatched": 0, "arrival_delay": []}
    newest = {"t": 0.0}

    def handle(msg, t_now):
        if msg["type"] != P.MSG_SENSOR or msg["vehicle_id"] != ROVER_ID:
            return
        ts = msg["t_sim"]
        pose = history.exact(ts)                       # the pose Godot used, found by t_sim
        if pose is None:
            stats["unmatched"] += 1
            return
        stats["arrival_delay"].append(t_now - ts)
        vals = np.array(msg["values"], dtype=float)
        if msg["sensor"] == P.SENSOR_RANGE and len(vals) == 1:          # forward range sensor
            ideal = vals[0]
            exp = expected_range(*pose)
            exp_latest = expected_range(*history.exact(newest["t"]))   # the WRONG way, for comparison
            meas = range_noise.apply([ideal])[0]
            log.write("range", t_sim=ts, t_arrive=t_now, range_true=ideal, range_meas=meas,
                      range_expected=exp, range_expected_latest=exp_latest)
            if math.isfinite(exp):
                stats["range"].append(ideal - exp)
                stats["range_latest"].append(ideal - exp_latest)
        elif msg["sensor"] == P.SENSOR_RANGE and len(vals) == N_RAYS:   # 2D lidar
            exp = expected_scan(*pose)
            meas = lidar_noise.apply(vals)
            both = np.isfinite(vals) & np.isfinite(exp)
            stats["lidar_err"] += list(np.abs(vals[both] - exp[both]))
            stats["lidar_mismatch"] += int(np.sum(np.isfinite(vals) != np.isfinite(exp)))
            stats["lidar_rays"] += N_RAYS
            row = {"t_arrive": t_now, "n_hit": int(np.isfinite(vals).sum())}
            row.update({f"r{i:03d}_true": round(float(x), 4) for i, x in enumerate(vals)})
            row.update({f"r{i:03d}_meas": round(float(x), 4) for i, x in enumerate(meas)})
            log.write("lidar", t_sim=ts, **row)
        elif msg["sensor"] == P.SENSOR_CONTACT:
            hit, nx, ny, nz, depth = vals
            ov = expected_curb_overlap(*pose)
            log.write("contact", t_sim=ts, t_arrive=t_now, hit=int(hit), nx=nx, ny=ny, nz=nz,
                      depth_m=depth, overlap_expected_m=ov)
            stats["contact"].append((int(hit), ov))

    # --- the fixed-step loop
    n_steps = int(args.duration * PHYSICS_HZ)
    wall0 = time.perf_counter()
    pos, q = send_pose(0.0)
    for k in range(1, n_steps + 1):
        t = k / PHYSICS_HZ
        # command: set the body velocity along its current heading (kinematic driving)
        v_cmd, w_cmd = profile(t)
        _, q_now = p.getBasePositionAndOrientation(rover)
        R_now = quat_to_matrix(q_now)
        yaw = math.atan2(R_now[1, 0], R_now[0, 0])
        vz = p.getBaseVelocity(rover)[0][2]
        p.resetBaseVelocity(rover, [v_cmd * math.cos(yaw), v_cmd * math.sin(yaw), vz], [0, 0, w_cmd])
        p.stepSimulation()

        # truth after the step
        pos, q = p.getBasePositionAndOrientation(rover)
        v, w = p.getBaseVelocity(rover)
        R = quat_to_matrix(q)
        f_true, w_true = truth_imu.update(t, v, w, R)

        # physics-side sensors: each samples at its own rate, delivers after its own latency
        for tv, s in imu.step(t, f_true, w_true):
            log.write("imu", t_sim=tv,
                      ax_true=f_true[0], ay_true=f_true[1], az_true=f_true[2],
                      ax_meas=s["acc"][0], ay_meas=s["acc"][1], az_meas=s["acc"][2],
                      gx_true=w_true[0], gy_true=w_true[1], gz_true=w_true[2],
                      gx_meas=s["gyr"][0], gy_meas=s["gyr"][1], gz_meas=s["gyr"][2])
        for tv, s in baro.step(t, pos[2] + 30.0):          # site elevation 30 m
            log.write("baro", t_sim=tv, alt_true=pos[2] + 30.0, alt_meas=s["alt_m"], p_meas_pa=s["p_pa"])
        for tv, s in mag.step(t, R):
            m_true = R.T @ mag.field_enu
            log.write("mag", t_sim=tv, mx_true=m_true[0], my_true=m_true[1], mz_true=m_true[2],
                      mx_meas=s["mag_uT"][0], my_meas=s["mag_uT"][1], mz_meas=s["mag_uT"][2])
        # GPS: the sample is VALID at tv but ARRIVES now (t). Truth must be taken at tv.
        for tv, s in gps.step(t, pos, v):
            hp = history.interp(tv)                        # truth at the time of validity
            pt = hp[0] if hp else np.asarray(pos)
            log.write("gps", t_sim=tv, t_arrive=t, e_true=pt[0], n_true=pt[1], u_true=pt[2],
                      e_meas=s["pos_enu"][0], n_meas=s["pos_enu"][1], u_meas=s["pos_enu"][2])

        if k % (PHYSICS_HZ // POSE_HZ) == 0:
            send_pose(t)
            newest["t"] = t
            yaw_deg = math.degrees(math.atan2(R[1, 0], R[0, 0]))
            log.write("pose", t_sim=t, e=pos[0], n=pos[1], u=pos[2], qx=q[0], qy=q[1], qz=q[2], qw=q[3],
                      yaw_deg=yaw_deg, speed=math.hypot(v[0], v[1]))
        for msg in br.poll(t):                            # Godot's sensor packets
            handle(msg, t)
        if not args.fast:                                 # real time: Godot sees a 60 Hz stream
            lag = wall0 + t - time.perf_counter()
            if lag > 0:
                time.sleep(lag)

    # drain late sensor packets (no new poses -> Godot goes stale and quits)
    t_end = time.perf_counter() + 0.4
    while time.perf_counter() < t_end:
        for msg in br.poll(t):
            handle(msg, t)
        time.sleep(0.01)
    log.close()

    # --- summary
    s = {"seed": args.seed, "log_dir": os.path.abspath(log.dir)}
    imu_rest = np.loadtxt(os.path.join(log.dir, "imu.csv"), delimiter=",", skiprows=1)
    rest = imu_rest[imu_rest[:, 0] > 10.5]
    s["imu_rest_true_flu"] = [round(x, 4) for x in rest[:, 2:5].mean(0)]
    s["imu_rest_meas_flu"] = [round(x, 4) for x in rest[:, 5:8].mean(0)]
    g = np.loadtxt(os.path.join(log.dir, "gps.csv"), delimiter=",", skiprows=1)
    s["gps_samples"] = len(g)
    s["gps_rms_h_m"] = round(float(np.sqrt(np.mean((g[:, 6] - g[:, 3]) ** 2 + (g[:, 7] - g[:, 4]) ** 2))), 3)
    if stats["range"]:
        r, rl = np.array(stats["range"]), np.array(stats["range_latest"])
        s["range_samples"] = len(r)
        s["range_max_abs_err_matched_m"] = float(f"{np.max(np.abs(r)):.2e}")
        s["range_rms_err_if_latest_pose_m"] = round(float(np.sqrt(np.mean(rl ** 2))), 4)
        s["range_max_err_if_latest_pose_m"] = round(float(np.max(np.abs(rl))), 4)
    if stats["lidar_rays"]:
        s["lidar_scans"] = stats["lidar_rays"] // N_RAYS
        s["lidar_max_abs_err_m"] = float(f"{np.max(stats['lidar_err']):.2e}")
        s["lidar_hit_mismatch_rays"] = stats["lidar_mismatch"]
    if stats["contact"]:
        c = stats["contact"]
        s["contact_samples"] = len(c)
        s["contact_hits"] = sum(h for h, _ in c)
        s["contact_disagree_beyond_5mm"] = sum(1 for h, ov in c if (h == 1) != (ov > 0) and abs(ov) > 0.005)
    if stats["arrival_delay"]:
        d = np.array(stats["arrival_delay"])
        s["sensor_delay_sim_s_mean"] = round(float(d.mean()), 4)
        s["sensor_delay_sim_s_max"] = round(float(d.max()), 4)
    s["unmatched_sensor_packets"] = stats["unmatched"]
    with open(os.path.join(log.dir, "summary.json"), "w") as f:
        json.dump(s, f, indent=2)
    print(json.dumps(s, indent=2))
    p.disconnect(cid)


if __name__ == "__main__":
    main()
