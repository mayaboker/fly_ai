"""
imu_jsbsim.py - Module 8: the same sensor models on a JSBSim vehicle (quad_rpy).

JSBSim already computes the specific force at the pilot eyepoint (accelerations/a-pilot-*)
and the body rates (velocities/p,q,r). We only convert FRD ft/s^2 -> FLU m/s^2 and add errors.
No viewer needed. Run from physics/:
    python sims/imu_jsbsim.py [--seed 42]
"""
import argparse, json, math, os, sys
import numpy as np
import jsbsim

PHYS = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PHYS)
from robosim.frames import FT, GeoOrigin, ned_frd_euler_to_enu_flu
from robosim.logger import RunLogger
from robosim.sensors import Imu, Barometer, Magnetometer, Gps, imu_truth_jsbsim

HZ = 120


def throttle_profile(t):
    """ground -> climb -> hover with a roll step -> hover."""
    if t < 2:
        return 0.0, 0.0
    if t < 4:
        return 0.6, 0.0
    if 6 <= t < 7:
        return 0.47, 10.0                     # roll 10 deg right
    return 0.47, 0.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--duration", type=float, default=9.0)
    ap.add_argument("--logs", default=os.path.join(PHYS, "..", "logs"))
    args = ap.parse_args()

    fdm = jsbsim.FGFDMExec(PHYS)                       # finds aircraft/quad_rpy under physics/
    fdm.set_debug_level(0)
    fdm.load_model("quad_rpy")
    fdm.load_ic("ground", True)
    fdm.set_dt(1.0 / HZ)
    fdm.run_ic()
    origin = GeoOrigin(fdm["position/lat-geod-rad"], fdm["position/long-gc-rad"], 0.0)

    imu, baro = Imu(args.seed, rate_hz=HZ), Barometer(args.seed)
    mag, gps = Magnetometer(args.seed), Gps(args.seed)
    log = RunLogger(args.logs, run_name="imu_jsbsim", seed=args.seed,
                    meta={"physics": "jsbsim", "physics_hz": HZ, "model": "quad_rpy"})
    rest = []
    n = int(args.duration * HZ)
    for k in range(n):
        thr, roll = throttle_profile(fdm["simulation/sim-time-sec"])
        fdm["ap/throttle-cmd"] = thr
        fdm["ap/roll-cmd-deg"] = roll
        fdm.run()
        t = fdm["simulation/sim-time-sec"]
        f_true, w_true = imu_truth_jsbsim(fdm)          # FLU, m/s^2 and rad/s
        R = ned_frd_euler_to_enu_flu(fdm["attitude/phi-rad"], fdm["attitude/theta-rad"], fdm["attitude/psi-rad"])
        p_enu = np.array(origin.to_enu(fdm["position/lat-geod-rad"], fdm["position/long-gc-rad"],
                                       fdm["position/h-sl-ft"] * FT))
        v_enu = np.array([fdm["velocities/v-east-fps"], fdm["velocities/v-north-fps"],
                          -fdm["velocities/v-down-fps"]]) * FT
        if 1.0 < t < 2.0:
            rest.append(fdm["accelerations/a-pilot-z-ft_sec2"])
        for tv, s in imu.step(t, f_true, w_true):
            log.write("imu", t_sim=tv,
                      ax_true=f_true[0], ay_true=f_true[1], az_true=f_true[2],
                      ax_meas=s["acc"][0], ay_meas=s["acc"][1], az_meas=s["acc"][2],
                      gx_true=w_true[0], gy_true=w_true[1], gz_true=w_true[2],
                      gx_meas=s["gyr"][0], gy_meas=s["gyr"][1], gz_meas=s["gyr"][2],
                      a_pilot_z_ftps2=fdm["accelerations/a-pilot-z-ft_sec2"])
        for tv, s in baro.step(t, p_enu[2]):
            log.write("baro", t_sim=tv, alt_true=p_enu[2], alt_meas=s["alt_m"])
        for tv, s in mag.step(t, R):
            log.write("mag", t_sim=tv, mx_meas=s["mag_uT"][0], my_meas=s["mag_uT"][1], mz_meas=s["mag_uT"][2])
        for tv, s in gps.step(t, p_enu, v_enu):
            log.write("gps", t_sim=tv, t_arrive=t, u_meas=s["pos_enu"][2], e_meas=s["pos_enu"][0],
                      n_meas=s["pos_enu"][1])
        if k % (HZ // 2) == 0:
            print(f"t={t:5.2f}  thr={thr:.2f}  h={p_enu[2]:6.2f} m  phi={math.degrees(fdm['attitude/phi-rad']):6.1f} deg"
                  f"  f_true=({f_true[0]:6.2f},{f_true[1]:6.2f},{f_true[2]:6.2f})  p_true={w_true[0]:6.3f} rad/s")
    log.close()
    summary = {"a_pilot_z_at_rest_ftps2": round(float(np.mean(rest)), 3),
               "accel_z_at_rest_flu_mps2": round(float(np.mean(rest)) * -FT, 3), "log_dir": log.dir}
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
