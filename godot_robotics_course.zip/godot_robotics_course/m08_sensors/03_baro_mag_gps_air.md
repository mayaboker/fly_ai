# 03 Barometer, magnetometer, GPS, air data and friends (1 h)

The IMU tells you how the vehicle is turning and accelerating. It cannot tell you where the vehicle is, or which way is north, without drifting. Other vehicle-state sensors fill those gaps, and each has a characteristic error that your estimator must handle. None of them depends on scene geometry, so all of them live in the physics process.

| Sensor | Fixes which IMU weakness | Characteristic error | Rate |
|---|---|---|---|
| Barometer | vertical drift | slow drift (weather, temperature), noise ≈ 0.1 m | 25–100 Hz |
| Magnetometer | heading drift | hard/soft iron offsets, local disturbances | 10–100 Hz |
| GPS | horizontal and vertical drift | correlated wander of 1–3 m, **late** by 100–200 ms | 5–10 Hz |
| Airspeed + vanes | wind vs ground speed (fixed-wing) | noise, useless below a few m/s | 10–50 Hz |
| Downward rangefinder (terrain) | height above ground near landing | max range, tilt, dropouts | 10–50 Hz |
| Motor RPM, battery | thrust and endurance | mostly model error | 10–50 Hz |

## Barometer

A barometer measures static pressure. Altitude is then **computed** from it with the standard atmosphere, so the sensor model has two steps: turn true altitude into pressure, add pressure errors, and convert back:

```python
def isa_pressure(h_m):                     # ISA troposphere, h < 11 km
    return 101325.0 * (1.0 - 2.25577e-5 * h_m) ** 5.25588

class Barometer(_Sensor):
    def _measure(self, t, dt, alt_m):
        p = float(self.err.apply([isa_pressure(alt_m)], dt)[0])
        return {"p_pa": p, "alt_m": isa_altitude(p)}
```

Near sea level, 1 Pa is about 8.3 cm. So σ = 1.5 Pa gives about 0.12 m of altitude noise. `test_baro` measured a standard deviation between 0.08 and 0.18 m. The turn-on bias (10 Pa ≈ 0.8 m) is why a real autopilot zeroes the baro on the ground before takeoff. In the lab plot, the measured altitude sits about 0.3 m below truth for the whole run. That offset is the bias for seed 42.

For JSBSim, you can either feed `position/h-sl-ft · 0.3048` into this model, or read JSBSim's own `atmosphere/P-psf` (×47.88 for Pa) as truth. The second option also includes any non-standard atmosphere you configured. On the ground at the `quad_rpy` site, `atmosphere/P-psf` read 2116.2 psf (101 325 Pa).

## Magnetometer

The Earth's field is a fixed vector in the world frame. The sensor sees it rotated into the body frame:

```
m_body = R_enu_fluᵀ · B_enu  +  hard-iron offset  +  noise
B_enu  = H·(sin D, cos D, 0) + (0, 0, −F·sin I)      H = F·cos I
         F total intensity (25–65 µT), I inclination (down is positive), D declination
```

```python
def earth_field_enu(total_uT=45.0, inclination_deg=50.0, declination_deg=4.0):
    I, D = math.radians(inclination_deg), math.radians(declination_deg)
    h = total_uT * math.cos(I)
    return np.array([h * math.sin(D), h * math.cos(D), -total_uT * math.sin(I)])
```

Get real F, I and D for your site from the NOAA calculator (link below). Remember the PyBullet convention from [frames](../reference/frames.md): the identity pose points the nose **east**. So with identity orientation, north is on the body's **left** (+y in FLU). `test_mag_heading` checks this: a field of (0, 20, −40) µT in ENU reads (0, 20, −40) at identity and (20, 0, −40) after a +90° yaw (nose north).

Real magnetometers sit near motors and power wires. Their dominant errors are the hard-iron offset (constant, in the body frame) and current-dependent offsets. Model the first as a turn-on bias, as `sensors.py` does. Model the second, if you need it, as `k · motor_current` added on one axis.

## GPS

GPS is the sensor where simple white noise gives a misleadingly good estimator. Real GPS error **wanders**: it stays off by 1–2 m in the same direction for tens of seconds. So `Gps` uses a first-order Gauss-Markov process plus a little white noise:

```python
# stationary std = sig, correlation time = tau
phi = math.exp(-dt / self.tau)
self.wander = phi * self.wander + math.sqrt(1 - phi * phi) * self.sig * self.rng.normal(0, 1, 3)
p = np.asarray(p_enu, float) + self.wander + self.rng.normal(0, self.white, 3)
```

With the defaults (5 Hz, 1.5 m horizontal, 3 m vertical, τ = 30 s, **150 ms latency**), seed 42 gave a horizontal RMS error of 1.96 m over the 12 s lab run. The GPS panel of the [lab plot](img/sensors_expected.png) shows the wander: east and north errors stay positive for the whole 12 s.

Latency is the part people forget. A fix computed for t = 2.0 s arrives at t = 2.15 s. `Gps.step()` returns `(t_valid, values)`, so you know which instant it describes. A GPS receiver tags its own messages with the time of validity in exactly the same way. Compare it to truth **at t_valid** ([05](05_timestamps_alignment.md)).

The course works in ENU meters ([frames](../reference/frames.md)). If your consumer wants latitude and longitude, invert `GeoOrigin.to_enu`: `lat = lat0 + n / R` and `lon = lon0 + e / (R cos lat0)`, with R = 6 378 137 m. Do not send lat/lon to Godot. The wire carries Godot-frame meters only.

## Air data: airspeed, alpha, beta

For a fixed-wing aircraft (Module 11), the useful velocity is relative to the **air**:

```
v_air_body = Rᵀ (v_world − wind_world)        then in FRD: (u, v, w)
airspeed = |v_air|      alpha = atan2(w, u)      beta = asin(v / airspeed)
```

`AirData` takes `v_air_flu`, converts to FRD (u, v, w), and adds noise. Below `min_speed` (3 m/s) it returns 0, because a pitot tube and vanes give garbage at low speed. JSBSim already computes all of these. Use `velocities/vtrue-kts` (×0.514444 for m/s), `aero/alpha-rad` and `aero/beta-rad` as truth, and apply only the noise.

## Downward rangefinder over terrain

A downward lidar or sonar over **bare terrain** can live in the physics process, because both processes read the same heightmap ([terrain](../reference/terrain.md)). `terrain_range_down` marches along the body's down axis and refines the hit by bisection:

```python
r = terrain_range_down(p_enu, R_enu_flu, height_fn)   # height_fn(e, n) -> terrain height in m
```

On flat ground at 10 m and 0.3 rad of roll, it returns 10 / cos(0.3) = 10.46 m (`test_terrain_rangefinder`). As soon as something other than terrain can be under the vehicle (a car, a landing pad, a building), use a Godot `RayCast3D` pointing down instead ([04](04_godot_range_lidar_contact.md)). The physics process does not know about those objects.

## Motor RPM and battery

These are vehicle internals, so they belong to the physics process. They are usually derived from your own motor model, not from the physics engine:

```python
def rpm_from_thrust(thrust_n, k_t=1.2e-7):
    """thrust = k_t * rpm^2  ->  rpm. Get k_t from a thrust-stand table for your prop."""
    return np.sqrt(np.maximum(thrust_n, 0.0) / k_t)

class Battery:
    """Crude LiPo: open-circuit voltage falls linearly with charge used; sag = I * R_internal."""
    def __init__(self, capacity_mah=5000, cells=4, r_int=0.02):
        self.cap_c, self.cells, self.r = capacity_mah * 3.6, cells, r_int
        self.used_c = 0.0

    def step(self, current_a, dt):
        self.used_c += current_a * dt
        soc = max(0.0, 1.0 - self.used_c / self.cap_c)
        return self.cells * (3.3 + 0.9 * soc) - current_a * self.r, soc
```

Run for 10 minutes at 20 A, this battery is at 33 % charge and 14.0 V under load. The thrust of `quad_rpy` at hover, 3.7 N per motor, gives about 5550 rpm with this `k_t`. Treat both as plausible placeholders and replace them with numbers from your own hardware. Measure RPM in the same way as any other channel: `ErrorModel(sigma=…, quant=…)`, at the ESC telemetry rate.

## Try it

- Plot `alt_meas − alt_true` from the lab's `baro.csv`. Estimate the bias from the first 2 s (while still) and subtract it. What is the remaining standard deviation?
- Set `Gps(tau_s=0.01)`, which is effectively white noise, and average 10 fixes. Then do the same with `tau_s=30`. Why does averaging help in one case and not the other?
- Give the magnetometer a 10 µT hard-iron offset on body x. Rotate the rover through 360° of yaw and plot `mx` vs `my`. What shape do you get, and where is its center?
- For JSBSim's `trainer` model, log `aero/alpha-rad` next to `AirData`'s alpha from the body velocity with zero wind. Do they agree?

## References

- [International Standard Atmosphere](https://en.wikipedia.org/wiki/International_Standard_Atmosphere)
- NOAA [magnetic field calculator](https://www.ngdc.noaa.gov/geomag/calculators/magcalc.shtml) (World Magnetic Model)
- [Gauss-Markov process](https://en.wikipedia.org/wiki/Gauss%E2%80%93Markov_process) for correlated noise
- JSBSim property names: run `fdm.print_property_catalog()` or see the [reference manual](https://jsbsim-team.github.io/jsbsim-reference-manual/)
