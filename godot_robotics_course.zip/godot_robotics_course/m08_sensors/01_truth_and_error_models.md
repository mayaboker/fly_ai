# 01 Ground truth, measurements and error models (1 h)

A simulator knows the exact state of the world. That exact state is **ground truth**: the true position, the true angular rate, the true distance to the wall. A real sensor never reports truth. It reports truth plus errors, sampled at its own rate, and delivered a little late.

A synthetic sensor is a function from truth to a believable measurement. You need both values, and you must keep them apart:

- **Truth** lets you grade an estimator. "My EKF's position error is 0.4 m RMS" only means something if you logged the true position.
- **Measurement** is what your controller or estimator is allowed to see. If it secretly uses truth, it will work perfectly in simulation and fail on hardware.

So the rule from [logging](../reference/logging.md) applies to every sensor: **truth and measurement are separate columns, and noise never overwrites truth.**

## Who owns which sensor

Before modelling errors, decide **where** the sensor is computed. Ask one question:

> Would the reading change if I moved a wall?

| Answer | Owner | Why |
|---|---|---|
| No (IMU, baro, GPS, mag, airspeed, motor RPM) | physics process | These depend only on the vehicle's own state, which the physics process owns. Computing them there needs no round trip and no extra latency. |
| Yes (range, lidar, camera, contact with scenery) | Godot | They depend on scene geometry, which Godot owns. The physics engine may not even know the wall exists. |

The downward rangefinder is the one borderline case. Over bare terrain, both processes share the same heightmap ([terrain](../reference/terrain.md)), so Python can compute it. Over obstacles, such as a car parked on the road, only Godot knows, so the downward rangefinder belongs in Godot too. [03](03_baro_mag_gps_air.md) shows the terrain-only version.

## The error model

Almost every sensor in this module uses the same recipe:

```
meas = (1 + s) · truth  +  b(t)  +  n        then quantize to steps of q
        └ scale ┘          └ bias ┘  └ white noise
b(t) = b0 + random walk          sampled every 1/rate, delivered after latency
```

| Term | Symbol | What it looks like | Typical cause | Unit of the parameter |
|---|---|---|---|---|
| White noise | n ~ N(0, σ²) | fuzz on every sample, uncorrelated | electronics, ADC | channel units |
| Turn-on bias | b0 ~ N(0, σ_b²) | constant offset, different every power-up | calibration residue | channel units |
| Bias random walk | b += N(0, σ_rw² dt) | offset that wanders slowly | temperature, aging | units / √s |
| Scale factor | s ~ N(0, σ_s²) | error proportional to the signal | gain error | fraction (0.005 = 0.5 %) |
| Quantization | q | staircase on slow signals | finite ADC bits | channel units per LSB |
| Rate | f | samples only every 1/f s | sensor ODR, bus | Hz |
| Latency | τ | the sample describes the past | filtering, bus, GPS solution time | s |

A few points matter here.

- **White noise vs bias.** Averaging removes white noise and does not remove bias. An IMU at rest averaged for 1 s still shows its bias. That is why our test compares the **mean** of the ideal signal, not of the measured one.
- **Random walk scales with √t.** After T seconds the bias has spread by σ_rw·√T. `test_bias_random_walk_growth` checks this with 400 runs. Note the `sqrt(dt)` in the code: if you forget it, the drift depends on your step size.
- **Turn-on terms are drawn once.** Draw b0 and s when the sensor is created, not every step.

## The code

`robosim/sensors.py` puts the recipe in one small class:

```python
class ErrorModel:
    def __init__(self, rng, n=3, sigma=0.0, bias_sigma=0.0, bias_rw=0.0, scale_sigma=0.0, quant=0.0):
        self.rng, self.n = rng, n
        self.sigma, self.bias_rw, self.quant = sigma, bias_rw, quant
        # draw the per-run constants FIRST, in a fixed order -> reproducible
        self.bias = rng.normal(0.0, bias_sigma, n) if bias_sigma > 0 else np.zeros(n)
        self.scale = 1.0 + (rng.normal(0.0, scale_sigma, n) if scale_sigma > 0 else np.zeros(n))

    def apply(self, truth, dt):
        truth = np.asarray(truth, float)
        if self.bias_rw > 0 and dt > 0:
            self.bias = self.bias + self.rng.normal(0.0, self.bias_rw * math.sqrt(dt), self.n)
        y = self.scale * truth + self.bias
        if self.sigma > 0:
            y = y + self.rng.normal(0.0, self.sigma, self.n)
        if self.quant > 0:
            y = np.round(y / self.quant) * self.quant
        return y
```

Rate and latency are a separate concern, handled by `Sampler`. A 50 Hz baro inside a 240 Hz loop must sample at t = 0, 0.02, 0.04, … exactly, and must not drift by accumulating `+= 1/50`. A sample taken at `t_valid` is held in a queue and handed out once `t ≥ t_valid + latency`:

```python
class Sampler:
    def due(self, t):
        if t + 1e-9 >= self._k / self.rate_hz:
            self._k = math.floor(t * self.rate_hz + 1e-6) + 1
            return True
        return False
```

Every sensor's `step(t, *truth)` is called **every physics step**. It returns a list, usually empty, of delivered samples `(t_valid, values)`. The list holds the time the sample is valid for, **not** the time it arrived. [05](05_timestamps_alignment.md) explains why that distinction matters.

## Seeded randomness

A simulation run must be repeatable. If a controller crashed in run 17, you want to replay run 17 exactly. Three rules make that possible:

1. **One seed per run**, written to `run.json`. `RunLogger(seed=...)` does this.
2. **One generator per sensor**, derived from the seed and the sensor's name:

   ```python
   def make_rng(seed, name):
       return np.random.default_rng([int(seed), zlib.crc32(name.encode())])
   ```

   With one shared generator, adding a magnetometer would shift every random number that the IMU draws afterwards. With per-sensor streams, the IMU's noise does not change when you add a sensor. `test_seed_reproducible` checks exactly this.
3. **Fixed draw order.** Every call draws the same number of values, whatever the data. For example, `RangeNoise` draws noise for **every** ray, including rays with no hit. Otherwise the number of draws, and so every later value, would depend on the scene.

Do **not** use Python's `hash(name)` to derive the stream. Python salts string hashes per process, so the value changes on every run. `zlib.crc32` is stable.

What did we measure? With `--seed 42`, two complete runs of the lab (12 s, 2880 IMU rows, 60 GPS fixes, 241 range and 121 lidar samples from Godot) were identical in every measurement column. With `--seed 7`, the IMU, baro, mag and GPS columns differed, and the pose columns did not. That is correct: noise must never change the dynamics.

## Picking numbers

Use datasheets when you have them. These defaults are in the right range for small robots. Treat them as starting points, not specifications.

| Sensor | Default in `sensors.py` | Notes |
|---|---|---|
| Accelerometer | σ 0.05 m/s², bias 0.05 m/s², rw 0.001 m/s²/√s, scale 0.5 %, LSB 0.0024 m/s² | MEMS ±8 g, 16 bit |
| Gyro | σ 0.003 rad/s, bias 0.005 rad/s, rw 1e-4 rad/s/√s, scale 0.5 % | MEMS ±2000 °/s |
| Barometer | σ 1.5 Pa (≈ 0.12 m), bias 10 Pa, rw 0.5 Pa/√s | MS5611 / BMP388 class |
| Magnetometer | σ 0.3 µT, hard iron 2 µT, scale 1 % | real installs are much worse near motors |
| GPS | 1.5 m horizontal, 3 m vertical (correlated), 5 Hz, 150 ms | consumer u-blox class |
| Range / lidar (Godot geometry + Python noise) | σ 2–3 cm, LSB 1 cm, 1 % dropouts | |

## Try it

- Create `Imu(seed=1)` and feed it a constant `(0, 0, 9.80665)` for 60 s at 240 Hz. Plot `acc[2]`. Turn off each term in turn (σ, bias, rw, scale, quant) and describe what changes.
- Set `bias_rw` 10× larger and plot the bias over 60 s for five different seeds. Does the spread grow like √t?
- Swap `make_rng` for one global `np.random.default_rng(seed)` shared by all sensors. Add a magnetometer, and show with `tools/compare_runs.py` that the IMU columns changed.
- Change `Sampler.due` to the naive `if t - last >= 1/rate`. Run a 50 Hz sensor in a 240 Hz loop for 10 s. How many samples do you get, and how far do the sample times drift?

## References

- NumPy, [random Generator and seeding](https://numpy.org/doc/stable/reference/random/generator.html)
- [Allan variance](https://en.wikipedia.org/wiki/Allan_variance): how datasheets specify noise and random walk
- PX4, [simulated sensor noise in Gazebo](https://docs.px4.io/main/en/sim_gazebo_gz/) (for comparison)
