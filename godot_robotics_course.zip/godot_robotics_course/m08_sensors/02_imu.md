# 02 The IMU: specific force, and where to get it (1.25 h)

An IMU has two parts. The **gyro** measures body angular rate. That one is easy: rotate the world angular velocity into the body frame. The **accelerometer** is where nearly every simulator bug in this area lives. The reason is that it does **not** measure acceleration.

## Specific force

An accelerometer is a proof mass on a spring. It measures the force the spring needs to apply to make the mass follow the case. Gravity pulls on the mass and on the case equally, so gravity alone does not stretch the spring. What the sensor reports is the **specific force**:

```
f = a − g          (all vectors in the world frame, then rotated into the body)
    a = kinematic acceleration of the sensor
    g = gravity vector = (0, 0, −9.81) in ENU
```

Three cases fix the idea:

| Situation | a (ENU) | f = a − g (ENU) | Reading, level body (FLU) |
|---|---|---|---|
| Resting on a table | (0, 0, 0) | (0, 0, +9.81) | **(0, 0, +9.81)** |
| Free fall | (0, 0, −9.81) | (0, 0, 0) | (0, 0, 0) |
| Hover, quad at constant height | (0, 0, 0) | (0, 0, +9.81) | (0, 0, +9.81): thrust / mass |
| Accelerating forward at 2 m/s² on flat ground | (2, 0, 0) along heading | (2, 0, +9.81) | (2, 0, +9.81) |

> **The stationary convention.** An IMU at rest reads **+g upward**: +9.81 m/s² on body z in FLU, −9.81 on body z in FRD. JSBSim's `accelerations/a-pilot-z-ft_sec2` is in FRD, so it reads about **−32.1 ft/s²** on the ground.

The tests check this convention ([`test_sensors.py`](code/physics/tests/test_sensors.py)), and so does real hardware: PX4 and ArduPilot logs show about −9.8 on the FRD z accel of a vehicle on the bench. If your simulated vehicle at rest shows +9.8 on FRD z, or 0, or −9.8 in FLU, the sign is wrong. An attitude estimator fed with it will think the vehicle is upside down.

## Ideal IMU from PyBullet

PyBullet gives you the base's **world** linear velocity (of the center of mass) and **world** angular velocity. It has no "acceleration" query, so we difference the velocity:

```
a_world = (v_k − v_{k−1}) / dt
f_world = a_world − g_world,         g_world = (0, 0, −g)
f_body  = R_enu_fluᵀ · f_world
ω_body  = R_enu_fluᵀ · ω_world
```

```python
class ImuTruthFD:
    def __init__(self, g=G0):
        self.g_world = np.array([0.0, 0.0, -g])
        self._v_prev = None
        self._t_prev = None

    def update(self, t, v_world, w_world, R_enu_flu):
        v = np.asarray(v_world, float)
        if self._v_prev is None or t <= self._t_prev:
            a = np.zeros(3)
        else:
            a = (v - self._v_prev) / (t - self._t_prev)
        self._v_prev, self._t_prev = v, t
        Rt = np.asarray(R_enu_flu).T
        return Rt @ (a - self.g_world), Rt @ np.asarray(w_world, float)
```

Use it once per physics step, **after** `stepSimulation()`:

```python
p.stepSimulation()
pos, q = p.getBasePositionAndOrientation(body)
v, w = p.getBaseVelocity(body)
f_true, w_true = truth_imu.update(t, v, w, quat_to_matrix(q))
```

Why is a finite difference good enough here? PyBullet integrates with semi-implicit Euler: `v_k = v_{k−1} + a·dt`. So the difference of two consecutive velocities is exactly the acceleration the solver applied during that step. It is not an approximation of it. The test results show this. A box at rest on a plane read (0.000002, −0.00008, 9.80665) m/s². The same box resting on its side read (−0.00002, 9.80665, 0.0002), so +g moved to body y, the axis that now points up.

Things to watch:

- **Use the same `g` as the world.** `p.setGravity(0, 0, -9.80665)` and `ImuTruthFD(g=9.80665)`. If you set gravity to −10 for convenience, the IMU must use 10 too.
- **The first sample** has no previous velocity, so it reports only gravity. Skip it, or settle the body before t = 0, as the lab does.
- **Contacts are spiky.** A wheel hitting a curb gives a one-step acceleration of tens of m/s². A real IMU sees a filtered version, because its internal low-pass filter is at tens to hundreds of Hz. If you need that realism, add a first-order low-pass to `f_true`.
- **IMU not at the center of mass.** At an offset r from the COM, add the lever-arm terms in the body frame: `f_imu = f_com + α × r + ω × (ω × r)`. For a 5 cm offset at 3 rad/s, the extra term is 0.45 m/s². That is noticeable, but you can ignore it for a first model.

## Ideal IMU from JSBSim

JSBSim already computes the specific force for you. It reports it at the **pilot eyepoint** (`EYEPOINT` in `<metrics>`), in body FRD axes, in ft/s²:

| Property | Meaning | Unit |
|---|---|---|
| `accelerations/a-pilot-x-ft_sec2` (`-y-`, `-z-`) | specific force at the eyepoint, FRD | ft/s² |
| `accelerations/n-pilot-z-norm` | same, in g (about −1 at rest) | g |
| `velocities/p-rad_sec`, `q-rad_sec`, `r-rad_sec` | body rates, FRD | rad/s |

Convert once, on the physics side, to FLU and SI:

```python
def imu_truth_jsbsim(fdm):
    f_frd = np.array([fdm["accelerations/a-pilot-x-ft_sec2"], fdm["accelerations/a-pilot-y-ft_sec2"],
                      fdm["accelerations/a-pilot-z-ft_sec2"]]) * FT
    w_frd = np.array([fdm["velocities/p-rad_sec"], fdm["velocities/q-rad_sec"], fdm["velocities/r-rad_sec"]])
    flip = np.array([1.0, -1.0, -1.0])           # FRD <-> FLU
    return f_frd * flip, w_frd * flip
```

Measured with JSBSim 1.3.1 and `reference/code/aircraft/quad_rpy` resting on the ground (120 Hz, after 2 s): `a-pilot-z-ft_sec2 = −32.136` ft/s², which is +9.795 m/s² in FLU. It is not 9.80665 because JSBSim models gravity with latitude and altitude, and the model's initial position is at latitude 32°. So a test should use a tolerance, not equality.

Two JSBSim details:

- **Set `EYEPOINT` to where the IMU is.** In `quad_rpy`, `EYEPOINT` is at the CG (0, 0, 0), so `a-pilot` is the CG specific force.
- **The first `run()` after `run_ic()` reports 0.** In `sims/imu_jsbsim.py`, the sample at t = 0.008 s read (0, 0, 0), and from the next steps on it read +9.79. Skip that first sample.

`sims/imu_jsbsim.py` runs `quad_rpy` through ground → climb → hover → 10° roll step, and feeds the same `Imu` class. Its printout shows f_z rising to about 12.8 m/s² during the climb (thrust > weight). It also shows a short p-rate pulse (±0.06 rad/s) during the roll step.

### JSBSim's own sensor components

JSBSim can also model sensors inside the aircraft file, as flight-control components with `<accelerometer>`, `<gyro>`, `<magnetometer>` and `<sensor>`. This is useful when a JSBSim autopilot (also in XML) must fly on noisy signals. The following was tested with JSBSim 1.3.1 on a copy of `quad_rpy`:

```xml
<system name="imu-sensors">
  <channel name="imu">
    <accelerometer name="sensors/accel-z">
      <location unit="M"> <x>0</x><y>0</y><z>0</z> </location>
      <orientation unit="DEG"> <roll>0</roll><pitch>0</pitch><yaw>0</yaw> </orientation>
      <axis>Z</axis>
      <noise variation="ABSOLUTE" distribution="GAUSSIAN"> 0.1 </noise>
      <bias> 0.05 </bias>
    </accelerometer>
    <gyro name="sensors/gyro-r">
      <axis>Z</axis>
      <noise variation="ABSOLUTE" distribution="GAUSSIAN"> 0.002 </noise>
    </gyro>
  </channel>
</system>
```

At rest, `sensors/accel-z` averaged −32.078 ft/s² with standard deviation 0.10. That is −32.136 plus the 0.05 bias, so these components use the same FRD, ft/s², specific-force convention. Setting `fdm["simulation/randomseed"] = 5` **before** `load_model` gave bit-identical noise in two runs and different noise with seed 6. Other elements are `<lag>`, `<drift_rate>` and `<quantization>`. See the JSBSim reference for these.

**Which to use?** In this course, the Python models in `sensors.py` are the default. They are identical for PyBullet and JSBSim, they log truth and measurement side by side, and they are seeded from `run.json`. Use JSBSim's components only when the consumer of the noisy signal is itself inside JSBSim.

## Gyro

The gyro has no convention trap: `ω_body = Rᵀ ω_world` (PyBullet), or `(p, −q, −r)` from FRD to FLU (JSBSim). The errors that matter in practice are bias (it integrates into a heading drift) and bias random walk. With the default `bias_sigma = 0.005` rad/s, a one-sigma bias integrated for 60 s gives about 17° of heading error. That is why the magnetometer in [03](03_baro_mag_gps_air.md) exists.

## Try it

- Turn on the lever-arm term: put the IMU 0.1 m ahead of the COM and drive the lab's slalom. Compare `ay` with and without the ω × (ω × r) term.
- In PyBullet, drop the box from 1 m and log `f_true[2]` at 240 Hz. Where is it 0, and how large is the spike at impact?
- Run `sims/imu_jsbsim.py` and look at the 10° roll step at t = 6–7 s. `ay_true` stays below 0.2 m/s² even though the quad is tilted. Explain why: thrust acts along body z, so it does not show up on y. Then explain where the small `ay` after the step comes from. Hint: the quad now drifts sideways through the air.
- Write a 3-line test that fails if someone "fixes" `ImuTruthFD` to return `R.T @ (a + g_world)`.

## References

- [frames: Where gravity points](../reference/frames.md)
- PyBullet [Quickstart Guide](https://docs.google.com/document/d/10sXEhzFRSnvFcl3XxNGhnD4N2SedqwdAvK3dsihxVUA/), `getBaseVelocity`
- JSBSim [reference manual](https://jsbsim-team.github.io/jsbsim-reference-manual/) and the [FGAccelerometer class](https://jsbsim-team.github.io/jsbsim/classJSBSim_1_1FGAccelerometer.html)
- The [JSBSim course](../README.md#jsbsim-parallel-track), lessons 3–4 (forces, frames, the quad)
