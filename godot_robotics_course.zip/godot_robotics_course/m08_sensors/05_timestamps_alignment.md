# 05 Timestamps and alignment (0.75 h)

You now have about ten sensor streams at six different rates, from two processes, some delivered late. Each one is useless for estimation or evaluation unless you know **which instant** each sample describes. This page has one idea: **every sample carries the `t_sim` of the state it was computed from**. Then a few techniques use that tag correctly.

## Three different times

| Time | Meaning | Example |
|---|---|---|
| `t_valid` (logged as `t_sim`) | the sim instant the sample describes | GPS fix computed for t = 4.000 s |
| `t_arrive` | the sim time when the consumer received it | the fix reaches the estimator at t = 4.150 s |
| `t_wall` | the wall-clock time of the log write | only for measuring real latency |

Physics-side sensors know `t_valid` exactly: it is the step they sampled at. `Sampler` then holds the sample until `t_valid + latency`. Godot-side sensors know `t_valid` because the pose they cast from carried it in its header. They send that value back in the SENSOR header ([protocol](../reference/protocol.md): "On viewer → physics packets it is the sim time of the pose the data was computed from").

In the logs, `t_sim` is always `t_valid`. Other times get their own columns (`t_arrive`). That way `t_sim` is the join key across all streams, as [logging](../reference/logging.md) requires.

## Matching a Godot sample to its physics pose

The physics process keeps the poses it sent in a `PoseHistory`:

```python
history = PoseHistory()
...
br.send_pose(t, ROVER_ID, gp, gq, gv)
history.add(t, pos_enu, quat_enu_flu)          # keep ENU truth, keyed by the same t
...
for msg in br.poll(t):
    if msg["type"] == P.MSG_SENSOR:
        pose = history.exact(msg["t_sim"])     # the pose Godot used
```

`exact()` uses a plain dictionary lookup on the float. That is safe here, and only here, because `t_sim` travels as an **f64** in both directions. Godot stores it as a GDScript `float` (64-bit) and sends it back untouched, so the value that comes back is bit-for-bit the one that was sent. Never round-trip a time through f32: at t = 1000 s, f32 resolution is about 0.06 ms, and lookups start to fail.

How much does this matter? The lab measured it. The rover drives at up to 1.5 m/s, and Godot's sensor packets arrived 21–32 ms of sim time after the pose they used, with occasional ones up to 117 ms. For every forward range sample, we computed the expected range analytically in two ways:

| Pose used for the expected range | Max error vs Godot's ray | RMS error |
|---|---:|---:|
| `history.exact(msg.t_sim)`: the pose Godot actually used | 2.2 × 10⁻⁶ m | — |
| the newest pose at arrival (the common mistake) | 3.5–7.4 cm | 1.9 cm |

The matched error is float32 rounding of positions on the wire, so it is essentially zero. The mismatched error is speed × delay. At 1.5 m/s it is a few centimeters. On the fixed-wing in Module 11, at 25 m/s with the same delay, it is about 0.5–3 m. A lidar map built from mismatched poses smears every wall.

## Matching a camera frame to its pose

Camera frames ([Module 7](../m07_frame_transport/README.md)) have the same problem with one twist: the camera may render at an **interpolated** pose. `SimBridge.sample()` places the vehicle at a render time between two received poses. There are two correct approaches:

1. **Tag the frame with the render time you sampled at**, then interpolate truth to that time on the Python side with `PoseHistory.interp(t)` (lerp position, slerp quaternion). This gives smooth video and correct truth.
2. **Capture at received poses only.** Place the camera rig at the exact received pose before rendering, and tag the frame with that pose's `t_sim`. Then `history.exact(t)` works, just as for rays. This is simpler to verify, and it suits lock-step runs.

Either way, `frames.csv` must hold the `t_sim` of the pose the image shows, not the time the PNG was written. Check it with a moving target: the predicted image position of a known object, from the matched pose and the camera intrinsics, should agree with where it appears.

## Interpolating for alignment

To compare streams at different rates, resample one onto the other's timestamps. **Resample truth onto the measurement's times, never the reverse.** Interpolating noisy measurements invents data.

```python
from robosim.sensors import interp_series
imu = np.genfromtxt(run + "/imu.csv", delimiter=",", names=True)       # 240 Hz truth
gps = np.genfromtxt(run + "/gps.csv", delimiter=",", names=True)       # 5 Hz, late
# yaw rate truth at each GPS fix's time of validity:
gz_at_gps = interp_series(gps["t_sim"], imu["t_sim"], imu["gz_true"])
```

Linear interpolation is fine when the truth stream is at least 5–10× faster than the signal changes. For orientation, use `slerp` (as `PoseHistory.interp` does), not component-wise lerp of quaternions. Never interpolate across a RESET: the history should be cleared when the physics process resets, just as `SimBridge` clears its buffers.

## Logging truth and measurement side by side

The lab writes one row per delivered sample, with truth taken **at the sample's `t_valid`**:

| Stream | Rate | Key columns |
|---|---|---|
| `imu.csv` | 240 Hz | `t_sim, ax_true … az_true, ax_meas … az_meas, gx_true …, gx_meas …` |
| `baro.csv` / `mag.csv` | 50 Hz | `t_sim, alt_true, alt_meas, p_meas_pa` / `mx_true …, mx_meas …` |
| `gps.csv` | 5 Hz | `t_sim, t_arrive, e_true, n_true, u_true, e_meas, n_meas, u_meas` |
| `range.csv` | 20 Hz | `t_sim, t_arrive, range_true` (Godot ideal), `range_meas` (+ noise), `range_expected` (analytic, matched pose), `range_expected_latest` (analytic, newest pose) |
| `lidar.csv` | 10 Hz | `t_sim, t_arrive, n_hit, r000_true … r179_true, r000_meas … r179_meas` |
| `contact.csv` | 30 Hz | `t_sim, t_arrive, hit, nx, ny, nz, depth_m, overlap_expected_m` |
| `pose.csv` | 60 Hz | `t_sim, e, n, u, qx, qy, qz, qw, yaw_deg, speed` |

Notice where the noise for Godot's sensors is added. Godot returns the **ideal** geometric distance. Python applies `RangeNoise` with a seed from the same `run.json`. This keeps all randomness in one process and one seed, and it gives each row a true and a measured value with no extra effort. It also means `compare_runs.py` can check that Godot sensor streams are reproducible as well. In our runs they were, because each scan arrived and was processed in `t_sim` order.

There is one catch: UDP can drop a packet. Then the noise stream shifts by one draw for every later sample, and two runs stop being identical from that point on. If bit-exact replay of the Godot sensors matters, derive each sample's noise from `(seed, sensor, t_sim)` instead of from a running stream. A **Stretch goal** in the lab asks you to do this.

## Try it

- In `range.csv`, plot `range_expected_latest − range_true` against the rover's speed from `pose.csv` (join on `t_sim`). Fit a line: the slope is the effective delay. Compare it with `sensor_delay_sim_s_mean` in `summary.json`.
- Change `history.exact(ts)` to `history.interp(ts + 0.0001)` and re-run. Which numbers in `summary.json` change, and by how much?
- Add a 50 ms artificial delay in Godot: hold the queue for three extra physics ticks before casting. Show that the matched error stays at the 10⁻⁶ m level while the arrival delay grows.
- For GPS, compute the error against truth at `t_arrive` instead of `t_sim`. How much larger is the RMS error at 1.5 m/s? At 25 m/s?

## References

- [Logging rules](../reference/logging.md): `t_sim` is the join key
- [Protocol](../reference/protocol.md): SENSOR header semantics
- [Module 5](../m05_time_rates/README.md): interpolation buffers, RESET handling
- ROS [`message_filters`](http://wiki.ros.org/message_filters) (`ApproximateTime`): the same problem in ROS
