# Module 8: Synthetic sensors and ground truth (8 h)

## What you will build

Your rover gets two kinds of sensors. The physics process gets an IMU, barometer, magnetometer and GPS, built from PyBullet or JSBSim truth with seeded noise models. Godot gets a forward range sensor, a 180-ray 2D lidar and a contact sensor, fired at the exact pose the physics process sent. One log holds truth and measurement side by side, and every Godot sample can be matched to its physics pose by `t_sim`.

## Prerequisites

- [Module 4](../m04_bridge/README.md): the bridge, `SimBridge.send_sensor`, `PhysicsBridge.poll`
- [Module 5](../m05_time_rates/README.md): sim time vs wall time, interpolation, `RunLogger`
- [Module 6](../m06_cameras/README.md) and [Module 7](../m07_frame_transport/README.md): cameras and frame metadata (this module only points back to them)
- Reference pages: [frames](../reference/frames.md) (especially "Where gravity points"), [protocol](../reference/protocol.md) (SENSOR message), [logging](../reference/logging.md)

## The one rule of this module

> **"Would the reading change if I moved a wall?"** Yes → the sensor lives in Godot. No → it lives in the physics process.

| Physics process (Python) | Godot (viewer) |
|---|---|
| IMU: accelerometer + gyro | RGB, depth, segmentation cameras (Modules 6–7) |
| Barometer, magnetometer | Forward rangefinder toward obstacles (`RayCast3D`) |
| GPS | Lidar: many rays with `intersect_ray` |
| Airspeed, alpha/beta vanes | Proximity (`ShapeCast3D`) |
| Downward rangefinder over **terrain only** | Contact / bumper (`Area3D` shape) |
| Motor RPM, battery voltage | Target bounding box (SENSOR_TARGET_BOX) |

## Sub-topics

| File | Topic | Time |
|---|---|---:|
| [01_truth_and_error_models.md](01_truth_and_error_models.md) | Ground truth vs measurement; noise, bias, random walk, scale, quantization, rate, latency; seeded RNG | 1 h |
| [02_imu.md](02_imu.md) | Specific force and the stationary convention; ideal IMU from PyBullet and from JSBSim | 1.25 h |
| [03_baro_mag_gps_air.md](03_baro_mag_gps_air.md) | Barometer, magnetometer, GPS, air data, terrain rangefinder, motor and battery | 1 h |
| [04_godot_range_lidar_contact.md](04_godot_range_lidar_contact.md) | `RayCast3D`, `intersect_ray` lidar, masks, cost per ray, `ShapeCast3D`, contact | 1.25 h |
| [05_timestamps_alignment.md](05_timestamps_alignment.md) | One `t_sim` per sample; matching Godot samples and camera frames to poses; interpolation | 0.75 h |
| [lab.md](lab.md) | Sensors on the rover, end to end, with a log and a plot | 2.75 h |

## Deliverables

- `physics/robosim/sensors.py` and `physics/tests/test_sensors.py` (all tests pass)
- `physics/sims/sensors_pybullet.py` (PyBullet rover with physics-side sensors, receives Godot sensors)
- `physics/sims/imu_jsbsim.py` (same models on the JSBSim `quad_rpy`)
- `godot/sensors/`: `sensor_clock.gd`, `range_sensor.gd`, `lidar_2d.gd`, `contact_sensor.gd`, `ray_bench.tscn`
- `godot/sensors_demo.tscn`: the sensor test range
- `tools/plot_sensors.py`, `tools/compare_runs.py`
- One run folder in `logs/` with `imu.csv`, `gps.csv`, `range.csv`, `lidar.csv`, `contact.csv`, `summary.json` and `sensors.png`

## Check

1. **Stationary accelerometer convention.** `python tests/test_sensors.py` passes. It includes these checks:
   - A PyBullet box resting level reads (0, 0, +9.81) m/s² in FLU, within 0.02. A box resting on its side reads +9.81 on body y.
   - A body in free fall reads (0, 0, 0).
   - JSBSim `quad_rpy` on the ground has `accelerations/a-pilot-z-ft_sec2` between −32.3 and −32.0 ft/s², which converts to about +9.79 m/s² up in FLU.
2. **Noise is reproducible.** Run `sensors_pybullet.py --seed 42` twice. `python tools/compare_runs.py <runA> <runB>` prints `RESULT: identical`. That covers every measurement column; wall-clock columns are ignored. With `--seed 7`, the result is `different`.
3. **Godot samples match the right physics pose.** In `summary.json` after a run with the viewer:
   - `unmatched_sensor_packets` is 0. Every SENSOR packet's `t_sim` is found exactly in the pose history.
   - `range_max_abs_err_matched_m` < 0.001. Godot's ideal range agrees with the range computed in Python from the matched pose.
   - `lidar_hit_mismatch_rays` is 0 and `lidar_max_abs_err_m` < 0.001.
   - `range_rms_err_if_latest_pose_m` is clearly larger. That is the error you get if you pair each sample with the newest pose instead.
4. **Cost measured.** You ran `ray_bench.tscn` and wrote down the µs per 1000 rays on your machine.

On the course test machine (Xeon 2.1 GHz, 2 cores, Godot headless), the values were: matched range error 2.2 × 10⁻⁶ m, lidar error 2.3 × 10⁻⁵ m, and latest-pose error 1.9 cm RMS / 3.5–7.4 cm max at 1.5 m/s. One 180-ray scan took 0.3–0.5 ms.

## Common mistakes

- **Accelerometer reads −g at rest.** That is the sign of acceleration, not specific force. A real IMU on a table reads +g **up**. In JSBSim's FRD axes, "up" is −z, so `a-pilot-z` is about −32.2 ft/s².
- **Noise from the global `np.random`.** Results then change whenever any other code draws a random number. Give each sensor its own generator, derived from the run seed and the sensor name.
- **Tagging a Godot sample with "now".** The ray was cast from a specific pose. Send that pose's `t_sim`, not `latest_t_sim` or wall time. Use the received pose, not the interpolated render pose.
- **Comparing a measurement to truth at arrival time.** A GPS fix that arrives 150 ms late describes where the vehicle **was**. Look up truth at the sample's time of validity.
- **Lidar rays that hit the vehicle or the ground.** Put obstacles and terrain on separate collision layers, and give each sensor a mask. The viewer's vehicle meshes should have no colliders at all.
- **Moving a wall in Godot and expecting PyBullet to stop at it.** Godot-only obstacles exist only for Godot sensors. If the vehicle must also bounce off an obstacle, the obstacle must exist in the physics engine too.
