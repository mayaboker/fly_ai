# 04 Godot-side sensors: range, lidar, proximity, contact (1.25 h)

Range, lidar, proximity and contact sensors answer a question about **scene geometry**: "what is in front of me, and how far away?" Godot owns the scene, so Godot computes them. This is also where Godot pays off: its physics server can answer thousands of ray queries per frame against the same colliders you placed in the editor, without copying the world into PyBullet.

Cameras are geometry sensors too. You built RGB capture in [Module 6](../m06_cameras/README.md) and frame transport in [Module 7](../m07_frame_transport/README.md). A **depth** camera is the same pipeline with a shader that writes linear depth. A **segmentation** camera uses unshaded materials with one flat color per class. For dense 3D range data, a depth camera usually beats casting rays one by one (see the cost section below). This page covers the ray-based sensors.

## Three rules for every Godot sensor

1. **Cast from the pose the physics process sent, not from the rendered pose.** The viewer draws the vehicle at an interpolated pose about one pose period in the past ([Module 5](../m05_time_rates/README.md)). That pose has no single `t_sim` that physics knows about. Instead, connect to `SimBridge.pose_received` and cast from `Transform3D(Basis(msg.quat), msg.pos)`, then tag the result with `msg.t_sim`.
2. **Query in `_physics_process`.** `PhysicsDirectSpaceState3D` is only guaranteed safe to use there. The pose arrives in `_process` (where `SimBridge` reads its socket), so queue it and cast on the next physics tick. The `t_sim` stays exact.
3. **Sample on sim time.** A 20 Hz sensor fires on every 3rd pose of a 60 Hz stream, whatever Godot's frame rate. `RsSensorClock` does this with `k / rate` instants, exactly like `Sampler` in Python.

```gdscript
class_name RsSensorClock
extends RefCounted

var rate_hz: float
var _next_t := 0.0

func _init(hz: float) -> void:
	rate_hz = hz

func due(t_sim: float) -> bool:
	if t_sim + 1e-9 < _next_t:
		return false
	_next_t = (floorf(t_sim * rate_hz + 1e-6) + 1.0) / rate_hz
	return true

func reset() -> void:
	_next_t = 0.0
```

## Collision layers and masks

The rays must hit obstacles. They must not hit the vehicle, the sensor itself, or (for a horizontal lidar) the ground. Plan your layers once and write the plan down:

| Layer | Name | Who is on it |
|---|---|---|
| 1 | terrain | ground mesh `HeightMapShape3D`, roads |
| 2 | obstacles | walls, pillars, curbs, parked cars |
| 3 | (free) | e.g. glass that cameras see and lidar does not |

Give each sensor a mask. The range sensor and lidar use `0b11` (terrain + obstacles). The contact sensor uses `0b10` only, so it does not trigger on the ground it drives on. Name the layers in *Project Settings → Layer Names → 3D Physics* so the inspector shows names instead of numbers.

The viewer's vehicle meshes have **no colliders**. The physics process owns the vehicle's body, and Godot only draws it. So rays never hit "self". If you do add an `Area3D` or a body to the vehicle, keep it off the layers your sensors scan, or pass its RID in `PhysicsRayQueryParameters3D.exclude`.

## Forward rangefinder with `RayCast3D`

`RayCast3D` is the node version of a single ray. You can see it in the editor (*Debug → Visible Collision Shapes*), and you can set its mask in the inspector. With `enabled = false` it never updates by itself. You place it and call `force_raycast_update()`:

```gdscript
class_name RsRangeSensor
extends Node3D
## Child of the vehicle node; its local transform is the mount. Ray along its -Z.

@export var bridge_path: NodePath
@export var vehicle_id := 1
@export var rate_hz := 20.0
@export var max_range := 30.0
@export_flags_3d_physics var collision_mask := 0b11

var _bridge: SimBridge
var _clock: RsSensorClock
var _queue: Array[Dictionary] = []
var _ray := RayCast3D.new()

func _ready() -> void:
	_bridge = get_node(bridge_path) as SimBridge
	_clock = RsSensorClock.new(rate_hz)
	_bridge.pose_received.connect(_on_pose)
	_bridge.physics_reset.connect(_on_reset)
	_ray.top_level = true                     # we place it ourselves, at the physics pose
	_ray.enabled = false
	_ray.target_position = Vector3(0, 0, -max_range)
	_ray.collision_mask = collision_mask
	add_child(_ray)

func _on_pose(id: int, msg: Dictionary) -> void:
	if id == vehicle_id and _clock.due(msg.t_sim):
		_queue.append(msg)

func _physics_process(_delta: float) -> void:
	for msg in _queue:
		var vehicle_xf := Transform3D(Basis(msg.quat), msg.pos)
		_ray.global_transform = vehicle_xf * transform          # pose * mount
		_ray.force_raycast_update()
		var d := INF
		if _ray.is_colliding():
			d = _ray.global_position.distance_to(_ray.get_collision_point())
		_bridge.send_sensor(msg.t_sim, vehicle_id, RsProtocol.SENSOR_RANGE, PackedFloat32Array([d]))
	_queue.clear()
```

(`_on_reset` clears the clock and the queue; see the full file in `code/godot/sensors/range_sensor.gd`.)

The key line is `vehicle_xf * transform`. The sensor's own `transform` is its mount relative to the vehicle node: in the lab, `(0, 0.05, -0.3)`, at the nose, looking forward. Multiplying it by the received pose gives the sensor's world pose at exactly `msg.t_sim`, whatever the rendered vehicle is doing. `top_level = true` on the inner ray makes `global_transform` mean what we set, independent of the parent.

`INF` is sent as an IEEE infinity in the f32 payload. Python's `struct` reads it back as `math.inf`, which is the protocol's "no hit".

## 2D lidar with `intersect_ray`

A lidar is many rays from one origin. Creating 180 `RayCast3D` nodes works, but it is clumsy. Use the space state directly, with one reusable query object:

```gdscript
func _physics_process(_delta: float) -> void:
	if _queue.is_empty():
		return
	var space := get_world_3d().direct_space_state
	for msg in _queue:
		var xf := Transform3D(Basis(msg.quat), msg.pos) * transform      # pose * mount
		for i in n_rays:
			_query.from = xf.origin
			_query.to = xf.origin + xf.basis * (_dirs[i] * max_range)
			var hit := space.intersect_ray(_query)
			last_scan[i] = INF if hit.is_empty() else xf.origin.distance_to(hit.position)
		_bridge.send_sensor(msg.t_sim, vehicle_id, RsProtocol.SENSOR_RANGE, last_scan)
	_queue.clear()
```

`_dirs` is computed once in `_ready()`. Ray i points at angle `a_i = −fov/2 + (i + 0.5)·fov/n` from forward (−Z), positive toward the left (−X), which is a ROS `LaserScan` convention:

```gdscript
_dirs.append(Vector3(-sin(a), 0.0, -cos(a)))
```

With 180 rays over 180°, the rays are 1° apart, from −89.5° (right) to +89.5° (left). The packet is 24 + 4·180 = 744 bytes, well within one UDP datagram.

**Two sensors, one message type.** The forward range sensor and the lidar both send `SENSOR_RANGE`. The protocol has no sensor-instance field, so the lab's Python side tells them apart by `count` (1 = forward range, 180 = lidar). That works for one vehicle with one sensor of each size. With more sensors, give each one its own vehicle id from the 10+ range, or propose a new message type ([protocol: changing the protocol](../reference/protocol.md#changing-the-protocol)).

## What does a ray cost?

Measure this on your own machine, with your own scene. Run `godot --headless --path godot res://sensors/ray_bench.tscn`. It casts 1000 random 30 m rays, repeats 5 times, and reports the best time. These are the results from the course test machine (Xeon 2.1 GHz, Godot 4.7.2 headless), in **µs per 1000 queries**:

| World | Engine | `intersect_ray` | `RayCast3D` + force update | `ShapeCast3D`, 0.25 m sphere, 5 m |
|---|---|---:|---:|---:|
| sensor range (6 shapes) | Godot Physics | 700 | 410 | 1 860 |
| + 500 boxes | Godot Physics | 6 670 | 5 790 | 18 460 |
| heightmap 257×257 | Godot Physics | 2 770 | 1 450 | 51 840 |
| sensor range (6 shapes) | Jolt | 660 | 380 | 750 |
| + 500 boxes | Jolt | 2 090 | 880 | 22 040 |
| heightmap 257×257 | Jolt | 2 420 | 1 220 | 880 |

In the lab, the GDScript lidar loop (with the transform math) took **1.6–2.9 µs per ray** over five runs: **0.3–0.5 ms per 180-ray scan**, so 3–5 ms per second at 10 Hz. That is cheap. Several lessons follow from the numbers:

- **The scene matters more than the API.** 500 extra boxes made each ray 10–14× slower with Godot Physics.
- **The physics engine matters.** *Project Settings → Physics → 3D → Physics Engine* selects Godot Physics or Jolt. A `project.godot` with no such line behaved like Godot Physics in our test (the setting printed `DEFAULT`). Benchmark both on your scene before choosing.
- **`intersect_ray` allocates a Dictionary per call.** In these tests, a forced `RayCast3D` was often faster.
- **A spinning 3D lidar is a different class of problem.** 16 channels × 1800 steps × 10 Hz is 288 000 rays per second. At about 2 µs each, that is about 0.5 s of CPU per simulated second in GDScript. Use a depth camera ([Module 6](../m06_cameras/README.md)) and convert depth to points. Or write the ray loop in C++ (GDExtension).

## Proximity with `ShapeCast3D`

A ray is infinitely thin. It slips past a thin pole between two lidar beams. For "is anything within 5 m ahead of my 0.5 m wide body?", sweep a shape instead:

```gdscript
var sc := ShapeCast3D.new()
var sph := SphereShape3D.new()
sph.radius = 0.25
sc.shape = sph
sc.enabled = false
sc.target_position = Vector3(0, 0, -5)          # sweep 5 m forward (-Z)
sc.collision_mask = 0b10
add_child(sc)
# in _physics_process, at the pose:
sc.global_transform = Transform3D(Basis(msg.quat), msg.pos) * mount
sc.force_shapecast_update()
if sc.is_colliding():
	var free_dist := sc.get_closest_collision_safe_fraction() * sc.target_position.length()
```

We tested this against a wall 4.9 m ahead. `free_dist` came out as 4.63 m, while the exact value is 4.9 − 0.25 = 4.65 m. The "safe fraction" is found by a conservative search, so it is a few centimeters short. If you need the exact clearance, use `get_collision_point(0)` and subtract the radius. As the table shows, shape casts cost much more than rays, so keep them few and short.

## Contact with an `Area3D`

A bumper or "touching an obstacle" sensor is a shape overlap test. `RsContactSensor` extends `Area3D`, so you can give it a `CollisionShape3D` child in the editor like any other area. It still does the query itself, at the exact pose:

```gdscript
global_transform = Transform3D(Basis(msg.quat), msg.pos) * _mount
_params.transform = global_transform * _shape_node.transform
var info := space.get_rest_info(_params)             # empty when not touching
if not info.is_empty():
	var pts := space.collide_shape(_params, 8)        # pairs: our point, obstacle point
	for k in range(0, pts.size() - 1, 2):
		depth = maxf(depth, pts[k].distance_to(pts[k + 1]))
	values = PackedFloat32Array([1, info.normal.x, info.normal.y, info.normal.z, depth])
_bridge.send_sensor(msg.t_sim, vehicle_id, RsProtocol.SENSOR_CONTACT, values)
```

Why not just use the `body_entered` signal? Area overlaps are computed during the physics step **after** you move the area. So the signal describes a pose you no longer have a `t_sim` for. The signals still work, and they are good for sounds and UI. In the lab, the area's `body_entered` fired once, and the packets switched from 0 to 1 exactly once. For the bridge, the direct query is exact. In the lab, the reported depth matched the analytic overlap of the rover and the curb to better than 0.001 mm (0.00397044 m vs 0.00397072 m).

**When is a Godot contact meaningful?** Only for obstacles that exist **only** in Godot, such as a curb, a geofence volume or a target zone. If the vehicle must physically bounce off something, that object must exist in the physics engine. Then PyBullet's own `getContactPoints` is the contact sensor, and it belongs on the physics side.

## Target box

`SENSOR_TARGET_BOX` (visible, cx, cy, w_px, h_px; cx, cy in −1…1 with +cx right and +cy down, as in the [protocol](../reference/protocol.md)) follows the same pattern: project a target's bounding box through the camera at the exact pose (`Camera3D.unproject_position` on the 8 corners), and check visibility with one ray. Module 12 uses it.

## Try it

- Add a 0.05 m-thick pole at ENU (12, 1) to `sensors_demo.gd`. At what range does the 1°-spaced lidar stop seeing it reliably? Does a `ShapeCast3D` with r = 0.25 m see it?
- Change the lidar to 720 rays and read the `us_per_ray` line that the demo prints when it quits. Is the cost per ray constant?
- Put the floor on layer 2 instead of 1 and tilt the lidar down 5°. Which rays now hit the ground, and at what range?
- Run `ray_bench.tscn` with Jolt and with Godot Physics on your machine and fill in the table above for your scene.

## References (Godot 4.7)

- [Ray-casting tutorial](https://docs.godotengine.org/en/stable/tutorials/physics/ray-casting.html)
- [RayCast3D](https://docs.godotengine.org/en/stable/classes/class_raycast3d.html), [ShapeCast3D](https://docs.godotengine.org/en/stable/classes/class_shapecast3d.html), [Area3D](https://docs.godotengine.org/en/stable/classes/class_area3d.html)
- [PhysicsDirectSpaceState3D](https://docs.godotengine.org/en/stable/classes/class_physicsdirectspacestate3d.html), [PhysicsRayQueryParameters3D](https://docs.godotengine.org/en/stable/classes/class_physicsrayqueryparameters3d.html)
- [Collision layers and masks](https://docs.godotengine.org/en/stable/tutorials/physics/physics_introduction.html#collision-layers-and-masks)
- [Using Jolt Physics](https://docs.godotengine.org/en/stable/tutorials/physics/using_jolt_physics.html)
