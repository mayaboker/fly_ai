# Module 12: Integration capstone and evaluation (10 h)

## What you will build

One complete, repeatable scenario on top of everything you built: a vehicle, a camera or sensor, an estimate computed from it, ground truth to judge the estimate, logs that tie images to telemetry by simulation time, timing measurements, and a run with injected network faults. You choose one of three options, document it so that someone else can reproduce it from a clean start, and show it in a short demo.

![Option A reference starter: TTC from vision (blue) against the true TTC (grey)](img/ttc_baseline.png)

## Prerequisites

- Modules 1–8 done, and the vehicle lab your option builds on: Module 10 (option A), Module 9 (option B) or Module 11 (option C).
- The [protocol](../reference/protocol.md), [frames](../reference/frames.md) and [log format](../reference/logging.md) pages. Your documents refer to them instead of repeating them.
- `ffmpeg` (or OBS) for the 60-second recording.

## Sub-topics

| File | Topic | Time |
|---|---|---:|
| [01_choosing_an_option.md](01_choosing_an_option.md) | Options A, B, C: what each one tests, what it reuses, how to pick | 0.5 h |
| [02_requirements_and_documents.md](02_requirements_and_documents.md) | Runnable project, setup, protocol document, frames diagram, timestamps and logs | 1 h |
| [03_measurement_and_validation.md](03_measurement_and_validation.md) | Frame rate, pose age, image latency; estimate vs truth; one sim time for image and telemetry; the 60 s recording | 1 h |
| [04_failure_injection.md](04_failure_injection.md) | 10 % packet loss or 100 ms latency, where to inject it, what to report | 0.75 h |
| [05_reference_starter_option_a.md](05_reference_starter_option_a.md) | The tested option A starter: JSBSim quad, target box, tau, braking; measured results | 0.75 h |
| [lab.md](lab.md) | The capstone itself, step by step | 6 h |

Per-option guidance: [option_a_ttc.md](option_a_ttc.md), [option_b_ugv.md](option_b_ugv.md), [option_c_fixed_wing.md](option_c_fixed_wing.md).
Assessment: [grading_rubric.md](grading_rubric.md), [report_template.md](report_template.md), [demo_checklist.md](demo_checklist.md).

## Deliverables

1. The project: your `robosim/` tree with the scenario script, the Godot scene, tools and a `README_capstone.md` with setup and run instructions.
2. `docs/protocol.md` (v1 by reference, plus your extensions), `docs/frames.md` (your frames diagram, every transform and unit).
3. Three run folders in the course log format: **nominal**, **failure injection**, and **reproduction from a clean start**.
4. The plot of your estimate against ground truth, with the error numbers.
5. A 60-second recording of the nominal run.
6. The report, filled in from [report_template.md](report_template.md).
7. The demo ([demo_checklist.md](demo_checklist.md)).

## Check (acceptance)

1. **Reproducible from a clean start.** A fresh clone, the setup steps in your README, and one documented command per process produce a run whose key numbers match your reported nominal run within the tolerances you state (the starter: same final state, final distance within 0.1 m).
2. **All transforms and units specified.** Every frame change between physics, wire, Godot, camera and image appears in your frames document with its matrix or rule and its units. Someone else can compute a pixel from a physics pose with it.
3. **Image and telemetry agree on time.** You show one captured image and the telemetry sample with the same `t_sim` (within one physics step), and the image itself carries that time (file name and `frames.csv`, and ideally burnt into the pixels).
4. **Estimate vs truth.** A plot and at least two error numbers (for example bias and RMSE) over a stated window. Starter reference: TTC RMSE 0.073 s, bias +0.045 s.
5. **Timing measured.** Frame rate, pose age and image latency on your machine, with the hardware stated.
6. **Failure injection.** One run with 10 % packet loss or 100 ms added latency, the same metrics, and a sentence on what the vehicle did differently. Starter reference (100 ms): braking started 0.15 s later and 0.38 m closer, the drone still stopped (0.13 m closer than nominal); TTC RMSE 0.150 s.
7. **Documents and demo** complete as per the rubric.

## Common mistakes

- **Timing on the wrong clock.** Estimating TTC from the arrival time of image data turns network jitter into fake looming. Use the `t_sim` in the packet header: the sim time of the pose the image was rendered from.
- **Reporting software-renderer numbers as the result.** Our starter ran at 60 FPS headless but 3 FPS with llvmpipe rendering, and at 3 FPS the same controller crashed into the target. Measure on the machine you demo on, and state it.
- **Ground truth from the same pipeline as the estimate.** If truth and estimate both come from Godot's projection, a frame error cancels out. Compute truth on the physics side from the scenario file.
- **One run.** A single run hides variance. Run the nominal case at least three times (different seeds if anything is random) and report the spread.
- **Injecting faults in the wrong place.** Dropping packets inside the estimator is not the same as dropping them on the wire. Inject in the transport (both directions), log what was dropped, and keep the seed.
- **Undocumented extensions.** If you added a message type, a command or a column, it goes into `docs/protocol.md` before the demo, not after.
