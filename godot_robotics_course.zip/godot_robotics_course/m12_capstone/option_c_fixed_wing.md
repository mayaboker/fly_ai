# Option C: fixed-wing approach visualised from JSBSim

The JSBSim trainer from Module 11 flies an approach toward the landing pad and over it at low height. A camera measures where the aircraft is relative to the desired glide path, and you compare that with JSBSim's truth. The simplest honest version is open-loop: the autopilot flies on truth, the vision estimate is judged on the side. Closing the loop on the estimate is the extension.

There is no separate starter: [Module 11](../m11_jsbsim_fixed_wing/README.md)'s code is the starting point.

## Start from

| You need | From | Files |
|---|---|---|
| Trainer, autopilot, terrain feed, crash logic | [Module 11](../m11_jsbsim_fixed_wing/lab.md) | `physics/sims/plane_jsbsim.py`, `robosim/jsbsim_vehicle.py` |
| Viewer, HUD, skirt, TELEMETRY | Module 11 | `scenes/plane_lab.*`, `ui/flight_hud.gd`, `bridge/telemetry_bridge.gd` |
| Pad, apron, range | [Module 2](../m02_scene_assets/README.md) | `range.json` (`pad` at ENU (0, 0), flat apron 0 m) |
| Cameras, intrinsics, ideal boxes | [Module 6](../m06_cameras/README.md) | `camera_rig.gd`, `camera_intrinsics.gd`, `target_box.gd` |
| Air data, baro | [Module 8](../m08_sensors/03_baro_mag_gps_air.md) | physics-side sensors |

## The scenario

Add an `approach` scenario to `plane_jsbsim.py`:

1. Start 250–300 m out on the extended centerline (for example south of the pad, heading north) at about 30 m. The map is 256 m wide, so a long final starts over the skirt; that is fine, the terrain feed clamps to the edge height there.
2. Descend on a fixed glide path (for example 6°, steeper than an airliner because the field is small) toward an aim point at the pad, at 14–16 m/s.
3. At 5 m above the pad, go around: climb back to 30 m. (The trainer has no landing gear worth the name; a low pass keeps the scenario repeatable.)

The autopilot's altitude command becomes `h_cmd = h_pad + tan(γ) · distance_to_aim_point`.

## The estimate (choose one)

**C1, ground camera (recommended).** A fixed camera at the aim point looks along the approach path, up by the glide angle. The ideal box of the aircraft (Module 6 `TargetBox` on the plane's body box) gives the aircraft's position in the image. The vertical image coordinate gives the elevation angle seen from the aim point, so the **glide-path deviation in degrees** is `atan((cy0 − cy_px) / fy)` relative to the camera's tilt (image rows grow **downward**, so an aircraft above the glide path has `cy_px < cy0` and a positive deviation), and the box size gives a range estimate (`range ≈ fy · span / w_px`).

**C2, onboard camera.** The aircraft's `fpv_cam` sees the pad. Detect the pad's corners (ideal: project the known corners; real: color threshold) and solve for the camera pose with `cv2.solvePnP`. That gives position relative to the pad, a fuller estimate and more work.

## Ground truth

From JSBSim, in ENU, at every logged step:

```
distance   = horizontal distance from the aim point along the approach course
gp_angle   = atan2(h_asl − h_aim, distance)          (deg)
deviation  = gp_angle − γ_desired                    (deg; + = high)
```

Compare at the `t_sim` of the frame the measurement came from.

## Failure injection

Open-loop, a fault does not change the flight, so report how it changes the **reported** deviation: with 100 ms latency at 15 m/s on a 6° path, the aircraft descends about 0.16 m in 100 ms, which near the aim point is a large fraction of a degree. Measure it. If you close the loop on the estimate, report the flight's response as well (deviation RMS, height over the pad at the go-around).

## Pitfalls

| Pitfall | Symptom | Fix |
|---|---|---|
| Ground camera tilt not in the frames document | constant deviation bias | write the camera pose (Module 6 extrinsics JSON) into `docs/frames.md` |
| Angles near the aim point | deviation blows up as distance → 0 | stop evaluating below a minimum distance (say 20 m) and state it |
| Feet in the logs | factor-3.28 errors | convert in Python once (Module 11, sub-topic 03) |
| Wrong vertical reference | deviation offset by the pad height | use ASL everywhere; the pad is at 0 m on Module 2's terrain, but read it, do not assume it |
| Aircraft too small in the ground camera | 2–3 px box, noisy estimate at long range | narrower FOV (zoom), higher resolution, or accept a range limit and state it |

## Checklist for option C

- [ ] approach + go-around flown from a clean start, plotted (track, height, glide path)
- [ ] glide-path deviation: estimate vs truth over a stated distance window, bias and RMS
- [ ] image–telemetry acceptance with one recorded frame
- [ ] failure run with the effect on the reported (or flown) deviation
- [ ] frame rate, pose age, image latency on your machine
- [ ] `docs/frames.md` covers JSBSim → Godot (Module 11) and the camera's own pose and intrinsics
