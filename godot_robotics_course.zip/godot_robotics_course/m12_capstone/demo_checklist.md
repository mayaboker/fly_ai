# Capstone demo checklist

The demo is 10 minutes: 6 minutes of showing, 4 of questions. Rehearse it once from a cold machine. Tick each line during the rehearsal.

## Before the demo (the day before)

- [ ] Fresh clone in a new folder, fresh venv, README followed exactly. The run works.
- [ ] Ports 9001/9002 free (`ss -ulpn | grep 900`); no old viewer or physics process running.
- [ ] Nominal, failure and reproduction run folders are in the submission, with plots generated from them.
- [ ] The 60-second recording plays.
- [ ] You know your three most important numbers by heart, and which file each one comes from.
- [ ] Screen resolution and font size: the HUD is readable on the projector.

## During the demo

**1. Start (1 min)**
- [ ] Start the viewer, then the physics process (or the other order: say which, and that both work).
- [ ] Point out the stale/connected status in the viewer.

**2. Nominal run (2 min)**
- [ ] Narrate the states as they happen (takeoff, acquire, cruise, brake, hold; or lap / approach).
- [ ] Show the camera view the estimate comes from.
- [ ] Show the HUD values that matter (τ, offset, deviation) next to their truth.

**3. Evidence (2 min)**
- [ ] Open the estimate-vs-truth plot of the run you just made (generate it live if it takes < 10 s).
- [ ] Show one recorded image and the telemetry row with the same `t_sim`.
- [ ] Show the timing table and say which machine it was measured on.

**4. Failure (1 min)**
- [ ] Show the failure run's plot or rerun it live (`--latency 0.1` or `--drop 0.1`).
- [ ] Say in one sentence what the vehicle did differently, with a number.

## Questions you should be ready for

- Where exactly is `t_sim` attached to the image data, and how do you know it is the right frame?
- Which transform would you change to move the camera 10 cm forward, and what else changes?
- Why does your estimate have the bias it has?
- What happens if the viewer runs at 10 FPS? (Have a number or a reasoned estimate, and say which it is.)
- If you added a new message, why a new type and not a new field?

## After the demo

- [ ] Any number you quoted that is not in the report: add it with its source, or remove it.
- [ ] Note any question you could not answer in the report's limitations section.
