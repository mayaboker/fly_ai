# 04 Failure injection

A simulator that only works on a perfect loopback link has not been tested. Real links lose packets and add delay, and a robot's software must degrade gracefully. The capstone asks for one run with **10 % packet loss or 100 ms added latency**, the same metrics as the nominal run, and a sentence on what the vehicle did differently. This page shows where to inject, what the starter does, and what we measured.

## Where to inject

| Place | How | Pros | Cons |
|---|---|---|---|
| In the physics process's transport (starter) | wrap what `poll()` returns: drop with probability p, hold the rest for L seconds; drop outgoing poses with probability p | seeded, logged, no root, per-run, both directions | does not delay the viewer's view of poses |
| In the viewer | the same, around `SimBridge` | delays poses too | needs GDScript changes, harder to seed |
| On the network | `tc qdisc add dev lo root netem loss 10% delay 100ms` (Linux, root) | the real thing, both directions, all messages | affects **every** program on loopback, needs root, easy to forget to remove. Not tested here. |

Do not inject inside the estimator ("skip every tenth update"). That tests the estimator, not the system, and it hides what the transport rules (latest wins, reliable commands) do for you.

## The starter's injector

```python
class LossyInbox:
    """Failure injection on the receive side: drop a fraction, delay the rest (wall clock)."""
    def push(self, msgs):
        now = time.monotonic()
        for m in msgs:
            self.seen += 1
            if self.rng.random() >= self.drop:
                self.q.append((now + self.latency, m))
            else:
                self.dropped += 1

    def pop_ready(self):
        now, out = time.monotonic(), []
        while self.q and self.q[0][0] <= now:
            out.append(self.q.popleft()[1])
        return out
```

The main loop pushes everything `br.poll()` returns and uses only what `pop_ready()` releases. Outgoing poses and telemetry are dropped with the same probability. The random generator is seeded (`--seed`), the settings go into `run.json`, and the counts go into a `link.csv` stream:

```
link: received 1360 viewer packets, dropped 122; sent 1362 poses, dropped 150
```

Two design points carry over to any option:

1. **Latency is added on the wall clock**, because that is how a network delays. The packet's header `t_sim` is unchanged, so the receiver still knows exactly which pose the data belongs to and can compute its age.
2. **The estimator must use the header time.** The starter's `TTCEstimator.update(t, size)` gets `m["t_sim"]`. A dropped packet then just means a larger `dt` between two samples. With arrival times instead, a 100 ms delay burst would look like a sudden change in `ṡ`.

## What we measured

Option A starter, headless viewer at 60 FPS, three runs per row unless noted. Window for τ errors as in [03](03_measurement_and_validation.md).

| Run | τ bias | τ RMSE | braking started | at distance | final state, distance | box age at use (median) |
|---|---|---|---|---|---|---|
| nominal (3 runs, identical) | +0.045 s | 0.073 s | t = 15.80 s | 10.63 m | HOLD, 1.23 m | 42 ms |
| 10 % loss (4 runs) | +0.060…0.067 s | 0.086…0.095 s | 15.82 s | 10.57 m | HOLD, 1.20…1.22 m | 43…60 ms |
| 100 ms latency (4 runs) | +0.119…0.120 s | 0.150…0.151 s | 15.95…15.98 s | 10.19…10.25 m | HOLD, 1.10…1.12 m | 142 ms |
| 300 ms latency (1 run) | +0.274 s | 0.312 s | 16.32 s | 9.43 m | HOLD, 0.84 m | 344 ms |
| 50 % loss (1 run) | +0.166 s | 0.194 s | 15.93 s | 10.26 m | HOLD, 1.11 m | 70 ms |
| viewer at 2.7 FPS (software renderer, 1 run) | | 2.1 s | 17.63 s | 3.6 m | **CRASH** | 225 ms |

The nominal run is bit-for-bit repeatable: three runs gave the same numbers to the last digit printed. That is what makes the differences in the other rows meaningful.

### What the vehicle did

- **10 % loss: almost nothing.** Boxes arrive at 60 Hz; losing one in ten means the next one is 17 ms later. τ RMSE rose from 0.073 to about 0.09 s and the drone stopped 1–3 cm closer.
- **100 ms latency: braking late, stopping closer, still safe.** Every box was 100 ms older when used, so τ_est was about 0.1 s too large (the bias rose by 0.075 s), braking started 0.15–0.18 s later and 0.38–0.44 m closer, and the drone stopped 0.11–0.13 m closer than nominal. In one sentence for the report: *with 100 ms extra latency the quad started braking 0.4 m later and held 0.12 m closer to the target; it did not touch it.*
- **Why it stayed safe:** the HOLD condition is "the box fills 30 % of the image width", a direct visual measurement, not τ. Latency moved where braking started, not where the drone stopped. A controller that stopped on τ alone would have degraded faster.
- **Where it breaks:** at 2.7 FPS the boxes came every 370 ms and τ was estimated from a few coarse samples. Braking started at 3.6 m instead of 10.6 m and the drone hit the box. A slow viewer is a worse fault than either injected one.

## What to report

For your option, a table like the one above with at least the nominal and one fault row, plus:

- the injection settings (from `run.json`) and the link counts;
- the vehicle's behavior in one or two sentences, with numbers;
- whether the outcome changed (stopped vs crashed, stayed on the road vs left it);
- one design change that would make your system degrade more gracefully, and why. For the starter, candidates are: predict the box forward by its measured age, slow down when the box age grows, or stop on the visual size as it already does.

## Try it

- Find the latency at which the starter first touches the target. Is the transition sharp or gradual?
- Add jitter: a random latency between 0 and 200 ms per packet. The estimator uses header times; does it still work? What happens if you sort the queue by release time (packets can now overtake each other)?
- Inject loss only on the pose stream (viewer → physics untouched). What changes, and why so little? (Hint: the viewer extrapolates up to 50 ms.)
- Make the reset command go through the injector and use `send_command` (reliable) in the viewer. With 50 % loss, how many resends does a RESET need?

## References

- [Protocol v1, reliability and failure behavior](../reference/protocol.md)
- [Module 4: handshake and failures](../m04_bridge/05_handshake_and_failures.md)
- Linux `tc-netem(8)`: <https://man7.org/linux/man-pages/man8/tc-netem.8.html>
