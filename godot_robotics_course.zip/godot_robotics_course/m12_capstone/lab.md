# Lab 12: the capstone (6 h)

You will turn one scenario into a reproducible, measured, documented result. The steps use option A's starter as the running example; for options B and C, do the same steps with your Module 9 or Module 11 scenario and the guidance in [option_b_ugv.md](option_b_ugv.md) or [option_c_fixed_wing.md](option_c_fixed_wing.md).

## Files

| File | New / changed | What it does |
|---|---|---|
| `data/scenarios/ttc_target.json` | new | start, target and camera, read by both processes |
| `physics/sims/ttc_quad_jsbsim.py` | new | option A physics: JSBSim quad, τ estimator, τ-dot braking, failure injector, logs |
| `godot/scenes/ttc_lab.tscn`, `ttc_lab.gd` | new | option A viewer: quad, FPV rig, TargetBox, contact, HUD, perf log, frame recording |
| `tools/plot_ttc.py`, `frame_sync_check.py`, `check_box_pixels.py` | new | metrics, image ↔ telemetry check, box vs pixels |
| `README_capstone.md`, `docs/protocol.md`, `docs/frames.md`, `docs/report.md` | new | your documents |

Reused unchanged: Module 11's `robosim/jsbsim_vehicle.py` and `terrain/terrain_skirt.gd`, the shared `robosim/telemetry.py` and `bridge/telemetry_bridge.gd` (TELEMETRY code 3 = TTC, see [protocol.md](../reference/protocol.md)), and Modules 2, 4, 5, 6 as in Module 11.

## Step 1: choose and plan (20 min)

Read [01_choosing_an_option.md](01_choosing_an_option.md) and the [rubric](grading_rubric.md). Write in `docs/report.md` section 1 one sentence each: what the vehicle does, what you estimate, what the truth is, which fault you will inject. List every process, port and data file.

## Step 2: nominal run end to end (60 min)

Copy the starter files (option A) or prepare your scenario (B, C). Then:

```bash
cd ~/robosim
godot --headless --path godot --import                       # once, new class_names
godot --path godot res://scenes/ttc_lab.tscn &               # viewer
cd physics && python sims/ttc_quad_jsbsim.py                 # physics
```

Expected console (our run):

```
t=15.78  BRAKE: tau=3.00 s, speed 3.67 m/s
t=19.67  HOLD: box fills 30% of the image, speed 1.08 m/s
link: received 1361 viewer packets, dropped 0; sent 1363 poses, dropped 0
finished in HOLD at t=22.7 s, distance to target 1.23 m
```

Run it again with the physics process started first. Both orders must work.

## Step 3: estimate vs truth (45 min)

```bash
cd ~/robosim && python tools/plot_ttc.py logs/<run>
```

Use a viewer capped at 60 FPS for the runs you report (vsync in a window, or `-- --perf-log=...`, which sets `Engine.max_fps = 60`): the box rate is the viewer's frame rate, and it changes the result. Check that `truth.csv` has `tau_true` and `tau_est` as separate columns, that `vision.csv` has `pose_t_sim`, and that the plot shows both curves. Our nominal numbers: bias +0.045 s, RMSE 0.073 s, median relative error 1.8 % (418 samples, 0.5 s < τ < 6 s). Run the nominal case three times; we got identical numbers all three times.

## Step 4: timing (45 min)

With rendering (a window or `xvfb-run`), record frames and the per-frame log:

```bash
godot --path godot res://scenes/ttc_lab.tscn -- --perf-log=/tmp/perf.csv --record=/tmp/frames &
cd physics && python sims/ttc_quad_jsbsim.py
cd .. && python tools/plot_ttc.py logs/<run> /tmp/perf.csv
python tools/frame_sync_check.py logs/<run> /tmp/frames
python tools/check_box_pixels.py logs/<run> /tmp/frames
```

Fill the timing table of [03_measurement_and_validation.md](03_measurement_and_validation.md) for your machine, and state the GPU and renderer. If the frame rate is low and the run fails (ours crashed at 2.7 FPS on a software renderer), that is a result: report it, then run the measurement on a machine with a GPU or reduce the rendering load (no shadows, smaller window) and report both.

Keep one frame and its telemetry row for the report (acceptance item 3). Ours: frame 29, `t_sim 11.408`, nearest telemetry row 11.400 (8.3 ms, one pose period is 16.7 ms).

## Step 5: the 60-second recording (20 min)

```bash
# while the nominal run is on screen (Linux, X11; OBS on Windows/macOS)
ffmpeg -f x11grab -video_size 1280x720 -framerate 30 -i :0.0 -t 60 -c:v libx264 -pix_fmt yuv420p demo.mp4
```

The starter's run is about 23 s. For 60 s, run the physics process again right after it ends (the viewer keeps running and resets on the new RESET pose), or lengthen the approach in `ttc_target.json` (`start.n` further south; keep it inside the 256 m map).

## Step 6: failure injection (30 min)

```bash
cd physics && python sims/ttc_quad_jsbsim.py --latency 0.1      # or --drop 0.1
```

Run it three times, generate the plots, and fill the failure table of the report. Ours (100 ms): RMSE 0.150–0.151 s, braking started 0.38–0.44 m closer, held 0.11–0.13 m closer than nominal, no contact. Write the one-sentence behavior description now, while you look at the plot.

## Step 7: documents (75 min)

1. `README_capstone.md`: versions, install, data, first run, ports, expected output, known limits ([02](02_requirements_and_documents.md), section 2).
2. `docs/protocol.md`: v1 by reference, messages used, extensions (section 3).
3. `docs/frames.md`: diagram and units table (section 4). Do the hand check: take one row of `truth.csv`, predict the target's pixel position with your document, compare with the recorded frame.
4. `docs/report.md` from [report_template.md](report_template.md).

## Step 8: reproduce from a clean start (30 min)

In a new folder, as if you were the grader:

```bash
git clone <your repo> robosim_check && cd robosim_check
python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt
python tools/make_heightmap.py                     # or check the committed files
godot --headless --path godot --import
godot --headless --path godot res://scenes/ttc_lab.tscn -- --perf-log=/tmp/perf.csv &   # 60 FPS cap
cd physics && python sims/ttc_quad_jsbsim.py
```

Compare with step 3. We did exactly this for the starter (course files only, heightmap regenerated from seed 42): the reproduced run matched the nominal run to the last printed digit (HOLD, 1.233 m, RMSE 0.073 s). Put the reproduction's run folder in the submission.

## Step 9: rehearse the demo (20 min)

Go through [demo_checklist.md](demo_checklist.md) once, with a timer.

## Check

| Item | Pass when | Starter reference |
|---|---|---|
| Clean start | fresh clone + README reproduces the nominal numbers within your stated tolerance | identical (HOLD, 1.233 m, RMSE 0.073 s) |
| Frames and units | document covers physics → wire → Godot → camera → pixel, with units | — |
| Image ↔ telemetry | one frame and the row at its `t_sim`, within one pose period | 8.3 ms |
| Estimate vs truth | plot + ≥ 2 metrics over a stated window | bias +0.045 s, RMSE 0.073 s |
| Timing | frame rate, pose age, image latency with hardware | headless 60 FPS; llvmpipe 2.7 FPS, image latency 377 ms median |
| Failure | one fault run, same metrics, behavior in one sentence | 100 ms: braking 0.4 m later, held 0.12 m closer |
| Recording | 60 s, real time | — |

## Stretch goals

1. Find the breaking point: the latency (or frame rate) at which the starter first touches the target. Plot outcome vs latency.
2. Replace the ideal box with a detector on real pixels (Module 7) and compare τ errors: ideal vs detected.
3. Port the physics to PyBullet (Module 10's quad) without touching the viewer. Report what changed in the numbers and why.
4. Add a second camera (downward, optical flow) and estimate ground speed; compare with the truth.
5. Make the run deterministic in lock-step (Module 5) so that the software-renderer run behaves exactly like the headless one, and measure what that costs in wall time.
