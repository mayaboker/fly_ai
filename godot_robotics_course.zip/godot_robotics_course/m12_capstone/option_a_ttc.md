# Option A: quadcopter, time to contact from vision

A quadcopter flies toward an obstacle and uses only what its forward camera sees to judge when to brake. The estimate is the time to contact τ = s / ṡ from the target's apparent size; the truth is distance / closing speed from the physics state. You may use PyBullet or JSBSim for the quad.

## Start from

| You need | From | Files |
|---|---|---|
| A flying quad with attitude/velocity control | [Module 10](../m10_multirotor/README.md) | `physics/sims/quad_pybullet.py` or `quad_jsbsim.py` |
| **Or the tested starter** (JSBSim `quad_rpy`) | this module | `code/physics/sims/ttc_quad_jsbsim.py`, `code/godot/scenes/ttc_lab.*` |
| Quad model with an `fpv_cam` mount, terrain, range | [Module 2](../m02_scene_assets/README.md) | `vehicles/quad.tscn`, `terrain/`, `world/range_builder.gd` |
| Bridge, render clock | Modules [4](../m04_bridge/README.md), [5](../m05_time_rates/README.md) | `bridge/sim_bridge.gd`, `render_clock.gd` |
| FPV camera, intrinsics, ideal target box | [Module 6](../m06_cameras/README.md) | `camera_rig.gd` (GIMBAL_LEVEL), `camera_intrinsics.gd`, `target_box.gd` |
| Pixels in Python (if you use a real detector) | [Module 7](../m07_frame_transport/README.md) | `shm_frame_writer.gd`, `frame_reader.py`, `cv_red_box.py` |
| Contact sensor, timestamps | [Module 8](../m08_sensors/README.md), [Module 11](../m11_jsbsim_fixed_wing/05_obstacles_and_crash.md) | Area3D + sweep |
| TELEMETRY extension (code 3 = TTC) | [protocol.md](../reference/protocol.md); used since [Module 10](../m10_multirotor/06_godot_quad_view.md) | `telemetry.py`, `telemetry_bridge.gd` (shared code) |

With PyBullet, keep the viewer and the protocol of the starter and replace only the physics script: the same `ttc_target.json`, the same SENSOR handling, the same logs. That is the point of the bridge.

## Minimum scope

1. Takeoff, acquire, cruise toward the target, brake on τ, hold. At least one braking law (τ-dot, or "brake when τ < threshold" with a fixed deceleration).
2. τ from the box **with the SENSOR header's `t_sim`**, logged next to τ_true every control step.
3. Contact with the target reported by Godot and decided by Python.
4. Plot τ_est and τ_true over time, with the state changes marked, and the error numbers over a stated window.

## Good extensions (pick one)

- A detector on real pixels instead of the ideal box (red threshold, then OpenCV contours). Report detection misses and how the estimator handles them.
- Optical flow instead of box size: divergence of the flow field in the FPV image gives 1/τ without knowing what the target is. Compare with the box method.
- Two targets at different distances; the controller must pick the nearest by τ.
- A moving target (on a track in Godot; its motion must also be known to the physics side for the truth).

## Ground truth

Compute it on the physics side from the scenario file, never from Godot's rendering:

```
d      = |p_face − p_drone|                (ENU, m; p_face = the face the drone approaches)
ḋ      = −(v_drone · (p_face − p_drone)) / d
τ_true = d / (−ḋ)    when −ḋ > 0.05 m/s, else ∞
```

If the target moves, add its velocity: `ḋ` uses the relative velocity.

## Pitfalls

| Pitfall | Symptom | Fix |
|---|---|---|
| Rigid FPV camera on a quad that pitches to accelerate | the box jumps vertically every time the speed changes, and its size changes slightly with the view angle | gimbal-level rig (as in the starter), or compensate with the attitude |
| τ from arrival times | τ jumps with network jitter; failure-injection runs look much worse than they are | use the SENSOR header `t_sim` |
| Size from width only | 1-px steps in w give big steps in ṡ at long range | `s = sqrt(w · h)`, low-pass ṡ, or fit a line to the last N samples |
| `cy` sign | altitude hold runs away from the target | document it: Module 6 `TargetBox` uses `+cy` = down |
| Target partly outside the image | box clamped to the image edge, so it stops growing, so τ → ∞ near the end | stop on size first (the starter holds at 30 % of the width), or flag clamped boxes |
| Truth at the target's center instead of its face | τ_true too large by (half depth) / speed | use the face the drone meets |

## Checklist for option A

- [ ] nominal run: τ plot, bias and RMSE over a stated window, braking point and final distance
- [ ] the image–telemetry acceptance: one recorded FPV frame and the telemetry row at its `t_sim`
- [ ] failure run (10 % loss or 100 ms latency) with the same numbers and one sentence on the behavior
- [ ] frame rate, pose age, image latency and box age at use, on your machine
- [ ] `docs/protocol.md` lists SENSOR_TARGET_BOX's sign conventions and any TELEMETRY codes
- [ ] `docs/frames.md` reaches from the physics pose to the pixel (mount offset, gimbal rule, intrinsics)
