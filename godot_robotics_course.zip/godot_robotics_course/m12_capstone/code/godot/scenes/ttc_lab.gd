extends Node3D
## Capstone option A viewer: JSBSim quad (vehicle 2) flying at a target box.
##   - places Module 2's quad from POSE (Module 5 render clock + SimBridge.sample)
##   - FPV: Module 6 CameraRig, GIMBAL_LEVEL, on the quad's fpv_cam mount (pitch/roll stabilised)
##   - "vision": Module 6 TargetBox -> SENSOR_TARGET_BOX [visible, cx, cy, w_px, h_px]
##     (cx, cy in -1..1, +cx right, +cy DOWN), tagged with the sim time of the rendered pose
##   - contact: Area3D overlap + shape sweep against the target -> SENSOR_CONTACT
##   - HUD: state, tau (vision) vs tau (truth), speed, distance from TELEMETRY code 3
## Command-line options (after "--"):
##   --ports=L,P         listen / physics ports (tests use 9220,9221)
##   --perf-log=PATH     per-frame CSV: frame time, render lag, pose receive age (Module 12)
##   --record=DIR        FPV frames at 5 Hz + frames.csv (logging.md format); needs rendering
##   --quit-after=S      quit after S wall seconds; with any option it also quits 1.5 s after
##                       the physics process stops sending

const SCENARIO := "../data/scenarios/ttc_target.json"
const TARGET_LAYER := 2                       # Module 2 layer 2 = obstacles
const TELEM_TTC := 3
const STATES := ["TAKEOFF", "ACQUIRE", "CRUISE", "BRAKE", "HOLD", "CRASH"]

@export var vehicle_id := 2
@export var record_hz := 5.0

@onready var bridge: TelemetryBridge = $SimBridge
@onready var terrain: HeightmapTerrain = $Terrain
@onready var quad: Vehicle = $Quad
@onready var chase_cam: Camera3D = $ChaseCam
@onready var bbox_rect: ReferenceRect = $UI/Fpv/BBox
@onready var hud: Label = $UI/Hud

var clock := RenderClock.new()
var fpv: CameraRig
var target: StaticBody3D
var target_aabb := AABB()
var t_render := -1.0
var hull: Area3D
var hull_shape: CollisionShape3D
var _args := {}
var _prev_hull := Transform3D()
var _paused := false
var _perf: FileAccess
var _rec: FileAccess
var _rec_dir := ""
var _next_rec_t := 0.0
var _frame_id := 0
var _got_pose := false
var _stamp: Label


func _enter_tree() -> void:
	for a in OS.get_cmdline_user_args():
		var kv := a.trim_prefix("--").split("=", true, 1)
		_args[kv[0]] = kv[1] if kv.size() > 1 else ""
	if _args.has("ports"):
		var p: PackedStringArray = _args.ports.split(",")
		$SimBridge.listen_port = int(p[0])
		$SimBridge.physics_port = int(p[1])


func _ready() -> void:
	var scen: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(HeightmapTerrain.resolve_path(SCENARIO)))
	_build_target(scen.target)
	_build_hull()
	# FPV camera: its own SubViewport, level gimbal, intrinsics from the scenario file
	fpv = CameraRig.new()
	fpv.camera_name = "fpv"
	fpv.mode = CameraRig.Mode.GIMBAL_LEVEL
	fpv.image_size = Vector2i(int(scen.camera.width_px), int(scen.camera.height_px))
	fpv.fov_v_deg = float(scen.camera.fov_v_deg)
	quad.mount("fpv_cam").add_child(fpv)
	fpv.camera.cull_mask = 1                      # the FPV must not see its own airframe ...
	for m in quad.get_node("Visual").get_children():
		if m is VisualInstance3D:
			(m as VisualInstance3D).layers = 2        # ... which lives on render layer 2
	_stamp = Label.new()                          # sim time burnt into every FPV image
	_stamp.position = Vector2(8, 4)
	_stamp.add_theme_color_override("font_color", Color(1, 1, 0.2))
	fpv.viewport.add_child(_stamp)
	$UI/Fpv.texture = fpv.viewport.get_texture()
	bridge.pose_received.connect(_on_pose)
	bridge.telemetry_received.connect(_on_telemetry)
	bridge.physics_reset.connect(func() -> void:
		clock.reset()
		_prev_hull = Transform3D())
	if _args.has("perf-log"):
		_perf = FileAccess.open(_args["perf-log"], FileAccess.WRITE)
		_perf.store_line("t_unix,t_render,latest_t_sim,render_lag_s,rx_age_s,fps")
	if _args.has("record"):
		_rec_dir = _args.record
		DirAccess.make_dir_recursive_absolute(_rec_dir)
		_rec = FileAccess.open(_rec_dir.path_join("frames.csv"), FileAccess.WRITE)
		_rec.store_line("frame_id,t_sim,pose_seq,t_capture_wall,width,height")
		fpv.save_intrinsics(_rec_dir.path_join("fpv_intrinsics.json"))   # Module 6 format
	if _args.has("perf-log") or _args.has("record"):
		Engine.max_fps = 60


func _build_target(tg: Dictionary) -> void:
	var e := float(tg.e)
	var n := float(tg.n)
	var size := Vector3(tg.size_m[0], tg.size_m[1], tg.size_m[2])
	target_aabb = AABB(-size / 2.0, size)
	target = StaticBody3D.new()
	target.name = "Target"
	target.collision_layer = 1 << (TARGET_LAYER - 1)
	target.collision_mask = 0
	target.position = Vector3(e, terrain.height_at(e, n) + float(tg.agl_m), -n)   # ENU -> Godot
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	var red := StandardMaterial3D.new()
	red.albedo_color = Color(0.9, 0.15, 0.1)
	bm.material = red
	mi.mesh = bm
	target.add_child(mi)
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	target.add_child(cs)
	var pole := MeshInstance3D.new()             # visual only
	var cyl := CylinderMesh.new()
	var h := float(tg.agl_m) - size.y / 2.0
	cyl.top_radius = 0.04
	cyl.bottom_radius = 0.04
	cyl.height = h
	pole.mesh = cyl
	pole.position.y = -size.y / 2.0 - h / 2.0
	target.add_child(pole)
	add_child(target)


func _build_hull() -> void:
	var body_shape: CollisionShape3D = quad.get_node("Body/Shape")
	hull = Area3D.new()
	hull.collision_layer = 0
	hull.collision_mask = 1 << (TARGET_LAYER - 1)
	hull.monitorable = false
	hull_shape = CollisionShape3D.new()
	hull_shape.shape = body_shape.shape
	hull_shape.transform = body_shape.transform
	hull.add_child(hull_shape)
	quad.add_child(hull)


func _process(delta: float) -> void:
	if not bridge.has_vehicle(vehicle_id):
		return
	_got_pose = true
	t_render = clock.advance(delta, bridge.latest_t_sim, _paused)
	quad.global_transform = bridge.sample(vehicle_id, t_render)
	fpv.sync_now()
	var back := Basis(Vector3.UP, fpv.camera.global_rotation.y) * Vector3(0, 1.2, 3.5)
	chase_cam.global_transform = Transform3D(Basis.IDENTITY, quad.global_position + back).looking_at(
			quad.global_position + Vector3(0, 0.3, 0), Vector3.UP)
	_send_target_box()
	_send_contact()
	_measure()


## Module 6 TargetBox: the ideal box of the target in the FPV image (a detector would give
## the same thing with noise). Pure math, so it also works in --headless tests.
func _send_target_box() -> void:
	var b := TargetBox.compute(fpv.intrinsics(), fpv.camera.global_transform, target_aabb, target.global_transform)
	var vals := PackedFloat32Array([1.0 if b.visible else 0.0, b.cx, b.cy, b.w_px, b.h_px])
	bridge.send_sensor(t_render, vehicle_id, RsProtocol.SENSOR_TARGET_BOX, vals)
	bbox_rect.visible = b.visible
	if b.visible:
		var k: Vector2 = ($UI/Fpv as Control).size / Vector2(fpv.viewport.size)
		bbox_rect.position = Vector2(b.x0, b.y0) * k
		bbox_rect.size = Vector2(b.w_px, b.h_px) * k


func _send_contact() -> void:
	var xf := hull_shape.global_transform
	var hit := not hull.get_overlapping_bodies().is_empty()
	if not hit and _prev_hull != Transform3D():
		var q := PhysicsShapeQueryParameters3D.new()
		q.shape = hull_shape.shape
		q.transform = _prev_hull
		q.motion = xf.origin - _prev_hull.origin
		q.collision_mask = hull.collision_mask
		var frac := get_world_3d().direct_space_state.cast_motion(q)
		hit = frac.size() == 2 and frac[1] < 1.0
	_prev_hull = xf
	if hit:
		bridge.send_sensor(t_render, vehicle_id, RsProtocol.SENSOR_CONTACT, PackedFloat32Array([1, 0, 0, 1, 0]))


func _on_pose(vid: int, msg: Dictionary) -> void:
	if vid == vehicle_id:
		clock.observe(msg.t_sim, Time.get_ticks_usec() / 1e6)
		_paused = msg.flags & RsProtocol.POSE_FLAG_PAUSED != 0


func _on_telemetry(vid: int, code: int, t_s: float, v: PackedFloat32Array) -> void:
	if vid != vehicle_id or code != TELEM_TTC or v.size() < 5:
		return
	hud.text = "t %.1f s   %s\ntau vision %s   tau truth %s\nspeed %.2f m/s   distance %.2f m   %.0f FPS" % [
		t_s, STATES[clampi(int(v[0]), 0, 5)], ("%.2f s" % v[1]) if v[1] >= 0 else "--",
		("%.2f s" % v[4]) if v[4] >= 0 else "--", v[2], v[3], Engine.get_frames_per_second()]


func _measure() -> void:
	_stamp.text = "t_sim %.3f" % t_render
	if _perf:
		_perf.store_line("%.6f,%.6f,%.6f,%.6f,%.6f,%.1f" % [Time.get_unix_time_from_system(), t_render,
				bridge.latest_t_sim, bridge.latest_t_sim - t_render, bridge.seconds_since_pose(),
				Engine.get_frames_per_second()])
	if _rec and t_render >= _next_rec_t:
		_next_rec_t = t_render + 1.0 / record_hz
		_capture(t_render, bridge.latest_seq)


## The texture holds the LAST drawn frame. Wait until this frame (posed at t) is drawn,
## then read it back, so the image, its stamp and frames.csv all mean the same t_sim.
func _capture(t: float, seq: int) -> void:
	await RenderingServer.frame_post_draw
	if _rec == null:
		return
	_frame_id += 1
	var img := fpv.get_image()
	img.save_png(_rec_dir.path_join("%06d.png" % _frame_id))
	_rec.store_line("%d,%.6f,%d,%.6f,%d,%d" % [_frame_id, t, seq, Time.get_unix_time_from_system(),
			img.get_width(), img.get_height()])


func _physics_process(_d: float) -> void:
	var wall := Time.get_ticks_msec() / 1000.0
	var done := _got_pose and _args.size() > 0 and bridge.seconds_since_pose() > 1.5
	if done or (_args.has("quit-after") and wall > float(_args["quit-after"])):
		if _perf:
			_perf.close()
			_perf = null
		if _rec:
			_rec.close()
			_rec = null
		get_tree().quit()
