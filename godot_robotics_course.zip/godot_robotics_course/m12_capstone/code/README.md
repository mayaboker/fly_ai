# Module 12 reference code: option A starter

Paths mirror `robosim/`.

```
code/
├── data/scenarios/ttc_target.json        start, target box, FPV camera (read by both processes)
├── physics/sims/ttc_quad_jsbsim.py       JSBSim quad_rpy (vehicle 2): tau estimator, tau-dot braking,
│                                         truth from the scenario file, failure injection, logs
├── godot/scenes/ttc_lab.tscn, ttc_lab.gd viewer: quad, gimbal FPV rig, TargetBox -> SENSOR_TARGET_BOX,
│                                         contact sweep, HUD, --perf-log, --record
└── tools/
    ├── plot_ttc.py                       tau plot + metrics (+ timing from perf.csv) -> ttc.png, ttc_metrics.json
    ├── frame_sync_check.py               image latency; one frame vs the telemetry row at its t_sim
    └── check_box_pixels.py               TargetBox sizes vs red pixels in the recorded frames
```

## Needs

Everything Module 11's code needs (see [../../m11_jsbsim_fixed_wing/code/README.md](../../m11_jsbsim_fixed_wing/code/README.md)), plus Module 11's own `robosim/jsbsim_vehicle.py` and `terrain/terrain_skirt.gd`, the shared `robosim/telemetry.py` and `bridge/telemetry_bridge.gd` (TELEMETRY code 3 = TTC), Module 2's `vehicles/quad.tscn`, Module 6's `cameras/target_box.gd`, and the JSBSim model `aircraft/quad_rpy`.

## Run

```bash
cd ~/robosim
godot --headless --path godot --import                                    # once
godot --path godot res://scenes/ttc_lab.tscn                              # viewer (window)
cd physics && python sims/ttc_quad_jsbsim.py [--drop 0.1] [--latency 0.1] [--seed 1]
cd .. && python tools/plot_ttc.py logs/<run> [perf.csv]
```

Viewer options after `--`: `--ports=L,P`, `--perf-log=PATH` (also caps at 60 FPS), `--record=DIR` (FPV PNGs at 5 Hz, `frames.csv`, `fpv_intrinsics.json`; needs rendering), `--quit-after=S`. With any option the viewer quits 1.5 s after the physics process stops.

Logs (course format): `truth.csv` (truth + estimate + box age per pose), `vision.csv` (every box used, with its `pose_t_sim`), `pose_tx.csv` (send time per pose, for image latency), `event.csv` (contact), `link.csv` (injected drops), `run.json`.

## What was verified, and how

Godot 4.7.2 (headless; and Compatibility renderer on Mesa llvmpipe under `xvfb-run`), JSBSim 1.3.1, Python 3.11, ports 9220/9221. Project assembled from `reference/` and the Module 2, 4, 5, 6, 11 code folders.

| Test | Result |
|---|---|
| Nominal, headless viewer capped at 60 FPS, 3 runs | identical: BRAKE at t = 15.78 s (τ 3.00 s, 10.63 m), HOLD 1.233 m; τ bias +0.045 s, RMSE 0.073 s, median relative error 1.8 % (418 samples); box age at use 42 ms; render lag 25 ms; pose receive age 0.27 ms |
| Clean start: fresh tree from course files, heightmap regenerated (seed 42), `--import`, run | identical to nominal |
| 10 % loss (`--drop 0.1`), 4 runs | RMSE 0.086–0.095 s, HOLD 1.20–1.22 m |
| 100 ms latency (`--latency 0.1`), 4 runs | RMSE 0.150–0.151 s, braking 0.38–0.44 m closer, HOLD 1.10–1.12 m |
| 300 ms latency, 50 % loss (1 run each) | RMSE 0.312 s, HOLD 0.84 m; RMSE 0.194 s, HOLD 1.11 m |
| Uncapped headless viewer | HOLD 1.26 m (box rate = viewer frame rate) |
| Physics run twice against one running viewer | both runs HOLD (viewer resets on the RESET pose) |
| Software-rendered viewer, `--record` (2.7 FPS) | **CRASH** into the target (braking at 3.6 m); image latency median 377 ms; `frame_sync_check.py`: frame 29 at t_sim 11.408 vs telemetry row 11.400; `check_box_pixels.py`: 50 frames, max 0.98 px, median 0.32 px |
| Screen recording (`ffmpeg -f x11grab`, Xvfb display) and `ffmpeg` from the PNG frames | both produced playable MP4s |
| FPV images | looked at: target visible, quad airframe not visible (render layer 2, camera cull mask 1), t_sim stamp burnt in |

Not tested here: a real GPU (frame rates above are not representative), Windows/macOS, `tc netem` (needs root and affects all loopback traffic), the PyBullet variant of option A, options B and C (they reuse Module 9 and Module 11 code; no new code here).

## Proposed shared changes (adopted)

Both are now in `reference/protocol.md`: the TARGET_BOX sign convention (+cx right, +cy **down**, as Module 6's `TargetBox`), and the TELEMETRY extension (type 100) with code 3 = TTC (code 1 = FLIGHT, Module 11; code 2 = MOTORS, Module 10). The starter sends TTC as code 3.
