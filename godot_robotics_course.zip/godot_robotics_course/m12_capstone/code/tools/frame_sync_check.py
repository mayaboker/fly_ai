"""
frame_sync_check.py - capstone acceptance: does a captured image and a telemetry sample name the
same simulation time? And how old is an image when it is written (image latency)?

    python tools/frame_sync_check.py logs/<run> <frames_dir> [frame_id]

<run>/pose_tx.csv   Python: t_sim of every pose sent and the Unix time it was sent
<run>/truth.csv     Python: ground truth per pose (the "telemetry sample")
<frames_dir>        Godot (ttc_lab --record): <frame_id>.png (6-digit zero padded) + frames.csv, t_sim burnt into the image

image latency = t_capture_wall (Godot, Unix time after the frame was drawn)
              - Unix time Python sent the pose with that t_sim (interpolated between sends)
Both clocks are the same machine's system clock, so the difference is meaningful.
"""
import csv
import os
import sys

import numpy as np


def rows(path):
    with open(path) as f:
        return list(csv.DictReader(f))


def main(run, frames_dir, frame_id=None):
    tx = [r for r in rows(os.path.join(run, "pose_tx.csv")) if r.get("sent", "1") != "0"]   # skip injected drops
    tx_t = np.array([float(r["t_sim"]) for r in tx])
    tx_u = np.array([float(r["t_unix"]) for r in tx])
    keep = np.r_[True, np.diff(tx_t) > 0]                 # idle poses repeat t_sim = 0
    tx_t, tx_u = tx_t[keep], tx_u[keep]
    fr = rows(os.path.join(frames_dir, "frames.csv"))
    ft = np.array([float(r["t_sim"]) for r in fr])
    fu = np.array([float(r["t_capture_wall"]) for r in fr])
    ok = (ft > tx_t[1]) & (ft < tx_t[-1])
    lat = fu[ok] - np.interp(ft[ok], tx_t, tx_u)
    print(f"frames: {len(fr)} captured, {ok.sum()} during the flight")
    print(f"image latency (pose sent -> frame written): median {1000 * np.median(lat):.0f} ms, "
          f"p95 {1000 * np.percentile(lat, 95):.0f} ms, max {1000 * lat.max():.0f} ms")

    # one frame and the telemetry sample at the same sim time
    tr = rows(os.path.join(run, "truth.csv"))
    tr_t = np.array([float(r["t_sim"]) for r in tr])
    pick = fr[int(frame_id) - 1] if frame_id else fr[np.flatnonzero(ok)[len(np.flatnonzero(ok)) // 2]]
    t = float(pick["t_sim"])
    j = int(np.argmin(np.abs(tr_t - t)))
    print(f"\nframe {int(pick['frame_id']):06d}.png: t_sim {t:.3f} (also burnt into the image), pose_seq {pick['pose_seq']}")
    print(f"telemetry row nearest that t_sim: t_sim {tr[j]['t_sim']} (difference {1000 * abs(tr_t[j] - t):.1f} ms)")
    print("   " + ", ".join(f"{k}={tr[j][k][:8]}" for k in ("e", "n", "h_asl", "speed_fwd", "dist", "tau_true", "state")))


if __name__ == "__main__":
    main(*sys.argv[1:4])
