"""
check_box_pixels.py - does the target box Python received describe the image Godot drew?

    python tools/check_box_pixels.py logs/<run> <frames_dir>

For every recorded FPV frame, find the SENSOR_TARGET_BOX that was computed for the same t_sim
(vision.csv, column pose_t_sim), count the red target pixels near that box in the PNG, and
compare their width and height with w_px, h_px. Independent check of the whole vision chain:
pose -> Godot camera -> TargetBox -> wire -> Python, against the rendered pixels.
Needs frames recorded with ttc_lab --record (rendering, not --headless).
"""
import csv
import glob
import os
import sys

import numpy as np
from PIL import Image


def main(run, frames_dir):
    frames = list(csv.DictReader(open(os.path.join(frames_dir, "frames.csv"))))
    vis = list(csv.DictReader(open(os.path.join(run, "vision.csv"))))
    vt = np.array([float(r["pose_t_sim"]) for r in vis])
    errs = []
    for fr in frames:
        t = float(fr["t_sim"])
        i = int(np.argmin(np.abs(vt - t)))
        v = vis[i]
        if abs(vt[i] - t) > 1e-4 or float(v["visible"]) < 0.5:
            continue                                    # no box for exactly this frame
        img = np.asarray(Image.open(os.path.join(frames_dir, f"{int(fr['frame_id']):06d}.png")).convert("RGB")).astype(int)
        H, W = img.shape[:2]
        red = (img[:, :, 0] > 150) & (img[:, :, 1] < 80) & (img[:, :, 2] < 80)
        red[:30, :150] = False                          # the yellow-ish time stamp corner
        cx, cy = (float(v["cx"]) + 1) * W / 2, (float(v["cy"]) + 1) * H / 2
        w, h = float(v["w_px"]), float(v["h_px"])
        x0, x1 = max(0, int(cx - w / 2 - 5)), int(cx + w / 2 + 5)
        y0, y1 = max(0, int(cy - h / 2 - 5)), int(cy + h / 2 + 5)
        ys, xs = np.nonzero(red[y0:y1, x0:x1])
        if xs.size == 0:
            continue
        pw, ph = xs.max() - xs.min() + 1, ys.max() - ys.min() + 1
        errs += [abs(w - pw), abs(h - ph)]
        print(f"frame {fr['frame_id']:>4}  t_sim {t:7.3f}  box {w:7.2f} x {h:7.2f}   pixels {pw:4d} x {ph:4d}")
    if errs:
        print(f"{len(errs) // 2} frames compared: max |box - pixels| {max(errs):.2f} px, median {np.median(errs):.2f} px")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
