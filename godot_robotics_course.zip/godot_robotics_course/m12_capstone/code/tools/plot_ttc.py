"""
plot_ttc.py - capstone option A: TTC from vision against ground truth, plus the timing numbers.

    python tools/plot_ttc.py logs/<run> [perf.csv]      # writes <run>/ttc.png, prints metrics

Metrics (printed and written to <run>/ttc_metrics.json):
  tau error      vision tau minus true tau, while 0.5 s < true tau < 6 s and the drone is
                 cruising or braking (the part of the flight where tau drives a decision)
  braking        speed and distance when braking started, final distance, minimum distance
  box age        how old (sim time) the newest target box was when the controller used it,
                 per control step, while cruising or braking
  perf (optional, from ttc_lab.gd --perf-log): frame rate, render lag, pose receive age
"""
import csv
import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                     # noqa: E402
import numpy as np                                                  # noqa: E402

BLUE, ORANGE, GREY, INK = "#2a78d6", "#eb6834", "#8a897f", "#3d3d3a"


def read(path):
    with open(path) as f:
        rows = list(csv.DictReader(f))
    cols = {}
    for k in rows[0]:
        vals = [r[k] for r in rows]
        try:
            cols[k] = np.array([float(v) if v != "" else np.nan for v in vals])
        except ValueError:
            cols[k] = np.array(vals)
    return cols


def main(run, perf_path=None):
    tr = read(os.path.join(run, "truth.csv"))
    vi = read(os.path.join(run, "vision.csv"))
    t, state = tr["t_sim"], tr["state"]
    active = np.isin(state, ["CRUISE", "BRAKE"]) & (tr["tau_true"] > 0.5) & (tr["tau_true"] < 6.0)
    err = (tr["tau_est"] - tr["tau_true"])[active & np.isfinite(tr["tau_est"])]
    m = {"run": os.path.basename(run.rstrip("/"))}
    if err.size:
        m.update(tau_samples=int(err.size), tau_bias_s=float(np.mean(err)), tau_rmse_s=float(np.sqrt(np.mean(err ** 2))),
                 tau_median_abs_s=float(np.median(np.abs(err))),
                 tau_rel_median_pct=float(100 * np.median(np.abs(err) / tr["tau_true"][active & np.isfinite(tr["tau_est"])])))
    brake = np.where(state == "BRAKE")[0]
    if brake.size:
        i = brake[0]
        m.update(brake_t_s=float(t[i]), brake_speed_mps=float(tr["speed_fwd"][i]), brake_dist_m=float(tr["dist"][i]),
                 brake_tau_true_s=float(tr["tau_true"][i]))
    m.update(final_state=str(state[-1]), final_dist_m=float(tr["dist"][-1]), min_dist_m=float(np.nanmin(tr["dist"])))
    age = tr["box_age_s"][np.isin(state, ["CRUISE", "BRAKE"])]       # age of the box the controller used
    m.update(vision_updates=int(vi["t_sim"].size),
             box_age_median_s=float(np.nanmedian(age)), box_age_p95_s=float(np.nanpercentile(age, 95)))
    if perf_path and os.path.exists(perf_path):
        pf = read(perf_path)
        # only while poses were flowing: after the first flight pose, up to the last new one
        last = int(np.argmax(pf["latest_t_sim"] >= np.nanmax(pf["latest_t_sim"])))
        ok = (pf["t_render"] > 0) & (np.arange(pf["t_render"].size) <= last)
        dt = np.diff(pf["t_unix"][ok])
        m.update(viewer_fps_mean=float(1.0 / np.mean(dt)), viewer_frame_ms_p95=float(1000 * np.percentile(dt, 95)),
                 render_lag_ms_median=float(1000 * np.median(pf["render_lag_s"][ok])),
                 pose_rx_age_ms_median=float(1000 * np.median(pf["rx_age_s"][ok])),
                 pose_rx_age_ms_p95=float(1000 * np.percentile(pf["rx_age_s"][ok], 95)))
    with open(os.path.join(run, "ttc_metrics.json"), "w") as f:
        json.dump(m, f, indent=2)
    for k, v in m.items():
        print(f"{k:24s} {v:.3f}" if isinstance(v, float) else f"{k:24s} {v}")

    fig, ax = plt.subplots(3, 1, figsize=(9, 8), sharex=True)
    show = np.isin(state, ["CRUISE", "BRAKE", "HOLD", "CRASH"])
    ax[0].plot(t[show], np.clip(tr["tau_true"][show], 0, 10), color=GREY, lw=2, label="true tau (distance / closing speed)")
    ax[0].plot(t[show], np.clip(tr["tau_est"][show], 0, 10), color=BLUE, lw=2, label="vision tau (s / ds/dt)")
    ax[0].set_ylabel("time to contact (s)")
    ax[0].set_ylim(0, 10)
    ax[0].legend(frameon=False, loc="lower left")
    ax[1].plot(t, tr["dist"], color=BLUE, lw=2)
    ax[1].set_ylabel("distance to target (m)")
    ax[2].plot(t, tr["speed_fwd"], color=BLUE, lw=2)
    ax[2].set_ylabel("forward speed (m/s)")
    ax[2].set_xlabel("sim time (s)")
    prev = None
    for i, s in enumerate(state):
        if s != prev:
            for a in ax:
                a.axvline(t[i], color=GREY, lw=0.6, ls=":")
            ax[2].text(t[i] + 0.2, ax[2].get_ylim()[1] * 0.9, s.lower(), fontsize=8, color=INK)
            prev = s
    for a in ax:
        a.spines[["top", "right"]].set_visible(False)
    fig.suptitle(m["run"], color=INK, fontsize=10, x=0.01, ha="left")
    fig.tight_layout()
    out = os.path.join(run, "ttc.png")
    fig.savefig(out, dpi=100)
    print("saved", out)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
