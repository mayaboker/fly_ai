"""
ttc_quad_jsbsim.py - Capstone option A reference starter: a JSBSim quadcopter brakes in front
of a target using only the target's image size (time-to-contact, tau), over protocol v1.

  JSBSim quad_rpy, 120 Hz      -- POSE 60 Hz (vehicle 2) ----------->  Godot ttc_lab scene
  TTC estimator + guidance     <-- SENSOR_TARGET_BOX (vehicle 2) ----  FPV camera: box in pixels (Module 6)
  crash decision               <-- SENSOR_CONTACT (vehicle 2) -------  sweep test against target
                               -- TELEMETRY code 3 (state, tau) ---->  HUD

  tau = s / (ds/dt)            s = sqrt(w_px * h_px), the target's apparent size
  braking (tau-dot law):       a = -(1 - k) * v / tau      (k = 0.5: constant deceleration)

Ground truth comes from data/scenarios/ttc_target.json (the same file Godot reads to place the
box): true distance to the box's front face and true tau = distance / closing speed.

Failure injection (Module 12): --drop 0.1 drops 10% of the viewer's packets and our poses,
--latency 0.1 delays the viewer's packets by 100 ms before the estimator sees them.

Run from robosim/physics:   python sims/ttc_quad_jsbsim.py [--drop 0.1] [--latency 0.1]
"""
import argparse
import collections
import json
import math
import os
import random
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
from robosim import protocol as P                                   # noqa: E402
from robosim.bridge import PhysicsBridge                            # noqa: E402
from robosim.logger import RunLogger                                # noqa: E402
from robosim.terrain import Heightmap                               # noqa: E402
from robosim.jsbsim_vehicle import JsbVehicle                       # noqa: E402
from robosim.telemetry import send_telemetry                        # noqa: E402

VEHICLE_ID = 2
TELEM_TTC = 3                 # TELEMETRY code 3: state, tau_est, forward speed, true distance, true tau
ROOT = os.path.join(HERE, "..", "..")
STATES = ["TAKEOFF", "ACQUIRE", "CRUISE", "BRAKE", "HOLD", "CRASH"]

TAKEOFF_AGL = 3.0             # m
V_CRUISE = 4.0                # m/s
TAU_BRAKE = 3.0               # s: start braking below this
K_TAU_DOT = 0.4               # 0.5 = constant deceleration, stop exactly at contact
STOP_FILL = 0.30              # hold when the box fills 30% of the image width
G = 9.81
HOVER = 1.5 * G / (4 * 8.0)   # quad_rpy: 1.5 kg, four 8 N motors


def clamp(x, lo, hi):
    return max(lo, min(hi, x))


class TTCEstimator:
    """tau = s / s_dot from successive box sizes. Uses the SENSOR's t_sim (the pose the image
    was rendered from), never the arrival time: arrival jitter would become fake looming."""

    def __init__(self, alpha=0.25):
        self.alpha = alpha
        self.reset()

    def reset(self):
        self.s = self.t = None
        self.sdot = 0.0

    def update(self, t, size_px):
        if self.t is not None and t > self.t:
            raw = (size_px - self.s) / (t - self.t)
            self.sdot += self.alpha * (raw - self.sdot)        # first-order low-pass
        if self.t is None or t > self.t:
            self.s, self.t = size_px, t

    @property
    def tau(self):
        return self.s / self.sdot if self.s and self.sdot > 1e-3 else math.inf


class LossyInbox:
    """Failure injection on the receive side: drop a fraction, delay the rest (wall clock)."""

    def __init__(self, drop, latency, rng):
        self.drop, self.latency, self.rng = drop, latency, rng
        self.q = collections.deque()
        self.seen = self.dropped = 0

    def push(self, msgs):
        now = time.monotonic()
        for m in msgs:
            self.seen += 1
            if self.rng.random() >= self.drop:
                self.q.append((now + self.latency, m))
            else:
                self.dropped += 1

    def pop_ready(self):
        now, out = time.monotonic(), []
        while self.q and self.q[0][0] <= now:
            out.append(self.q.popleft()[1])
        return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rate", type=float, default=120.0, help="JSBSim Hz")
    ap.add_argument("--pose-hz", type=float, default=60.0)
    ap.add_argument("--duration", type=float, default=40.0)
    ap.add_argument("--drop", type=float, default=0.0, help="fraction of packets lost, both ways")
    ap.add_argument("--latency", type=float, default=0.0, help="extra delay on viewer packets, s")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--viewer-port", type=int, default=P.PORT_TO_VIEWER)
    ap.add_argument("--listen-port", type=int, default=P.PORT_TO_PHYSICS)
    ap.add_argument("--logs", default=os.path.join(ROOT, "logs"))
    args = ap.parse_args()

    scen = json.load(open(os.path.join(ROOT, "data", "scenarios", "ttc_target.json")))
    hm = Heightmap.load(os.path.join(ROOT, "data", "terrain", "heightmap.png"))
    tg = scen["target"]
    face = (tg["e"], tg["n"] - tg["size_m"][2] / 2, hm.height_at(tg["e"], tg["n"]) + tg["agl_m"])  # south face
    img_w = scen["camera"]["width_px"]

    quad = JsbVehicle("quad_rpy", hm, rate_hz=args.rate)
    st = scen["start"]
    quad.place(st["e"], st["n"], agl=0.09, heading_deg=st["heading_deg"])   # 0.09 m = quad_rpy ground.xml
    rng = random.Random(args.seed)
    br = PhysicsBridge(viewer_port=args.viewer_port, listen_port=args.listen_port)
    inbox = LossyInbox(args.drop, args.latency, rng)
    tag = f"ttc_drop{args.drop:g}_lat{args.latency:g}"
    log = RunLogger(args.logs, run_name=tag, seed=args.seed,
                    meta={"physics": "jsbsim", "model": "quad_rpy", "vehicle_id": VEHICLE_ID,
                          "physics_hz": args.rate, "pose_hz": args.pose_hz, "scenario": scen,
                          "failure": {"drop": args.drop, "latency_s": args.latency},
                          "ttc": {"k_tau_dot": K_TAU_DOT, "tau_brake_s": TAU_BRAKE, "v_cruise": V_CRUISE,
                                  "stop_fill": STOP_FILL}})

    tx = {"poses": 0, "dropped": 0}

    def send_pose():
        pos, quat, vel = quad.godot_pose()
        tx["poses"] += 1
        sent = rng.random() >= args.drop                    # outgoing loss too
        if sent:
            br.send_pose(quad.t, VEHICLE_ID, pos, quat, vel)
        else:
            tx["dropped"] += 1
        log.write("pose_tx", quad.t, t_unix=time.time(), sent=int(sent))   # for image latency

    print(f"waiting for the viewer on UDP {args.listen_port} ...")
    br.wait_for_viewer(send_idle_pose=send_pose)            # idle poses while waiting; either start order
    print(f"flying ({tag}), logs in {log.dir}")

    ttc, state = TTCEstimator(), 0
    alt_sp = quad.terrain_m + TAKEOFF_AGL
    alt_int, hold_t, crash_t = 0.0, 0.0, None
    box = None                                               # newest TARGET_BOX message
    steps = max(1, round(args.rate / args.pose_hz))
    dt_frame = steps * quad.dt
    next_wall = time.monotonic()
    while quad.t < args.duration and hold_t < 3.0 and (crash_t is None or quad.t - crash_t < 2.0):
        # ---- 1. viewer messages, through the failure injector
        inbox.push(br.poll(quad.t))
        for m in inbox.pop_ready():
            if m["type"] != P.MSG_SENSOR or m["vehicle_id"] != VEHICLE_ID:
                continue
            if m["sensor"] == P.SENSOR_TARGET_BOX:
                if box is None or m["t_sim"] > box["t_sim"]:
                    box = m
                    vis, cx, cy, w, h = m["values"]
                    if vis > 0.5:
                        ttc.update(m["t_sim"], math.sqrt(w * h))
                    log.write("vision", quad.t, pose_t_sim=m["t_sim"], age_s=quad.t - m["t_sim"],
                              visible=vis, cx=cx, cy=cy, w_px=w, h_px=h,
                              tau_est=ttc.tau if math.isfinite(ttc.tau) else "")
            elif m["sensor"] == P.SENSOR_CONTACT and m["values"][0] > 0.5 and state != 5:
                state, crash_t = 5, quad.t
                print(f"t={quad.t:5.2f}  CONTACT with the target (pose t={m['t_sim']:.2f})")
                log.write("event", quad.t, event="crash", pose_t_sim=m["t_sim"])

        # ---- 2. guidance (once per frame), from the newest box
        s = quad.state()
        visible = box is not None and box["values"][0] > 0.5
        cx, cy, w = (box["values"][1], box["values"][2], box["values"][3]) if visible else (0, 0, 0)
        u = s["u"]
        a_fwd, yawrate = 0.0, 0.0
        if state == 0 and s["agl"] > TAKEOFF_AGL - 0.3:
            state = 1
        elif state == 1:                                     # ACQUIRE: turn to face the target
            a_fwd = -1.0 * u
            yawrate = 60 * cx if visible else 20
            if visible and abs(cx) < 0.03 and abs(s["r"]) < 0.05:
                state = 2
                ttc.reset()
        elif state in (2, 3):
            if visible:
                yawrate = 60 * cx
                alt_sp -= 1.5 * cy * dt_frame                # keep the box vertically centred (cy + = below)
            if state == 2:                                   # CRUISE
                a_fwd = 1.0 * (V_CRUISE - u)
                if visible and ttc.tau < TAU_BRAKE and u > 1.0:
                    state = 3
                    print(f"t={quad.t:5.2f}  BRAKE: tau={ttc.tau:.2f} s, speed {u:.2f} m/s")
            else:                                            # BRAKE: tau-dot law
                a_fwd = -(1 - K_TAU_DOT) * max(u, 0) / max(ttc.tau, 0.2) if visible else -2.0 * u
                if (visible and w / img_w > STOP_FILL) or u < 0.15:
                    state = 4
                    print(f"t={quad.t:5.2f}  HOLD: box fills {100 * w / img_w:.0f}% of the image, speed {u:.2f} m/s")
        elif state == 4:
            a_fwd = -1.5 * u
            hold_t += dt_frame

        # ---- 3. inner loops -> quad_rpy's built-in attitude controller
        a_fwd = clamp(a_fwd, -4.0, 3.0)
        pitch = -math.degrees(math.atan2(a_fwd, G))          # nose down = accelerate
        roll = clamp(-8.0 * s["v"], -15, 15)
        err = alt_sp - s["h_asl"]
        alt_int = clamp(alt_int + err * dt_frame, -2, 2)
        tilt = max(0.5, math.cos(math.radians(pitch)) * math.cos(math.radians(roll)))
        thr = (HOVER + 0.12 * err + 0.05 * alt_int - 0.12 * s["climb_rate"]) / tilt
        if state == 5:
            thr, pitch, roll, yawrate = 0.0, 0.0, 0.0, 0.0
        f = quad.fdm
        f["ap/roll-cmd-deg"], f["ap/pitch-cmd-deg"] = roll, clamp(pitch, -25, 25)
        f["ap/yawrate-cmd-dps"], f["ap/throttle-cmd"] = clamp(yawrate, -60, 60), thr
        for _ in range(steps):
            quad.step()

        # ---- 4. truth, logs, outputs
        s = quad.state()
        d_vec = (face[0] - s["e"], face[1] - s["n"], face[2] - s["h_asl"])
        dist = math.sqrt(sum(c * c for c in d_vec))
        _, _, vel_g = quad.godot_pose()
        v_enu = (vel_g[0], -vel_g[2], vel_g[1])
        closing = sum(v * c for v, c in zip(v_enu, d_vec)) / max(dist, 1e-6)
        tau_true = dist / closing if closing > 0.05 else math.inf
        log.write("truth", quad.t, e=s["e"], n=s["n"], h_asl=s["h_asl"], speed_fwd=s["u"], dist=dist,
                  closing=closing, tau_true=tau_true if math.isfinite(tau_true) else "",
                  tau_est=ttc.tau if math.isfinite(ttc.tau) else "", state=STATES[state],
                  box_age_s=quad.t - box["t_sim"] if box else "")     # age of the image data in use
        send_pose()
        if rng.random() >= args.drop:
            send_telemetry(br, quad.t, VEHICLE_ID, TELEM_TTC,
                           [float(state), ttc.tau if math.isfinite(ttc.tau) else -1.0, s["u"], dist,
                            tau_true if math.isfinite(tau_true) else -1.0])
        next_wall += dt_frame
        time.sleep(max(0.0, next_wall - time.monotonic()))

    br.tx.sendto(P.pack_simple(P.MSG_BYE, br._next(), quad.t), br.viewer)
    log.write("link", quad.t, rx_packets=inbox.seen, rx_dropped=inbox.dropped,
              tx_poses=tx["poses"], tx_dropped=tx["dropped"])
    print(f"link: received {inbox.seen} viewer packets, dropped {inbox.dropped}; "
          f"sent {tx['poses']} poses, dropped {tx['dropped']}")
    log.close()
    print(f"finished in {STATES[state]} at t={quad.t:.1f} s, distance to target {dist:.2f} m; log {log.dir}")


if __name__ == "__main__":
    main()
