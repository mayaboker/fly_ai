# Capstone grading rubric

100 points. Each criterion has four levels. Score each criterion at the level whose description fits **all** of its points; partial fits take the lower level. Evidence means a file in the submission (log folder, plot, document) or something shown in the demo; claims without evidence score as missing.

| # | Criterion | Weight | 0 (missing) | 1 (partial) | 2 (meets) | 3 (exceeds) |
|---|---|---:|---|---|---|---|
| 1 | **Runs from a clean start** | 15 | does not run from the README | runs with help or undocumented steps | a fresh clone + README + one command per process reproduces the nominal run's key numbers within the stated tolerance; start order tested both ways | also tested on a second machine or OS, and a script checks the reproduced numbers automatically |
| 2 | **Frames and units** | 10 | no frames document | some transforms, units missing or ambiguous | every frame change from physics state to image pixel, with matrix/rule, units and where in the code; sign conventions (like `cy`) stated | plus a worked example: one logged pose → predicted pixel, matching the recorded image within 2 px |
| 3 | **Protocol document** | 5 | missing | lists messages but not rates, reliability or extensions | v1 by reference; every message used with direction, rate, reliability; every extension with layout and codes | plus a packet capture or unit test showing each extension's layout |
| 4 | **Logs and timestamps** | 10 | no structured logs | logs exist but not in the course format, or no `t_sim` | course log format; `run.json` with seed, versions, rates, failure settings; truth and estimate in separate columns; measurements carry the pose `t_sim` | plus a tool that checks the logs (row counts, monotonic `t_sim`, joins) |
| 5 | **Image ↔ telemetry acceptance** | 10 | not shown | a frame and a row shown, times differ by more than one pose period, or unexplained | one recorded image and the telemetry row at its `t_sim` (within one physics step or pose period, explained); the time is in `frames.csv` and the file name | the `t_sim` is also burnt into the image, and an independent check (like counting target pixels) confirms the image content matches the logged state |
| 6 | **Estimate vs ground truth** | 15 | no comparison | a plot without numbers, or truth taken from the estimate's own pipeline | plot + at least two error metrics over a stated window; truth computed independently on the physics side | plus error broken down (bias vs noise vs latency), or several runs with spread |
| 7 | **Timing measurements** | 10 | none | one number, or definitions missing | frame rate, pose age, image latency, with definitions, method and hardware | plus the measurement age at use by the controller, and a change that improved one of them, measured before and after |
| 8 | **Failure injection** | 10 | none | run exists, no comparison | 10 % loss or 100 ms latency: same metrics as nominal, injection settings logged, behavior described in one or two sentences with numbers | both faults, or a sweep that finds where the behavior breaks, plus a proposed mitigation |
| 9 | **60-second recording** | 5 | none | shorter, or does not show the vehicle and the key view | 60 s of the nominal run in real time showing the vehicle and its camera or HUD | narrated or captioned with the events (brake, hold, contact) and their sim times |
| 10 | **Report and demo** | 10 | missing | report incomplete or demo fails | report from the template, all sections; demo follows the checklist within time | report states limitations and next steps clearly; demo handles a live question with the logs |

Points per criterion: level 0 = 0 %, 1 = 40 %, 2 = 80 %, 3 = 100 % of the weight. A capstone that meets every criterion (level 2) scores 80.

## Automatic deductions

| Issue | Deduction |
|---|---|
| A number in the report that does not appear in the submitted logs or plots | −5 each (max −15) |
| Software-renderer or other-machine numbers presented as the result without saying so | −5 |
| Existing protocol message layout changed instead of adding a new type | −5 |
| Ground truth taken from Godot when the estimate also comes from Godot (no independent truth) | criterion 6 at most level 1 |
