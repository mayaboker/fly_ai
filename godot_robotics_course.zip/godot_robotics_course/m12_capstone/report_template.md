# Capstone report: <title>

*Copy this file into your project as `docs/report.md` and replace every `<...>`. Keep the headings. Every number must come from a file in your submission; name the file.*

**Author:** <name>  **Date:** <YYYY-MM-DD>  **Option:** <A / B / C>  **Repository / archive:** <link or file name>

## 1. Summary (5 sentences)

<What the vehicle does, what is estimated, the main accuracy number, the main timing number, what the failure run showed.>

## 2. Setup

| Item | Value |
|---|---|
| Machine | <CPU, GPU, RAM> |
| OS, driver, renderer | <e.g. Ubuntu 24.04, NVIDIA 550, Forward+> |
| Godot | <4.7.2> |
| Python, jsbsim / pybullet, numpy, opencv | <versions> |
| Physics rate, pose rate, camera rate | <Hz> |
| Seed(s) | <...> |
| Commands to reproduce | <exact commands, from README_capstone.md> |

## 3. System

### 3.1 Architecture

<A diagram: processes, messages, rates. Reference reference/protocol.md for v1.>

### 3.2 Protocol and extensions

<Short. Point to docs/protocol.md. List extensions here in one line each.>

### 3.3 Frames and units

<Point to docs/frames.md. Summarize the chain from physics pose to pixel in 3–6 lines, with the conventions that are not in the course cheat sheet.>

### 3.4 Estimator and controller

<Equations, filter settings, thresholds. What uses the estimate (closed loop) or not (open loop).>

## 4. Ground truth

<How truth is computed, on which side, from which inputs. Why it is independent of the estimate.>

## 5. Results: nominal

### 5.1 Estimate vs truth

<Plot (file name). Window used. Table:>

| Metric | Value | Run folder |
|---|---|---|
| samples | | |
| bias | | |
| RMSE | | |
| <other> | | |

<Spread over N runs, if you ran several.>

### 5.2 Mission outcome

<Key events with sim times: e.g. brake start, hold, distance; lap time; go-around height.>

### 5.3 Timing

| Number | Definition | Value (median / p95) | Source file |
|---|---|---|---|
| frame rate | | | |
| pose age (render lag, receive age) | | | |
| image latency | | | |
| measurement age at use | | | |

### 5.4 Image ↔ telemetry acceptance

<One image (embed or file name), its t_sim, and the telemetry row at that t_sim. Explain any difference.>

## 6. Failure injection

| Run | Setting | Link counts (sent/dropped) | <accuracy metric> | <outcome metric> |
|---|---|---|---|---|
| nominal | — | | | |
| fault | <10 % loss / 100 ms latency> | | | |

**What the vehicle did:** <one or two sentences with numbers.>

**Why:** <mechanism.>

**Mitigation you would try next:** <one idea and the expected effect.>

## 7. Reproduction from a clean start

<What you did (fresh clone, fresh venv, ...), what you got, and the comparison with section 5 within your stated tolerance.>

## 8. Limitations

<What is not modelled, not tested, or only valid under assumptions (flat ground, ideal detector, software renderer, ...).>

## 9. Files

| File | Content |
|---|---|
| `README_capstone.md` | setup and run |
| `docs/protocol.md`, `docs/frames.md` | documents |
| `logs/<nominal>/`, `logs/<fault>/`, `logs/<repro>/` | runs |
| `<plot>.png` | estimate vs truth |
| `demo.mp4` | 60 s recording |
