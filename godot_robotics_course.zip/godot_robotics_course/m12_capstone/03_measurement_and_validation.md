# 03 Measurement and validation

Your capstone makes two kinds of claims. **Timing claims**: how fast, how old, how late. **Accuracy claims**: how close the estimate is to the truth. Both need definitions before numbers, because "latency" means four different things to four people. This page fixes the definitions, shows how the starter measures each one, and lists our numbers on two very different machines' worth of rendering.

## Timing: four numbers, four definitions

```
 physics                      wire                    viewer                               physics
 pose t_sim=T sent ────────▶ received ──▶ frame drawn for t_render ──▶ image written       box used at t_now
 (t_unix_tx)                  (wall)        (render lag = latest − t_render)  (t_capture)   (box age = t_now − T')
```

| Number | Definition | Unit | Where it comes from |
|---|---|---|---|
| **Frame rate** | viewer frames per wall second; also the 95th percentile frame time | FPS, ms | `perf.csv`: differences of `t_unix` |
| **Pose age** (two parts) | *render lag*: newest pose's `t_sim` − the `t_sim` drawn. *Receive age*: wall time since the newest pose arrived, when the frame uses it | ms | `perf.csv`: `render_lag_s`, `rx_age_s` |
| **Image latency** | wall time from "physics sent the pose with `t_sim` = T" to "the image drawn for T is written" | ms | `pose_tx.csv` (`t_unix` per `t_sim`) and `frames.csv` (`t_capture_wall`), joined on `t_sim` |
| **Measurement age at use** | when the controller uses the newest target box: its now − the box's header `t_sim` | sim ms | `truth.csv`: `box_age_s` |

Pose age has two parts on purpose. Render lag is a **design choice**: Module 5's `RenderClock` draws 25 ms behind the newest pose so it can interpolate. Receive age is the **cost** of the frame loop: how long a pose waited before a frame used it.

Image latency compares two processes' clocks. On one machine, `time.time()` in Python and `Time.get_unix_time_from_system()` in Godot read the same system clock, so the difference is meaningful. Across two machines it is not, unless they are synchronized (PTP, or at least NTP and a stated error).

Measurement age at use is the one the controller feels. It includes the render lag, the frame loop, the transport and the time the box sat in Python before the next control step.

### Our numbers

The starter (option A, nominal run), measured with `tools/plot_ttc.py` and `tools/frame_sync_check.py`:

| | Headless viewer (no rendering, 60 FPS cap) | Software renderer (Mesa llvmpipe, xvfb) |
|---|---|---|
| Frame rate | 60.0 FPS, p95 frame 16.8 ms | 2.7 FPS, p95 frame 533 ms |
| Render lag (median) | 25.0 ms | 25.0 ms |
| Receive age (median / p95) | 0.27 / 0.38 ms | 0.25 / 0.30 ms |
| Image latency (median / p95) | n/a (headless renders no images) | 377 / 566 ms |
| Box age at use (median / p95) | 42 / 43 ms | 225 / 425 ms |
| Outcome | stopped 1.23 m from the target | **crashed into the target** |

The software renderer is not a GPU, and these numbers say nothing about your machine. They do say something general: **the viewer's frame rate is part of the control loop** as soon as the controller uses a measurement the viewer computes. At 2.7 FPS the box arrived every 370 ms, τ was estimated from a few coarse samples (τ RMSE 2.1 s instead of 0.07 s), braking started too late and the drone hit the box.

The frame rate matters even when it is high. Our reference runs cap the viewer at 60 FPS (`--perf-log` sets `Engine.max_fps = 60`; a window with vsync does the same at the monitor's rate). With an uncapped headless viewer, the box arrives more often and the same scenario held at 1.26 m instead of 1.23 m. Always report the viewer's frame rate with the result.

One more measured effect, from Module 7's list of mistakes: before we gave `SimBridge` a lower `process_priority` than the scene script, the receive age was 16.6 ms (one frame): every frame drew the previous frame's newest pose. After the fix: 0.25 ms. (`SimBridge` now sets `process_priority = -100` itself in `_ready()`, so you get this for free; if your receive age is one frame period, check that nothing overrides it.)

## Accuracy: estimate vs ground truth

For option A the estimate is τ from vision, `tau = s / ṡ`, with `s = sqrt(w_px · h_px)`. The truth is computed on the physics side, from the scenario file, not from Godot:

```python
face = (tg["e"], tg["n"] - tg["size_m"][2] / 2, terrain(tg["e"], tg["n"]) + tg["agl_m"])  # south face
d_vec = face - drone_position                       # ENU
dist = |d_vec|
closing = v_enu · d_vec / dist                      # speed toward the face
tau_true = dist / closing   (if closing > 0.05 m/s)
```

Report, for a stated window:

| Metric | Formula | Starter (window: cruising or braking, 0.5 s < τ_true < 6 s) |
|---|---|---|
| samples | count | 418 |
| bias | mean(τ_est − τ_true) | +0.045 s |
| RMSE | sqrt(mean((τ_est − τ_true)²)) | 0.073 s |
| median relative error | median(|err| / τ_true) | 1.8 % |

Why the window? Outside it, τ is infinite (hovering) or meaningless (inside the hold distance), and including those samples makes any number you like. State the window in the report.

Why the positive bias? The estimator low-pass filters ṡ (first-order, α = 0.25 per sample) and its newest box is 42 ms old at use. Both make τ_est lag τ_true; since τ is falling, a lagging τ is too large. The latency run in [04](04_failure_injection.md) confirms it: 100 ms more delay, bias +0.12 s.

And one independent check that the vision is right at all: `tools/check_box_pixels.py` counts the red target pixels in every recorded FPV frame and compares their extent with the `TargetBox` that Python received for the same `t_sim`. In our recorded run: 50 frames, from a 6 px speck to the full 640 × 480 image, worst difference 0.98 px, median 0.32 px. The box Python receives describes the image Godot draws.

## Image and telemetry name the same sim time

Acceptance item 3. The starter's viewer, with `-- --record=DIR`, saves the FPV image at 5 Hz and writes `frames.csv` in the course format. Three details make the times line up:

1. The image is read **after** the frame is drawn (`await RenderingServer.frame_post_draw`). Reading it in `_process` gives the previous frame (Module 7 measured 39 of 39 frames stale).
2. The `t_sim` written is the `t_render` the scene was posed for in that frame.
3. The same `t_sim` is burnt into the image as text by a `Label` inside the camera's `SubViewport`.

`tools/frame_sync_check.py` then picks a frame and the nearest telemetry row:

```
frames: 56 captured, 56 during the flight
image latency (pose sent -> frame written): median 377 ms, p95 566 ms, max 716 ms

frame 000029.png: t_sim 11.408 (also burnt into the image), pose_seq 1391
telemetry row nearest that t_sim: t_sim 11.4 (difference 8.3 ms)
   e=42.06826, n=-1.64578, h_asl=4.327155, speed_fwd=3.669107, dist=26.68443, tau_true=7.262074, state=CRUISE
```

![FPV frame 29: the sim time is part of the image](img/fpv_frame_000029.png)

The 8.3 ms is not an error: telemetry rows exist every 16.7 ms (one per pose) and the render clock draws between poses. Within one pose period is the tolerance. If you need the exact state at 11.408 s, interpolate the truth, as `compare_hud.py` does in Module 11.

## The 60-second recording

The recording is for humans: it shows the run in real time. Two tested ways:

**Screen capture** (what the viewer window shows, at a fixed frame rate):

```bash
ffmpeg -f x11grab -video_size 1280x720 -framerate 30 -i :0.0 -t 60 -c:v libx264 -pix_fmt yuv420p demo.mp4
```

(Use the display your Godot window is on. On Windows/macOS use OBS.) We tested this command on an Xvfb display.

**From the recorded frames** (the robot's camera, at the record rate):

```bash
ffmpeg -framerate 5 -i frames/%06d.png -c:v libx264 -pix_fmt yuv420p fpv.mp4
```

Godot's Movie Maker mode (`--write-movie`) is tempting but wrong here: it renders at a fixed simulated frame rate as fast or as slow as it can, while the physics process runs on the wall clock. The two drift apart. Use it only with a lock-step physics mode (Module 5).

## Try it

- Run the starter headless and with rendering on your machine. Fill the timing table for both. Does your machine reach the frame rate where braking works?
- Halve `record_hz` and double it. Does the image latency change? Why (or why not)?
- Compute τ_true from the **rendered** distance instead (Godot's camera to the target) and compare with the physics truth. How large is the difference, and where does it come from?
- Remove `await RenderingServer.frame_post_draw` from `_capture` and rerun `frame_sync_check.py`. Then look at the stamp in the images.

## References

- [Module 5: rates, age, jitter](../m05_time_rates/02_rates_age_jitter.md), [Module 7: measuring](../m07_frame_transport/04_measuring.md), [Module 8: timestamps and alignment](../m08_sensors/05_timestamps_alignment.md)
- Lee, D. N. (1976). A theory of visual control of braking based on information about time-to-collision. *Perception* 5, 437–459.
- FFmpeg x11grab: <https://ffmpeg.org/ffmpeg-devices.html#x11grab>
