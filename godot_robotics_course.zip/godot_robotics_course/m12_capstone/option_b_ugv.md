# Option B: UGV road following with camera and IMU

The rover from Module 9 drives its road using its forward camera to find the road and its IMU to steady the heading. The estimate is the rover's lateral offset from the road centerline and its heading error relative to the road; the truth comes from the PyBullet pose and the road polyline that Module 9 already steers on.

There is no separate starter for this option: [Module 9](../m09_ugv_pybullet/README.md)'s code is the starting point. This page tells you what to add.

## Start from

| You need | From | Files (see [project layout](../reference/project_layout.md)) |
|---|---|---|
| Rover on the shared terrain, DIFF_DRIVE commands, road following on the true pose, cross-track error | [Module 9](../m09_ugv_pybullet/05_road_following.md) | `physics/sims/ugv_pybullet.py`, `data/terrain/range.json` (roads, ENU; the route comes from `build_route()` in `ugv_pybullet.py`), `tools/plot_cross_track.py` |
| Road drawn in Godot, rover model with `fpv_cam` mount | [Module 2](../m02_scene_assets/05_range_and_vehicles.md) | `range.json` roads, `vehicles/rover.tscn` |
| Camera rig, intrinsics | [Module 6](../m06_cameras/README.md) | `camera_rig.gd` (RIGID on `fpv_cam`) |
| Pixels in Python | [Module 7](../m07_frame_transport/README.md) | shared-memory writer and `frame_reader.py` (or the UDP fallback) |
| IMU with noise, truth columns | [Module 8](../m08_sensors/02_imu.md) | physics-side IMU |
| Log format, timing tools | Modules 5, 7 | `RunLogger`, `plot_pose_age.py`, `check_frames.py` |

## Minimum scope

1. A **vision measurement** of the road: the lateral offset of the road center in the image at a fixed look-ahead row, and the road direction (two rows give a line). If the road is drawn like Module 2's (dark asphalt, white edges, yellow dashed center line, on grass), a color threshold is enough to start.
2. Convert it to meters with the camera intrinsics and mount (flat-ground assumption: a pixel row maps to a ground distance). This conversion goes into `docs/frames.md`.
3. Module 9's controller, now steering on the estimate instead of the true pose. Use the IMU yaw rate as the damping term or in a complementary filter with the vision heading.
4. One lap of the loop. Plot estimated vs true offset and heading error.

## Ground truth

Python has the true pose and the road polyline (ENU). Module 9 already computes exactly the truth you need, for its own controller: the cross-track error `cte` (**> 0 = rover left of the road**) and the heading error `ψ_e = road heading − rover heading`, from the nearest segment with a progress index ([Module 9, sub-topic 05](../m09_ugv_pybullet/05_road_following.md)). Log them as `cte_true`, `heading_err_true` and your vision estimates as `cte_est`, `heading_err_est`, with the same sign conventions.

Make sure the road the camera sees in Godot is the road the truth uses: the viewer must draw the polyline from the same file Python reads, not a copy.

The image measurement belongs to the pose the frame was rendered from (`frames.csv` `t_sim`, or the shared-memory header). Compare it with the truth **at that `t_sim`**, not at the time Python read the frame. The difference between the two comparisons is a nice number for your report: it is the effect of image latency on the controller.

## Failure injection

Inject latency or loss on the image path (and the pose path). Typical behavior to look for and report: with a delayed offset the steering loop loses phase margin, so the rover weaves around the center line or cuts the corners; with loss the controller holds an old offset longer. Measure the RMS offset per lap and the maximum offset, nominal vs fault.

## Pitfalls

| Pitfall | Symptom | Fix |
|---|---|---|
| Flat-ground pixel-to-meter conversion on a slope | offset error grows on the hills of the loop's corners | state the assumption; use the terrain height (or the rover's pitch) to correct, or keep the look-ahead short |
| Camera mount not in the conversion | constant offset bias | use the mount transform from `intrinsics_<name>.json` (Module 6) |
| Comparing at the read time | offset error looks large in curves | compare at the frame's `t_sim` |
| Yellow center dashes | the center line disappears between dashes | use the asphalt edges, or both |
| IMU frame | yaw rate sign flipped (FLU vs Godot) | test a pure left turn before closing the loop |

## Checklist for option B

- [ ] one full lap, nominal: offset and heading-error plots (estimate vs truth), RMS and max errors
- [ ] image–telemetry acceptance: a frame and the truth row at its `t_sim`
- [ ] failure run: RMS offset per lap and what the rover did
- [ ] frame rate, pose age, image latency (Module 7's numbers on your machine)
- [ ] `docs/frames.md` includes the pixel → ground conversion and the IMU axes
