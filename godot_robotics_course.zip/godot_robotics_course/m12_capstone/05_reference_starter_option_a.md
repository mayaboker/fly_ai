# 05 The option A reference starter

Option A has a tested starter in [code/](code/README.md): a JSBSim quadcopter takes off, turns toward a red target box, flies at it, estimates the time to contact (τ) from the box's size in its FPV image, and brakes to a stop in front of it. Everything goes over protocol v1. This page walks through it so you can extend it rather than copy it.

It descends from an earlier Godot + JSBSim prototype that used its own ad-hoc packets (Euler angles on the wire, a custom "vision" packet carrying the true distance). The starter keeps its control ideas and replaces the plumbing:

| Prototype | Starter |
|---|---|
| pose packet `<I10f>` with Euler angles | protocol v1 POSE with quaternion, Godot frame |
| custom vision packet incl. `true_dist` from Godot | SENSOR_TARGET_BOX; truth computed in Python from the scenario file |
| contact flag in the vision packet | SENSOR_CONTACT, Area3D + sweep |
| target position hard-coded in GDScript | `data/scenarios/ttc_target.json`, read by both sides |
| `+cy` = up | `+cy` = down (Module 6 `TargetBox`, image coordinates) |

## The pieces

```
 physics/sims/ttc_quad_jsbsim.py  (vehicle 2)              godot/scenes/ttc_lab.tscn
 ──────────────────────────────────────────                ─────────────────────────────────────────
 JSBSim quad_rpy, 120 Hz, terrain feed                     Module 2 quad.tscn, terrain, range
 state machine + tau estimator + tau-dot braking           Module 6 CameraRig GIMBAL_LEVEL on fpv_cam
 truth from ttc_target.json                                 Module 6 TargetBox -> SENSOR_TARGET_BOX
 LossyInbox (failure injection)       ◀── SENSOR ────────  Area3D + sweep -> SENSOR_CONTACT
 RunLogger: truth, vision, pose_tx,   ── POSE 60 Hz ────▶  Module 5 RenderClock, SimBridge.sample
            event, link               ── TELEMETRY 3 ───▶  HUD: state, tau vision vs truth
                                                            --perf-log, --record (frames.csv + PNGs)
```

`data/scenarios/ttc_target.json` is the single source of the layout:

```json
{
  "start": {"e": 40.0, "n": -30.0, "heading_deg": 0.0},
  "target": {"e": 44.0, "n": 25.0, "agl_m": 3.0, "size_m": [1.0, 1.0, 0.1]},
  "camera": {"width_px": 640, "height_px": 480, "fov_v_deg": 70.0}
}
```

The start is east of Module 2's gates on purpose. The prototype's layout (target 4 m east, 25 m north of the pad) would put the target right behind `gate_1`, with the approach passing about 1.5 m from a gate post.

## The state machine

| State | Does | Leaves when |
|---|---|---|
| TAKEOFF | climb to 3 m AGL | AGL > 2.7 m |
| ACQUIRE | yaw toward the box (`yawrate = 60 · cx`), brake to zero speed; spin slowly if not visible | box centered (`|cx| < 0.03`) and yaw rate small; resets the estimator |
| CRUISE | fly at 4 m/s, keep the box centered (yaw) and level (altitude += −1.5 · cy · dt) | τ < 3 s |
| BRAKE | tau-dot law (below) | box fills 30 % of the width, or speed < 0.15 m/s |
| HOLD | hold position for 3 s | end of run |
| CRASH | motors off | (set by SENSOR_CONTACT from Godot) |

The inner loops are those of `quad_rpy`'s built-in attitude controller (JSBSim course lesson 5): Python sets `ap/pitch-cmd-deg`, `ap/roll-cmd-deg`, `ap/yawrate-cmd-dps`, `ap/throttle-cmd`. A forward acceleration command becomes a pitch angle, `pitch = −atan(a / g)`.

## τ from the image

For an object of size S at distance d, a pinhole camera sees an image size `s = f · S / d`. Differentiate: `ṡ = −f · S · ḋ / d²`, so

```
s / ṡ = (f S / d) / (−f S ḋ / d²) = d / (−ḋ) = τ
```

The ratio of size to growth rate is the time to contact, with no need to know f, S or d. That is why it is a classic vision cue (Lee, 1976) and a good capstone estimate: it is cheap, and it has an exact ground truth.

```python
class TTCEstimator:
    def update(self, t, size_px):           # t = the SENSOR header's t_sim
        if self.t is not None and t > self.t:
            raw = (size_px - self.s) / (t - self.t)
            self.sdot += self.alpha * (raw - self.sdot)     # alpha = 0.25: low-pass
        if self.t is None or t > self.t:
            self.s, self.t = size_px, t

    @property
    def tau(self):
        return self.s / self.sdot if self.s and self.sdot > 1e-3 else math.inf
```

`size_px = sqrt(w · h)` uses both box dimensions, which halves the effect of one-pixel steps in either. The `t > self.t` checks make duplicate or out-of-order packets harmless.

## Braking with τ-dot

Lee's τ-dot strategy: keep `dτ/dt = −k` constant while braking. For a constant k the required deceleration is

```
a = −(1 − k) · v / τ
```

With k = 0.5 that is a constant deceleration that reaches zero speed exactly at contact; with k < 0.5 the deceleration fades and the vehicle stops short. The starter uses k = 0.4 and also stops on the visual size (30 % of the image width), which is what kept it safe in the latency runs ([04](04_failure_injection.md)).

## Running it

```bash
# terminal 1 (robosim/)
godot --path godot res://scenes/ttc_lab.tscn
# terminal 2 (robosim/physics)
python sims/ttc_quad_jsbsim.py                       # nominal
python sims/ttc_quad_jsbsim.py --latency 0.1         # failure injection
# afterwards (robosim/)
python tools/plot_ttc.py logs/<run> [perf.csv]
```

Measurements need the viewer options: `-- --perf-log=perf.csv` (every frame) and `-- --record=frames` (FPV PNGs at 5 Hz, `frames.csv`, `fpv_intrinsics.json`). Then:

```bash
python tools/frame_sync_check.py logs/<run> frames       # image latency + one frame vs telemetry
python tools/check_box_pixels.py logs/<run> frames       # box sizes vs rendered pixels
```

Console of the nominal run (headless viewer):

```
flying (ttc_drop0_lat0), logs in .../logs/20261001T071931Z_ttc_drop0_lat0
t=15.78  BRAKE: tau=3.00 s, speed 3.67 m/s
t=19.67  HOLD: box fills 30% of the image, speed 1.08 m/s
link: received 1361 viewer packets, dropped 0; sent 1363 poses, dropped 0
finished in HOLD at t=22.7 s, distance to target 1.23 m
```

The cruise speed settles at 3.67 m/s, not 4: the forward loop is proportional only. That is fine for the capstone; fixing it is an easy first extension.

## Measured results (summary)

| | Nominal | 10 % loss | 100 ms latency |
|---|---|---|---|
| τ RMSE (0.5 s < τ < 6 s) | 0.073 s | 0.086–0.095 s | 0.150–0.151 s |
| τ bias | +0.045 s | +0.060–0.067 s | +0.119–0.120 s |
| braking started at | 10.63 m | 10.57 m | 10.19–10.25 m |
| stopped at | 1.23 m | 1.20–1.22 m | 1.10–1.12 m |

With a headless viewer at 60 FPS. With a software renderer at 2.7 FPS the same code crashed into the target ([03](03_measurement_and_validation.md)).

![The same starter with a 2.7 FPS viewer: τ from three or four samples, braking far too late](img/ttc_software_renderer.png)

## Extending it into your capstone

The starter satisfies the mechanics. Your capstone adds the parts that are yours:

- **A real detector.** Replace the ideal box with a detector on the pixels (Module 7 transport, then for example a red-color threshold, `tools/cv_red_box.py` in Module 7). Now the box has noise and misses; plot τ again.
- **The PyBullet quad** from Module 10 instead of JSBSim: only the physics script changes; the viewer and the protocol do not.
- **Speed control** with an integrator so the cruise speed is really 4 m/s, or a τ-based cruise ("approach at constant τ-dot from the start").
- **A moving target**, which breaks the assumption behind τ = d / closing speed only if you compute truth wrongly.

## Try it

- Set `K_TAU_DOT = 0.5` and `STOP_FILL = 2.0` (never hold on size). Does the drone touch the target? At what speed?
- Change the camera to 1280 × 960. Does τ RMSE improve? Why only a little?
- Plot `box_age_s` from `truth.csv` over the run. Where are the spikes, and what causes them?

## References

- Lee, D. N. (1976). A theory of visual control of braking based on information about time-to-collision. *Perception* 5, 437–459.
- [Module 6: ground-truth boxes](../m06_cameras/06_ground_truth_boxes.md), [Module 10: multirotor lab](../m10_multirotor/README.md)
- Companion JSBSim course, lessons 4–6 (`quad_rpy`, its attitude controller)
