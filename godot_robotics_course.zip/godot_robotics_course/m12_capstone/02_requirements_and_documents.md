# 02 Requirements and documents

A simulator result that only runs on your laptop, on the day you made it, is an anecdote. The capstone's documents turn it into something another person can rerun and check. This page lists what to deliver and shows what "good enough" looks like, using the option A starter as the example.

## 1. A runnable project

Rules:

- **One command per process**, run from a documented folder. For the starter:
  ```bash
  godot --path godot res://scenes/ttc_lab.tscn                 # viewer
  cd physics && python sims/ttc_quad_jsbsim.py                 # physics
  ```
- **Start order does not matter.** The physics process sends idle poses while it waits (`wait_for_viewer(send_idle_pose=...)`); the viewer says HELLO at start-up, until its first pose, and on the first pose of each physics session (Module 4, `reference/protocol.md`). Test both orders.
- **No hidden state.** Everything the run needs is in the tree: aircraft files, heightmap (or the command and seed that generate it), scenario JSON. Nothing from your home folder, no absolute paths.
- **Defaults are the nominal run.** Options such as `--latency 0.1` change one thing and are written into `run.json`.

## 2. Setup instructions

`README_capstone.md` at the top of the project. It must contain:

| Section | Content |
|---|---|
| Versions | OS, Godot (4.7.2), Python, `pip freeze` lines for jsbsim / pybullet / numpy / opencv |
| Install | venv creation and `pip install`, as in [00_setup](../00_setup/README.md) |
| Data | `python tools/make_heightmap.py` (seed 42) or the committed files and their checksums |
| First run | `godot --headless --path godot --import`, then the two commands above |
| Ports | 9001 / 9002, or the ports you changed and why |
| Expected output | the console lines of a good run, and where the logs go |
| Known limits | what you did not test (for example "not tested on Windows") |

## 3. The protocol document

Do not copy the protocol. Reference it and list only what you use and what you added. `docs/protocol.md` for the starter:

```markdown
# Protocol: capstone option A

Transport: robosim protocol v1, unchanged (reference/protocol.md). Ports 9001 (to viewer), 9002 (to physics).

## Messages used
| Message | Direction | Rate | Reliability | Notes |
|---|---|---|---|---|
| POSE, vehicle 2 | physics → viewer | 60 Hz | unreliable, latest wins | Godot frame, m, quat (x,y,z,w), ground velocity |
| SENSOR_TARGET_BOX (3), vehicle 2 | viewer → physics | every rendered frame | unreliable | visible, cx, cy (−1..1, +cx right, +cy DOWN), w_px, h_px; header t_sim = sim time of the rendered pose |
| SENSOR_CONTACT (1), vehicle 2 | viewer → physics | every frame while touching | unreliable | hit, normal (Godot), depth = 0 (not measured) |
| HELLO / BYE / ACK | both | as in v1 | | |

## Extensions
| Type | Name | Direction | Layout | Codes |
|---|---|---|---|---|
| 100 | TELEMETRY | physics → viewer, 60 Hz (with every pose), unreliable | header + vehicle_id u16, code u16, count u16, reserved u16, count × f32 | 3 = TTC: state, tau_est (−1 = none), forward speed m/s, true distance m, true tau (−1 = none). (1 = FLIGHT and 2 = MOTORS are used by Modules 11 and 10.) |

Viewers that do not know type 100 ignore it. No existing layout was changed.
```

Write down the conventions that are not obvious, like the sign of `cy`. Module 6's `TargetBox` uses image coordinates (`+cy` = down); an earlier prototype used `+cy` = up. `reference/protocol.md` now states it (+cx right, +cy down); say it again in your document, because a reader of your protocol should not need ours.

## 4. The frames diagram

Every transform from physics state to image pixel, with units. The starter's `docs/frames.md`:

```
 JSBSim (quad_rpy)          physics side (Python)                      wire          Godot
 ──────────────────         ─────────────────────────────────────      ─────         ───────────────────────────────
 lat, lon (rad)      ─┐
 h-sl (ft)           ─┼─ GeoOrigin(32.08°, 34.80°, 0 m).to_enu ──▶ ENU (m) ─ M_GODOT_ENU ─▶ pos (m) ──▶ Quad node
 φ, θ, ψ (rad, NED)  ─┘   R_enu_flu = T_ENU_NED·R_zyx·D_FRD_FLU      quat = M·R·C_FLU_MODEL ─▶ quat ──▶ (nose −Z, top +Y)
 v_north/east/down   ──── (vE, vU, −vN) · 0.3048 ───────────────────────────────────▶ vel (m/s)
                                                                                           │ Mounts/fpv_cam
                                                                                           ▼  (0, 0, −0.15) m
                                                                     CameraRig GIMBAL_LEVEL: position of the mount,
                                                                     heading of the mount, roll = 0, pitch = 0
                                                                                           │
                                                                     pinhole: fy = (H/2)/tan(fov_v/2) = 342.76 px
                                                                     fx = fy, cx = 320, cy = 240 (640 × 480, fov_v 70°)
                                                                                           ▼
                                                            TargetBox: 8 corners → (u, v) px → box → (cx, cy, w, h)
```

And a units table:

| Quantity | Physics | Wire | Godot | Logs |
|---|---|---|---|---|
| position | ENU m (from ft) | Godot m | m | `e, n, h_asl` m |
| attitude | φ θ ψ rad | quat (x,y,z,w) | Basis | `*_deg` |
| velocity | NED ft/s → m/s | Godot m/s | m/s | `speed_fwd` m/s |
| image | — | px (box) | px, origin top-left | `w_px, h_px`, `cx, cy` (−1..1) |
| time | sim s | header `t_sim` f64 | `t_render` | `t_sim`, `t_wall` |

The [frames cheat sheet](../reference/frames.md) holds the matrices. Your document must name each one and say where in your code it is applied. Test: someone else computes the pixel position of the target from one logged pose with only your document.

## 5. Timestamps and log format

Use the course [log format](../reference/logging.md) without changes. On top of it, the capstone needs:

| Stream | Written by | Columns that matter |
|---|---|---|
| `truth.csv` (or `pose.csv`) | physics, every pose | `t_sim`, true state, true value of what you estimate |
| `vision.csv` | physics, every sensor packet used | `t_sim` (when used), `pose_t_sim` (header of the packet), measurement, estimate |
| `pose_tx.csv` | physics, every pose sent | `t_sim`, `t_unix` (for image latency) |
| `frames/frames.csv` | viewer, every saved image | `frame_id, t_sim, pose_seq, t_capture_wall, width, height` |
| `perf.csv` | viewer, every frame | `t_unix, t_render, latest_t_sim, render_lag_s, rx_age_s, fps` |
| `event.csv` | physics | crashes, phase changes, with the pose time they refer to |
| `run.json` | physics | seed, versions, rates, scenario, failure settings |

Three rules carry most of the value:

1. **Every measurement carries the sim time of the pose it was computed from.** Protocol v1 puts it in the SENSOR header. Log it next to the time you used it; the difference is the measurement's age.
2. **Truth and estimate are separate columns** (`tau_true`, `tau_est`). Never overwrite one with the other.
3. **Wall clocks only for latency**, and only `time.time()` / `Time.get_unix_time_from_system()` when you compare across processes on one machine. For anything else, `t_sim`.

## Try it

- Fill the units table for your option before you write code. Any empty cell is a bug waiting to happen.
- Ask a classmate to follow your README on their machine without help. Write down every question they ask; each one is a missing line.
- Find one convention in your project that the course pages do not specify (like the `cy` sign) and document it.
