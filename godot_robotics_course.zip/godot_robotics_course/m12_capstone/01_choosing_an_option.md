# 01 Choosing an option

The capstone is not a new feature. It is the proof that the pieces you built work **together**, under measurement, and that somebody else can rerun them. So choose the option whose vehicle you already know best, and spend the time on integration, measurement and documentation, not on a new controller.

## The three options

| | A: quadcopter, time to contact | B: UGV road following | C: fixed-wing approach |
|---|---|---|---|
| Vehicle | quadcopter, PyBullet **or** JSBSim (`quad_rpy`) | rover, PyBullet | trainer (or quadplane), JSBSim |
| Builds on | Module 10, Module 6 (TargetBox, gimbal rig), Module 8 | Module 9, Module 6/7 (camera, frames), Module 8 (IMU) | Module 11, Module 6/7, Module 8 (baro, air data) |
| Camera job | FPV sees a target; its image size gives time to contact (τ) | forward camera sees the road; lane offset and heading | onboard or ground camera during an approach to the pad |
| Estimate to plot vs truth | τ from vision vs true distance / closing speed | lateral offset and heading error from vision (+ IMU) vs true pose relative to the road | glide-path deviation (or runway-relative position) from vision vs JSBSim's true position |
| Closed loop on the estimate | yes: braking law uses τ | yes: steering uses the offset | optional: autopilot may use truth; the estimate can be open-loop |
| What a fault does | late or noisy τ → brakes late → stands off closer or touches | stale offset → oscillation, leaves the road | stale estimate → wrong deviation reported; with closed loop, a missed approach |
| Reference code | **tested starter in [code/](code/README.md)** | Module 9 code | Module 11 code |
| Guidance | [option_a_ttc.md](option_a_ttc.md) | [option_b_ugv.md](option_b_ugv.md) | [option_c_fixed_wing.md](option_c_fixed_wing.md) |

## How to pick

Ask four questions, in this order.

1. **Which vehicle lab did you finish with the fewest open problems?** A capstone on a shaky controller turns into controller tuning. Pick the vehicle that already flies or drives reliably.
2. **Which sensor path have you measured?** Option A needs only the ideal target box (no image transport). B needs real pixels in Python (Module 7). C can go either way. If Module 7's shared memory is not working on your machine, A or C (ideal measurements) keeps you moving; you can still record images for the acceptance test.
3. **Do you want a closed loop on your estimate?** A and B close the loop: a bad estimate changes the vehicle's path, and the failure-injection run becomes interesting. C is easier to keep open-loop: the aircraft flies on truth and you judge the estimate on the side. Open-loop is a legitimate, smaller capstone; say so in your report.
4. **What is your goal after the course?** Drones and perception: A. Ground robots: B. Aircraft, landing, sense-and-avoid: C.

If two options tie, take A: it has a tested starter, so you can spend your time on the parts that are graded.

## What every option must have

The requirements are the same for all three ([02_requirements_and_documents.md](02_requirements_and_documents.md)):

| Requirement | One-line meaning |
|---|---|
| Runnable project | clone, follow the README, two commands, it runs |
| Setup instructions | versions, install, data generation, ports |
| Protocol document | "protocol v1" by reference, plus every extension you added |
| Frames diagram | every frame and transform from physics to image pixels |
| Timestamps and log format | course log format; image and telemetry joined by `t_sim` |
| 60-second recording | a screen recording of the nominal run |
| Timing | frame rate, pose age, image latency, on your machine |
| Estimate vs truth | a plot and error numbers |
| Failure injection | 10 % packet loss or 100 ms latency; what the vehicle did |

## Scope

Plan for about 6 h of project work after reading. A typical split:

| Work | Time |
|---|---:|
| Get the scenario running end to end (starter or your own) | 1.5 h |
| Ground truth, estimate logging, the plot | 1 h |
| Timing measurements, the recording | 1 h |
| Failure injection runs | 0.5 h |
| Documents: README, protocol, frames, report | 1.5 h |
| Clean-start reproduction and demo rehearsal | 0.5 h |

If you are well over this after the first two rows, cut scope (fewer states in your mission, open loop instead of closed loop), not documentation. The rubric weights evidence and reproducibility higher than features.

## Try it

- Write down, for your chosen option, the one number that would tell you the estimate is good enough for the vehicle's job. For A, for example: "τ error below 10 % while τ < 5 s".
- List every process, port and file your scenario needs. Anything you cannot list yet is a risk for the clean-start test.
- Read the rubric now, not at the end.
