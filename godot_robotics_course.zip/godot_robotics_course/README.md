# Godot for Robotics Simulation, with PyBullet and JSBSim

**Level:** beginner in Godot, intermediate in Python and robotics
**Format:** 12 hands-on modules, about **96 hours** including labs and the capstone
**Stack:** Godot 4.7.2 (standard build, GDScript), Python 3.10+, PyBullet, JSBSim 1.3.1, VS Code; Terrain3D (optional, see Module 2)

## The one architectural rule

> **One physics owner.** The Python process (PyBullet *or* JSBSim) owns simulation time and vehicle dynamics. Godot owns the 3D scene, cameras, visuals and world-geometry sensors. Commands go to physics. Poses and sensor data travel over a documented bridge. Never simulate the same vehicle's dynamics in both.

```
 Python physics process                         Godot viewer
 ──────────────────────────                     ──────────────────────────
 PyBullet / JSBSim, fixed step   ── POSE ────▶  interpolated vehicle nodes
 IMU, GPS, baro, airspeed        ── ACK ─────▶  cameras (FPV, chase, down)
 controllers, logs               ◀─ COMMAND ──  UI, keyboard, gamepad
 contact response                ◀─ SENSOR ───  raycasts, lidar, contact, target box
```

## How to use this course

1. Do [00_setup](00_setup/README.md) once. [INDEX.md](INDEX.md) lists every file in reading order.
2. Read the three reference pages. You will come back to them constantly:
   - [Frames cheat sheet](reference/frames.md): every conversion, tested
   - [Bridge protocol](reference/protocol.md): every packet
   - [Log format](reference/logging.md): every recorded run
3. Work through the modules **in order**. Each module folder has:
   - `README.md`: goals, time, prerequisites, sub-topic list, the module's **Check**
   - `NN_*.md`: one file per sub-topic, with explanation, code and a small exercise
   - `lab.md`: the module's main exercise, step by step, extending **one** project
   - `code/`: finished, tested reference files for that module (look only after trying)
4. Everything goes into one growing project, `robosim/` (see [project layout](reference/project_layout.md)). You never start a new demo from scratch.

## Course map

| # | Module | Time | You build |
|---:|---|---:|---|
| 1 | [Godot editor and GDScript](m01_editor_gdscript/README.md) | 5 h | A navigable 3D viewport with status text, pause/reset and an XYZ marker |
| 2 | [Scenes, terrain and vehicle assets](m02_scene_assets/README.md) | 6 h | A test range: terrain, road, gates, pad; UGV, quad, plane and quadplane models |
| 3 | [Frames, units, quaternions, mounts](m03_frames/README.md) | 9 h | Verified PyBullet→Godot and JSBSim→Godot adapters, frame cheat sheet |
| 4 | [External simulator bridge](m04_bridge/README.md) | 8 h | Versioned pose/command/sensor protocol with stale detection and restart handling |
| 5 | [Time, rates, interpolation, resets](m05_time_rates/README.md) | 7 h | Smooth visuals across rate mismatch; pause, step, reset, lock-step; the log format |
| 6 | [Cameras and image formation](m06_cameras/README.md) | 8 h | FPV, chase and downward cameras with exported intrinsics |
| 7 | [RGB frame transport and measurement](m07_frame_transport/README.md) | 8 h | Shared-memory video with metadata and a performance report |
| 8 | [Synthetic sensors and ground truth](m08_sensors/README.md) | 8 h | IMU, GPS, baro on the physics side; range, lidar, contact on the Godot side |
| 9 | [PyBullet UGV lab](m09_ugv_pybullet/README.md) | 9 h | Differential-drive rover on shared terrain, road following |
| 10 | [Multirotor lab: PyBullet or JSBSim](m10_multirotor/README.md) | 10 h | Quadcopter with motor forces, attitude/altitude control, FPV |
| 11 | [JSBSim fixed-wing lab](m11_jsbsim_fixed_wing/README.md) | 8 h | Aircraft state bridge, terrain feed, chase/onboard cameras; quadplane stretch goal |
| 12 | [Integration capstone](m12_capstone/README.md) | 10 h | A repeatable scenario with logs, validation and a short demo |
| | **Total** | **96 h** | |

## Pace

At 6–8 h a week the course takes **12–16 weeks**. Do modules 1–8 in order. Then do Module 9 and/or 10 depending on whether the UGV or the drone is your goal. Module 11 is the fixed-wing path; it reuses Modules 4–8. Do the capstone after the vehicle lab it builds on.

## JSBSim parallel track

JSBSim gets equal weight with PyBullet here. If you are new to JSBSim, interleave the separate *JSBSim from zero to quad and VTOL* course (8 lessons, about 10–15 h, not counted in the 96 h):

| Before | Do JSBSim lessons | Because |
|---|---|---|
| Module 3 | 1–3 (what JSBSim is, first model, forces and frames) | Module 3 converts JSBSim states |
| Module 10 (JSBSim option) | 4–6 (quad, built-in controller, missions) | Module 10 reuses that quad |
| Module 11 | 7–8 (fixed-wing coefficients, VTOL) | Module 11 flies that aircraft |

## Outcomes

By the end you can:

1. Build terrain, vehicles, lights, materials, cameras and overlays in Godot.
2. Convert positions, orientations and camera frames between PyBullet, JSBSim and Godot, and prove it with tests.
3. Drive Godot visuals from a fixed-step physics process at an independent render rate.
4. Export timestamped RGB frames, synthetic IMU/GPS/range/lidar data and ground truth.
5. Measure latency, dropped frames, readback cost and synchronization error.
6. Build a UGV or quadcopter simulator and a JSBSim fixed-wing visualization path.

## Why Godot rather than Unreal

Godot's small node model, GDScript and lightweight projects keep the focus on frames, time and transport, which are the robotics part. Unreal is the better choice later, when photorealism or very large worlds become the goal. Nothing in this course's bridge prevents that move.

## Versions this course was written and tested with

| Tool | Version |
|---|---|
| Godot | 4.7.2-stable (headless used for the automated tests) |
| Python | 3.11 |
| JSBSim | 1.3.1 (`pip install jsbsim`) |
| PyBullet | 3.2.x (`pip install pybullet`) |
| Terrain3D | check its release page for 4.7 support before Module 2 |

If you have an existing project (for example a shared-memory FPV demo with a PyBullet pose sender), you can use it as the starting point for Module 1. Every lab says which files it adds, so you can merge them into what you already have.
