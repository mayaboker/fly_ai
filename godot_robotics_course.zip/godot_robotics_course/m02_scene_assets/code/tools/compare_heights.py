#!/usr/bin/env python3
"""
compare_heights.py - Module 2 Check: Godot and Python must read the same terrain.

Runs the Godot test scene headless, reads the heights it printed (bilinear lookup and
raycast against HeightMapShape3D), samples the same ENU points with robosim/terrain.py,
and prints a table. Run from the robosim/ folder:

  python tools/compare_heights.py --godot ~/tools/godot
  python tools/compare_heights.py --godot ~/tools/godot --points "37.3,-12.6;-55.5,41.2;101.7,-88.3"

Tolerances:
  Godot lookup vs Python    one height step of the PNG (height_range / 65535 = 0.3 mm)
  Godot raycast vs Python   5 cm: the physics shape is made of triangles, not bilinear patches
"""
import argparse
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))     # robosim/
sys.path.insert(0, os.path.join(ROOT, "physics"))
from robosim.terrain import Heightmap  # noqa: E402

LINE = re.compile(r"HEIGHT e=(\S+) n=(\S+) direct=(\S+) ray=(\S+)")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--godot", default=os.environ.get("GODOT", "godot"), help="Godot 4.7 binary")
    ap.add_argument("--points", default="37.3,-12.6;-55.5,41.2;101.7,-88.3", help="ENU e,n;e,n;...")
    ap.add_argument("--ray-tol", type=float, default=0.05)
    args = ap.parse_args()

    hm = Heightmap.load(os.path.join(ROOT, "data", "terrain", "heightmap.png"))
    step = hm.meta["height_range_m"] / 65535.0

    cmd = [args.godot, "--headless", "--path", os.path.join(ROOT, "godot"),
           "-s", "tests/test_m02.gd", "--", "--points=" + args.points]
    out = subprocess.run(cmd, capture_output=True, text=True, timeout=120).stdout
    rows = [tuple(map(float, m.groups())) for m in LINE.finditer(out)]
    if not rows:
        sys.exit("no HEIGHT lines from Godot. Output was:\n" + out)

    ok = True
    print(f"{'E':>8} {'N':>8} | {'python':>9} {'godot':>9} {'diff mm':>8} | {'raycast':>9} {'diff mm':>8}")
    for e, n, direct, ray in rows:
        py = hm.height_at(e, n)
        d1, d2 = direct - py, ray - py
        ok &= abs(d1) <= step and abs(d2) <= args.ray_tol
        print(f"{e:8.2f} {n:8.2f} | {py:9.4f} {direct:9.4f} {d1 * 1000:8.3f} | {ray:9.4f} {d2 * 1000:8.2f}")
    print(f"tolerance: lookup {step * 1000:.3f} mm, raycast {args.ray_tol * 1000:.0f} mm  ->  "
          + ("PASS" if ok else "FAIL"))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
