#!/usr/bin/env python3
"""
make_heightmap.py - generate the shared test-range terrain (Module 2).

Writes, per reference/terrain.md:
  data/terrain/heightmap.png    16-bit grayscale, N x N (N = 257), row 0 = north edge
  data/terrain/heightmap.json   size_px, meters_per_px, min_height_m, height_range_m, seed, origin
and the range layout that Godot and the physics side both read:
  data/terrain/range.json       road centerlines, gates, obstacles, pad, vehicle lineup (ENU meters)

Same seed -> byte-identical files. Run from the robosim/ folder:
  python tools/make_heightmap.py                 # seed 42, 257 px, 1 m/px
  python tools/make_heightmap.py --seed 7 --out /tmp/terrain

Only numpy and Pillow are needed (Pillow comes with matplotlib).
"""
import argparse
import json
import math
import os

import numpy as np
from PIL import Image

# ---------------------------------------------------------------- range layout (ENU, meters)
# x/e = East, y/n = North. Heights are not stored here: everything sits on the terrain.
APRON = {"e_min": -18.0, "e_max": 18.0, "n_min": -20.0, "n_max": 10.0}   # flattened to 0 m


def rounded_rect_loop(e0, e1, n0, n1, r, step=2.0):
    """Closed road centerline: rectangle with rounded corners, counter-clockwise, ENU."""
    pts = []
    corners = [(e1 - r, n0 + r, -90), (e1 - r, n1 - r, 0), (e0 + r, n1 - r, 90), (e0 + r, n0 + r, 180)]
    for ce, cn, a0 in corners:
        for k in range(0, 91, 5):           # 5 degree steps on each quarter circle
            a = math.radians(a0 + k)
            pts.append((ce + r * math.cos(a), cn + r * math.sin(a)))
    pts.append(pts[0])                      # close the loop
    return [[round(e, 3), round(n, 3)] for e, n in pts]


LAYOUT = {
    "frame": "ENU",
    "units": "m, deg",
    "road_width_m": 5.0,
    "roads": [
        {"name": "loop", "closed": True, "points": rounded_rect_loop(-70, 70, -55, 65, 22)},
        {"name": "spur", "closed": False, "points": [[0.0, -20.0], [0.0, -36.0], [0.0, -55.0]]},
    ],
    "pad": {"e": 0.0, "n": 0.0, "radius_m": 4.0},
    "apron": APRON,
    # vehicle lineup south of the pad; each gets a 1 m reference box at e + 2.2
    "lineup": [
        {"id": 1, "name": "rover", "e": -9.0, "n": -12.0},
        {"id": 2, "name": "quad", "e": -3.0, "n": -12.0},
        {"id": 3, "name": "plane", "e": 3.5, "n": -12.0},
        {"id": 4, "name": "quadplane", "e": 10.5, "n": -12.0},
    ],
    # drone gates: heading_deg = compass direction you fly through them (0 = north, 90 = east)
    "gates": [
        {"name": "gate_1", "e": 0.0, "n": 20.0, "heading_deg": 0.0, "width_m": 4.0, "height_m": 3.0},
        {"name": "gate_2", "e": 8.0, "n": 34.0, "heading_deg": 20.0, "width_m": 4.0, "height_m": 3.0},
        {"name": "gate_3", "e": 0.0, "n": 48.0, "heading_deg": -20.0, "width_m": 4.0, "height_m": 3.0},
    ],
    # obstacles near (not on) the road, for the rover's range sensors later
    "obstacles": [
        {"name": "box_1", "type": "box", "e": 30.0, "n": -45.0, "size_m": [2.0, 2.0, 2.0], "yaw_deg": 15.0},
        {"name": "box_2", "type": "box", "e": -40.0, "n": -64.5, "size_m": [3.0, 1.0, 1.5], "yaw_deg": 0.0},
        {"name": "box_3", "type": "box", "e": 60.0, "n": 20.0, "size_m": [1.5, 1.5, 3.0], "yaw_deg": 40.0},
        {"name": "pole_1", "type": "cylinder", "e": -60.0, "n": 0.0, "radius_m": 0.3, "height_m": 4.0},
        {"name": "pole_2", "type": "cylinder", "e": -79.0, "n": 30.0, "radius_m": 0.5, "height_m": 6.0},
        {"name": "pole_3", "type": "cylinder", "e": 20.0, "n": 72.0, "radius_m": 0.4, "height_m": 5.0},
    ],
}


# ---------------------------------------------------------------- helpers
def blur(a, sigma_px):
    """Separable Gaussian blur with reflect padding (numpy only)."""
    r = int(3 * sigma_px) + 1
    x = np.arange(-r, r + 1, dtype=float)
    k = np.exp(-0.5 * (x / sigma_px) ** 2)
    k /= k.sum()
    p = np.pad(a, r, mode="reflect")
    p = np.apply_along_axis(lambda v: np.convolve(v, k, mode="valid"), 0, p)
    p = np.apply_along_axis(lambda v: np.convolve(v, k, mode="valid"), 1, p)
    return p


def normalize(a):
    return (a - a.min()) / (a.max() - a.min())


def smoothstep(edge0, edge1, x):
    t = np.clip((x - edge0) / (edge1 - edge0), 0.0, 1.0)
    return t * t * (3 - 2 * t)


def dist_to_polyline(E, N, pts):
    """Distance from every grid point (E, N arrays) to a polyline (list of [e, n])."""
    d = np.full(E.shape, np.inf)
    for (ea, na), (eb, nb) in zip(pts[:-1], pts[1:]):
        de, dn = eb - ea, nb - na
        L2 = de * de + dn * dn
        t = np.clip(((E - ea) * de + (N - na) * dn) / L2, 0.0, 1.0)
        d = np.minimum(d, np.hypot(E - (ea + t * de), N - (na + t * dn)))
    return d


# ---------------------------------------------------------------- terrain
def make_heights(size_px, mpp, seed, height_range_m):
    rng = np.random.default_rng(seed)
    half = (size_px - 1) / 2
    idx = np.arange(size_px, dtype=float)
    # ENU coordinates of every pixel center: column -> east, row -> north (row 0 = north edge)
    E = (idx[None, :] - half) * mpp
    N = (half - idx[:, None]) * mpp
    E, N = np.broadcast_arrays(E, N)

    n_big = normalize(blur(rng.standard_normal((size_px, size_px)), 14 / mpp))
    n_mid = normalize(blur(rng.standard_normal((size_px, size_px)), 5 / mpp))
    n_small = normalize(blur(rng.standard_normal((size_px, size_px)), 1.5 / mpp))

    # 1) valley floor: rolling ground, flat near the center, up to ~3.5 m further out
    r = np.hypot(E, N)
    floor_amp = 0.3 + 3.2 * smoothstep(15, 70, r)
    h = floor_amp * (0.75 * n_big + 0.25 * n_mid) + 0.15 * n_small

    # 2) hills along the border (box distance), so the range has a visible edge
    d_box = np.maximum(np.abs(E), np.abs(N))
    h += smoothstep(92, 126, d_box) * (6.0 + 10.0 * n_big + 2.0 * n_mid)

    # 3) roads: blend toward a heavily smoothed copy -> gentle grades, near-flat cross-section
    h_smooth = blur(h, 10 / mpp)
    half_w = LAYOUT["road_width_m"] / 2
    for road in LAYOUT["roads"]:
        d = dist_to_polyline(E, N, road["points"])
        w = 1.0 - smoothstep(half_w + 1.0, half_w + 6.0, d)
        h = h * (1 - w) + h_smooth * w

    # 4) apron + pad: exactly 0 m, blended out over 8 m
    a = APRON
    de = np.maximum(np.maximum(a["e_min"] - E, E - a["e_max"]), 0)
    dn = np.maximum(np.maximum(a["n_min"] - N, N - a["n_max"]), 0)
    w = 1.0 - smoothstep(0.0, 8.0, np.hypot(de, dn))
    h = h * (1 - w)

    return np.clip(h, 0.0, height_range_m)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--size", type=int, default=257, help="pixels per side, 2^k + 1")
    ap.add_argument("--mpp", type=float, default=1.0, help="meters per pixel")
    ap.add_argument("--range", dest="height_range", type=float, default=20.0, help="height range in m")
    ap.add_argument("--out", default="data/terrain")
    ap.add_argument("--r16", action="store_true",
                    help="also write heightmap.r16 (raw little-endian uint16) for the optional Terrain3D importer")
    args = ap.parse_args()
    if (args.size - 1) & (args.size - 2):
        raise SystemExit("size must be 2^k + 1 (e.g. 129, 257, 513)")

    h = make_heights(args.size, args.mpp, args.seed, args.height_range)
    min_h = 0.0
    values = np.round((h - min_h) / args.height_range * 65535).astype(np.uint16)

    os.makedirs(args.out, exist_ok=True)
    png = os.path.join(args.out, "heightmap.png")
    Image.fromarray(values).save(png)          # uint16 array -> 16-bit grayscale PNG
    meta = {"size_px": args.size, "meters_per_px": args.mpp, "min_height_m": min_h,
            "height_range_m": args.height_range, "seed": args.seed, "origin": "center"}
    with open(os.path.join(args.out, "heightmap.json"), "w") as f:
        json.dump(meta, f, indent=2)
    with open(os.path.join(args.out, "range.json"), "w") as f:
        json.dump(LAYOUT, f, indent=2)
    if args.r16:   # same pixels, same row order (row 0 = north); not part of the shared contract
        values.astype("<u2").tofile(os.path.join(args.out, "heightmap.r16"))

    hm = min_h + values.astype(float) / 65535 * args.height_range
    c = args.size // 2
    print(f"wrote {png} ({args.size}x{args.size}, seed {args.seed})")
    print(f"height min {hm.min():.3f} m  max {hm.max():.3f} m  center {hm[c, c]:.3f} m")


if __name__ == "__main__":
    main()
