# Module 2 reference code

The `robosim/` files as they stand after Lab 2. Paths mirror the project:

```
tools/make_heightmap.py          seeded terrain + range layout generator (numpy, Pillow); --r16 for Terrain3D
tools/compare_heights.py         runs Godot headless and compares heights with the Python sampler
data/terrain/                    the generated files for seed 42 (heightmap.png 16-bit, heightmap.json, range.json)
physics/robosim/terrain.py       Heightmap: load(), height_at(e, n) bilinear ENU, height_at_godot(x, z), normal_at()
physics/tests/test_terrain.py    determinism, 16-bit, mapping, apron, road cross-slope
godot/project.godot              Module 1 settings + layer names (1 terrain, 2 obstacles, 3 vehicles, 4 gates)
godot/main.tscn, main.gd         range viewer: terrain, range, four parked vehicles, cameras, status, pause/reset
godot/cameras/*.gd               unchanged from Module 1
godot/world/axis_marker.gd       unchanged from Module 1
godot/terrain/png16.gd           16-bit grayscale PNG reader (Godot's Image loader drops to 8 bits)
godot/terrain/heightmap_terrain.gd  @tool: ArrayMesh + HeightMapShape3D, height_at(), raycast_height()
godot/world/range_builder.gd     @tool: roads, pad, gates, obstacles, reference boxes from range.json
godot/vehicles/vehicle.gd        Vehicle class: vehicle_id, kind, rest_height_m, mount(), place_on_ground()
godot/vehicles/build_vehicles.gd generator for the four vehicle scenes (deterministic output)
godot/vehicles/*.tscn            generated: rover (1), quad (2), plane (3), quadplane (4)
godot/tests/test_m02.gd          acceptance test; prints HEIGHT lines; --shots=DIR renders views
```

`godot/bridge/` (from 00 Setup) is not repeated here.

## Run (from `robosim/`)

```bash
python tools/make_heightmap.py                              # -> data/terrain/ (already included for seed 42)
(cd physics && python tests/test_terrain.py)
cd godot
~/tools/godot --headless --path . --import
~/tools/godot --headless --path . -s vehicles/build_vehicles.gd   # regenerates the four .tscn (identical bytes)
~/tools/godot --headless --path . -s tests/test_m02.gd
cd .. && python tools/compare_heights.py --godot ~/tools/godot
# screenshots without a display:
cd godot && xvfb-run -a -s "-screen 0 1280x720x24" ~/tools/godot --path . --rendering-driver opengl3 \
    -s tests/test_m02.gd -- --shots=/tmp/range
```

## What was verified (Godot 4.7.2-stable, Python 3.11, numpy 2.4.4, Pillow 12.2.0, Linux)

- `make_heightmap.py`: two runs with seed 42 give byte-identical PNG, json and range.json. Seed 7 gives a different terrain. Heights: min 0.000 m, max 18.958 m, center 0.000 m. `--r16` writes the same pixel values as raw little-endian uint16 (compared in numpy).
- `test_terrain.py` passes: 16-bit mode, the json keys of the terrain contract, corner and center pixel mapping, exact values at pixel centers and midpoints, clamping, array input, apron and parking spots at 0 m, and worst road cross-height 0.218 m over 5 m.
- `png16.gd`: zero mismatches against Python on a synthetic 16-bit PNG that uses all five PNG filter types, and on the real 257 × 257 heightmap. Read time about 92 ms. Godot's own `Image.load_from_file()` was confirmed to return `FORMAT_L8` for this file (values rounded to 8 bits).
- `HeightMapShape3D` triangulation: over 20 000 random vertical rays, the raycast height matches NE–SW-split triangles within 0.17 mm (NW–SE would be off by up to 235 mm). The render mesh uses the same split. Raycast vs bilinear: max 4.5 mm in the valley (|E|, |N| < 90 m) and 133 mm on the steep border hills.
- `test_m02.gd`: 40 checks pass, headless and under xvfb (OpenGL). Terrain load + build: 131–134 ms headless.
- `compare_heights.py` at (37.3, −12.6), (−55.5, 41.2), (101.7, −88.3): Godot lookup − Python = 0.000 mm, raycast − Python = +0.37, +0.32, −0.31 mm. Also at (0, 0), (−127.9, 127.9), (64.25, −30.75), (12.5, 99.1): lookup 0.000 mm, raycast within 0.4 mm.
- `build_vehicles.gd`: two consecutive runs give identical `md5sum`s for all four scenes. The scenes load without errors and are instanced in `main.tscn`.
- Screenshots in `../img/` were rendered by `test_m02.gd --shots` under xvfb and checked by eye. They show the terrain, the road loop with markings, the gates north of the pad, the obstacles beside the road, the four vehicles nose-north with their 1 m boxes, and the plane's green right tip and red left tip.

## Not tested here

- **Terrain3D** (optional path). Its v1.0.2 release notes cover Godot 4.4–4.6 and do not confirm 4.7. The `--r16` export and the import advice in `04_terrain_heightmap.md` were not run against Terrain3D.
- **glTF import** of a real model. The text describes it, but the tests use primitive meshes only.
- **PyBullet heightfield** cross-check. It is deferred to Module 9.
- Interactive mouse and keyboard use and editor workflows (assigning the `terrain` export, dragging instances). The resulting files were tested, not the clicks.
