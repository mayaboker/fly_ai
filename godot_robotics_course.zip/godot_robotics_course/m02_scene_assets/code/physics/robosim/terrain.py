"""
terrain.py - load the shared heightmap and sample it in ENU (Module 2).

Contract: reference/terrain.md
  h(pixel)   = min_height_m + value / 65535 * height_range_m
  ENU -> px  col = (N-1)/2 + E / mpp,   row = (N-1)/2 - North / mpp   (row 0 = north edge)
  between pixels: bilinear interpolation

    from robosim.terrain import Heightmap
    hm = Heightmap.load("../data/terrain/heightmap.png")   # json next to the png
    hm.height_at(10.0, -5.0)          # ENU east, north -> meters
    hm.height_at_godot(10.0, 5.0)     # Godot x, z  -> same point
"""
import json
import os

import numpy as np


class Heightmap:
    def __init__(self, heights, meters_per_px=1.0, meta=None):
        self.h = np.asarray(heights, dtype=float)        # [row, col], meters
        if self.h.ndim != 2 or self.h.shape[0] != self.h.shape[1]:
            raise ValueError("heightmap must be square")
        self.size_px = self.h.shape[0]
        self.mpp = float(meters_per_px)
        self.half_px = (self.size_px - 1) / 2.0
        self.size_m = (self.size_px - 1) * self.mpp      # 256 m by default
        self.meta = meta or {}

    @classmethod
    def load(cls, png_path, json_path=None):
        """Read the 16-bit PNG and its json. Never let an 8-bit loader touch it."""
        from PIL import Image
        json_path = json_path or os.path.splitext(png_path)[0] + ".json"
        with open(json_path) as f:
            meta = json.load(f)
        img = Image.open(png_path)
        if img.mode not in ("I;16", "I;16B", "I"):
            raise ValueError(f"{png_path}: expected 16-bit grayscale, got mode {img.mode}")
        values = np.array(img, dtype=np.float64)
        if values.shape != (meta["size_px"], meta["size_px"]):
            raise ValueError(f"size mismatch: png {values.shape}, json {meta['size_px']}")
        h = meta["min_height_m"] + values / 65535.0 * meta["height_range_m"]
        return cls(h, meta["meters_per_px"], meta)

    # ---- coordinates
    def enu_to_pixel(self, e, n):
        """ENU meters -> fractional (col, row)."""
        return self.half_px + e / self.mpp, self.half_px - n / self.mpp

    def pixel_to_enu(self, col, row):
        return (col - self.half_px) * self.mpp, (self.half_px - row) * self.mpp

    def contains(self, e, n):
        lim = self.size_m / 2
        return -lim <= e <= lim and -lim <= n <= lim

    # ---- sampling
    def height_at(self, e, n):
        """Bilinear height (m) at ENU (e, n). Points outside the map are clamped to the edge.
        Works on scalars and on numpy arrays of the same shape."""
        col, row = self.enu_to_pixel(np.asarray(e, float), np.asarray(n, float))
        col = np.clip(col, 0.0, self.size_px - 1.0)
        row = np.clip(row, 0.0, self.size_px - 1.0)
        c0 = np.minimum(np.floor(col).astype(int), self.size_px - 2)
        r0 = np.minimum(np.floor(row).astype(int), self.size_px - 2)
        fc, fr = col - c0, row - r0
        h = self.h
        top = h[r0, c0] * (1 - fc) + h[r0, c0 + 1] * fc
        bot = h[r0 + 1, c0] * (1 - fc) + h[r0 + 1, c0 + 1] * fc
        out = top * (1 - fr) + bot * fr
        return float(out) if np.ndim(out) == 0 else out

    def height_at_godot(self, x, z):
        """Same point given in Godot world coordinates: x = east, z = -north."""
        return self.height_at(x, -np.asarray(z, float))

    def normal_at(self, e, n, d=0.5):
        """Unit surface normal in ENU from central differences (useful later for spawn poses)."""
        dhde = (self.height_at(e + d, n) - self.height_at(e - d, n)) / (2 * d)
        dhdn = (self.height_at(e, n + d) - self.height_at(e, n - d)) / (2 * d)
        v = np.array([-dhde, -dhdn, 1.0])
        return v / np.linalg.norm(v)
