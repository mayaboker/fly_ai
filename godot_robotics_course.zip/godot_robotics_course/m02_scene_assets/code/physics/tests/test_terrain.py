"""
test_terrain.py - checks for the shared heightmap and robosim/terrain.py (Module 2).
Run from robosim/physics:   python tests/test_terrain.py   (or: python -m pytest tests/test_terrain.py)
"""
import json
import os
import subprocess
import sys
import tempfile

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PHYSICS = os.path.dirname(HERE)                       # robosim/physics
ROOT = os.path.dirname(PHYSICS)                       # robosim
sys.path.insert(0, PHYSICS)
from robosim.terrain import Heightmap  # noqa: E402

MAKE = os.path.join(ROOT, "tools", "make_heightmap.py")


def generate(out_dir, seed=42):
    subprocess.run([sys.executable, MAKE, "--seed", str(seed), "--out", out_dir],
                   check=True, capture_output=True)
    return Heightmap.load(os.path.join(out_dir, "heightmap.png"))


def check_contract(hm, out_dir):
    meta = json.load(open(os.path.join(out_dir, "heightmap.json")))
    assert set(meta) == {"size_px", "meters_per_px", "min_height_m", "height_range_m", "seed", "origin"}, meta
    assert meta["size_px"] == 257 and meta["origin"] == "center"
    assert hm.size_m == 256.0
    from PIL import Image
    assert Image.open(os.path.join(out_dir, "heightmap.png")).mode == "I;16", "must be 16-bit"


def check_mapping(hm):
    # center pixel is ENU (0, 0); row 0 is the north edge; columns grow to the east
    assert hm.enu_to_pixel(0, 0) == (128, 128)
    assert hm.enu_to_pixel(128, 128) == (256, 0)          # north-east corner: last column, first row
    assert hm.enu_to_pixel(-128, -128) == (0, 256)        # south-west corner
    # at pixel centers the sample is the pixel itself
    for col, row in [(0, 0), (256, 0), (17, 200), (128, 128), (256, 256)]:
        e, n = hm.pixel_to_enu(col, row)
        assert abs(hm.height_at(e, n) - hm.h[row, col]) < 1e-12
    # halfway between two pixels: the mean of the two
    e, n = hm.pixel_to_enu(40.5, 90)
    assert abs(hm.height_at(e, n) - 0.5 * (hm.h[90, 40] + hm.h[90, 41])) < 1e-12
    # Godot form: x = east, z = -north
    assert hm.height_at_godot(37.3, 12.6) == hm.height_at(37.3, -12.6)
    # outside the map: clamped to the edge
    assert hm.height_at(500, 0) == hm.height_at(128, 0)
    # arrays work too
    out = hm.height_at(np.array([0.0, 10.0]), np.array([0.0, -5.0]))
    assert out.shape == (2,)


def check_layout(hm, out_dir):
    lay = json.load(open(os.path.join(out_dir, "range.json")))
    assert abs(hm.height_at(0, 0)) < 1e-9, "pad center must be at 0 m"
    for spot in lay["lineup"]:                            # parking spots are on the flat apron
        assert hm.height_at(spot["e"], spot["n"]) < 1e-6, spot
    # roads: gentle cross-slope (left vs right edge differ by < 0.3 m on a 5 m road)
    worst = 0.0
    for road in lay["roads"]:
        p = np.array(road["points"])
        d = np.diff(p, axis=0)
        mid = p[:-1] + d / 2
        left = np.stack([-d[:, 1], d[:, 0]], 1) / np.linalg.norm(d, axis=1)[:, None]
        a = hm.height_at(*(mid + 2.5 * left).T)
        b = hm.height_at(*(mid - 2.5 * left).T)
        worst = max(worst, float(np.max(np.abs(a - b))))
    assert worst < 0.3, worst
    return worst


def main():
    with tempfile.TemporaryDirectory() as t1, tempfile.TemporaryDirectory() as t2:
        hm = generate(t1)
        generate(t2)
        same = all(open(os.path.join(t1, f), "rb").read() == open(os.path.join(t2, f), "rb").read()
                   for f in ("heightmap.png", "heightmap.json", "range.json"))
        assert same, "same seed must give byte-identical files"
        other = generate(t2, seed=7)
        assert not np.array_equal(other.h, hm.h), "a different seed must change the terrain"
        check_contract(hm, t1)
        check_mapping(hm)
        slope = check_layout(hm, t1)
    print("terrain: all tests pass (seeded, 16-bit, center origin, row 0 = north, bilinear); "
          f"worst road cross-height {slope:.3f} m")


def test_terrain_all():          # pytest entry point
    main()


if __name__ == "__main__":
    main()
