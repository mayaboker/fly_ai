@tool
class_name RangeBuilder
extends Node3D
## Builds the static test range from data/terrain/range.json (written by tools/make_heightmap.py):
## roads with markings, landing pad, drone gates, obstacles, and a 1 m reference box next to
## each vehicle parking spot. Everything sits on the terrain (heights from HeightmapTerrain).
##
## range.json is in ENU meters (e = east, n = north). Godot position = (e, h, -n).
## Compass heading psi (0 = north, 90 = east) -> rotation.y = -psi.
##
## Collision layers (Project Settings > Layer Names > 3D Physics):
##   1 terrain, 2 obstacles (boxes, poles, pad), 3 vehicles, 4 gates

@export var terrain: HeightmapTerrain
@export var layout_path := "../data/terrain/range.json"   ## relative to the Godot project folder

const LAYER_OBSTACLES := 1 << 1
const LAYER_GATES := 1 << 3
const ROAD_LIFT := 0.05          ## m above the sampled terrain, so the road never z-fights
const MARK_LIFT := 0.07

var layout := {}
var _mats := {}


func _ready() -> void:
	if terrain and terrain.size_px == 0:
		await terrain.terrain_built          # terrain not loaded yet: wait for it
	build()


func build() -> void:
	for c in get_children():
		if c.has_meta("range_part"):
			c.free()
	if terrain == null or terrain.size_px == 0:
		push_error("RangeBuilder: set the terrain property to a loaded HeightmapTerrain")
		return
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(HeightmapTerrain.resolve_path(layout_path)))
	if typeof(parsed) != TYPE_DICTIONARY:
		push_error("RangeBuilder: cannot read %s" % layout_path)
		return
	layout = parsed
	var roads := _group_node("Roads")
	for road in layout.roads:
		_build_road(roads, road)
	_build_pad(_group_node("Pad"), layout.pad)
	var gates := _group_node("Gates")
	for g in layout.gates:
		_build_gate(gates, g)
	var obstacles := _group_node("Obstacles")
	for o in layout.obstacles:
		_build_obstacle(obstacles, o)
	var refs := _group_node("RefBoxes")
	for spot in layout.lineup:
		_build_ref_box(refs, spot)


## ENU (east, north) -> Godot point on the terrain surface, lifted by dy.
func ground(e: float, n: float, dy := 0.0) -> Vector3:
	return Vector3(e, terrain.height_at(e, n) + dy, -n)


# ---------------------------------------------------------------- roads

func _build_road(parent: Node3D, road: Dictionary) -> void:
	var node := Node3D.new()
	node.name = road.name
	parent.add_child(node)
	var s := _resample(road.points, 1.0)
	var w: float = layout.road_width_m
	_ribbon(node, "Surface", s, 0.0, w, ROAD_LIFT, 0.0, 0.0, _mat(Color(0.22, 0.22, 0.24)))
	var white := _mat(Color(0.95, 0.95, 0.95))
	_ribbon(node, "EdgeLeft", s, w / 2.0 - 0.25, 0.12, MARK_LIFT, 0.0, 0.0, white)
	_ribbon(node, "EdgeRight", s, -(w / 2.0 - 0.25), 0.12, MARK_LIFT, 0.0, 0.0, white)
	_ribbon(node, "CenterDash", s, 0.0, 0.15, MARK_LIFT, 3.0, 3.0, _mat(Color(0.95, 0.8, 0.2)))


## Polyline (ENU [e, n] pairs) -> samples every `step` m: {p: Vector2, left: Vector2, s: distance}
func _resample(points: Array, step: float) -> Array:
	var out := []
	var dist := 0.0
	for i in points.size() - 1:
		var a := Vector2(points[i][0], points[i][1])
		var b := Vector2(points[i + 1][0], points[i + 1][1])
		var seg := a.distance_to(b)
		if seg < 1e-6:
			continue
		var dir := (b - a) / seg
		var t := 0.0
		while t < seg:
			out.append({"p": a + dir * t, "dir": dir, "s": dist + t})
			t += step
		dist += seg
	var last := Vector2(points[-1][0], points[-1][1])
	out.append({"p": last, "dir": out[-1].dir, "s": dist})
	# smooth the direction at corners: average of neighbors; left = direction turned +90 deg (ENU)
	for i in out.size():
		var d: Vector2 = out[maxi(i - 1, 0)].dir + out[i].dir
		out[i].left = Vector2(-d.y, d.x).normalized()
	return out


## A flat strip that follows the terrain: centered `offset` m to the left of the centerline.
## dash_on > 0 draws dashes (dash_on m on, dash_off m off).
func _ribbon(parent: Node3D, node_name: String, samples: Array, offset: float, width: float,
		lift: float, dash_on: float, dash_off: float, mat: Material) -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in samples.size() - 1:
		var a: Dictionary = samples[i]
		var b: Dictionary = samples[i + 1]
		if dash_on > 0.0 and fmod(a.s, dash_on + dash_off) >= dash_on:
			continue
		var l0 := _surf(a.p + a.left * (offset + width / 2.0), lift)
		var r0 := _surf(a.p + a.left * (offset - width / 2.0), lift)
		var l1 := _surf(b.p + b.left * (offset + width / 2.0), lift)
		var r1 := _surf(b.p + b.left * (offset - width / 2.0), lift)
		for v in [l1, r1, r0, l1, r0, l0]:       # clockwise seen from above = front face up
			st.set_normal(Vector3.UP)
			st.add_vertex(v)
	var mi := MeshInstance3D.new()
	mi.name = node_name
	mi.mesh = st.commit()
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)


func _surf(p: Vector2, lift: float) -> Vector3:
	return ground(p.x, p.y, lift)


# ---------------------------------------------------------------- pad, gates, obstacles

func _build_pad(parent: Node3D, pad: Dictionary) -> void:
	parent.position = ground(pad.e, pad.n)
	var r: float = pad.radius_m
	var disk := CylinderMesh.new()
	disk.top_radius = r
	disk.bottom_radius = r
	disk.height = 0.1
	_mesh(parent, "Disk", disk, Vector3(0, 0.05, 0), _mat(Color(0.25, 0.3, 0.35)))
	var ring := TorusMesh.new()
	ring.inner_radius = r - 0.45
	ring.outer_radius = r - 0.15
	var ring_mi := _mesh(parent, "Ring", ring, Vector3(0, 0.1, 0), _mat(Color(0.95, 0.8, 0.2)))
	ring_mi.scale = Vector3(1, 0.1, 1)
	var white := _mat(Color(0.95, 0.95, 0.95))
	for x in [-0.9, 0.9]:                        # the "H", readable from the south (-Z is north)
		_mesh(parent, "H_bar", _box_mesh(Vector3(0.4, 0.02, 2.6)), Vector3(x, 0.11, 0), white)
	_mesh(parent, "H_cross", _box_mesh(Vector3(1.4, 0.02, 0.4)), Vector3(0, 0.11, 0), white)
	var shape := CylinderShape3D.new()
	shape.radius = r
	shape.height = 0.1
	_static_body(parent, LAYER_OBSTACLES, [[shape, Vector3(0, 0.05, 0)]])


func _build_gate(parent: Node3D, g: Dictionary) -> void:
	var gate := Node3D.new()
	gate.name = g.name
	gate.position = ground(g.e, g.n)
	gate.rotation.y = -deg_to_rad(g.heading_deg)  # fly through along the gate's -Z
	gate.add_to_group("gates", true)
	parent.add_child(gate)
	var w: float = g.width_m
	var h: float = g.height_m
	var orange := _mat(Color(1.0, 0.45, 0.1))
	var shapes := []
	for side in [-1, 1]:
		var size := Vector3(0.2, h + 0.2, 0.2)
		var pos := Vector3(side * (w / 2.0 + 0.1), (h + 0.2) / 2.0, 0)
		_mesh(gate, "Post", _box_mesh(size), pos, orange)
		shapes.append([_box_shape(size), pos])
	var bar := Vector3(w + 0.4, 0.2, 0.2)
	_mesh(gate, "Bar", _box_mesh(bar), Vector3(0, h + 0.1, 0), orange)
	shapes.append([_box_shape(bar), Vector3(0, h + 0.1, 0)])
	_static_body(gate, LAYER_GATES, shapes)
	var label := Label3D.new()
	label.text = String(g.name).replace("gate_", "")
	label.font_size = 96
	label.pixel_size = 0.01
	label.outline_size = 16
	label.position = Vector3(0, h + 0.8, 0)
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	gate.add_child(label)


func _build_obstacle(parent: Node3D, o: Dictionary) -> void:
	var node := Node3D.new()
	node.name = o.name
	node.add_to_group("obstacles", true)
	parent.add_child(node)
	var e: float = o.e
	var n: float = o.n
	var shape: Shape3D
	var height: float
	var mesh: Mesh
	var footprint := 0.0                          # half-diagonal, to find the lowest ground under it
	if o.type == "box":
		var size := Vector3(o.size_m[0], o.size_m[2], o.size_m[1])   # [east, north, up] -> Godot (x, y, z)
		mesh = _box_mesh(size)
		shape = _box_shape(size)
		height = size.y
		footprint = Vector2(size.x, size.z).length() / 2.0
		node.rotation.y = -deg_to_rad(o.get("yaw_deg", 0.0))
	else:
		var cyl := CylinderMesh.new()
		cyl.top_radius = o.radius_m
		cyl.bottom_radius = o.radius_m
		cyl.height = o.height_m
		mesh = cyl
		var cs := CylinderShape3D.new()
		cs.radius = o.radius_m
		cs.height = o.height_m
		shape = cs
		height = o.height_m
		footprint = o.radius_m
	# sit on the lowest terrain point under the footprint, so no corner floats
	var low := terrain.height_at(e, n)
	for d in [Vector2(1, 1), Vector2(1, -1), Vector2(-1, 1), Vector2(-1, -1)]:
		low = minf(low, terrain.height_at(e + d.x * footprint, n + d.y * footprint))
	node.position = Vector3(e, low, -n)
	var color := Color(0.55, 0.5, 0.45) if o.type == "box" else Color(0.9, 0.2, 0.2)
	_mesh(node, "Mesh", mesh, Vector3(0, height / 2.0, 0), _mat(color))
	_static_body(node, LAYER_OBSTACLES, [[shape, Vector3(0, height / 2.0, 0)]])


func _build_ref_box(parent: Node3D, spot: Dictionary) -> void:
	var e: float = spot.e + 1.8
	var n: float = spot.n
	var mi := _mesh(parent, "RefBox_%s" % spot.name, _box_mesh(Vector3.ONE), ground(e, n, 0.5),
			_mat(Color(0.95, 0.75, 0.2)))
	mi.set_meta("reference_box", true)
	var label := Label3D.new()
	label.text = "%d %s" % [spot.id, spot.name]
	label.font_size = 64
	label.pixel_size = 0.006
	label.outline_size = 12
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.position = ground(spot.e, spot.n, 1.4)
	parent.add_child(label)


# ---------------------------------------------------------------- small helpers

func _group_node(node_name: String) -> Node3D:
	var n := Node3D.new()
	n.name = node_name
	n.set_meta("range_part", true)
	add_child(n)
	return n


func _mesh(parent: Node3D, node_name: String, mesh: Mesh, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = mat
	parent.add_child(mi, true)               # true = readable unique names (H_bar, H_bar2, ...)
	return mi


func _static_body(parent: Node3D, layer: int, shapes: Array) -> void:
	var body := StaticBody3D.new()
	body.name = "Body"
	body.collision_layer = layer
	body.collision_mask = 0
	for s in shapes:
		var cs := CollisionShape3D.new()
		cs.shape = s[0]
		cs.position = s[1]
		body.add_child(cs, true)
	parent.add_child(body)


func _box_mesh(size: Vector3) -> BoxMesh:
	var m := BoxMesh.new()
	m.size = size
	return m


func _box_shape(size: Vector3) -> BoxShape3D:
	var s := BoxShape3D.new()
	s.size = size
	return s


func _mat(color: Color) -> StandardMaterial3D:
	var key := color.to_html()
	if not _mats.has(key):
		var m := StandardMaterial3D.new()
		m.albedo_color = color
		m.roughness = 0.85
		_mats[key] = m
	return _mats[key]
