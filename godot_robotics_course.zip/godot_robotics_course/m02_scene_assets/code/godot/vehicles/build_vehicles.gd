extends SceneTree
## Generates the four placeholder vehicle scenes from code and saves them as .tscn:
##   vehicles/rover.tscn (id 1), quad.tscn (id 2), plane.tscn (id 3), quadplane.tscn (id 4)
##
## Run from the godot/ folder, then commit the .tscn files (they are plain text and diff well):
##   godot --headless --path . -s vehicles/build_vehicles.gd
##
## Model frame: x = right, y = up, z = back (nose at -Z). Sizes match the JSBSim models
## from reference/code/aircraft. JSBSim structural offsets from the CG map to this frame as
##   model (x, y, z) = structural (y, z, x)   (structural: x aft, y right, z up)

const VehicleScript := preload("res://vehicles/vehicle.gd")
const LAYER_VEHICLES := 1 << 2            # layer 3 "vehicles" (see Project Settings > Layer Names)

var _materials := {}


func _initialize() -> void:
	for v in [_rover(), _quad(), _plane(), _quadplane()]:
		_save(v)
	quit()


# ---------------------------------------------------------------- vehicles

func _rover() -> Node3D:
	var v := _root("Rover", 1, "rover", 0.25)            # wheel bottoms are 0.25 m below the origin
	var vis := v.get_node("Visual")
	_box(vis, "Chassis", Vector3(0.6, 0.2, 0.9), Vector3.ZERO, Color(0.85, 0.5, 0.15))
	_box(vis, "Bumper", Vector3(0.6, 0.08, 0.06), Vector3(0, -0.02, -0.48), Color(0.8, 0.1, 0.1))   # red = front
	_box(vis, "Mast", Vector3(0.04, 0.2, 0.04), Vector3(0, 0.2, -0.38), Color(0.2, 0.2, 0.2))
	for side in [-1, 1]:
		for fb in [-1, 1]:
			var w := _cyl(vis, "Wheel_%s%s" % ["F" if fb < 0 else "B", "L" if side < 0 else "R"],
					0.15, 0.1, Vector3(0.36 * side, -0.1, 0.3 * fb), Color(0.12, 0.12, 0.12))
			w.rotation = Vector3(0, 0, PI / 2)            # cylinder axis (local Y) along X
	_collision(v, Vector3(0.82, 0.5, 0.96), Vector3(0, -0.05, 0))
	_mounts(v, {
		"fpv_cam": [Vector3(0, 0.32, -0.4), 0.0],
		"down_cam": [Vector3(0, -0.1, -0.2), -90.0],
		"imu": [Vector3.ZERO, 0.0],
		"range": [Vector3(0, 0.0, -0.52), 0.0],           # rover: forward-looking range sensor
	})
	return v


func _quad() -> Node3D:
	var v := _root("Quad", 2, "quad", 0.08)               # legs 0.08 m below the CG (quad_rpy.xml)
	var vis := v.get_node("Visual")
	_box(vis, "Body", Vector3(0.12, 0.06, 0.2), Vector3.ZERO, Color(0.25, 0.25, 0.28))
	_box(vis, "NoseCam", Vector3(0.05, 0.04, 0.04), Vector3(0, 0.0, -0.12), Color(0.8, 0.1, 0.1))
	for sx in [-1, 1]:
		for sz in [-1, 1]:
			var front: bool = sz < 0
			var motor := Vector3(0.177 * sx, 0.0, 0.177 * sz)   # X layout, 0.5 m diagonal
			var arm := _box(vis, "Arm_%s%s" % ["F" if front else "B", "L" if sx < 0 else "R"],
					Vector3(0.025, 0.02, 0.25), motor / 2.0, Color(0.3, 0.3, 0.3))
			arm.rotation.y = atan2(motor.x, motor.z)       # point the arm from center to motor
			_cyl(vis, "Rotor_%s%s" % ["F" if front else "B", "L" if sx < 0 else "R"], 0.11, 0.008,
					motor + Vector3(0, 0.04, 0), Color(0.85, 0.15, 0.15) if front else Color(0.6, 0.6, 0.6))
			_contact(vis, Vector3(0.12 * sx, -0.08, 0.12 * sz))
	_collision(v, Vector3(0.6, 0.14, 0.6), Vector3(0, -0.01, 0))
	_mounts(v, {
		"fpv_cam": [Vector3(0, 0.0, -0.15), 0.0],
		"down_cam": [Vector3(0, -0.04, 0.0), -90.0],
		"imu": [Vector3.ZERO, 0.0],
		"range": [Vector3(0, -0.04, 0.05), -90.0],         # aircraft: downward rangefinder
	})
	return v


func _plane() -> Node3D:
	var v := _root("Plane", 3, "plane", 0.12)             # nose contact 0.12 m below the CG (trainer.xml)
	_airframe(v.get_node("Visual"), Color(0.92, 0.92, 0.9))
	_contact(v.get_node("Visual"), Vector3(0, -0.12, -0.35))
	_contact(v.get_node("Visual"), Vector3(0, -0.10, 0.6))
	_collision(v, Vector3(1.6, 0.3, 1.45), Vector3(0, 0.05, 0.12))
	_mounts(v, _aircraft_mounts())
	return v


func _quadplane() -> Node3D:
	var v := _root("QuadPlane", 4, "quadplane", 0.15)     # legs 0.15 m below the CG (quadplane.xml)
	var vis := v.get_node("Visual")
	_airframe(vis, Color(0.6, 0.78, 0.92))
	for sx in [-1, 1]:
		_box(vis, "LiftBoom_%s" % ("L" if sx < 0 else "R"), Vector3(0.03, 0.03, 0.9),
				Vector3(0.3 * sx, 0.05, 0.0), Color(0.3, 0.3, 0.3))
		for sz in [-1, 1]:
			var front: bool = sz < 0
			_cyl(vis, "LiftRotor_%s%s" % ["F" if front else "B", "L" if sx < 0 else "R"], 0.13, 0.008,
					Vector3(0.3 * sx, 0.09, 0.35 * sz), Color(0.85, 0.15, 0.15) if front else Color(0.6, 0.6, 0.6))
			_contact(vis, Vector3(0.3 * sx, -0.15, 0.35 * sz))
			_box(vis, "Leg_%s%s" % ["F" if front else "B", "L" if sx < 0 else "R"], Vector3(0.015, 0.2, 0.015),
					Vector3(0.3 * sx, -0.05, 0.35 * sz), Color(0.3, 0.3, 0.3))
	_collision(v, Vector3(1.6, 0.35, 1.45), Vector3(0, 0.0, 0.12))
	_mounts(v, _aircraft_mounts())
	return v


## Fuselage pod, high wing with colored tips, tail boom, tail, pusher prop.
## Wingtip colors follow aircraft navigation lights: right (+X) green, left (-X) red.
## They make bank angle readable from any view.
func _airframe(vis: Node3D, body_color: Color) -> void:
	_box(vis, "Pod", Vector3(0.12, 0.12, 0.7), Vector3(0, 0, -0.15), body_color)
	var nose := _cyl(vis, "Nose", 0.06, 0.12, Vector3(0, 0, -0.56), Color(0.8, 0.1, 0.1), 0.0)
	nose.rotation.x = -PI / 2                              # cone tip (local +Y) toward -Z
	_box(vis, "Wing", Vector3(1.6, 0.025, 0.25), Vector3(0, 0.07, -0.05), body_color)
	_box(vis, "WingTip_R", Vector3(0.04, 0.035, 0.25), Vector3(0.8, 0.07, -0.05), Color(0.1, 0.75, 0.2))
	_box(vis, "WingTip_L", Vector3(0.04, 0.035, 0.25), Vector3(-0.8, 0.07, -0.05), Color(0.85, 0.1, 0.1))
	_box(vis, "TailBoom", Vector3(0.03, 0.03, 0.75), Vector3(0, 0.11, 0.47), Color(0.3, 0.3, 0.3))
	_box(vis, "HStab", Vector3(0.5, 0.015, 0.12), Vector3(0, 0.11, 0.8), body_color)
	_box(vis, "VFin", Vector3(0.015, 0.18, 0.14), Vector3(0, 0.2, 0.8), Color(0.95, 0.75, 0.2))   # fin = top
	var prop := _cyl(vis, "Pusher", 0.09, 0.01, Vector3(0, 0, 0.25), Color(0.2, 0.2, 0.2))
	prop.rotation.x = PI / 2                               # disk faces along Z


func _aircraft_mounts() -> Dictionary:
	return {
		"fpv_cam": [Vector3(0, 0.03, -0.5), 0.0],
		"down_cam": [Vector3(0, -0.07, -0.25), -90.0],
		"imu": [Vector3.ZERO, 0.0],
		"range": [Vector3(0, -0.07, 0.0), -90.0],
	}


# ---------------------------------------------------------------- building blocks

func _root(node_name: String, id: int, kind: String, rest: float) -> Node3D:
	var v := Node3D.new()
	v.name = node_name
	v.set_script(VehicleScript)
	v.set("vehicle_id", id)
	v.set("kind", kind)
	v.set("rest_height_m", rest)
	var vis := Node3D.new()
	vis.name = "Visual"
	v.add_child(vis)
	var mounts := Node3D.new()
	mounts.name = "Mounts"
	v.add_child(mounts)
	return v


func _mat(color: Color) -> StandardMaterial3D:
	var key := color.to_html()
	if not _materials.has(key):
		var m := StandardMaterial3D.new()
		m.albedo_color = color
		m.roughness = 0.7
		m.resource_scene_unique_id = "mat_" + key   # fixed ids -> regenerating gives identical files
		_materials[key] = m
	return _materials[key]


func _box(parent: Node, node_name: String, size: Vector3, pos: Vector3, color: Color) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh.material = _mat(color)
	return _mesh(parent, node_name, mesh, pos)


## Cylinder along local +Y. top_radius 0 makes a cone.
func _cyl(parent: Node, node_name: String, radius: float, height: float, pos: Vector3, color: Color,
		top_radius := -1.0) -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.bottom_radius = radius
	mesh.top_radius = radius if top_radius < 0.0 else top_radius
	mesh.height = height
	mesh.radial_segments = 24
	mesh.material = _mat(color)
	return _mesh(parent, node_name, mesh, pos)


## Small gray ball at a physics contact point: the visual should touch the ground where physics does.
func _contact(parent: Node, pos: Vector3) -> void:
	var mesh := SphereMesh.new()
	mesh.radius = 0.02
	mesh.height = 0.04
	mesh.material = _mat(Color(0.5, 0.5, 0.5))
	_mesh(parent, "Contact_%d" % parent.get_child_count(), mesh, pos + Vector3(0, 0.02, 0))


func _mesh(parent: Node, node_name: String, mesh: Mesh, pos: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	mesh.resource_scene_unique_id = "mesh_" + node_name
	mi.mesh = mesh
	mi.position = pos
	parent.add_child(mi)
	return mi


func _collision(v: Node3D, size: Vector3, center: Vector3) -> void:
	var body := StaticBody3D.new()
	body.name = "Body"
	body.collision_layer = LAYER_VEHICLES
	body.collision_mask = 0                 # Godot physics never moves or pushes a vehicle
	var cs := CollisionShape3D.new()
	cs.name = "Shape"
	var shape := BoxShape3D.new()
	shape.size = size
	shape.resource_scene_unique_id = "body_shape"
	cs.shape = shape
	cs.position = center
	body.add_child(cs)
	v.add_child(body)


## mounts: name -> [position, pitch_deg]. pitch -90 turns the marker's -Z (its view axis) straight down,
## with its +Y (image up) toward the nose.
func _mounts(v: Node3D, mounts: Dictionary) -> void:
	for mount_name in mounts:
		var m := Marker3D.new()
		m.name = mount_name
		m.position = mounts[mount_name][0]
		m.rotation_degrees = Vector3(mounts[mount_name][1], 0, 0)
		m.gizmo_extents = 0.15
		v.get_node("Mounts").add_child(m)


func _save(v: Node3D) -> void:
	_own(v, v)                              # pack() only saves nodes owned by the root
	var scene := PackedScene.new()
	var err := scene.pack(v)
	var path := "res://vehicles/%s.tscn" % String(v.get("kind"))
	if err == OK:
		err = ResourceSaver.save(scene, path)
	if err == OK:
		_strip_unique_ids(path)
	print("%s -> %s (%s)" % [v.name, path, error_string(err)])
	v.free()


func _own(node: Node, owner_node: Node) -> void:
	for c in node.get_children():
		c.owner = owner_node
		_own(c, owner_node)


## Godot 4.7 writes a random unique_id on every node. Nothing in these scenes needs it, so
## remove it: then running this script twice gives byte-identical files and clean git diffs.
## (The editor adds the ids back the first time you save the scene there. That is harmless.)
func _strip_unique_ids(path: String) -> void:
	var text := FileAccess.get_file_as_string(path)
	var re := RegEx.create_from_string(" unique_id=\\d+")
	var f := FileAccess.open(path, FileAccess.WRITE)
	f.store_string(re.sub(text, "", true))
	f.close()
