class_name Vehicle
extends Node3D
## Root script of every vehicle scene (rover, quad, plane, quadplane).
##
## Conventions (reference/frames.md): nose toward -Z, top toward +Y, right wing toward +X.
## The node origin is the physics body origin (the CG). The Python physics process owns
## the motion; from Module 4 on, the bridge sets this node's transform. Nothing in Godot
## moves a vehicle by itself.
##
## Children every vehicle has:
##   Visual   meshes only
##   Body     StaticBody3D on layer 3 "vehicles", so Godot rays and sensors can hit it
##   Mounts   Marker3D sensor mounts: fpv_cam, down_cam, imu, range (each looks along its -Z)

@export var vehicle_id := 0               ## 1 rover, 2 quad, 3 plane, 4 quadplane (protocol ids)
@export var kind := ""                    ## "rover", "quad", "plane", "quadplane"
@export var rest_height_m := 0.0          ## origin height above flat ground when resting on it

const MOUNT_NAMES: Array[String] = ["fpv_cam", "down_cam", "imu", "range"]


func _ready() -> void:
	add_to_group("vehicles")


func mount(mount_name: String) -> Marker3D:
	return get_node("Mounts/" + mount_name) as Marker3D


## World-space direction a mount looks along (its -Z).
func mount_forward(mount_name: String) -> Vector3:
	return -mount(mount_name).global_basis.z


## Put the vehicle at rest on the ground at ENU (east, north), nose along compass heading_deg.
## Only for static placement in the editor and in tests; at run time the physics side owns this.
func place_on_ground(terrain: HeightmapTerrain, east: float, north: float, heading_deg := 0.0) -> void:
	position = Vector3(east, terrain.height_at(east, north) + rest_height_m, -north)
	rotation = Vector3(0.0, -deg_to_rad(heading_deg), 0.0)   # compass heading -> rotation about +Y
