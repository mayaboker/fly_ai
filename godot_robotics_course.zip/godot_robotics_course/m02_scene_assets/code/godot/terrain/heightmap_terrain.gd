@tool
class_name HeightmapTerrain
extends Node3D
## The FALLBACK terrain (no plugin needed): builds a render mesh and a HeightMapShape3D
## from the shared 16-bit heightmap (reference/terrain.md).
##
##   pixel (col, row)  ->  Godot (x, y, z) = ((col - c) * mpp, h, (row - c) * mpp),  c = (N - 1) / 2
##   row 0 is the north edge, and north is -Z, so the row index grows with +Z.
##
## height_at(e, n) samples bilinearly in ENU, exactly like robosim/terrain.py.
## @tool so the terrain is also visible in the editor. The generated children have no
## owner, so they are never written into the .tscn.

signal terrain_built

## PNG path. Relative paths are relative to the Godot project folder (robosim/godot),
## so the default points at robosim/data/terrain/heightmap.png. The json sits next to it.
@export var heightmap_path := "../data/terrain/heightmap.png"
@export_flags_3d_physics var collision_layer := 1     ## layer 1 = "terrain"
@export var grid_every_m := 10.0                      ## darker grid lines for scale; 0 = off
@export var build_collision := true

var size_px := 0
var meters_per_px := 1.0
var min_height_m := 0.0
var height_range_m := 0.0
var heights := PackedFloat32Array()   ## meters, row-major: index = row * size_px + col
var build_ms := 0.0                   ## how long load + build took (printed by the tests)
var _half := 0.0


func _ready() -> void:
	var t0 := Time.get_ticks_usec()
	if load_heightmap():
		_build()
	build_ms = (Time.get_ticks_usec() - t0) / 1000.0


## Absolute path of a project-relative, res:// or absolute path.
static func resolve_path(p: String) -> String:
	if p.begins_with("res://") or p.begins_with("user://"):
		return ProjectSettings.globalize_path(p)
	if p.is_absolute_path():
		return p
	return ProjectSettings.globalize_path("res://").path_join(p).simplify_path()


func load_heightmap() -> bool:
	var png_path := resolve_path(heightmap_path)
	var json_path := png_path.get_basename() + ".json"
	var meta = JSON.parse_string(FileAccess.get_file_as_string(json_path))
	if typeof(meta) != TYPE_DICTIONARY:
		push_error("HeightmapTerrain: cannot read %s (run tools/make_heightmap.py first)" % json_path)
		return false
	var png := Png16.read(png_path)
	if png.is_empty():
		return false
	size_px = int(meta.size_px)
	if png.width != size_px or png.height != size_px or png.bit_depth != 16:
		push_error("HeightmapTerrain: %s is %dx%d, %d bit; json says %d px, 16 bit" % [
				png_path, png.width, png.height, png.bit_depth, size_px])
		return false
	meters_per_px = float(meta.meters_per_px)
	min_height_m = float(meta.min_height_m)
	height_range_m = float(meta.height_range_m)
	_half = (size_px - 1) / 2.0
	heights.resize(size_px * size_px)
	var values: PackedInt32Array = png.values
	for i in values.size():
		heights[i] = min_height_m + values[i] / 65535.0 * height_range_m
	return true


# ---------------------------------------------------------------- sampling

## Bilinear height in meters at ENU (east, north). Outside the map: clamped to the edge.
func height_at(east: float, north: float) -> float:
	var col := clampf(_half + east / meters_per_px, 0.0, size_px - 1.0)
	var row := clampf(_half - north / meters_per_px, 0.0, size_px - 1.0)
	var c0 := mini(int(col), size_px - 2)
	var r0 := mini(int(row), size_px - 2)
	var fc := col - c0
	var fr := row - r0
	var i := r0 * size_px + c0
	var top := lerpf(heights[i], heights[i + 1], fc)
	var bot := lerpf(heights[i + size_px], heights[i + size_px + 1], fc)
	return lerpf(top, bot, fr)


## Same, for a point given in Godot world coordinates (x = east, z = -north).
func height_at_world(x: float, z: float) -> float:
	return height_at(x, -z)


## Ground height under (x, z) from the physics shape (needs one physics frame after _ready).
## Returns NAN when nothing is hit. Module 8 builds range sensors on exactly this call.
func raycast_height(x: float, z: float) -> float:
	var q := PhysicsRayQueryParameters3D.create(Vector3(x, 1000.0, z), Vector3(x, -1000.0, z), collision_layer)
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	return hit.position.y if hit else NAN


# ---------------------------------------------------------------- building

func _build() -> void:
	for c in get_children():
		if c.has_meta("terrain_part"):
			c.free()
	var mi := MeshInstance3D.new()
	mi.name = "Mesh"
	mi.mesh = _make_mesh()
	_add(mi)
	if build_collision:
		var body := StaticBody3D.new()
		body.name = "Collision"
		body.collision_layer = collision_layer
		body.collision_mask = 0                     # terrain never needs to detect anything
		var shape := HeightMapShape3D.new()
		shape.map_width = size_px                   # samples along X (columns)
		shape.map_depth = size_px                   # samples along Z (rows)
		shape.map_data = heights                    # same row-major order: index = z * width + x
		var cs := CollisionShape3D.new()
		cs.shape = shape
		if not is_equal_approx(meters_per_px, 1.0):
			cs.scale = Vector3(meters_per_px, 1.0, meters_per_px)   # the shape's spacing is 1 unit
		body.add_child(cs)
		_add(body)
	add_to_group("terrain")
	terrain_built.emit()


func _make_mesh() -> ArrayMesh:
	var n := size_px
	var verts := PackedVector3Array()
	var normals := PackedVector3Array()
	var colors := PackedColorArray()
	verts.resize(n * n)
	normals.resize(n * n)
	colors.resize(n * n)
	var grid_px := int(round(grid_every_m / meters_per_px)) if grid_every_m > 0.0 else 0
	for row in n:
		for col in n:
			var i := row * n + col
			var hgt := heights[i]
			verts[i] = Vector3((col - _half) * meters_per_px, hgt, (row - _half) * meters_per_px)
			# normal from central differences: (-dh/dx, 1, -dh/dz)
			var dx := (heights[row * n + mini(col + 1, n - 1)] - heights[row * n + maxi(col - 1, 0)]) / (2.0 * meters_per_px)
			var dz := (heights[mini(row + 1, n - 1) * n + col] - heights[maxi(row - 1, 0) * n + col]) / (2.0 * meters_per_px)
			var nrm := Vector3(-dx, 1.0, -dz).normalized()
			normals[i] = nrm
			var c := _ground_color(hgt, nrm.y)
			if grid_px > 0 and (int(col - _half) % grid_px == 0 or int(row - _half) % grid_px == 0):
				c = c.darkened(0.15)
			colors[i] = c
	# two triangles per cell, clockwise seen from above (Godot's front-face winding)
	var idx := PackedInt32Array()
	idx.resize((n - 1) * (n - 1) * 6)
	var k := 0
	for row in n - 1:
		for col in n - 1:
			var nw := row * n + col
			var ne := nw + 1
			var sw := nw + n
			var se := sw + 1
			idx[k] = nw; idx[k + 1] = ne; idx[k + 2] = sw
			idx[k + 3] = ne; idx[k + 4] = se; idx[k + 5] = sw
			k += 6
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_COLOR] = colors
	arrays[Mesh.ARRAY_INDEX] = idx
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.vertex_color_is_srgb = true
	mat.roughness = 0.95
	mesh.surface_set_material(0, mat)
	return mesh


## Grass on flat low ground, olive higher up, rock on steep slopes.
func _ground_color(hgt: float, up: float) -> Color:
	var t := clampf((hgt - min_height_m) / maxf(height_range_m, 0.001), 0.0, 1.0)
	var c := Color(0.22, 0.32, 0.15).lerp(Color(0.33, 0.33, 0.2), smoothstep(0.05, 0.4, t))
	c = c.lerp(Color(0.45, 0.43, 0.4), smoothstep(0.55, 0.95, t))
	return c.lerp(Color(0.33, 0.29, 0.25), smoothstep(0.9, 0.75, up))   # up = normal.y


func _add(n: Node) -> void:
	n.set_meta("terrain_part", true)
	add_child(n)
