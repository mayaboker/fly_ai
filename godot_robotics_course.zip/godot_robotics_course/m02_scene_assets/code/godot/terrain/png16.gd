class_name Png16
extends RefCounted
## Minimal PNG reader for 8- or 16-bit GRAYSCALE, non-interlaced images.
##
## Why it exists: Godot's Image.load_from_file() converts a 16-bit PNG to 8 bits
## (format L8). For a 20 m height range that is 20 / 255 = 7.8 cm steps instead of
## 20 / 65535 = 0.3 mm. The physics side reads all 16 bits, so Godot must too.
##
##   var png := Png16.read("/abs/path/heightmap.png")
##   png.width, png.height, png.bit_depth, png.values (PackedInt32Array, row-major, row 0 = top)

const SIGNATURE := [137, 80, 78, 71, 13, 10, 26, 10]


static func read(path: String) -> Dictionary:
	var f := FileAccess.get_file_as_bytes(path)
	if f.size() < 8 or Array(f.slice(0, 8)) != SIGNATURE:
		push_error("Png16: %s is missing or not a PNG" % path)
		return {}
	var w := 0
	var h := 0
	var depth := 0
	var ctype := -1
	var interlace := 0
	var idat := PackedByteArray()
	var pos := 8
	while pos + 8 <= f.size():                       # walk the chunks: length, type, data, crc
		var n := f.decode_u32(pos)
		n = _swap32(n)                               # PNG is big-endian, decode_u32 is little
		var kind := f.slice(pos + 4, pos + 8).get_string_from_ascii()
		var data := f.slice(pos + 8, pos + 8 + n)
		if kind == "IHDR":
			w = _swap32(data.decode_u32(0))
			h = _swap32(data.decode_u32(4))
			depth = data[8]
			ctype = data[9]
			interlace = data[12]
		elif kind == "IDAT":
			idat.append_array(data)
		elif kind == "IEND":
			break
		pos += 12 + n
	if ctype != 0 or interlace != 0 or not (depth == 8 or depth == 16):
		push_error("Png16: %s must be grayscale, 8/16 bit, not interlaced (type %d, depth %d)" % [path, ctype, depth])
		return {}

	var bpp := depth / 8                             # bytes per pixel
	var stride := w * bpp
	var raw := idat.decompress((stride + 1) * h, FileAccess.COMPRESSION_DEFLATE)   # zlib stream
	if raw.size() != (stride + 1) * h:
		push_error("Png16: %s: decompressed %d bytes, expected %d" % [path, raw.size(), (stride + 1) * h])
		return {}

	var values := PackedInt32Array()
	values.resize(w * h)
	var prev := PackedByteArray()
	prev.resize(stride)                              # row "above" the first row is all zeros
	var cur := PackedByteArray()
	cur.resize(stride)
	for r in h:
		var base := r * (stride + 1)
		_unfilter(raw[base], raw, base + 1, cur, prev, stride, bpp)
		var o := r * w
		if bpp == 2:
			for c in w:
				values[o + c] = (cur[2 * c] << 8) | cur[2 * c + 1]
		else:
			for c in w:
				values[o + c] = cur[c]
		var tmp := prev
		prev = cur
		cur = tmp
	return {"width": w, "height": h, "bit_depth": depth, "values": values}


## Undo one of the five PNG row filters (spec section 9.2). a = left, b = up, c = up-left.
static func _unfilter(kind: int, raw: PackedByteArray, start: int, cur: PackedByteArray,
		prev: PackedByteArray, stride: int, bpp: int) -> void:
	for i in stride:
		var x := raw[start + i]
		var a := cur[i - bpp] if i >= bpp else 0
		var b := prev[i]
		match kind:
			1:
				x += a
			2:
				x += b
			3:
				x += (a + b) >> 1
			4:
				var c := prev[i - bpp] if i >= bpp else 0
				var p := a + b - c
				var pa := absi(p - a)
				var pb := absi(p - b)
				var pc := absi(p - c)
				x += a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
		cur[i] = x & 0xFF


static func _swap32(v: int) -> int:
	return ((v & 0xFF) << 24) | ((v & 0xFF00) << 8) | ((v >> 8) & 0xFF00) | ((v >> 24) & 0xFF)
