extends Node3D
## Test-range viewer root (Module 1 + Module 2).
##  - camera switching [C], pause [P], reset [R], status text
##  - parks each vehicle at its lineup spot from range.json (static placement only:
##    from Module 4 on, vehicle poses come from the physics process over the bridge)
## main.tscn sets process_mode = ALWAYS on this node, so the keys work while paused.

@onready var _cameras: Array[Camera3D] = [$Cameras/FreeFly, $Cameras/Orbit]
@onready var _status: Label = $UI/Status
@onready var terrain: HeightmapTerrain = $World/Terrain
@onready var range_builder: RangeBuilder = $World/Range

var _cam_index := 0


func _ready() -> void:
	park_vehicles()
	_set_camera(0)


## Put every Vehicle under $Vehicles on its lineup spot (matched by vehicle_id), nose north.
func park_vehicles() -> void:
	if range_builder.layout.is_empty():
		return
	for v in $Vehicles.get_children():
		if v is Vehicle:
			for spot in range_builder.layout.lineup:
				if int(spot.id) == v.vehicle_id:
					v.place_on_ground(terrain, spot.e, spot.n, 0.0)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("camera_next"):
		_set_camera((_cam_index + 1) % _cameras.size())
	elif event.is_action_pressed("pause_toggle"):
		get_tree().paused = not get_tree().paused
	elif event.is_action_pressed("reset"):
		reset()


## Reset: cameras back home, vehicles back on their spots, and every node in
## group "resettable" gets reset() called.
func reset() -> void:
	for cam in _cameras:
		cam.call("reset_view")
	park_vehicles()
	get_tree().call_group("resettable", "reset")


func _set_camera(i: int) -> void:
	_cam_index = i
	_cameras[i].make_current()


func active_camera_name() -> String:
	var cam := get_viewport().get_camera_3d()
	return cam.name if cam else "none"


func _process(_delta: float) -> void:
	var cam := get_viewport().get_camera_3d()
	var p := cam.global_position if cam else Vector3.ZERO
	var ground := terrain.height_at_world(p.x, p.z) if terrain.size_px > 0 else 0.0
	# Godot (x, y, z) = (East, Up, South)  ->  ENU (E, N, U) = (x, -z, y)
	_status.text = ("FPS %d   camera: %s [C]   %s [P]   reset [R]\n"
			+ "camera ENU  E %.1f  N %.1f  U %.1f m   (%.1f m above ground)") % [
		Engine.get_frames_per_second(), active_camera_name(),
		"PAUSED" if get_tree().paused else "running", p.x, -p.z, p.y, p.y - ground]
