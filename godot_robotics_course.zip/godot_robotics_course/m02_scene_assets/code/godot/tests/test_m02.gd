extends SceneTree
## Module 2 automated check. Run from the godot/ folder (data/terrain must exist):
##   godot --headless --path . -s tests/test_m02.gd
##   godot --headless --path . -s tests/test_m02.gd -- --points="37.3,-12.6;-55.5,41.2;101.7,-88.3"
## Screenshots (needs a renderer, e.g. xvfb-run ... --rendering-driver opengl3):
##   godot --path . --rendering-driver opengl3 -s tests/test_m02.gd -- --shots=/tmp/range
##
## Prints one line per sample point, which tools/compare_heights.py parses:
##   HEIGHT e=<east> n=<north> direct=<bilinear m> ray=<raycast m>

var _fail := 0
var _main: Node3D


func _initialize() -> void:
	_run()


func _check(ok: bool, what: String) -> void:
	print(("PASS  " if ok else "FAIL  ") + what)
	if not ok:
		_fail += 1


func _arg(key: String, default: String) -> String:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--%s=" % key):
			return a.split("=", true, 1)[1]
	return default


func _run() -> void:
	_main = load("res://main.tscn").instantiate()
	root.add_child(_main)
	for i in 3:
		await physics_frame              # shapes enter the physics space
	await process_frame

	var terrain: HeightmapTerrain = _main.get_node("World/Terrain")
	_check(terrain.size_px == 257 and terrain.heights.size() == 257 * 257, "terrain 257 x 257 loaded from 16-bit PNG")
	print("terrain: PNG read + mesh + shape built in %.0f ms" % terrain.build_ms)
	_check(terrain.get_node("Collision").collision_layer == 1, "terrain collision on layer 1 (terrain)")

	# ---- 1. heights: direct bilinear lookup vs raycast against HeightMapShape3D
	var pts := _arg("points", "37.3,-12.6;-55.5,41.2;101.7,-88.3")
	var worst := 0.0
	for p in pts.split(";"):
		var en := p.split(",")
		var e := float(en[0])
		var n := float(en[1])
		var direct := terrain.height_at(e, n)
		var ray := terrain.raycast_height(e, -n)
		worst = maxf(worst, absf(direct - ray))
		print("HEIGHT e=%.3f n=%.3f direct=%.6f ray=%.6f" % [e, n, direct, ray])
	_check(worst < 0.05, "raycast within 5 cm of bilinear lookup (worst %.4f m)" % worst)

	# ---- 2. vehicles: ids, mounts, nose -Z, resting on the ground, parent transforms
	var expect := {"Rover": 1, "Quad": 2, "Plane": 3, "QuadPlane": 4}
	for vname in expect:
		var v: Vehicle = _main.get_node("Vehicles/" + vname)
		_check_vehicle(v, expect[vname], terrain)

	# plane: roll right (+30 deg about its forward axis) must put the right (green) wingtip DOWN
	var plane: Vehicle = _main.get_node("Vehicles/Plane")
	var fwd := -plane.global_basis.z
	# right-hand rule about the FORWARD axis: +angle takes the right wing (+X) down, like FRD roll
	plane.global_basis = Basis(fwd, deg_to_rad(30.0)) * plane.global_basis
	var tip_r: Node3D = plane.get_node("Visual/WingTip_R")
	var tip_l: Node3D = plane.get_node("Visual/WingTip_L")
	_check(tip_r.global_position.y < tip_l.global_position.y - 0.5,
			"plane rolled right: right tip %.2f m below left tip" % (tip_l.global_position.y - tip_r.global_position.y))
	# pitch up 20 deg: the nose and the fpv mount must rise, the mount still looks along the nose
	plane.global_basis = Basis.IDENTITY
	plane.rotate_object_local(Vector3.RIGHT, deg_to_rad(20.0))
	_check(plane.mount_forward("fpv_cam").y > 0.3, "plane pitched up: fpv_cam looks up (y = %.2f)" % plane.mount_forward("fpv_cam").y)
	_main.call("park_vehicles")
	_check(plane.global_basis.is_equal_approx(Basis.IDENTITY), "park_vehicles() restores the pose")

	# ---- 3. reference boxes: 1 m, sitting on the ground
	for box in _main.get_node("World/Range/RefBoxes").get_children():
		if box is MeshInstance3D:
			var bb: AABB = box.global_transform * box.get_aabb()
			var g := terrain.height_at_world(box.global_position.x, box.global_position.z)
			_check(bb.size.is_equal_approx(Vector3.ONE) and absf(bb.position.y - g) < 0.02,
					"%s is 1 m and on the ground" % box.name)

	# ---- 4. range content and collision layers
	_check(get_nodes_in_group("gates").size() == 3, "3 gates in group 'gates'")
	_check(get_nodes_in_group("obstacles").size() == 6, "6 obstacles in group 'obstacles'")
	_check(get_nodes_in_group("vehicles").size() == 4, "4 vehicles in group 'vehicles'")
	var space := _main.get_world_3d().direct_space_state
	var g1: Node3D = get_nodes_in_group("gates")[0]
	var q := PhysicsRayQueryParameters3D.create(g1.global_position + Vector3(-10, 1.5, 0),
			g1.global_position + Vector3(10, 1.5, 0), 1 << 3)            # gates layer only
	var hit := space.intersect_ray(q)
	_check(not hit.is_empty(), "a ray on layer 4 (gates) hits gate_1's posts")
	var rover: Vehicle = _main.get_node("Vehicles/Rover")
	q = PhysicsRayQueryParameters3D.create(rover.global_position + Vector3(0, 5, 0),
			rover.global_position - Vector3(0, 5, 0), 1 << 2)            # vehicles layer only
	hit = space.intersect_ray(q)
	_check(not hit.is_empty() and hit.collider.get_parent() == rover, "a ray on layer 3 (vehicles) hits the rover, not the terrain")

	# ---- 5. axis marker unchanged from Module 1
	var texts := []
	for c in _main.get_node("World/AxisMarker").get_children():
		if c is Label3D:
			texts.append(c.text)
	_check(texts == ["+X  East", "+Y  Up", "+Z  South", "-Z  North"], "axis labels match reference/frames.md")

	var shots := _arg("shots", "")
	if shots != "":
		await _screenshots(shots, terrain)

	print("M02 RESULT: %s (%d failed)" % ["PASS" if _fail == 0 else "FAIL", _fail])
	quit(_fail)


func _check_vehicle(v: Vehicle, id: int, terrain: HeightmapTerrain) -> void:
	_check(v.vehicle_id == id, "%s has vehicle_id %d" % [v.name, id])
	var ok := true
	for m in Vehicle.MOUNT_NAMES:
		ok = ok and v.has_node("Mounts/" + m) and v.get_node("Mounts/" + m) is Marker3D
	_check(ok, "%s has Marker3D mounts %s" % [v.name, Vehicle.MOUNT_NAMES])
	# parked nose north: fpv looks along -Z (north), down_cam looks along -Y with image-up = nose
	var fpv := v.mount_forward("fpv_cam")
	var down: Marker3D = v.mount("down_cam")
	_check(fpv.is_equal_approx(Vector3.FORWARD) and v.mount("fpv_cam").position.z < 0.0,
			"%s fpv_cam is at the front and looks along -Z (north)" % v.name)
	_check((-down.global_basis.z).is_equal_approx(Vector3.DOWN) and down.global_basis.y.is_equal_approx(Vector3.FORWARD),
			"%s down_cam looks down, image top toward the nose" % v.name)
	# resting: lowest visual point on the ground
	var low := INF
	for mi in v.find_children("*", "MeshInstance3D", true, false):
		low = minf(low, (mi.global_transform * mi.get_aabb()).position.y)
	var g := terrain.height_at_world(v.global_position.x, v.global_position.z)
	_check(absf(low - g) < 0.03, "%s rests on the ground (lowest point %.3f m, ground %.3f m)" % [v.name, low, g])
	# parent transform: turn the vehicle to heading 90 (east); the children follow
	v.rotation.y = -deg_to_rad(90.0)
	_check(v.mount_forward("fpv_cam").is_equal_approx(Vector3.RIGHT), "%s heading 90: fpv_cam looks east (+X)" % v.name)
	v.rotation.y = 0.0


func _screenshots(dir: String, terrain: HeightmapTerrain) -> void:
	DirAccess.make_dir_recursive_absolute(dir)
	var ff: FreeFlyCamera = _main.get_node("Cameras/FreeFly")
	var orbit: OrbitCamera = _main.get_node("Cameras/Orbit")
	var views := [
		["overview", ff, Vector3(35, 25, 45), Vector3(0, 0, -15)],
		["high", ff, Vector3(0, 170, 140), Vector3(0, 0, -5)],
		["gates", ff, Vector3(-6, 4, 2), Vector3(2, 2, -34)],
		["road", ff, Vector3(-58, 3.0, 52), Vector3(-20, 1, 58)],
	]
	for view in views:
		var cam: Camera3D = view[1]
		cam.make_current()
		cam.global_position = view[2]
		cam.look_at(view[3])
		await _save_shot(dir, view[0])
	orbit.make_current()
	await _save_shot(dir, "lineup")
	# one close-up per vehicle, seen from the front (north-west), with its reference box in view
	for vname in ["Rover", "Quad", "Plane", "QuadPlane"]:
		var v: Vehicle = _main.get_node("Vehicles/" + vname)
		orbit.target = v.global_position + Vector3(0.9, 0.2, 0)
		orbit.distance = 4.0 if vname in ["Plane", "QuadPlane"] else 3.2
		orbit.yaw_deg = -150.0
		orbit.pitch_deg = -18.0
		await _save_shot(dir, "closeup_" + vname.to_lower())


func _save_shot(dir: String, shot_name: String) -> void:
	for i in 8:
		await process_frame
	var img := root.get_texture().get_image()
	img.save_png(dir.path_join(shot_name + ".png"))
	print("saved ", dir.path_join(shot_name + ".png"))
