# 03 Collision layers, sensor mounts and world organisation (40 min)

Godot's physics engine will never move a vehicle in this course ([Module 1, 03](../m01_editor_gdscript/03_gdscript_and_callbacks.md)). You still need collision shapes, because Godot-side sensors are physics **queries**. A range finder is a ray, a lidar is many rays, and a contact sensor is a shape overlap. Queries only see what has a shape, and they only see the shapes whose layer is in the query's mask. This page sets up those layers, defines where sensors attach, and fixes names so that later modules can find things without guessing.

## Layers and masks

Every collision object has two 32-bit fields:

| Field | Question it answers | Set on |
|---|---|---|
| `collision_layer` | **what am I?** | terrain, obstacles, gates, vehicles |
| `collision_mask` | **what do I look for?** | rays, areas, anything that detects |

A ray with mask `M` hits an object with layer `L` only if `M & L != 0`. The course uses four named layers (*Project Settings → Layer Names → 3D Physics*):

| Layer | Name | Value (`1 << (n−1)`) | Who is on it |
|---:|---|---:|---|
| 1 | `terrain` | 1 | `HeightmapTerrain/Collision` |
| 2 | `obstacles` | 2 | boxes, poles, landing pad |
| 3 | `vehicles` | 4 | each vehicle's `Body` |
| 4 | `gates` | 8 | gate posts and bars |

All of these are passive objects. Their **mask is 0**. They never need to detect anything. Masks belong to sensors. Some examples of how a sensor might choose its mask (Module 8 builds the real ones):

| Sensor | Mask | Why |
|---|---|---|
| downward range finder on the quad | `terrain + obstacles` = 3 | altitude above whatever is below, but not the gate it flies through |
| rover forward range | `obstacles + vehicles` = 6 | stop for boxes and other robots, ignore the ground ahead |
| lidar | 1 + 2 + 4 + 8 = 15 | everything |
| gate passage detector (`Area3D`) | `vehicles` = 4 | "did a vehicle pass?" |

With names in the project settings, the Inspector shows checkboxes labelled `terrain`, `obstacles`, and so on. In code, use `@export_flags_3d_physics var mask := 3` to get the same checkboxes on your own scripts.

A ray query from code, as the Module 2 test uses it:

```gdscript
var space := get_world_3d().direct_space_state
var q := PhysicsRayQueryParameters3D.create(from, to, 1 << 2)     # vehicles layer only
var hit := space.intersect_ray(q)
if hit:
	print(hit.collider.get_parent().name, " at ", hit.position, " normal ", hit.normal)
```

The test fires a vertical ray through the rover with mask `vehicles`. It hits the rover's `Body`, not the terrain under it. A horizontal ray at 1.5 m with mask `gates` hits gate 1's posts.

## Which body type?

| Type | Moves how | Use in this course |
|---|---|---|
| `StaticBody3D` | only when you set its transform | **everything**: terrain, obstacles, gates, and vehicles (the bridge sets their transform) |
| `Area3D` | you set its transform; it detects overlaps | trigger volumes (gate passage, Module 8) |
| `AnimatableBody3D` | moved by you, pushes `RigidBody3D`s | not used: nothing should be pushed |
| `RigidBody3D` / `CharacterBody3D` | simulated by Godot | **not used**: physics belongs to Python |

Each body needs one or more `CollisionShape3D` children with a `Shape3D` resource: `BoxShape3D`, `CylinderShape3D`, `HeightMapShape3D` for the terrain. Keep vehicle shapes simple. One box per vehicle is enough for rays and lidar. Turn on *Debug → Visible Collision Shapes* to see them.

## Sensor mounts with `Marker3D`

A `Marker3D` is a `Node3D` that draws a small cross in the editor. That is all, and it is all a mount needs: a named, visible transform on the vehicle. Every vehicle has the same four mounts under `Mounts/`:

| Mount | Looks along (its −Z) | Image up / its +Y | Who uses it |
|---|---|---|---|
| `fpv_cam` | forward (vehicle −Z) | vehicle up | FPV camera, Module 6 |
| `down_cam` | straight down (vehicle −Y) | toward the nose | downward camera, Module 6 |
| `imu` | (orientation = body axes) | | IMU truth point, Module 8 |
| `range` | rover: forward; aircraft: down | | range finder ray, Module 8 |

Rules:

1. **Every mount looks along its own −Z**, like a Godot camera. A camera added as a child with an identity transform looks where the mount looks.
2. **`down_cam` is pitched −90° about X.** That turns −Z into −Y (down) and +Y into −Z (the nose). The top of the downward image therefore points forward. The test checks both.
3. **Mounts are fixed offsets from the vehicle origin (the CG).** Physics reports the CG pose, Godot places the vehicle there, and the hierarchy places the mounts.
4. **The `imu` mount sits at the CG with identity rotation.** Its axes are the MODEL frame (x right, y up, z back). Modules 3 and 8 convert from there to FLU or FRD. The IMU reading itself is computed on the physics side, because it would not change if you moved a wall.

Offsets used for the placeholders (model frame, meters):

| Vehicle | `fpv_cam` | `down_cam` | `range` |
|---|---|---|---|
| rover | (0, 0.32, −0.40) | (0, −0.10, −0.20) | (0, 0, −0.52), forward |
| quad | (0, 0, −0.15) | (0, −0.04, 0) | (0, −0.04, 0.05), down |
| plane, quadplane | (0, 0.03, −0.50) | (0, −0.07, −0.25) | (0, −0.07, 0), down |

`Vehicle` gives later modules one way to reach them:

```gdscript
var cam_mount: Marker3D = vehicle.mount("fpv_cam")
var look_dir: Vector3 = vehicle.mount_forward("down_cam")    # world vector, = -global_basis.z
```

## Organising the world

**Folders (in `robosim/godot/`)** follow [project_layout.md](../reference/project_layout.md):

| Folder | Holds |
|---|---|
| `terrain/` | `png16.gd`, `heightmap_terrain.gd` |
| `world/` | axis marker, range builder: things that make up the static world |
| `vehicles/` | `vehicle.gd`, the generator, the four `.tscn` files, later `models/` |
| `cameras/` | free-fly, orbit; camera rigs from Module 6 |
| `tests/` | `test_m01.gd`, `test_m02.gd`, … |

Data that Python also reads stays **outside** the Godot project, in `robosim/data/`.

**Scene tree.** Group the main scene by role, not by node type:

```
Main
├── Environment, Sun
├── World          static: Terrain, Range (Roads, Pad, Gates, Obstacles, RefBoxes), AxisMarker, RefCube
├── Vehicles       Rover, Quad, Plane, QuadPlane   (things the bridge moves)
├── Cameras        viewer cameras (vehicle cameras live under vehicle mounts)
└── UI
```

**Groups** let code find things without paths:

| Group | Members | Used by |
|---|---|---|
| `terrain` | `HeightmapTerrain` | sensors that need ground height |
| `vehicles` | every `Vehicle` | bridge (match `vehicle_id`), HUD |
| `gates` | each gate node | lap timing, gate detectors |
| `obstacles` | each obstacle node | lidar tests, scenario setup |
| `resettable` | anything with `reset()` | the reset key |

**Names.** Files are `snake_case.gd`, nodes are `PascalCase`, and mounts are lowercase and named after the sensor (`fpv_cam`), because strings in code refer to them. Vehicle ids are the protocol ids, never array indices. The ids 1–4 (rover, quad, plane, quadplane) are the `id`s of the lineup in `range.json`, and they are what goes into the `vehicle_id` field of every POSE packet ([protocol.md](../reference/protocol.md)).

## Try it

- Turn on *Debug → Visible Collision Shapes*, run, and fly to a gate and to the plane. Do the boxes match the visuals well enough for a range sensor?
- Write a 10-line function `range_down(vehicle: Vehicle, mask: int) -> float` that casts from `mount("range")` along its −Z for 50 m. Compare mask 1 and mask 3 with the quad parked under gate 1 (move it there in the Remote inspector).
- Add a fifth layer `sensor_targets` in Project Settings and put the landing pad on it as well. What do you have to change in `range_builder.gd`?
- Pick a mount and print its `global_transform` before and after you turn the vehicle to heading 180. Explain each column.

## References

- Godot docs, *Physics introduction* (layers and masks): <https://docs.godotengine.org/en/stable/tutorials/physics/physics_introduction.html>
- Godot docs, *Ray-casting*: <https://docs.godotengine.org/en/stable/tutorials/physics/ray-casting.html>
- Godot docs, `Marker3D`: <https://docs.godotengine.org/en/stable/classes/class_marker3d.html>
- Godot docs, *Groups*: <https://docs.godotengine.org/en/stable/tutorials/scripting/groups.html>
