# 05 The range layout and the vehicle scenes (40 min)

The terrain is shared between Python and Godot through one file. The **things on it** need the same treatment. Module 9's rover follows the road centerline, so Python needs the road's coordinates. Module 10's quad flies through gates, so the controller needs their positions and headings. If those numbers live only in a Godot scene, Python has to copy them by hand, and they will drift apart. So the range is described in `data/terrain/range.json`, written by the same seeded generator, and Godot **builds** the range from it. The vehicles are the opposite case. Godot alone draws them, so they are scenes, but scenes generated from a script so that their dimensions are reviewable and match the JSBSim models.

## `range.json`

All coordinates are ENU meters. Headings are compass degrees (0 = north, 90 = east). Heights are not stored, because everything sits on the terrain.

```json
{
  "frame": "ENU",
  "units": "m, deg",
  "road_width_m": 5.0,
  "roads": [
    {"name": "loop", "closed": true,  "points": [[48.0, -55.0], [49.917, -54.916], "... 77 points"]},
    {"name": "spur", "closed": false, "points": [[0.0, -20.0], [0.0, -36.0], [0.0, -55.0]]}
  ],
  "pad": {"e": 0.0, "n": 0.0, "radius_m": 4.0},
  "apron": {"e_min": -18.0, "e_max": 18.0, "n_min": -20.0, "n_max": 10.0},
  "lineup": [{"id": 1, "name": "rover", "e": -9.0, "n": -12.0}, "..."],
  "gates": [{"name": "gate_1", "e": 0.0, "n": 20.0, "heading_deg": 0.0, "width_m": 4.0, "height_m": 3.0}, "..."],
  "obstacles": [
    {"name": "box_1", "type": "box", "e": 30.0, "n": -45.0, "size_m": [2.0, 2.0, 2.0], "yaw_deg": 15.0},
    {"name": "pole_1", "type": "cylinder", "e": -60.0, "n": 0.0, "radius_m": 0.3, "height_m": 4.0}
  ]
}
```

| Element | Layout | Used later by |
|---|---|---|
| road loop | rounded rectangle, E −70…70, N −55…65, corner radius 22 m, 5 m wide | Module 9 road following |
| spur | apron (N −20) south to the loop (N −55) | rover leaves the apron |
| pad | 4 m radius at the origin, on the 0 m apron | quad take-off and landing |
| lineup | four parking spots at N = −12 | spawn poses for ids 1–4 |
| gates | three gates north of the pad, headings 0°, 20°, −20° | Module 10 gate run |
| obstacles | 3 boxes, 3 poles, 7–10 m outside the road | range and lidar tests |

The generator also uses the layout: it flattens the roads and the apron into the terrain. So editing `range.json` by hand is a mistake. Edit `LAYOUT` in `make_heightmap.py` and rerun it, and terrain and layout stay consistent. Treat it like the `seed`.

## Building the range (`world/range_builder.gd`)

`RangeBuilder` is a `@tool` node with an exported `terrain: HeightmapTerrain`. In `_ready()` it reads the json and builds everything as unowned children (so nothing is saved into `main.tscn`):

```
Range
├── Roads/loop, Roads/spur   Surface (dark), EdgeLeft/EdgeRight (white), CenterDash (yellow, 3 m on / 3 m off)
├── Pad                      disk, yellow ring, white "H"; StaticBody3D on layer 2
├── Gates/gate_1..3          two posts + bar (orange), number label; StaticBody3D on layer 4; group "gates"
├── Obstacles/box_*, pole_*  StaticBody3D on layer 2; group "obstacles"
└── RefBoxes                 one 1 m box + "id name" label per lineup spot
```

The building blocks:

- **ENU → Godot on the ground.** `ground(e, n, dy)` returns `Vector3(e, terrain.height_at(e, n) + dy, -n)`.
- **Roads are ribbons.** The centerline is resampled every 1 m. At each sample, a "left" vector is the direction turned +90° in ENU, `(-d.y, d.x)`. The two edge points get their own terrain height, plus 5 cm so the road never z-fights with the ground. Markings are thinner ribbons 7 cm up. Triangles are wound clockwise seen from above, so they face up.
- **Gates** get `rotation.y = -deg_to_rad(heading_deg)` ([01](01_transforms_and_hierarchy.md)), so you fly through along the gate's −Z.
- **Obstacles** sit at the **lowest** terrain height under their footprint, so no corner floats. Box sizes in the json are `[east, north, up]` and become Godot `(x, y, z) = (east, up, north)` before the yaw.

## The vehicles

All four vehicles share one structure and one script, `vehicles/vehicle.gd`:

```
Rover            Node3D + vehicle.gd: vehicle_id = 1, kind = "rover", rest_height_m = 0.25
├── Visual       meshes only (Chassis, Bumper, Wheel_FL…, …)
├── Body         StaticBody3D, layer 3 "vehicles", mask 0
│   └── Shape    CollisionShape3D with one BoxShape3D
└── Mounts
    ├── fpv_cam  Marker3D
    ├── down_cam Marker3D (pitched −90°)
    ├── imu      Marker3D
    └── range    Marker3D
```

```gdscript
class_name Vehicle
extends Node3D
@export var vehicle_id := 0               ## 1 rover, 2 quad, 3 plane, 4 quadplane (protocol ids)
@export var kind := ""
@export var rest_height_m := 0.0          ## origin height above flat ground when resting on it

func mount(mount_name: String) -> Marker3D:
	return get_node("Mounts/" + mount_name) as Marker3D

func place_on_ground(terrain: HeightmapTerrain, east: float, north: float, heading_deg := 0.0) -> void:
	position = Vector3(east, terrain.height_at(east, north) + rest_height_m, -north)
	rotation = Vector3(0.0, -deg_to_rad(heading_deg), 0.0)
```

`place_on_ground` is for static placement only, in the editor and in tests. From Module 4 on, the pose comes from physics. The **origin is the CG**, the point whose pose physics reports. That is why `rest_height_m` exists: the origin floats above the ground by the distance from CG to wheels or legs.

| id | Scene | Shape | Readability cues |
|---:|---|---|---|
| 1 | `rover.tscn` | 0.6 × 0.2 × 0.9 m chassis, 4 wheels r 0.15 m, camera mast | red front bumper |
| 2 | `quad.tscn` | X frame, rotors at (±0.177, ±0.177) m | red front rotors, red nose camera |
| 3 | `plane.tscn` | pod, 1.6 m high wing, tail boom, stabilizer, fin, pusher prop | red nose, **green right tip, red left tip**, yellow fin up |
| 4 | `quadplane.tscn` | plane + two lift booms with four rotors at (±0.3, ±0.35) m, four legs | as plane, plus red front lift rotors |

The fixed-wing gets a real wing because **bank and pitch must be readable** from any camera. A plain box hides a 10° roll. A 1.6 m wing with colored tips shows it at once. The Module 2 test rolls the plane +30° and checks that the right tip drops 0.80 m below the left.

### From JSBSim locations to model coordinates

The aircraft dimensions come from the JSBSim models in [`reference/code/aircraft`](../reference/code/aircraft). JSBSim's *structural* frame has x aft, y right and z up. Offsets from the CG in that frame map onto the Godot model frame (x right, y up, z back) as a plain reorder:

```
model (x, y, z) = structural (y, z, x)            (offsets from the CG, meters)
```

For example, the quad's leg `LEG_FR` at structural (−0.12, 0.12, −0.08) is at model (0.12, −0.08, −0.12): right, below and in front of the CG. The generator puts a small gray sphere at every JSBSim contact point. If the visual model and the physics model disagree about where the ground is, you see it in the lineup. The test confirms that each vehicle's lowest visual point is within 3 cm of the terrain. (Module 3 derives the full rotation chains. This shortcut applies to fixed offsets only.)

### Generating the scenes (`vehicles/build_vehicles.gd`)

```bash
cd ~/robosim/godot
~/tools/godot --headless --path . -s vehicles/build_vehicles.gd
# Rover -> res://vehicles/rover.tscn (OK)
# Quad -> res://vehicles/quad.tscn (OK)
# Plane -> res://vehicles/plane.tscn (OK)
# QuadPlane -> res://vehicles/quadplane.tscn (OK)
```

The generator is ordinary code: `_box()`, `_cyl()`, `_contact()`, `_collision()` and `_mounts()` helpers, one function per vehicle. As described in [Module 1, 04](../m01_editor_gdscript/04_scenes_from_code.md), it sets fixed resource ids and strips Godot's random node ids, so a second run produces byte-identical files. We checked this with `md5sum`.

After generating, open `rover.tscn` in the editor. It is a normal scene. Click a mount to see its gizmo, and use *Visible Collision Shapes* to see the body box. If you want to change a dimension, change the generator and rerun it. Do not edit the `.tscn`.

### Putting them in the main scene

The four scenes are **instanced** in `main.tscn` under `Vehicles` (drag them in from the FileSystem dock). `main.gd` parks them on their lineup spots when the scene starts and when you press `R`:

```gdscript
func park_vehicles() -> void:
	for v in $Vehicles.get_children():
		if v is Vehicle:
			for spot in range_builder.layout.lineup:
				if int(spot.id) == v.vehicle_id:
					v.place_on_ground(terrain, spot.e, spot.n, 0.0)
```

Matching by `vehicle_id` rather than by node name or order is deliberate. Module 4's bridge matches incoming poses the same way.

## Try it

- Add a fourth gate at E = −10, N = 40, heading 90°, in `make_heightmap.py`. Regenerate, run, and check that you fly through it eastward. Did the terrain change? Why or why not?
- Change the rover's wheel radius to 0.2 m in the generator. What else must change so that it still rests on the ground? Rerun the test to confirm.
- Park the plane at heading 135° (south-east) in `main.gd` and orbit around it. Which colored tip is closer to the pad?
- Compute by hand where the quadplane's front-right lift rotor is in world coordinates when the quadplane is parked. Then print `get_node("Visual/LiftRotor_FR").global_position` and compare.

## References

- Godot docs, `SurfaceTool`: <https://docs.godotengine.org/en/stable/tutorials/3d/procedural_geometry/surfacetool.html>
- Godot docs, `PackedScene`: <https://docs.godotengine.org/en/stable/classes/class_packedscene.html>
- JSBSim structural frame: the header comment of [`quad_rpy.xml`](../reference/code/aircraft/quad_rpy/quad_rpy.xml) ("X points AFT, Y RIGHT, Z UP") and the JSBSim reference manual: <https://jsbsim-team.github.io/jsbsim-reference-manual/>
- Course: [frames](../reference/frames.md), [protocol](../reference/protocol.md) (the `vehicle_id` field)
