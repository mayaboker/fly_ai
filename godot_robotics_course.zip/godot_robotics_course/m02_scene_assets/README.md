# Module 2: Scenes, terrain and vehicle assets (6 h)

## What you will build

You turn the Module 1 viewer into the course's **test range**: a 256 m × 256 m terrain generated from a seeded heightmap that the Python side reads too, with a marked road loop, three drone gates, obstacles and a landing pad. Four placeholder vehicles stand on the apron: rover, quadcopter, fixed-wing plane and quadplane. Each has a 1 m reference box beside it and `Marker3D` mounts for its sensors. Later modules move these vehicles from PyBullet and JSBSim and use their mounts for cameras and sensors.

![The test range](img/range_overview.png)

*Rendered by `code/godot/tests/test_m02.gd` under xvfb. More views: [lineup](img/range_lineup.png), [plane close-up](img/range_closeup_plane.png), [road](img/range_road.png), [top](img/range_high.png).*

## Prerequisites

- [Module 1](../m01_editor_gdscript/README.md) finished: `~/robosim/godot` runs and `tests/test_m01.gd` passes.
- [Frames cheat sheet](../reference/frames.md) and [terrain contract](../reference/terrain.md) read.
- Python venv from [00 Setup](../00_setup/README.md) (numpy, Pillow via matplotlib).

## Sub-topics

| File | Topic | Time |
|---|---|---:|
| [01_transforms_and_hierarchy.md](01_transforms_and_hierarchy.md) | `Node3D` transforms, local vs global, parent/child, compass heading → rotation | 40 min |
| [02_meshes_materials_lights.md](02_meshes_materials_lights.md) | Primitive meshes, importing glTF (and its +Z front), `StandardMaterial3D`, lights, sky, model scale and the 1 m box | 50 min |
| [03_collision_mounts_organisation.md](03_collision_mounts_organisation.md) | Collision layers and masks for sensing, `Marker3D` sensor mounts, groups, folders, naming | 40 min |
| [04_terrain_heightmap.md](04_terrain_heightmap.md) | Seeded heightmap in Python, the 16-bit trap, the fallback loader (mesh + `HeightMapShape3D`), Terrain3D as an option | 60 min |
| [05_range_and_vehicles.md](05_range_and_vehicles.md) | `range.json`, roads, gates, obstacles, pad; generated vehicle scenes for ids 1–4 | 40 min |
| [lab.md](lab.md) | Build the range and the vehicles, then run the checks | 130 min |

## Deliverables

```
robosim/
├── tools/make_heightmap.py           seeded generator: heightmap.png (16-bit), heightmap.json, range.json
├── tools/compare_heights.py          Godot vs Python height check
├── data/terrain/                     heightmap.png, heightmap.json, range.json  (generated, seed 42)
├── physics/robosim/terrain.py        Heightmap.load(), height_at(e, n) bilinear in ENU
├── physics/tests/test_terrain.py
└── godot/
    ├── project.godot                 + layer names: 1 terrain, 2 obstacles, 3 vehicles, 4 gates
    ├── main.tscn / main.gd           Ground and DemoSpinner removed; Terrain, Range, Vehicles added
    ├── terrain/png16.gd              16-bit PNG reader
    ├── terrain/heightmap_terrain.gd  ArrayMesh + HeightMapShape3D from the PNG
    ├── world/range_builder.gd        roads, pad, gates, obstacles, reference boxes
    ├── vehicles/vehicle.gd           Vehicle class (id, kind, rest height, mounts)
    ├── vehicles/build_vehicles.gd    generator for the four vehicle scenes
    ├── vehicles/{rover,quad,plane,quadplane}.tscn
    └── tests/test_m02.gd
```

## Check

1. **Python side.** `cd physics && python tests/test_terrain.py` prints `terrain: all tests pass ...`. The same seed gives byte-identical files.
2. **Godot side.** `godot --headless --path godot -s tests/test_m02.gd` ends with `M02 RESULT: PASS (0 failed)`. Among other things, it checks that:
   - each vehicle has the right `vehicle_id` (rover 1, quad 2, plane 3, quadplane 4) and the four mounts `fpv_cam`, `down_cam`, `imu`, `range`;
   - each `fpv_cam` sits at the front and looks along −Z (north) when parked, and each `down_cam` looks along −Y with image-up toward the nose;
   - each vehicle's lowest visual point is within 3 cm of the terrain;
   - turning a vehicle to heading 90° turns its `fpv_cam` to +X (east), because the children follow the parent;
   - rolling the plane +30° about its forward axis puts the right (green) wingtip 0.8 m below the left;
   - every reference box is exactly 1 m and sits on the ground.
3. **Heights agree.** `python tools/compare_heights.py --godot ~/tools/godot` samples three world points in Godot (bilinear lookup **and** a raycast against the `HeightMapShape3D`) and with the Python bilinear sampler. Tolerances: lookup within one height step (20 m / 65535 = 0.3 mm), raycast within 5 cm. Our run:

   | E, N (m) | Python | Godot lookup | raycast |
   |---|---:|---:|---:|
   | 37.3, −12.6 | 0.6476 | 0.6476 (0.000 mm) | 0.6479 (+0.37 mm) |
   | −55.5, 41.2 | 2.7400 | 2.7400 (0.000 mm) | 2.7403 (+0.32 mm) |
   | 101.7, −88.3 | 3.3864 | 3.3864 (0.000 mm) | 3.3860 (−0.31 mm) |

   The cross-check against the PyBullet heightfield is **deferred to Module 9**. It needs a PyBullet body on the terrain.
4. **By eye.** Fly along the lineup. Each 1 m box looks right beside its vehicle: the rover (0.9 m long) is a bit shorter than the box, the quad (0.5 m motor to motor) half of it, and the plane's 1.6 m wing longer. Fly the orbit camera around the plane. Its green wingtip is on its right, its fin points up, and its red nose points north.

## Common mistakes

- **Loading the heightmap with `Image.load_from_file()`.** Godot converts 16-bit PNGs to 8 bits. Over a 20 m range that gives 7.8 cm steps, and Godot and Python then disagree by centimeters. Use `Png16.read()` ([04](04_terrain_heightmap.md)).
- **Putting `heightmap.png` under `res://`.** Godot imports it as a compressed texture. Keep it in `robosim/data/terrain/`, outside the Godot project.
- **Mirroring the terrain north–south.** Row 0 is the **north** edge. In Godot, north is −Z, so row index grows with +Z. If the road loop looks right but the gates end up south of the pad, you flipped it.
- **Importing a glTF model and getting the nose backwards.** glTF models face +Z. This course's models face −Z. Wrap the import in a `Node3D` rotated 180° about Y ([02](02_meshes_materials_lights.md)).
- **Scaling the vehicle root to "fix" its size.** Scale the meshes, never the node that physics will place. A scaled root also scales every mount offset and every collision shape.
- **Giving static bodies a collision mask.** Terrain, obstacles and vehicles only need a **layer** (what they are). The mask (what they look for) belongs to the sensor ray ([03](03_collision_mounts_organisation.md)).

Next: [Module 3: Frames, units, quaternions, mounts](../m03_frames/README.md)
