# 04 Terrain: one heightmap, two engines (60 min)

The rover in Module 9 drives on PyBullet's terrain. The camera in Module 6 sees Godot's terrain. The JSBSim plane in Module 11 needs the ground elevation below it. If those three terrains differ by 10 cm, the rover's wheels float or sink in the video, and a downward range finder disagrees with the physics altitude. So the course has **one** terrain file, read by both sides with the same origin and the same interpolation: the contract in [reference/terrain.md](../reference/terrain.md). This page makes that file with Python and loads it in Godot without any plugin.

## The contract in one table

| Item | Value |
|---|---|
| file | `robosim/data/terrain/heightmap.png`: 16-bit grayscale, 257 × 257 |
| sidecar | `heightmap.json`: `size_px`, `meters_per_px` (1.0), `min_height_m` (0), `height_range_m` (20), `seed`, `origin` ("center") |
| height | `h = min_height_m + value / 65535 · height_range_m` → steps of 0.3 mm |
| extent | (257 − 1) · 1 m = 256 m, ENU x and y from −128 to +128 |
| pixel ↔ ENU | `col = 128 + E`, `row = 128 − N`. **Row 0 is the north edge** |
| Godot | the point (E, N, h) is `Vector3(E, h, −N)` |
| between pixels | bilinear |

Why 2^k + 1 pixels? So that the center pixel lands exactly on the origin, and 256 cells of 1 m span 256 m. PyBullet's heightfield and Godot's `HeightMapShape3D` both place one **vertex** per sample, so the counts match without resampling.

## Step 1: Generate it in Python (`tools/make_heightmap.py`)

The generator is about 150 lines of numpy. It writes the PNG, its json, and `range.json`, the layout of roads, gates and obstacles ([05](05_range_and_vehicles.md)). The terrain is designed for the course's vehicles:

| Region | Shape | Why |
|---|---|---|
| apron, E −18…18, N −20…10 | exactly 0 m, blended out over 8 m | vehicles park and take off here; origin on the ground |
| valley floor | rolling, 0.3 m near the center up to ~3.5 m at 70 m | slopes for the rover, terrain for the downward camera |
| roads | blended toward a heavily smoothed copy of the terrain | gentle grades, almost flat across the road |
| border (\|E\| or \|N\| > 92 m) | hills up to ~19 m | a visible edge; something for the plane to avoid |

The noise is seeded white noise blurred at three scales. Nothing else is random:

```python
rng = np.random.default_rng(seed)
n_big = normalize(blur(rng.standard_normal((size_px, size_px)), 14 / mpp))
...
values = np.round((h - min_h) / args.height_range * 65535).astype(np.uint16)
Image.fromarray(values).save(png)            # uint16 array -> 16-bit grayscale PNG
```

Run it from `robosim/`:

```bash
python tools/make_heightmap.py
# wrote data/terrain/heightmap.png (257x257, seed 42)
# height min 0.000 m  max 18.958 m  center 0.000 m
```

That is the output of our run. Same seed, same files: the test runs the generator twice into two folders and compares bytes. Byte identity was checked with numpy 2.4 and Pillow 12.2. With other library versions, compare **heights** (the table in the module README), not file hashes. The PNG compressor may produce different bytes for the same pixels.

## Step 2: Sample it in Python (`physics/robosim/terrain.py`)

```python
from robosim.terrain import Heightmap
hm = Heightmap.load("../data/terrain/heightmap.png")     # reads the json next to it
hm.height_at(37.3, -12.6)            # ENU east, north -> 0.6476 m
hm.height_at_godot(37.3, 12.6)       # same point given as Godot x, z
```

The core is ten lines of bilinear interpolation:

```python
def height_at(self, e, n):
    col, row = self.enu_to_pixel(np.asarray(e, float), np.asarray(n, float))
    col = np.clip(col, 0.0, self.size_px - 1.0)
    row = np.clip(row, 0.0, self.size_px - 1.0)
    c0 = np.minimum(np.floor(col).astype(int), self.size_px - 2)
    r0 = np.minimum(np.floor(row).astype(int), self.size_px - 2)
    fc, fr = col - c0, row - r0
    top = h[r0, c0] * (1 - fc) + h[r0, c0 + 1] * fc
    bot = h[r0 + 1, c0] * (1 - fc) + h[r0 + 1, c0 + 1] * fc
    return top * (1 - fr) + bot * fr
```

`Heightmap.load` refuses an 8-bit PNG. `physics/tests/test_terrain.py` checks the mapping at the corners, at pixel centers and halfway between pixels, the clamping outside the map, and that the apron is at 0 m. Modules 9–11 import this class. That is why it lives in the shared `robosim` package (a new file, nothing existing changes).

## Step 3: The 16-bit trap in Godot

The obvious Godot code is wrong:

```gdscript
var img := Image.load_from_file(path)     # DON'T: 16-bit PNG becomes 8-bit
```

We tested it on Godot 4.7.2. The image comes back as `FORMAT_L8`, and a pixel stored as 1799/65535 reads back as 7/255. Values are rounded to the nearest of 256 levels. For a 20 m range that is 7.8 cm steps, so Godot and Python would disagree by up to 3.9 cm, everywhere on the map. Importing the PNG as a texture under `res://` is worse: it is 8-bit **and** compressed.

So the course reads the PNG itself. `terrain/png16.gd` is a 100-line decoder for grayscale PNGs. It walks the chunks, joins the `IDAT` data, inflates it with Godot's zlib (`PackedByteArray.decompress(size, FileAccess.COMPRESSION_DEFLATE)`), and undoes the five PNG row filters:

```gdscript
var png := Png16.read("/home/you/robosim/data/terrain/heightmap.png")
# png.width, png.height, png.bit_depth (16), png.values: PackedInt32Array, row 0 first
```

We verified it against Python. It gave zero mismatches on a test image that uses all five filter types and on the real 257 × 257 heightmap. Reading the heightmap took about 90 ms in GDScript on our machine. It happens once at startup.

## Step 4: Build mesh and collision (`terrain/heightmap_terrain.gd`)

`HeightmapTerrain` (a `@tool` `Node3D`) reads the json and the PNG, converts values to meters, and builds two children:

```
Terrain (HeightmapTerrain)
├── Mesh        MeshInstance3D, ArrayMesh: 66 049 vertices, 131 072 triangles, vertex colors
└── Collision   StaticBody3D on layer 1 "terrain"
    └── CollisionShape3D with HeightMapShape3D(map_width = 257, map_depth = 257, map_data = heights)
```

**Pixel → vertex.** The same rule as the contract:

```gdscript
verts[i] = Vector3((col - _half) * meters_per_px, hgt, (row - _half) * meters_per_px)
```

Row grows southward, and so does Godot +Z. No flip is needed. `HeightMapShape3D` wants its samples row-major with x fastest, centered on the node, 1 unit apart. That is exactly the PNG's order, so `map_data = heights` is the whole conversion. (For `meters_per_px ≠ 1` the loader scales the collision shape in X and Z. The course default is 1.)

**Which diagonal?** Each 1 m cell is two triangles, and the diagonal can run NW–SE or NE–SW. Rays hit the collision shape, and your eye sees the mesh, so the two had better match. We measured the shape by firing 20 000 vertical rays at random points and comparing with both choices:

| Interpolation compared with the raycast | max difference |
|---|---:|
| triangles split NE–SW | 0.17 mm |
| triangles split NW–SE | 235 mm |
| bilinear (the contract) | 4.5 mm in the valley, 133 mm on the steep border hills |

`HeightMapShape3D` splits cells NE–SW, so the mesh does too. The last row matters for later modules. **Bilinear** (the contract, `height_at`) and **triangles** (what rays hit, and what PyBullet's heightfield also uses) agree within a few millimeters on the gentle valley, but by up to 13 cm on the steep border. Use `height_at` wherever Python also computes the number, for example a spawn height or the JSBSim terrain elevation. Use rays for Godot-side sensors, because a sensor should see what is rendered.

**Normals and color.** Normals come from central differences, `(−dh/dx, 1, −dh/dz)` normalized. Vertex colors go from grass to olive to rock by height, rock on steep slopes, and every 10 m vertex row and column is darkened. Those darker lines give a free 10 m scale grid when you look at camera images.

**Timing.** Loading and building everything took 131–134 ms in our headless runs. Expect a similar order of magnitude on a desktop. Measure it with `terrain.build_ms`, which the test prints.

## Step 5: Sample it in Godot

```gdscript
var terrain: HeightmapTerrain = $World/Terrain
terrain.height_at(37.3, -12.6)          # ENU, bilinear: same algorithm as Python
terrain.height_at_world(37.3, 12.6)     # same point given as Godot x, z
terrain.raycast_height(37.3, 12.6)      # what a ray hits (needs one physics frame after _ready)
```

`tools/compare_heights.py` runs the Godot test headless, parses its `HEIGHT` lines and compares them with Python. Results are in the [module README](README.md#check). Lookup vs Python: 0.000 mm. Raycast vs Python: within 0.4 mm at the three check points. The comparison against **PyBullet's** own heightfield is part of Module 9's Check, once a PyBullet world exists.

## Terrain3D: optional, and why it is not the default

[Terrain3D](https://github.com/TokisanGames/Terrain3D) is a good GDExtension terrain system: clipmap LOD, texture painting, large worlds. For this course it is optional, for two reasons:

1. **Version support.** At the time of writing, its latest release (v1.0.2) says it supports Godot 4.4–4.6. Its release-candidate notes say *"I don't know about 4.7."* We did not test it with 4.7.2. Check the releases page before you install it.
2. **The contract.** Terrain3D has its own storage, LOD and collision. Then your raycasts no longer hit a shape built from exactly our 257 × 257 samples, and you must prove again that both engines agree.

If you want to try it:

- Export raw 16-bit data with `python tools/make_heightmap.py --r16`. That writes `heightmap.r16` (little-endian uint16, same row order) next to the PNG. Import that with Terrain3D's importer and set its height scale to 20 m. Do not let it read the PNG through Godot's image loader (8-bit, Step 3).
- Keep `HeightmapTerrain` in the scene with its mesh hidden, so sensors keep raycasting the contract shape. Or rerun `compare_heights.py`-style checks against Terrain3D's collision.
- Expect to fix position offsets. Terrain3D regions are not centered the way the contract is.

None of the course's tests depend on Terrain3D.

## Try it

- Run the generator with `--seed 7` into `/tmp/t7` and look at both PNGs in an image viewer (they look almost black: values are low because most of the map is below 4 m of 20). Which regions are identical, and why?
- In Godot, temporarily fill `heights` from `Image.load_from_file` instead (`min_height_m + img.get_pixel(col, row).r * height_range_m`) and rerun `compare_heights.py`. Record the error you get, then undo it.
- Flip the mesh diagonal in `_make_mesh()` and fly low over the border hills with *Visible Collision Shapes* on. Where does the debug shape poke through?
- Add `slope_at(e, n)` to `terrain.py` (degrees, from `normal_at`) and print the steepest slope along the road loop. Could the rover climb it?

## References

- Course: [terrain contract](../reference/terrain.md), [frames](../reference/frames.md)
- Godot docs, `HeightMapShape3D`: <https://docs.godotengine.org/en/stable/classes/class_heightmapshape3d.html>
- Godot docs, *Using the ArrayMesh*: <https://docs.godotengine.org/en/stable/tutorials/3d/procedural_geometry/arraymesh.html>
- PNG specification, filtering: <https://www.w3.org/TR/png-3/#9Filters>
- Terrain3D releases: <https://github.com/TokisanGames/Terrain3D/releases>, documentation: <https://terrain3d.readthedocs.io/>
