# 02 Meshes, materials, lights and model scale (50 min)

A robotics viewer needs **correct** visuals more than pretty ones. Correct means the right size, a front you can see, colors that survive tone mapping, and lighting that stays the same from run to run, because Modules 6–8 feed these pixels to vision code. This page covers what you need to make placeholder vehicles and a range, and how to bring in a real model later without breaking the frame conventions.

## Meshes: primitives first

A `MeshInstance3D` node draws a `Mesh` resource. Godot ships parametric primitives, and they are all you need for placeholders:

| Mesh | Key properties | Course use |
|---|---|---|
| `BoxMesh` | `size` (x, y, z) m | chassis, wings, gates, reference boxes |
| `CylinderMesh` | `top_radius`, `bottom_radius`, `height`; axis = local **+Y** | wheels, rotors, poles; `top_radius = 0` gives a cone (noses, arrow heads) |
| `SphereMesh` | `radius`, `height` | contact-point markers |
| `PlaneMesh` | `size` (x, z) | the Module 1 ground |
| `TorusMesh` | `inner_radius`, `outer_radius` | landing-pad ring |
| `ArrayMesh` | vertex/index arrays you fill | terrain ([04](04_terrain_heightmap.md)) |
| `SurfaceTool` | add vertices one by one, then `commit()` | road ribbons ([05](05_range_and_vehicles.md)) |

Primitive meshes are centered on their node, and cylinders stand along +Y. A wheel therefore needs a rotation: `rotation = Vector3(0, 0, PI / 2)` lays its axis along X. A nose cone needs `rotation.x = -PI / 2` to point its tip along −Z.

```gdscript
var cone := CylinderMesh.new()
cone.top_radius = 0.0          # tip at local +Y
cone.bottom_radius = 0.06
cone.height = 0.12
var nose := MeshInstance3D.new()
nose.mesh = cone
nose.rotation.x = -PI / 2      # +Y -> -Z: tip forward
nose.position = Vector3(0, 0, -0.56)
```

## Materials

`StandardMaterial3D` is Godot's physically based material. Set it on the mesh (`mesh.material`, shared by every instance of that mesh) or on the node (`material_override`, or `surface_material_override/0` for one surface).

| Property | Use |
|---|---|
| `albedo_color` | base color |
| `roughness` (0 glossy … 1 matte) | 0.7–1.0 for placeholders: no glare in camera images |
| `metallic` | leave at 0 unless it is metal |
| `shading_mode = UNSHADED` | color ignores lights: axis arrows, debug markers |
| `vertex_color_use_as_albedo` + `vertex_color_is_srgb` | per-vertex color: the terrain |
| `transparency` | glass, ghosts; avoid for anything a sensor should "see" |
| `cull_mode` | `CULL_DISABLED` shows both faces (thin strips, single planes) |

Colors you pick in the color picker are sRGB. Godot converts them to linear for lighting, then the tone mapper maps the result back to the screen. A strong color under a bright sun and the *Filmic* tone mapper looks lighter than the swatch. The first terrain colors we tried looked neon green under the default sun and sky, so we darkened them. Judge colors in the running scene, not in the picker.

**Color as information.** Placeholders should make the pose readable at a glance:

| Cue | Convention used here |
|---|---|
| front | red nose cone, red bumper, red front rotors |
| right / left wing | **green** tip on the right (+X), **red** tip on the left (−X), like aircraft navigation lights |
| top | yellow vertical fin |
| contact points | small gray spheres exactly where the physics model touches the ground |

## Lights and environment

| Node | Settings used | Why |
|---|---|---|
| `DirectionalLight3D` (Sun) | rotation (−50°, 30°, 0), shadows on, *Max Distance* 200 m | one fixed sun: shadows show height above ground |
| `WorldEnvironment` | `ProceduralSkyMaterial`, ambient from sky, tone mapper *Filmic* | soft fill light, no black shadows |

A directional light has no position, only a direction: it shines along its −Z. `rotation x = −50°` is 50° below the horizon. Shadows matter more than they seem. In an image from a downward camera, the gap between a quad and its shadow is how *you* judge altitude. In Module 8 the same gap is a cue for vision code.

Keep the environment **fixed** for reproducible images. Do not use auto exposure, random sky or time-of-day changes unless a module asks for them. Module 7 compares frames between runs.

## Importing a glTF model

When a placeholder is no longer enough, use glTF 2.0 (`.glb`). It is the format Godot imports best. Copy the file into `res://vehicles/models/`, and Godot imports it into a scene you can instance.

glTF uses meters and +Y up, the same as Godot. But it defines the **front of a model as +Z**. Godot even has a constant for it, `Vector3.MODEL_FRONT = (0, 0, 1)`. This course's vehicles face **−Z** (camera forward, and north at zero rotation). So most downloaded or exported models face backwards. Fix it once, in the vehicle scene, never in the bridge:

```
Plane (Node3D, vehicle.gd)        ← the bridge sets this transform; nose must be -Z
└── Visual (Node3D)
    └── ModelFix (Node3D)          rotation_degrees = (0, 180, 0); scale if needed
        └── plane.glb (instance)   faces +Z as exported
```

Other import checks:

| Problem | Fix |
|---|---|
| model is 100× too big or small (cm vs m) | Import dock → *Root Scale*, or scale `ModelFix`, never the vehicle root |
| model origin is not the CG | move `ModelFix` so the physics CG is at the vehicle origin |
| exported from Blender sideways | in Blender's glTF exporter keep *+Y Up* on |
| hundreds of thousands of triangles | decimate. Four vehicles, many cameras and a lidar all render the same scene |

The automated tests in this course use only primitive meshes. Glb import was not part of them.

## Model scale and the 1 m reference box

Wrong scale is the most common asset bug, and it is invisible when a vehicle stands alone on a plain surface. Put a **1 m cube** next to every vehicle. Module 1 put one at the origin. The Module 2 range builder adds one beside each parking spot, labelled with the vehicle id.

Sizes used for the placeholders. They come from the JSBSim models in [`reference/code/aircraft`](../reference/code/aircraft) and from a small UGV:

| Vehicle (id) | Size | Origin height when resting (`rest_height_m`) |
|---|---|---|
| rover (1) | 0.6 × 0.9 m chassis, wheels r = 0.15 m | 0.25 m |
| quad (2) | rotors at ±0.177 m (0.5 m diagonal) | 0.08 m (legs, `quad_rpy.xml`) |
| plane (3) | span 1.6 m, chord 0.25 m | 0.12 m (nose contact, `trainer.xml`) |
| quadplane (4) | span 1.6 m, lift rotors at ±0.3 / ±0.35 m | 0.15 m (legs, `quadplane.xml`) |

How to check by eye: orbit to a low angle beside each vehicle so the box and the vehicle are the same distance from the camera. The plane's wing should be clearly longer than the box (1.6×), and the quad should be about half as wide. The automated test also checks that each box's bounding box is exactly 1 m and rests on the terrain.

## Try it

- Give the rover a cone-shaped "antenna" on top using `CylinderMesh` with `top_radius = 0`. Get the rotation right so it points up, not forward.
- Set the terrain material's roughness to 0.2 and look at the lineup from the sun's side. Why is a glossy ground a bad idea for a downward camera?
- Change the tone mapper from *Filmic* to *Linear* and compare the yellow reference box. Put it back.
- Export any small model from Blender as `.glb`, import it, and wrap it as shown above so its nose points −Z. Check with the axis marker.

## References

- Godot docs, *Standard Material 3D*: <https://docs.godotengine.org/en/stable/tutorials/3d/standard_material_3d.html>
- Godot docs, *3D lights and shadows*: <https://docs.godotengine.org/en/stable/tutorials/3d/lights_and_shadows.html>
- Godot docs, *Environment and post-processing*: <https://docs.godotengine.org/en/stable/tutorials/3d/environment_and_post_processing.html>
- Godot docs, *Importing 3D scenes*: <https://docs.godotengine.org/en/stable/tutorials/assets_pipeline/importing_3d_scenes/index.html>
- Godot docs, `Vector3.MODEL_FRONT`: <https://docs.godotengine.org/en/stable/classes/class_vector3.html>
- glTF 2.0 specification, coordinate system and units: <https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html#coordinate-system-and-units>
