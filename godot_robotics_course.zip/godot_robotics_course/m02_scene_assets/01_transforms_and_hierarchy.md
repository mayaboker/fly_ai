# 01 Node3D transforms and the parent/child hierarchy (40 min)

Every robotics frame problem is a transform problem. Where is the camera, given the vehicle pose and the mount offset? Which way is the nose? Godot answers both with one object, the `Transform3D` of each `Node3D`, and one rule: **a child's transform is relative to its parent.** If you get these two right, a sensor mount follows its vehicle with no extra code. Module 3 builds the conversions from PyBullet and JSBSim on top of exactly this.

## What a transform is

```
Transform3D = (basis, origin)
  basis   3×3 rotation (and scale): its COLUMNS are the node's local x, y, z axes
          expressed in the parent's frame
  origin  the node's position in the parent's frame (meters)

  point_in_parent = basis * point_in_node + origin
```

In GDScript:

```gdscript
var t: Transform3D = node.transform           # relative to the parent
var right: Vector3 = t.basis.x                # local +X in parent coords
var up: Vector3 = t.basis.y
var back: Vector3 = t.basis.z                 # local +Z; the node LOOKS along -basis.z
var p: Vector3 = t.origin                     # same as node.position
```

The convenience properties all edit that one transform:

| Property | Meaning | Note |
|---|---|---|
| `position` | `transform.origin` | meters, in the parent frame |
| `rotation` | Euler angles, radians | default order **YXZ**: yaw about Y, then pitch about X, then roll about Z |
| `rotation_degrees` | same in degrees | handy in the Inspector |
| `quaternion` | the rotation as `Quaternion(x, y, z, w)` | the bridge uses this (Module 4) |
| `scale` | per-axis scale | keep it 1 on anything physics will place |
| `basis` | the 3×3 matrix | the safest way to set orientation from computed data |

Euler angles are fine for typing a pose into the Inspector. For computed poses, set `basis` or `quaternion` directly. Euler angles have a singularity at ±90° pitch, and adding angles is not the same as composing rotations.

## Local and global

Every `Node3D` also has `global_transform`, `global_position` and `global_basis`, which are relative to the **world**:

```
global_transform(child) = global_transform(parent) * transform(child)
```

```
Main (identity)
└── Vehicles (identity)
    └── Plane              transform = T_world_plane       ← set by the bridge from Module 4 on
        ├── Visual          meshes, fixed offsets
        ├── Body            StaticBody3D, collision box
        └── Mounts
            └── fpv_cam     transform = T_plane_cam        ← fixed mount offset
                            global    = T_world_plane * T_plane_cam
```

The mount's offset is set once, when the vehicle scene is built. The vehicle's pose changes every frame. Godot multiplies them for you. That is why every sensor and camera in this course is a **child of a mount**. Module 6 puts a `Camera3D` under `Mounts/fpv_cam` and never computes a camera pose by hand.

Useful helpers:

```gdscript
var p_world := vehicle.to_global(Vector3(0, 0, -0.5))    # a point 0.5 m ahead of the CG, in world
var p_local := vehicle.to_local(gate.global_position)    # where is the gate, seen from the vehicle?
var fwd := -mount.global_basis.z                          # where a mount looks, in world
```

## Moving and turning: which axes?

| Call | Rotates about | Use |
|---|---|---|
| `rotate_y(a)` / `rotate(axis, a)` | an axis in the **parent** frame | yaw a vehicle about world up |
| `rotate_object_local(axis, a)` | an axis in the node's **own** frame | pitch the nose up about the wing axis |
| `global_basis = Basis(axis, a) * global_basis` | a **world** axis through the node | roll about the current forward vector |
| `look_at(target, up)` | turns the node's −Z toward `target` | aim a camera |

Angles are radians, and positive means counter-clockwise when you look *down the axis toward the origin* (right-hand rule). Two consequences that the Module 2 test checks:

- **Roll.** Rotating the plane by +30° about its **forward** vector (−Z, the nose direction) puts the right wing (+X) **down**. That is the same sign as aerospace roll φ in FRD. The test measured the right tip 0.80 m below the left: `1.6 m · sin 30°`.
- **Pitch.** `rotate_object_local(Vector3.RIGHT, +20°)` lifts the nose. The test saw `fpv_cam`'s forward vector get y = +0.34 (= sin 20°).

## Compass heading → rotation about Y

Maps, `range.json` and pilots use compass heading ψ: 0° = north, 90° = east, increasing **clockwise** seen from above. Godot's rotation about +Y is **counter-clockwise** seen from above, and a node with zero rotation faces −Z = north. So:

```gdscript
node.rotation.y = -deg_to_rad(heading_deg)      # compass heading -> Godot yaw
```

Check: ψ = 90°. The node's −Z goes to `(-sin(-90°), 0, -cos(-90°)) = (+1, 0, 0)` = east. This is the same `-psi` you see in the JSBSim shortcut in [frames.md](../reference/frames.md), `Basis.from_euler(Vector3(theta, -psi, -phi))`. `Vehicle.place_on_ground()` and the gate builder both use it, and the test checks that a rover turned to heading 90° has its `fpv_cam` looking along +X.

| Heading ψ | Godot `rotation.y` | Model −Z points to |
|---:|---:|---|
| 0° (north) | 0 | −Z |
| 90° (east) | −π/2 | +X |
| 180° (south) | ±π | +Z |
| 270° (west) | +π/2 | −X |

## ENU ↔ Godot positions

Every data file in the course is in ENU meters. The one conversion you need in this module is the position mapping from [frames.md](../reference/frames.md):

```gdscript
func enu_to_godot(e: float, n: float, u: float) -> Vector3:
	return Vector3(e, u, -n)
```

`RangeBuilder.ground(e, n)` does exactly this, with `u` taken from the terrain height.

## Scale: keep it at 1

Scale lives in the basis, so it is multiplied down the hierarchy. A vehicle root scaled by 2 doubles every mount offset, every collision box and every camera position, and `global_basis` is no longer a pure rotation. The quaternion you send over the bridge would then be wrong. Rules for this course:

- Never scale a vehicle root, a mount or anything the bridge places.
- If an imported mesh has the wrong size, scale the **mesh node** under `Visual`, or fix it in the import settings ([02](02_meshes_materials_lights.md)).
- After you compose many rotations in a loop, call `basis = basis.orthonormalized()` to remove numerical drift.

## Try it

- Select `Vehicles/Plane` in the running scene (Remote tab). Set `rotation_degrees = (0, -90, 0)` and confirm it points east. Then set `(0, 0, -30)`. Which wing goes down? Explain the sign using the right-hand rule about +Z.
- In `main.gd`, print `Vehicles/Rover/Mounts/fpv_cam`'s `global_position` before and after `rover.position.x += 1`. The mount moves with no code of its own.
- Write `heading_of(node: Node3D) -> float` that returns the compass heading in degrees from `-node.global_basis.z`. Test it on 0, 90, 180 and 270.
- Scale `Vehicles/Quad` by 2 in the Remote inspector and print `quaternion` and `global_basis.x.length()`. Then put it back to 1.

## References

- Godot docs, *Using 3D transforms*: <https://docs.godotengine.org/en/stable/tutorials/3d/using_transforms.html>
- Godot docs, `Node3D`: <https://docs.godotengine.org/en/stable/classes/class_node3d.html>
- Godot docs, *Matrices and transforms*: <https://docs.godotengine.org/en/stable/tutorials/math/matrices_and_transforms.html>
- Course: [frames cheat sheet](../reference/frames.md)
