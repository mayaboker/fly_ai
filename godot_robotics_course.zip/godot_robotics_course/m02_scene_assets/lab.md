# Lab 2: The test range (130 min)

You replace the Module 1 grid with the shared terrain. You build the range on it (road, pad, gates, obstacles), add the four vehicles with their sensor mounts, and prove that Godot and Python read the same ground. The finished files are in [code/](code/), laid out like `robosim/`.

## Files

| File | New / changed |
|---|---|
| `tools/make_heightmap.py`, `tools/compare_heights.py` | new |
| `data/terrain/heightmap.png`, `heightmap.json`, `range.json` | new (generated, commit them) |
| `physics/robosim/terrain.py`, `physics/tests/test_terrain.py` | new (a new module in the shared package; nothing existing changes) |
| `godot/project.godot` | changed: layer names |
| `godot/terrain/png16.gd`, `godot/terrain/heightmap_terrain.gd` | new |
| `godot/world/range_builder.gd` | new |
| `godot/vehicles/vehicle.gd`, `godot/vehicles/build_vehicles.gd` | new |
| `godot/vehicles/rover.tscn`, `quad.tscn`, `plane.tscn`, `quadplane.tscn` | new (generated) |
| `godot/main.tscn`, `godot/main.gd` | changed: Ground and DemoSpinner removed; Terrain, Range, Vehicles added |
| `godot/tests/test_m02.gd` | new |
| `godot/world/ground_grid.gd`, `world/demo_spinner.gd`, `tests/test_m01.gd` | deleted (Module 1 only; git keeps them) |

## Step 1: Generate the terrain (Python)

```bash
cd ~/robosim
source ~/robosim-venv/bin/activate
cp <course>/m02_scene_assets/code/tools/make_heightmap.py tools/
python tools/make_heightmap.py
```

Expected:

```
wrote data/terrain/heightmap.png (257x257, seed 42)
height min 0.000 m  max 18.958 m  center 0.000 m
```

Read the generator top to bottom ([04](04_terrain_heightmap.md) explains it). Find the `LAYOUT` dictionary. It is the only place where roads, gates and obstacles are defined.

## Step 2: The Python sampler and its test

```bash
cp <course>/m02_scene_assets/code/physics/robosim/terrain.py   physics/robosim/
cp <course>/m02_scene_assets/code/physics/tests/test_terrain.py physics/tests/
cd physics && python tests/test_terrain.py
```

Expected:

```
terrain: all tests pass (seeded, 16-bit, center origin, row 0 = north, bilinear); worst road cross-height 0.218 m
```

Then try the sampler interactively:

```python
>>> from robosim.terrain import Heightmap
>>> hm = Heightmap.load("../data/terrain/heightmap.png")
>>> round(hm.height_at(37.3, -12.6), 4), round(hm.height_at(0, 0), 4)
(0.6476, 0.0)
```

## Step 3: Collision layer names

In Godot: *Project Settings → Layer Names → 3D Physics*. Name layer 1 `terrain`, 2 `obstacles`, 3 `vehicles`, 4 `gates`. In `project.godot` this adds a `[layer_names]` section.

## Step 4: The terrain node

1. Copy `terrain/png16.gd` and `terrain/heightmap_terrain.gd` into `godot/terrain/`. Close the editor and run `~/tools/godot --headless --path ~/robosim/godot --import` (new `class_name`s), then reopen.
2. In `main.tscn`, delete `World/Ground` and `World/DemoSpinner`. Delete the files `world/ground_grid.gd`, `world/demo_spinner.gd` and `tests/test_m01.gd` too. The Module 2 test replaces the Module 1 test.
3. Add a `Node3D` named `Terrain` as the **first** child of `World`, and attach `heightmap_terrain.gd`. Because the script is `@tool`, the terrain appears in the editor viewport. Its default `heightmap_path` is `../data/terrain/heightmap.png`, relative to the Godot project folder.
4. Select `Sun` and set *Directional Shadow → Max Distance* to 200 m.

Run (F5) and fly around. The yellow cube and the axis marker from Module 1 still stand at the origin. The origin is on the 0 m apron, so they still sit on the ground.

## Step 5: The range

1. Copy `world/range_builder.gd`.
2. Add a `Node3D` named `Range` under `World`, **after** `Terrain`, and attach the script.
3. In the Inspector, set its `Terrain` property to the `Terrain` node (click *Assign…*).

The roads, pad, gates, obstacles and four reference boxes appear in the editor. Check two things by eye: the road loop goes all around the pad, and the gates are **north** of the pad (toward the `-Z North` label). If the gates are south, your terrain or layout is mirrored. Recheck the row rule in [04](04_terrain_heightmap.md).

## Step 6: The vehicles

1. Copy `vehicles/vehicle.gd` and `vehicles/build_vehicles.gd`. Run `--import` once, then generate:

   ```bash
   cd ~/robosim/godot
   ~/tools/godot --headless --path . --import
   ~/tools/godot --headless --path . -s vehicles/build_vehicles.gd
   ```

   Expect four `-> res://vehicles/<kind>.tscn (OK)` lines. Run it again and check with `git status` or `md5sum` that nothing changed.
2. Open `vehicles/plane.tscn` in the editor. Click `Mounts/down_cam` and look at its gizmo. Turn on *Debug → Visible Collision Shapes* (affects running games) and remember to look for the `Body` box later.
3. In `main.tscn`, add a `Node3D` named `Vehicles` as a child of `Main`. Drag the four `.tscn` files from the FileSystem dock onto it. Name the instances `Rover`, `Quad`, `Plane`, `QuadPlane`.

## Step 7: `main.gd` and the cameras

Replace `main.gd` with [the Module 2 version](code/godot/main.gd). The new parts:

```gdscript
@onready var terrain: HeightmapTerrain = $World/Terrain
@onready var range_builder: RangeBuilder = $World/Range

func _ready() -> void:
	park_vehicles()                 # put ids 1-4 on their lineup spots, nose north
	_set_camera(0)
```

`reset()` now calls `park_vehicles()` too, and the status line adds the camera's height above the ground.

Set the camera start poses for a view of the whole range:

| Node | Property | Value |
|---|---|---|
| `Cameras/FreeFly` | Position / Rotation | (35, 25, 45) / x = −19.8°, y = 30.3° (looks at the apron from the south-east) |
| `Cameras/Orbit` | Target, Distance, Yaw Deg, Pitch Deg | (1, 0.5, 12), 12, 20, −22 (looks at the lineup) |

Run it. Press `C` for the lineup view. Compare with these reference images, rendered by the test:

| FreeFly start | Orbit start (lineup) |
|---|---|
| ![overview](img/range_overview.png) | ![lineup](img/range_lineup.png) |

## Step 8: The automated checks

```bash
cd ~/robosim/godot
cp <course>/m02_scene_assets/code/godot/tests/test_m02.gd tests/
~/tools/godot --headless --path . --import
~/tools/godot --headless --path . -s tests/test_m02.gd
```

Expected output (our run; the build time will differ):

```
PASS  terrain 257 x 257 loaded from 16-bit PNG
terrain: PNG read + mesh + shape built in 134 ms
PASS  terrain collision on layer 1 (terrain)
HEIGHT e=37.300 n=-12.600 direct=0.647581 ray=0.647949
HEIGHT e=-55.500 n=41.200 direct=2.739971 ray=2.740295
HEIGHT e=101.700 n=-88.300 direct=3.386358 ray=3.386047
PASS  raycast within 5 cm of bilinear lookup (worst 0.0004 m)
PASS  Rover has vehicle_id 1
PASS  Rover has Marker3D mounts ["fpv_cam", "down_cam", "imu", "range"]
PASS  Rover fpv_cam is at the front and looks along -Z (north)
PASS  Rover down_cam looks down, image top toward the nose
PASS  Rover rests on the ground (lowest point -0.000 m, ground 0.000 m)
PASS  Rover heading 90: fpv_cam looks east (+X)
   ... the same six lines for Quad, Plane and QuadPlane ...
PASS  plane rolled right: right tip 0.80 m below left tip
PASS  plane pitched up: fpv_cam looks up (y = 0.34)
PASS  park_vehicles() restores the pose
PASS  RefBox_rover is 1 m and on the ground
   ... RefBox_quad, RefBox_plane, RefBox_quadplane ...
PASS  3 gates in group 'gates'
PASS  6 obstacles in group 'obstacles'
PASS  4 vehicles in group 'vehicles'
PASS  a ray on layer 4 (gates) hits gate_1's posts
PASS  a ray on layer 3 (vehicles) hits the rover, not the terrain
PASS  axis labels match reference/frames.md
M02 RESULT: PASS (0 failed)
```

Then the cross-engine height check, from `robosim/`:

```bash
cp <course>/m02_scene_assets/code/tools/compare_heights.py tools/
python tools/compare_heights.py --godot ~/tools/godot
```

```
       E        N |    python     godot  diff mm |   raycast  diff mm
   37.30   -12.60 |    0.6476    0.6476    0.000 |    0.6479     0.37
  -55.50    41.20 |    2.7400    2.7400   -0.000 |    2.7403     0.32
  101.70   -88.30 |    3.3864    3.3864   -0.000 |    3.3860    -0.31
tolerance: lookup 0.305 mm, raycast 50 mm  ->  PASS
```

Pick three points of your own with `--points "e,n;e,n;e,n"`, including one on the steep border hills (|E| or |N| > 100). Explain why the raycast column can differ by centimeters there while the lookup column stays at zero.

Optional: render the reference images yourself (needs `xvfb-run`):

```bash
xvfb-run -a -s "-screen 0 1280x720x24" ~/tools/godot --path . --rendering-driver opengl3 \
    -s tests/test_m02.gd -- --shots=/tmp/range
```

## Step 9: Commit

```bash
cd ~/robosim
git add -A && git commit -m "Module 2: shared terrain, test range, vehicle scenes"
```

Commit `data/terrain/*` and the generated `.tscn` files **and** their generators. Anyone can regenerate them, but a commit records exactly what your tests ran against.

## Check

The full list is in the [module README](README.md#check). In short:

1. `python tests/test_terrain.py` passes.
2. `test_m02.gd` prints `M02 RESULT: PASS (0 failed)`: ids, mounts, nose −Z, resting on the ground, parent transforms (heading 90 → east, roll → right tip down), 1 m reference boxes, layers.
3. `compare_heights.py` passes at three points: Godot lookup = Python within 0.3 mm; raycast within 5 cm. The PyBullet heightfield comparison is Module 9's Check.
4. By eye: every vehicle looks right next to its 1 m box. The plane's green tip is on its right, the fin is up, and the nose points north.

## Stretch goals

- Add `heading_deg` to each lineup entry in `LAYOUT` and make `park_vehicles()` use it. Park the plane facing the road's south straight (heading 90).
- Add a windsock (cylinder + cone) at the pad edge that points along a `wind_from_deg` value stored in `range.json`. Module 11 can feed it the JSBSim wind later.
- Build a simple 10 m tall "tree" obstacle type (trunk + sphere crown) and add three to the layout.
- Import a real `.glb` model for the rover. Wrap it in a `ModelFix` node so its nose points −Z, then delete the placeholder meshes but keep the mounts and the `Body`.
- Write a Python script that plots `heightmap.png` with the road, gates and obstacles from `range.json` on top (matplotlib, `extent=[-128, 128, -128, 128]`, origin upper). Check it against the top view [img/range_high.png](img/range_high.png). Mind that row 0 is north.
