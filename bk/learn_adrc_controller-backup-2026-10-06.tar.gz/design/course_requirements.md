# ADRC Controller Course Requirements

## Learner profile

- The learner has about five years of Python experience.
- The course must refresh the physics and mathematics needed for each topic.
- The course assumes no prior ADRC knowledge.

## Course goal

Teach active disturbance rejection control (ADRC) from first principles to a
simulation-only drone controller. The learner should understand the physical
model, derive the mathematics, implement the controller in Python, and explain
the design choices and limitations.

The final required project uses PyBullet. Earlier examples use plain Python,
NumPy, and Matplotlib so the equations and state updates remain visible.

## Teaching requirements

Every module must include:

1. A physical intuition and the relevant physics refresher.
2. The mathematics needed for that module, including units and assumptions.
3. Full transformations where applicable:
   differential equation → transfer function → state-space model →
   discrete-time update.
4. A small runnable NumPy/Matplotlib example.
5. A hands-on exercise that changes or extends the example.
6. An option-based checkpoint quiz immediately after the math and physics
   explanation, plus 3–5 option-based lesson checkpoint questions.
7. A link to the prerequisite and next topic.

Use explicit equations and controller code. Do not hide the main ideas behind
a control-systems library. Start numerical integration with explicit Euler,
then introduce RK4 when accuracy or stability requires it.

## Required progression

### Module 1 — Simulation and physical modeling

Refresh Python simulation patterns, units, signals, time steps, state, input,
output, and disturbance. Build a simple plant simulator and visualize its
response.

### Module 2 — First-order systems

Use thermal, tank-level, or similar systems to introduce balance laws,
derivatives, time constants, equilibrium, actuator limits, setpoint tracking,
and constant disturbances. Implement a basic feedback controller.

### Module 3 — Second-order systems

Use a mass–spring–damper system to refresh Newton’s laws, force, acceleration,
damping, stiffness, resonance, and numerical integration. Compare open-loop
and closed-loop behavior.

### Module 4 — System representations

Derive and verify the conversion between physical differential equations,
transfer functions, state-space equations, and discrete-time updates. Explain
what each representation reveals and when to use it.

### Module 5 — Linear ADRC

Introduce the ADRC viewpoint, total disturbance, tracking differentiation,
linear state-error feedback, and the linear extended state observer (LESO).
Apply LADRC to the earlier first- and second-order plants.

### Module 6 — Motor and rotational systems

Model a DC motor and a simple rotational body. Refresh electrical dynamics,
torque, inertia, angular velocity, angular acceleration, and the relationship
between torque and angle. Apply LADRC to speed and angle control.

### Module 7 — Cascade ADRC

Explain inner and outer loops, bandwidth separation, loop interaction, and
signal flow. Build cascades such as current/torque → speed → position and
angular rate → angle. Include tuning and failure examples.

### Module 8 — Nonlinear ADRC

After the LADRC foundation is solid, introduce nonlinear tracking and
feedback functions, nonlinear disturbance estimation, tuning differences, and
the trade-offs between LADRC and NLADRC.

### Module 9 — Coupled rotational systems

Use a pendulum, reaction-wheel or gimbal system, and a two-axis rotational
system to introduce gravity, coupled axes, nonlinear behavior, and the bridge
from single-axis control to drone attitude control.

### Module 10 — Drone-control preparation

Explain the drone rigid-body model, thrust, torque, mass, inertia, body and
world frames, attitude representation, motor mixing, sensors, and control
loop timing. Derive the altitude and attitude control signals before using
PyBullet.

## Required capstone — PyBullet drone control

Begin with an intentionally simple and informative demo: drone takeoff and
hover without disturbances. The first demo must emphasize the physics and
mathematics: weight, thrust balance, vertical acceleration, integration,
altitude error, and the control signal needed to reach and hold a target
altitude.

Then extend the same project to:

- altitude control;
- roll, pitch, and yaw attitude control;
- LADRC and NLADRC comparison;
- comparison with a baseline PID controller;
- deterministic wind-gust disturbances, including step, pulse, and ramped
  gusts;
- plots of tracking error, control effort, attitude, altitude, and disturbance
  estimates;
- a written explanation of the model, assumptions, tuning, and limitations.

Position control is optional and is not part of the required capstone.

## Tooling

- Core tools: Python, NumPy, and Matplotlib.
- Use PyBullet only for the final drone capstone.
- Keep simulations reproducible with fixed time steps and documented
  parameters.
- Prefer transparent, handwritten model and controller updates over opaque
  abstractions.
