# ADRC Simulation Learning

This course teaches active disturbance rejection control through repeatable
simulations and evidence from plots. Mathematical derivations are optional
reference material, not prerequisites for the main learning path.

## Learning approach

**Experiment-first learning**:
Learners change one simulator setting, predict the result, run the experiment,
and explain the plotted evidence before introducing an implementation detail.
_Avoid_: derivation-first learning, equation-first learning

**Experiment**:
A runnable, controlled simulator scenario with one question to answer, one or
more settings to change, and a plot or measurable result to interpret.
_Avoid_: example, demo

**Evidence**:
A visible behavior in a plot or a recorded metric that supports a conclusion
about a controller setting or disturbance.
_Avoid_: proof (on the main learning path)

**Target**:
The value the controller is asked to reach, such as a requested altitude.
_Avoid_: desired output

**Measurement**:
The value the controller receives from the plant, such as measured altitude.
_Avoid_: ground truth

**Command**:
The controller output sent to the plant to influence its behavior, such as an
upward force request.
_Avoid_: control action (on the main learning path)

**Timestep**:
The simulated time between consecutive plant updates.
_Avoid_: frame rate

**Fair comparison**:
Two or more runs that differ in exactly the factor the experiment intends to
test, while target, starting state, duration, timestep, and all other stated
conditions remain the same.
_Avoid_: a comparison where several settings changed

**Physical property**:
A plant characteristic that changes its motion, such as mass, drag, gravity,
or available thrust.
_Avoid_: controller setting

**Thrust limit**:
The greatest upward force the actuator can apply. It can represent a maximum
motor RPM, propeller capability, or available battery power.
_Avoid_: requested command

**Drag**:
A force that opposes motion through the environment and grows with velocity in
this course's simple vertical-plant experiments.
_Avoid_: disturbance estimate

## Control concepts

**Plant**:
The simulated system being controlled, such as the drone's vertical motion.
_Avoid_: model, process

**Baseline controller**:
A feedback controller that reacts to tracking error but does not estimate and
cancel unknown effects. It is the comparison point for ADRC experiments.
_Avoid_: ordinary ADRC

**Disturbance**:
Any effect on plant behavior that the controller did not plan for, including a
wind force, an incorrect mass assumption, or actuator loss.
_Avoid_: noise (unless it specifically means a corrupted measurement)

**Disturbance estimate**:
The controller's running estimate of the combined unplanned effect acting on
the plant.
_Avoid_: exact disturbance measurement

**Observer**:
The ADRC component that maintains estimates of motion and disturbance from the
available measurement and recent control actions.
_Avoid_: sensor

**ADRC controller**:
A feedback controller that uses an observer's disturbance estimate to counter
unknown effects while following a target.
_Avoid_: perfect model controller

**Reaction setting**:
A learner-facing tuning control for how strongly the controller corrects a
tracking error.
_Avoid_: controller bandwidth (on the main learning path)

**Detection setting**:
A learner-facing tuning control for how rapidly the observer updates its
disturbance estimate.
_Avoid_: observer bandwidth (on the main learning path)
