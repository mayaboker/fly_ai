"""Run one repeatable vertical-motion simulator experiment.

Change one command-line argument per experiment and compare the saved plots.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mass", type=float, default=1.0, help="plant mass in kg")
    parser.add_argument("--dt", type=float, default=0.01, help="simulation timestep in s")
    parser.add_argument("--reaction", type=float, default=3.0, help="controller reaction setting")
    parser.add_argument("--output", type=Path, default=Path("simulator_signals.png"))
    args = parser.parse_args()
    if args.mass <= 0 or args.dt <= 0 or args.reaction <= 0:
        parser.error("mass, dt, and reaction must be positive")
    return args


def run(mass: float, dt: float, reaction: float) -> tuple[np.ndarray, ...]:
    # --8<-- [start:signal-update-loop]
    duration = 8.0
    target = 3.0
    times = np.arange(0.0, duration + dt, dt)
    altitude = np.zeros_like(times)
    velocity = np.zeros_like(times)
    command = np.zeros_like(times)
    disturbance = np.zeros_like(times)

    for index in range(len(times) - 1):
        disturbance[index] = -1.5 if times[index] >= 2.0 else 0.0
        error = target - altitude[index]
        command[index] = reaction * error - 1.2 * velocity[index]
        acceleration = (command[index] + disturbance[index]) / mass
        velocity[index + 1] = velocity[index] + acceleration * dt
        altitude[index + 1] = altitude[index] + velocity[index + 1] * dt

    disturbance[-1] = disturbance[-2]
    command[-1] = command[-2]
    return times, altitude, command, disturbance
    # --8<-- [end:signal-update-loop]


def plot(results: tuple[np.ndarray, ...], output: Path, mass: float, dt: float) -> None:
    # --8<-- [start:plot-signals]
    times, altitude, command, disturbance = results
    target = np.full_like(times, 3.0)
    figure, axes = plt.subplots(3, 1, figsize=(9, 8), sharex=True)
    axes[0].plot(times, target, "k--", label="target")
    axes[0].plot(times, altitude, label="measurement")
    axes[0].set_ylabel("altitude (m)")
    axes[0].legend()
    axes[1].plot(times, command, color="tab:orange", label="command")
    axes[1].set_ylabel("force request (N)")
    axes[1].legend()
    axes[2].plot(times, disturbance, color="tab:red", label="disturbance")
    axes[2].set_ylabel("force (N)")
    axes[2].set_xlabel("simulated time (s)")
    axes[2].legend()
    figure.suptitle(f"Signals in one experiment: mass={mass:.2f} kg, timestep={dt:.3f} s")
    figure.tight_layout()
    figure.savefig(output, dpi=160)
    # --8<-- [end:plot-signals]


def main() -> None:
    args = parse_args()
    results = run(args.mass, args.dt, args.reaction)
    final_error = 3.0 - results[1][-1]
    plot(results, args.output, args.mass, args.dt)
    print(f"Final tracking error: {final_error:.3f} m")
    print(f"Saved plot: {args.output}")


if __name__ == "__main__":
    main()
