"""Compare baseline feedback and ADRC in one repeatable hover experiment.

Run this file before reading its implementation.  The exposed settings are
deliberately named for the experiment: ``reaction`` controls how firmly the
controller returns to target, and ``detection`` controls how quickly ADRC
updates its estimate of an unplanned effect.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


@dataclass
class Trial:
    """Signals recorded during one controller trial."""

    time: np.ndarray
    altitude: np.ndarray
    correction: np.ndarray
    disturbance_estimate: np.ndarray


def disturbance(time: float, gust: float) -> float:
    """Return a downward gust after the hover has settled."""
    return gust if 4.0 <= time < 7.0 else 0.0


def run_trial(*, use_adrc: bool, reaction: float, detection: float, gust: float) -> Trial:
    """Run the shared plant with either baseline feedback or ADRC enabled."""
    # --8<-- [start:trial-loop]
    assumed_mass = 1.5
    actual_mass = 1.8  # Deliberate model mismatch; both controllers get this wrong.
    gravity = 9.81
    target = 3.0
    timestep = 0.005
    time = np.arange(0.0, 10.0, timestep)

    altitude = np.zeros_like(time)
    velocity = np.zeros_like(time)
    correction = np.zeros_like(time)
    disturbance_estimate = np.zeros_like(time)

    # Internal observer memory. Learners tune its behavior through detection,
    # not through these implementation details.
    estimated_altitude = 0.0
    estimated_velocity = 0.0
    estimated_disturbance = 0.0
    kp = reaction**2
    kd = 2.0 * reaction
    beta1 = 3.0 * detection
    beta2 = 3.0 * detection**2
    beta3 = detection**3

    for index in range(1, len(time)):
        measurement = altitude[index - 1]
        measurement_error = measurement - estimated_altitude

        if use_adrc:
            estimated_altitude += timestep * (estimated_velocity + beta1 * measurement_error)
            estimated_velocity += timestep * (
                correction[index - 1] + estimated_disturbance + beta2 * measurement_error
            )
            estimated_disturbance += timestep * beta3 * measurement_error
            feedback_altitude = estimated_altitude
            feedback_velocity = estimated_velocity
        else:
            feedback_altitude = measurement
            feedback_velocity = velocity[index - 1]

        desired_change = kp * (target - feedback_altitude) - kd * feedback_velocity
        estimated_effect = estimated_disturbance if use_adrc else 0.0
        correction[index] = np.clip(desired_change - estimated_effect, -8.0, 8.0)

        thrust = assumed_mass * (gravity + correction[index])
        acceleration = thrust / actual_mass - gravity + disturbance(time[index], gust) / actual_mass
        velocity[index] = velocity[index - 1] + acceleration * timestep
        altitude[index] = max(0.0, altitude[index - 1] + velocity[index] * timestep)
        if altitude[index] == 0.0 and velocity[index] < 0.0:
            velocity[index] = 0.0
        disturbance_estimate[index] = estimated_disturbance

    return Trial(time, altitude, correction, disturbance_estimate)
    # --8<-- [end:trial-loop]


def late_error(trial: Trial, target: float = 3.0) -> float:
    """Return mean absolute error after the gust has finished."""
    return float(np.mean(np.abs(trial.altitude[trial.time >= 8.0] - target)))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reaction", type=float, default=1.6, help="How firmly to return to target (default: 1.6).")
    parser.add_argument("--detection", type=float, default=6.4, help="How quickly ADRC updates its estimate (default: 6.4).")
    parser.add_argument("--gust", type=float, default=-4.0, help="Downward gust force in N (default: -4).")
    return parser.parse_args()


def main() -> None:
    # --8<-- [start:comparison-and-report]
    args = parse_args()
    if args.reaction <= 0 or args.detection <= 0:
        raise SystemExit("--reaction and --detection must be positive.")

    baseline = run_trial(use_adrc=False, reaction=args.reaction, detection=args.detection, gust=args.gust)
    adrc = run_trial(use_adrc=True, reaction=args.reaction, detection=args.detection, gust=args.gust)
    assert late_error(adrc) < late_error(baseline), "Default experiment should show ADRC improving late recovery."

    figure, axes = plt.subplots(3, 1, sharex=True, figsize=(9, 8))
    axes[0].plot(baseline.time, baseline.altitude, label="Baseline feedback")
    axes[0].plot(adrc.time, adrc.altitude, label="ADRC")
    axes[0].axhline(3.0, color="black", linestyle="--", label="Target")
    axes[0].axvspan(4.0, 7.0, color="tab:gray", alpha=0.15, label="Downward gust")
    axes[0].set_ylabel("Altitude (m)")
    axes[0].legend(loc="best")

    axes[1].plot(baseline.time, baseline.correction, label="Baseline feedback")
    axes[1].plot(adrc.time, adrc.correction, label="ADRC")
    axes[1].axvspan(4.0, 7.0, color="tab:gray", alpha=0.15)
    axes[1].set_ylabel("Control correction")
    axes[1].legend(loc="best")

    axes[2].plot(adrc.time, adrc.disturbance_estimate, color="tab:green")
    axes[2].axvspan(4.0, 7.0, color="tab:gray", alpha=0.15)
    axes[2].set_ylabel("ADRC estimate")
    axes[2].set_xlabel("Time (s)")
    figure.suptitle("Experiment: baseline feedback versus ADRC")
    figure.tight_layout()

    output = Path(__file__).with_name("adrc_disturbance_experiment.png")
    figure.savefig(output, dpi=140)
    print(f"Saved {output}")
    print(f"Baseline late-test error: {late_error(baseline):.3f} m")
    print(f"ADRC late-test error:     {late_error(adrc):.3f} m")
    # --8<-- [end:comparison-and-report]


if __name__ == "__main__":
    main()
