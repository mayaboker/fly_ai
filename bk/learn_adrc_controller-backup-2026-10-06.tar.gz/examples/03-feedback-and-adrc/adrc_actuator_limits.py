"""Compare naive and saturation-aware ADRC under a maximum thrust correction.

``--max-correction`` is a learner-facing proxy for a motor RPM/thrust limit.
The aware controller feeds the applied, clamped correction back into its
observer; the naive controller feeds back the unavailable requested correction.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


TARGET = 3.0
TARGET_START = 0.5
PAYLOAD_TIME = 4.0
DURATION = 8.0
TIMESTEP = 0.01
ASSUMED_MASS = 1.0
PAYLOAD_MASS = 1.4
GRAVITY = 9.81
TARGET_BAND = 0.10


class ADRCController:
    """Compact ADRC with an optional applied-command observer input."""

    # --8<-- [start:saturation-aware-controller]
    def __init__(self, reaction: float, detection: float, use_applied_command: bool) -> None:
        self.reaction_gain = reaction**2
        self.damping_gain = 2.0 * reaction
        self.beta1 = 3.0 * detection
        self.beta2 = 3.0 * detection**2
        self.beta3 = detection**3
        self.use_applied_command = use_applied_command
        self.estimated_altitude = 0.0
        self.estimated_velocity = 0.0
        self.estimated_disturbance = 0.0
        self.observer_command = 0.0

    def request_correction(self, measurement: float, target: float) -> float:
        measurement_error = measurement - self.estimated_altitude
        # The observer must predict from the command the plant could receive.
        # Saturation-aware ADRC uses the applied command on the next update.
        self.estimated_altitude += TIMESTEP * (
            self.estimated_velocity + self.beta1 * measurement_error
        )
        self.estimated_velocity += TIMESTEP * (
            self.observer_command
            + self.estimated_disturbance
            + self.beta2 * measurement_error
        )
        self.estimated_disturbance += TIMESTEP * self.beta3 * measurement_error
        desired_change = (
            self.reaction_gain * (target - self.estimated_altitude)
            - self.damping_gain * self.estimated_velocity
        )
        return desired_change - self.estimated_disturbance

    def record_applied_command(self, requested: float, applied: float) -> None:
        # Feeding back an impossible request makes the observer predict motion
        # the saturated actuator could not create.
        self.observer_command = applied if self.use_applied_command else requested
    # --8<-- [end:saturation-aware-controller]


@dataclass
class Trial:
    time: np.ndarray
    target: np.ndarray
    altitude: np.ndarray
    requested: np.ndarray
    applied: np.ndarray
    disturbance_estimate: np.ndarray


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reaction", type=float, default=2.2)
    parser.add_argument("--detection", type=float, default=6.4)
    parser.add_argument("--max-correction", type=float, default=5.0, help="maximum available correction in m/s²")
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("adrc_actuator_limits.png"))
    args = parser.parse_args()
    if args.reaction <= 0 or args.detection <= 0 or args.max_correction <= 0:
        parser.error("reaction, detection, and max correction must be positive")
    return args


def run_trial(*, reaction: float, detection: float, max_correction: float, use_applied_command: bool) -> Trial:
    """Run one controller while the plant enforces the correction limit."""
    # --8<-- [start:actuator-limit-loop]
    controller = ADRCController(reaction, detection, use_applied_command)
    time = np.arange(0.0, DURATION + TIMESTEP, TIMESTEP)
    target = np.where(time >= TARGET_START, TARGET, 0.0)
    altitude = np.zeros_like(time)
    velocity = np.zeros_like(time)
    requested = np.zeros_like(time)
    applied = np.zeros_like(time)
    disturbance_estimate = np.zeros_like(time)

    for index in range(len(time) - 1):
        requested[index + 1] = controller.request_correction(altitude[index], target[index])
        # This clamp is the actuator boundary: requested and applied differ
        # whenever the maximum RPM/thrust proxy has been reached.
        applied[index + 1] = np.clip(
            requested[index + 1], -max_correction, max_correction
        )
        controller.record_applied_command(requested[index + 1], applied[index + 1])

        actual_mass = PAYLOAD_MASS if time[index] >= PAYLOAD_TIME else ASSUMED_MASS
        thrust = ASSUMED_MASS * (GRAVITY + applied[index + 1])
        acceleration = thrust / actual_mass - GRAVITY
        velocity[index + 1] = velocity[index] + acceleration * TIMESTEP
        altitude[index + 1] = max(0.0, altitude[index] + velocity[index + 1] * TIMESTEP)
        if altitude[index + 1] == 0.0 and velocity[index + 1] < 0.0:
            velocity[index + 1] = 0.0
        disturbance_estimate[index + 1] = controller.estimated_disturbance

    return Trial(time, target, altitude, requested, applied, disturbance_estimate)
    # --8<-- [end:actuator-limit-loop]


def recovery_time(trial: Trial) -> float | None:
    start_index = int(np.searchsorted(trial.time, PAYLOAD_TIME))
    within_band = np.abs(trial.target - trial.altitude) <= TARGET_BAND
    for index in range(start_index, len(trial.time)):
        if np.all(within_band[index:]):
            return float(trial.time[index] - PAYLOAD_TIME)
    return None


def saturation_time(trial: Trial) -> float:
    return float(np.count_nonzero(np.abs(trial.requested - trial.applied) > 1e-9) * TIMESTEP)


def recovery_label(trial: Trial) -> str:
    recovery = recovery_time(trial)
    return f"{recovery:.3f} s" if recovery is not None else "not reached"


def report_metrics(naive: Trial, aware: Trial, max_correction: float) -> None:
    # --8<-- [start:limit-evidence]
    required_hover = GRAVITY * (PAYLOAD_MASS / ASSUMED_MASS - 1.0)
    print(f"Maximum correction: {max_correction:.3f} m/s²")
    print(f"Required correction to hover after payload: {required_hover:.3f} m/s²")
    print(f"Naive saturation time: {saturation_time(naive):.3f} s")
    print(f"Aware saturation time: {saturation_time(aware):.3f} s")
    print(f"Naive payload recovery: {recovery_label(naive)}")
    print(f"Aware payload recovery: {recovery_label(aware)}")
    print(f"Naive final estimate: {naive.disturbance_estimate[-1]:.3f} m/s²")
    print(f"Aware final estimate: {aware.disturbance_estimate[-1]:.3f} m/s²")
    # --8<-- [end:limit-evidence]


def plot(naive: Trial, aware: Trial, output: Path, max_correction: float) -> None:
    figure, axes = plt.subplots(4, 1, figsize=(10, 10), sharex=True)
    axes[0].plot(naive.time, naive.target, "k--", label="target")
    axes[0].plot(naive.time, naive.altitude, label="naive ADRC altitude")
    axes[0].plot(aware.time, aware.altitude, label="aware ADRC altitude")
    axes[0].axhspan(TARGET - TARGET_BAND, TARGET + TARGET_BAND, color="tab:green", alpha=0.10, label="target band")
    axes[0].axvline(PAYLOAD_TIME, color="tab:red", linestyle=":", label="payload added")
    axes[0].set_ylabel("altitude (m)")
    axes[0].legend(loc="best")

    axes[1].plot(naive.time, naive.requested, label="naive requested")
    axes[1].plot(naive.time, naive.applied, label="naive applied")
    axes[1].axhline(max_correction, color="tab:red", linestyle="--", label="positive limit")
    axes[1].set_ylabel("naive correction")
    axes[1].legend(loc="best")

    axes[2].plot(aware.time, aware.requested, label="aware requested")
    axes[2].plot(aware.time, aware.applied, label="aware applied")
    axes[2].axhline(max_correction, color="tab:red", linestyle="--", label="positive limit")
    axes[2].set_ylabel("aware correction")
    axes[2].legend(loc="best")

    axes[3].plot(naive.time, naive.disturbance_estimate, label="naive estimate")
    axes[3].plot(aware.time, aware.disturbance_estimate, label="aware estimate")
    axes[3].axvline(PAYLOAD_TIME, color="tab:red", linestyle=":")
    axes[3].set_ylabel("estimate (m/s²)")
    axes[3].set_xlabel("simulated time (s)")
    axes[3].legend(loc="best")
    figure.suptitle(f"ADRC with actuator correction limit = {max_correction:.1f} m/s²")
    figure.tight_layout()
    figure.savefig(output, dpi=160)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    naive = run_trial(
        reaction=args.reaction,
        detection=args.detection,
        max_correction=args.max_correction,
        use_applied_command=False,
    )
    aware = run_trial(
        reaction=args.reaction,
        detection=args.detection,
        max_correction=args.max_correction,
        use_applied_command=True,
    )
    plot(naive, aware, args.output, args.max_correction)
    report_metrics(naive, aware, args.max_correction)
    print(f"Saved plot: {args.output}")


if __name__ == "__main__":
    main()
