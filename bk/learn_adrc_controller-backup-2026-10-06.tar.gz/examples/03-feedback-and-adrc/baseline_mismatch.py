"""Show what baseline feedback can recover from under a mass mismatch.

The controller assumes a 1.0 kg plant while the simulated plant is 1.4 kg.
Change only --reaction when testing the baseline controller's trade-off.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation, PillowWriter


TARGET = 3.0
TARGET_START = 0.5
DURATION = 8.0
TIMESTEP = 0.01
ASSUMED_MASS = 1.0
ACTUAL_MASS = 1.4
GRAVITY = 9.81
TARGET_BAND = 0.10


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reaction", type=float, default=2.2, help="baseline reaction setting")
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("baseline_mismatch.png"))
    parser.add_argument(
        "--animation",
        type=Path,
        default=Path(__file__).with_name("baseline_mismatch.gif"),
    )
    args = parser.parse_args()
    if args.reaction <= 0:
        parser.error("reaction must be positive")
    return args


def run_baseline(reaction: float) -> tuple[np.ndarray, ...]:
    """Run feedback that knows its target but not the plant's actual mass."""
    # --8<-- [start:baseline-loop]
    times = np.arange(0.0, DURATION + TIMESTEP, TIMESTEP)
    target = np.where(times >= TARGET_START, TARGET, 0.0)
    altitude = np.zeros_like(times)
    velocity = np.zeros_like(times)
    correction = np.zeros_like(times)
    command = np.zeros_like(times)
    reaction_gain = reaction**2
    damping_gain = 2.0 * reaction

    for index in range(len(times) - 1):
        error = target[index] - altitude[index]
        correction[index] = reaction_gain * error - damping_gain * velocity[index]
        command[index] = ASSUMED_MASS * (GRAVITY + correction[index])
        acceleration = command[index] / ACTUAL_MASS - GRAVITY
        velocity[index + 1] = velocity[index] + acceleration * TIMESTEP
        altitude[index + 1] = max(0.0, altitude[index] + velocity[index + 1] * TIMESTEP)
        if altitude[index + 1] == 0.0 and velocity[index + 1] < 0.0:
            velocity[index + 1] = 0.0

    correction[-1] = correction[-2]
    command[-1] = command[-2]
    return times, target, altitude, correction, command
    # --8<-- [end:baseline-loop]


def recovery_time(times: np.ndarray, target: np.ndarray, altitude: np.ndarray) -> float | None:
    """Return settling time after the target step, or None when the band is not reached."""
    start_index = int(np.searchsorted(times, TARGET_START))
    within_band = np.abs(target - altitude) <= TARGET_BAND
    for index in range(start_index, len(times)):
        if np.all(within_band[index:]):
            return float(times[index] - TARGET_START)
    return None


def report_metrics(results: tuple[np.ndarray, ...]) -> None:
    # --8<-- [start:report-metrics]
    times, target, altitude, correction, _ = results
    final_error = float(target[-1] - altitude[-1])
    overshoot = float(max(0.0, np.max(altitude) - TARGET))
    peak_correction = float(np.max(np.abs(correction)))
    settled = recovery_time(times, target, altitude)
    print(f"Final tracking error: {final_error:.3f} m")
    if settled is None:
        print(f"Recovery to within {TARGET_BAND:.2f} m: not reached by {DURATION:.1f} s")
    else:
        print(f"Recovery to within {TARGET_BAND:.2f} m: {settled:.3f} s after target step")
    print(f"Overshoot: {overshoot:.3f} m")
    print(f"Peak correction: {peak_correction:.3f} m/s²")
    # --8<-- [end:report-metrics]


def plot(results: tuple[np.ndarray, ...], output: Path, reaction: float) -> None:
    times, target, altitude, correction, _ = results
    figure, axes = plt.subplots(2, 1, figsize=(9, 6), sharex=True)
    axes[0].plot(times, target, "k--", label="target")
    axes[0].plot(times, altitude, label="measurement")
    axes[0].axhspan(TARGET - TARGET_BAND, TARGET + TARGET_BAND, color="tab:green", alpha=0.10, label="target band")
    axes[0].set_ylabel("altitude (m)")
    axes[0].legend(loc="best")
    axes[1].plot(times, correction, color="tab:orange", label="baseline correction")
    axes[1].set_xlabel("simulated time (s)")
    axes[1].set_ylabel("correction (m/s²)")
    axes[1].legend(loc="best")
    figure.suptitle(
        f"Baseline feedback with mass mismatch: assumes {ASSUMED_MASS:.1f} kg, plant is {ACTUAL_MASS:.1f} kg, reaction={reaction:.1f}"
    )
    figure.tight_layout()
    figure.savefig(output, dpi=160)
    plt.close(figure)


def animate(results: tuple[np.ndarray, ...], output: Path) -> None:
    """Reveal the same altitude and correction evidence as a compact looping GIF."""
    times, target, altitude, correction, _ = results
    frame_indices = np.linspace(0, len(times) - 1, 96, dtype=int)
    figure, axes = plt.subplots(2, 1, figsize=(7.5, 5), sharex=True)
    axes[0].set(xlim=(0, DURATION), ylim=(-0.1, TARGET + 0.5), ylabel="altitude (m)")
    axes[1].set(xlim=(0, DURATION), ylim=(min(-1.0, correction.min() - 0.5), correction.max() + 0.5), ylabel="correction (m/s²)", xlabel="simulated time (s)")
    axes[0].axhline(TARGET, color="black", linestyle="--", label="target")
    axes[0].axhspan(TARGET - TARGET_BAND, TARGET + TARGET_BAND, color="tab:green", alpha=0.10, label="target band")
    altitude_line, = axes[0].plot([], [], label="measurement")
    correction_line, = axes[1].plot([], [], color="tab:orange", label="baseline correction")
    time_markers = [axis.axvline(0.0, color="tab:gray", alpha=0.6) for axis in axes]
    axes[0].legend(loc="best")
    axes[1].legend(loc="best")
    figure.suptitle("Baseline feedback: heavier plant, no disturbance estimate")
    figure.tight_layout()

    def update(frame: int):
        end = frame_indices[frame] + 1
        altitude_line.set_data(times[:end], altitude[:end])
        correction_line.set_data(times[:end], correction[:end])
        for marker in time_markers:
            marker.set_xdata([times[end - 1], times[end - 1]])
        return altitude_line, correction_line, *time_markers

    animation = FuncAnimation(figure, update, frames=len(frame_indices), interval=83, blit=True, repeat=True)
    animation.save(output, writer=PillowWriter(fps=12))
    plt.close(figure)


def main() -> None:
    args = parse_args()
    results = run_baseline(args.reaction)
    plot(results, args.output, args.reaction)
    animate(results, args.animation)
    report_metrics(results)
    print(f"Saved plot: {args.output}")
    print(f"Saved animation: {args.animation}")


if __name__ == "__main__":
    main()
