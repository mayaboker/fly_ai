"""Compare ADRC detection settings using the same timed-payload experiment."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt

from estimate_timing import DURATION, PAYLOAD_TIME, TARGET, TARGET_BAND, post_payload_recovery, run_adrc


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--detections", type=float, nargs="+", default=[4.0, 6.4, 8.0])
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("detection_sweep.png"))
    args = parser.parse_args()
    if any(value <= 0 for value in args.detections):
        parser.error("all detection settings must be positive")
    return args


def recovery_label(value: float | None) -> str:
    return f"{value:.3f} s" if value is not None else "not reached"


def run_sweep(detections: list[float]):
    # --8<-- [start:detection-sweep]
    trials = []
    for detection in detections:
        # Only detection changes; run_adrc keeps the target, payload, reaction,
        # timestep, and duration fixed for every trace in the comparison.
        trials.append((detection, run_adrc(reaction=2.2, detection=detection, payload_mass=1.4)))
    return trials
    # --8<-- [end:detection-sweep]


def report(trials) -> None:
    # --8<-- [start:sweep-metrics]
    print("Detection | final error (m) | payload recovery | final estimate (m/s²)")
    for detection, trial in trials:
        # Every row uses the same metric definition so the tuning trade-off is
        # evidence from the setting, not a change in how success is scored.
        error = trial.target[-1] - trial.altitude[-1]
        print(
            f"{detection:9.1f} | {error:15.3f} | {recovery_label(post_payload_recovery(trial)):16} | "
            f"{trial.disturbance_estimate[-1]:22.3f}"
        )
    # --8<-- [end:sweep-metrics]


def plot(trials, output: Path) -> None:
    figure, axes = plt.subplots(3, 1, figsize=(9, 8), sharex=True)
    for detection, trial in trials:
        axes[0].plot(trial.time, trial.altitude, label=f"detection {detection:g}")
        axes[1].plot(trial.time, trial.correction, label=f"detection {detection:g}")
        axes[2].plot(trial.time, trial.disturbance_estimate, label=f"detection {detection:g}")
    axes[0].axhline(TARGET, color="black", linestyle="--", label="target")
    axes[0].axhspan(TARGET - TARGET_BAND, TARGET + TARGET_BAND, color="tab:green", alpha=0.10, label="target band")
    axes[0].axvline(PAYLOAD_TIME, color="tab:red", linestyle=":", label="payload added")
    axes[0].set_ylabel("altitude (m)")
    axes[0].legend(loc="best")
    axes[1].axvline(PAYLOAD_TIME, color="tab:red", linestyle=":")
    axes[1].set_ylabel("correction (m/s²)")
    axes[1].legend(loc="best")
    axes[2].axvline(PAYLOAD_TIME, color="tab:red", linestyle=":")
    axes[2].set_ylabel("estimate (m/s²)")
    axes[2].set_xlabel("simulated time (s)")
    axes[2].legend(loc="best")
    figure.suptitle("Detection-setting sweep under the same timed payload")
    figure.tight_layout()
    figure.savefig(output, dpi=160)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    trials = run_sweep(args.detections)
    plot(trials, args.output)
    report(trials)
    print(f"Saved plot: {args.output}")


if __name__ == "__main__":
    main()
