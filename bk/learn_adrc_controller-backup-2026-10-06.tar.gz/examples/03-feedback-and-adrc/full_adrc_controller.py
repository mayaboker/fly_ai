"""A compact, complete ADRC controller for the timed-payload experiment.

Run this reference after completing the guided build in Module 3, Topic 5.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


TARGET = 3.0
TARGET_START = 0.5
PAYLOAD_TIME = 4.0
DURATION = 8.0
TIMESTEP = 0.01
ASSUMED_MASS = 1.0
PAYLOAD_MASS = 1.4
GRAVITY = 9.81
TARGET_BAND = 0.10


class ADRCController:
    """Estimate motion and combined disturbance, then compensate in feedback."""

    # --8<-- [start:controller-state]
    def __init__(self, reaction: float, detection: float) -> None:
        self.reaction_gain = reaction**2
        self.damping_gain = 2.0 * reaction
        self.beta1 = 3.0 * detection
        self.beta2 = 3.0 * detection**2
        self.beta3 = detection**3
        # These states begin without knowledge of the plant or payload.
        self.estimated_altitude = 0.0
        self.estimated_velocity = 0.0
        self.estimated_disturbance = 0.0
        self.previous_correction = 0.0
    # --8<-- [end:controller-state]

    # --8<-- [start:controller-update]
    def update(self, measurement: float, target: float, timestep: float) -> float:
        measurement_error = measurement - self.estimated_altitude
        # Update predicted motion from the measurement gap before using the
        # estimate for compensation in this control step.
        self.estimated_altitude += timestep * (
            self.estimated_velocity + self.beta1 * measurement_error
        )
        self.estimated_velocity += timestep * (
            self.previous_correction
            + self.estimated_disturbance
            + self.beta2 * measurement_error
        )
        self.estimated_disturbance += timestep * self.beta3 * measurement_error

        desired_change = (
            self.reaction_gain * (target - self.estimated_altitude)
            - self.damping_gain * self.estimated_velocity
        )
        # A negative downward-effect estimate increases the upward correction.
        correction = desired_change - self.estimated_disturbance
        self.previous_correction = correction
        return correction
    # --8<-- [end:controller-update]


@dataclass
class Trial:
    time: np.ndarray
    target: np.ndarray
    altitude: np.ndarray
    correction: np.ndarray
    disturbance_estimate: np.ndarray


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reaction", type=float, default=2.2)
    parser.add_argument("--detection", type=float, default=6.4)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("full_adrc_controller.png"))
    args = parser.parse_args()
    if args.reaction <= 0 or args.detection <= 0:
        parser.error("reaction and detection must be positive")
    return args


def run_trial(reaction: float, detection: float) -> Trial:
    # --8<-- [start:controller-test]
    controller = ADRCController(reaction, detection)
    time = np.arange(0.0, DURATION + TIMESTEP, TIMESTEP)
    target = np.where(time >= TARGET_START, TARGET, 0.0)
    altitude = np.zeros_like(time)
    velocity = np.zeros_like(time)
    correction = np.zeros_like(time)
    disturbance_estimate = np.zeros_like(time)

    for index in range(len(time) - 1):
        correction[index + 1] = controller.update(
            measurement=altitude[index], target=target[index], timestep=TIMESTEP
        )
        # The payload is visible only in the plant; it is never passed to ADRC.
        actual_mass = PAYLOAD_MASS if time[index] >= PAYLOAD_TIME else ASSUMED_MASS
        thrust = ASSUMED_MASS * (GRAVITY + correction[index + 1])
        acceleration = thrust / actual_mass - GRAVITY
        velocity[index + 1] = velocity[index] + acceleration * TIMESTEP
        altitude[index + 1] = max(0.0, altitude[index] + velocity[index + 1] * TIMESTEP)
        if altitude[index + 1] == 0.0 and velocity[index + 1] < 0.0:
            velocity[index + 1] = 0.0
        disturbance_estimate[index + 1] = controller.estimated_disturbance

    return Trial(time, target, altitude, correction, disturbance_estimate)
    # --8<-- [end:controller-test]


def recovery_time(trial: Trial) -> float | None:
    start_index = int(np.searchsorted(trial.time, PAYLOAD_TIME))
    within_band = np.abs(trial.target - trial.altitude) <= TARGET_BAND
    for index in range(start_index, len(trial.time)):
        if np.all(within_band[index:]):
            return float(trial.time[index] - PAYLOAD_TIME)
    return None


def report(trial: Trial) -> None:
    final_error = trial.target[-1] - trial.altitude[-1]
    recovery = recovery_time(trial)
    print(f"Final tracking error: {final_error:.3f} m")
    print(
        f"Recovery after payload to within {TARGET_BAND:.2f} m: "
        f"{recovery:.3f} s" if recovery is not None else "Recovery after payload: not reached"
    )
    print(f"Final disturbance estimate: {trial.disturbance_estimate[-1]:.3f} m/s²")


def plot(trial: Trial, output: Path) -> None:
    figure, axes = plt.subplots(3, 1, figsize=(9, 8), sharex=True)
    axes[0].plot(trial.time, trial.target, "k--", label="target")
    axes[0].plot(trial.time, trial.altitude, label="measurement")
    axes[0].axhspan(TARGET - TARGET_BAND, TARGET + TARGET_BAND, color="tab:green", alpha=0.10, label="target band")
    axes[0].axvline(PAYLOAD_TIME, color="tab:red", linestyle=":", label="payload added")
    axes[0].set_ylabel("altitude (m)")
    axes[0].legend(loc="best")
    axes[1].plot(trial.time, trial.correction, color="tab:orange", label="ADRC correction")
    axes[1].axvline(PAYLOAD_TIME, color="tab:red", linestyle=":")
    axes[1].set_ylabel("correction (m/s²)")
    axes[1].legend(loc="best")
    axes[2].plot(trial.time, trial.disturbance_estimate, color="tab:green", label="ADRC estimate")
    axes[2].axvline(PAYLOAD_TIME, color="tab:red", linestyle=":")
    axes[2].set_ylabel("estimate (m/s²)")
    axes[2].set_xlabel("simulated time (s)")
    axes[2].legend(loc="best")
    figure.suptitle("Complete compact ADRC controller under a timed payload")
    figure.tight_layout()
    figure.savefig(output, dpi=160)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    trial = run_trial(args.reaction, args.detection)
    plot(trial, args.output)
    report(trial)
    print(f"Saved plot: {args.output}")


if __name__ == "__main__":
    main()
