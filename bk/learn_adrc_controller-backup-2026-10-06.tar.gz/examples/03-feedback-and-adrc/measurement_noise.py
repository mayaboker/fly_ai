"""Compare slow and fast ADRC detection with the same noisy altitude sensor.

The two trials receive the identical seeded noise sequence and timed payload.
Change only one command-line setting when designing a follow-up experiment.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


TARGET = 3.0
TARGET_START = 0.5
PAYLOAD_TIME = 4.0
DURATION = 8.0
TIMESTEP = 0.01
ASSUMED_MASS = 1.0
PAYLOAD_MASS = 1.4
GRAVITY = 9.81
TARGET_BAND = 0.10


@dataclass
class Trial:
    time: np.ndarray
    target: np.ndarray
    altitude: np.ndarray
    measurement: np.ndarray
    correction: np.ndarray
    disturbance_estimate: np.ndarray


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--noise-std", type=float, default=0.04, help="altitude measurement noise standard deviation in m")
    parser.add_argument("--slow-detection", type=float, default=4.0)
    parser.add_argument("--fast-detection", type=float, default=10.0)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("measurement_noise.png"))
    args = parser.parse_args()
    if args.noise_std < 0 or args.slow_detection <= 0 or args.fast_detection <= 0:
        parser.error("noise standard deviation must be non-negative and detections must be positive")
    return args


def run_adrc(detection: float, noise: np.ndarray) -> Trial:
    """Run one ADRC setting against a payload and supplied measurement noise."""
    # --8<-- [start:noisy-observer-loop]
    time = np.arange(0.0, DURATION + TIMESTEP, TIMESTEP)
    target = np.where(time >= TARGET_START, TARGET, 0.0)
    altitude = np.zeros_like(time)
    measurement = np.zeros_like(time)
    velocity = np.zeros_like(time)
    correction = np.zeros_like(time)
    disturbance_estimate = np.zeros_like(time)
    reaction_gain, damping_gain = 2.2**2, 2.0 * 2.2
    beta1, beta2, beta3 = 3.0 * detection, 3.0 * detection**2, detection**3
    estimated_altitude = estimated_velocity = estimated_disturbance = 0.0

    for index in range(len(time) - 1):
        # Both trials receive the same seeded noise, so detection is the only
        # intended reason their observer traces can differ.
        measurement[index] = altitude[index] + noise[index]
        measurement_error = measurement[index] - estimated_altitude
        estimated_altitude += TIMESTEP * (estimated_velocity + beta1 * measurement_error)
        estimated_velocity += TIMESTEP * (
            correction[index] + estimated_disturbance + beta2 * measurement_error
        )
        estimated_disturbance += TIMESTEP * beta3 * measurement_error
        desired_change = reaction_gain * (target[index] - estimated_altitude) - damping_gain * estimated_velocity
        correction[index + 1] = desired_change - estimated_disturbance

        actual_mass = PAYLOAD_MASS if time[index] >= PAYLOAD_TIME else ASSUMED_MASS
        thrust = ASSUMED_MASS * (GRAVITY + correction[index + 1])
        acceleration = thrust / actual_mass - GRAVITY
        velocity[index + 1] = velocity[index] + acceleration * TIMESTEP
        altitude[index + 1] = max(0.0, altitude[index] + velocity[index + 1] * TIMESTEP)
        if altitude[index + 1] == 0.0 and velocity[index + 1] < 0.0:
            velocity[index + 1] = 0.0
        disturbance_estimate[index + 1] = estimated_disturbance

    measurement[-1] = altitude[-1] + noise[-1]
    return Trial(time, target, altitude, measurement, correction, disturbance_estimate)
    # --8<-- [end:noisy-observer-loop]


def estimate_jitter(trial: Trial) -> float:
    settled = trial.time >= 6.0
    return float(np.std(trial.disturbance_estimate[settled]))


def recovery_time(trial: Trial) -> float | None:
    start_index = int(np.searchsorted(trial.time, PAYLOAD_TIME))
    within_band = np.abs(trial.target - trial.altitude) <= TARGET_BAND
    for index in range(start_index, len(trial.time)):
        if np.all(within_band[index:]):
            return float(trial.time[index] - PAYLOAD_TIME)
    return None


def recovery_label(trial: Trial) -> str:
    recovery = recovery_time(trial)
    return f"{recovery:.3f} s" if recovery is not None else "not reached"


def report(slow: Trial, fast: Trial, slow_detection: float, fast_detection: float) -> None:
    # --8<-- [start:noise-evidence]
    # Use the same post-payload recovery and late-estimate-jitter definitions
    # for both settings so the trade-off is measured consistently.
    print("Detection | payload recovery | late estimate jitter (m/s²) | final error (m)")
    for detection, trial in ((slow_detection, slow), (fast_detection, fast)):
        final_error = trial.target[-1] - trial.altitude[-1]
        print(
            f"{detection:9.1f} | {recovery_label(trial):16} | "
            f"{estimate_jitter(trial):28.3f} | {final_error:15.3f}"
        )
    # --8<-- [end:noise-evidence]


def plot(slow: Trial, fast: Trial, output: Path, slow_detection: float, fast_detection: float) -> None:
    figure, axes = plt.subplots(3, 1, figsize=(10, 8), sharex=True)
    axes[0].plot(slow.time, slow.target, "k--", label="target")
    axes[0].plot(slow.time, slow.altitude, label=f"true altitude, detection {slow_detection:g}")
    axes[0].plot(fast.time, fast.altitude, label=f"true altitude, detection {fast_detection:g}")
    axes[0].plot(fast.time[::10], fast.measurement[::10], ".", alpha=0.25, markersize=2, label="noisy measurements")
    axes[0].axvline(PAYLOAD_TIME, color="tab:red", linestyle=":", label="payload added")
    axes[0].set_ylabel("altitude (m)")
    axes[0].legend(loc="best")
    axes[1].plot(slow.time, slow.correction, label=f"detection {slow_detection:g}")
    axes[1].plot(fast.time, fast.correction, label=f"detection {fast_detection:g}")
    axes[1].axvline(PAYLOAD_TIME, color="tab:red", linestyle=":")
    axes[1].set_ylabel("correction (m/s²)")
    axes[1].legend(loc="best")
    axes[2].plot(slow.time, slow.disturbance_estimate, label=f"detection {slow_detection:g}")
    axes[2].plot(fast.time, fast.disturbance_estimate, label=f"detection {fast_detection:g}")
    axes[2].axvline(PAYLOAD_TIME, color="tab:red", linestyle=":")
    axes[2].set_ylabel("estimate (m/s²)")
    axes[2].set_xlabel("simulated time (s)")
    axes[2].legend(loc="best")
    figure.suptitle("Detection trade-off with the same noisy altitude measurement")
    figure.tight_layout()
    figure.savefig(output, dpi=160)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    time = np.arange(0.0, DURATION + TIMESTEP, TIMESTEP)
    noise = np.random.default_rng(args.seed).normal(0.0, args.noise_std, len(time))
    slow = run_adrc(args.slow_detection, noise)
    fast = run_adrc(args.fast_detection, noise)
    plot(slow, fast, args.output, args.slow_detection, args.fast_detection)
    report(slow, fast, args.slow_detection, args.fast_detection)
    print(f"Saved plot: {args.output}")


if __name__ == "__main__":
    main()
