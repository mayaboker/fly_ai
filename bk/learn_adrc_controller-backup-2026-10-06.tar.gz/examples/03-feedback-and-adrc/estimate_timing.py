"""Show when an ADRC disturbance estimate responds to an added payload.

The plant starts at its expected 1.0 kg mass, then becomes heavier at 4 s.
Change only --detection when testing how quickly the observer responds.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation, PillowWriter


TARGET = 3.0
TARGET_START = 0.5
PAYLOAD_TIME = 4.0
DURATION = 8.0
TIMESTEP = 0.01
ASSUMED_MASS = 1.0
PAYLOAD_MASS = 1.4
GRAVITY = 9.81
TARGET_BAND = 0.10


@dataclass
class Trial:
    time: np.ndarray
    target: np.ndarray
    altitude: np.ndarray
    correction: np.ndarray
    disturbance_estimate: np.ndarray


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reaction", type=float, default=2.2, help="reaction setting")
    parser.add_argument("--detection", type=float, default=6.4, help="detection setting")
    parser.add_argument("--payload-mass", type=float, default=PAYLOAD_MASS, help="mass after payload time in kg")
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("estimate_timing.png"))
    parser.add_argument("--animation", type=Path, default=Path(__file__).with_name("estimate_timing.gif"))
    args = parser.parse_args()
    if args.reaction <= 0 or args.detection <= 0 or args.payload_mass <= ASSUMED_MASS:
        parser.error("reaction and detection must be positive, and payload mass must exceed 1.0 kg")
    return args


def run_adrc(reaction: float, detection: float, payload_mass: float) -> Trial:
    """Run ADRC while one known-time mass change tests estimate timing."""
    # --8<-- [start:estimate-timing-loop]
    time = np.arange(0.0, DURATION + TIMESTEP, TIMESTEP)
    target = np.where(time >= TARGET_START, TARGET, 0.0)
    altitude = np.zeros_like(time)
    velocity = np.zeros_like(time)
    correction = np.zeros_like(time)
    disturbance_estimate = np.zeros_like(time)
    reaction_gain = reaction**2
    damping_gain = 2.0 * reaction
    estimated_altitude = 0.0
    estimated_velocity = 0.0
    estimated_disturbance = 0.0
    beta1, beta2, beta3 = 3.0 * detection, 3.0 * detection**2, detection**3

    for index in range(len(time) - 1):
        measurement = altitude[index]
        measurement_error = measurement - estimated_altitude
        # The observer corrects its prediction using the measurement gap, then
        # stores the remaining unexplained behavior as a combined estimate.
        estimated_altitude += TIMESTEP * (estimated_velocity + beta1 * measurement_error)
        estimated_velocity += TIMESTEP * (
            correction[index] + estimated_disturbance + beta2 * measurement_error
        )
        estimated_disturbance += TIMESTEP * beta3 * measurement_error

        desired_change = reaction_gain * (target[index] - estimated_altitude) - damping_gain * estimated_velocity
        correction[index + 1] = desired_change - estimated_disturbance

        # The only plant change occurs at PAYLOAD_TIME. The observer is not
        # told about it, so any response in its estimate comes from evidence.
        actual_mass = payload_mass if time[index] >= PAYLOAD_TIME else ASSUMED_MASS
        thrust = ASSUMED_MASS * (GRAVITY + correction[index + 1])
        acceleration = thrust / actual_mass - GRAVITY
        velocity[index + 1] = velocity[index] + acceleration * TIMESTEP
        altitude[index + 1] = max(0.0, altitude[index] + velocity[index + 1] * TIMESTEP)
        if altitude[index + 1] == 0.0 and velocity[index + 1] < 0.0:
            velocity[index + 1] = 0.0
        disturbance_estimate[index + 1] = estimated_disturbance

    return Trial(time, target, altitude, correction, disturbance_estimate)
    # --8<-- [end:estimate-timing-loop]


def post_payload_recovery(trial: Trial) -> float | None:
    start_index = int(np.searchsorted(trial.time, PAYLOAD_TIME))
    within_band = np.abs(trial.target - trial.altitude) <= TARGET_BAND
    for index in range(start_index, len(trial.time)):
        if np.all(within_band[index:]):
            return float(trial.time[index] - PAYLOAD_TIME)
    return None


def report_metrics(trial: Trial) -> None:
    # --8<-- [start:timing-metrics]
    # Compare before and after the event without treating the estimate as a
    # direct payload-mass reading.
    before_index = int(np.searchsorted(trial.time, PAYLOAD_TIME)) - 1
    recovery = post_payload_recovery(trial)
    print(f"Estimate before payload: {trial.disturbance_estimate[before_index]:.3f} m/s²")
    print(f"Final disturbance estimate: {trial.disturbance_estimate[-1]:.3f} m/s²")
    if recovery is None:
        print(f"Recovery after payload to within {TARGET_BAND:.2f} m: not reached by {DURATION:.1f} s")
    else:
        print(f"Recovery after payload to within {TARGET_BAND:.2f} m: {recovery:.3f} s")
    print(f"Lowest altitude after payload: {np.min(trial.altitude[before_index:]):.3f} m")
    # --8<-- [end:timing-metrics]


def plot(trial: Trial, output: Path, detection: float, payload_mass: float) -> None:
    figure, axes = plt.subplots(3, 1, figsize=(9, 8), sharex=True)
    axes[0].plot(trial.time, trial.target, "k--", label="target")
    axes[0].plot(trial.time, trial.altitude, label="measurement")
    axes[0].axhspan(TARGET - TARGET_BAND, TARGET + TARGET_BAND, color="tab:green", alpha=0.10, label="target band")
    axes[0].axvline(PAYLOAD_TIME, color="tab:red", linestyle=":", label="payload added")
    axes[0].set_ylabel("altitude (m)")
    axes[0].legend(loc="best")
    axes[1].plot(trial.time, trial.correction, color="tab:orange", label="ADRC correction")
    axes[1].axvline(PAYLOAD_TIME, color="tab:red", linestyle=":")
    axes[1].set_ylabel("correction (m/s²)")
    axes[1].legend(loc="best")
    axes[2].plot(trial.time, trial.disturbance_estimate, color="tab:green", label="ADRC estimate")
    axes[2].axvline(PAYLOAD_TIME, color="tab:red", linestyle=":")
    axes[2].set_ylabel("estimate (m/s²)")
    axes[2].set_xlabel("simulated time (s)")
    axes[2].legend(loc="best")
    figure.suptitle(f"ADRC estimate timing: payload mass={payload_mass:.1f} kg, detection={detection:.1f}")
    figure.tight_layout()
    figure.savefig(output, dpi=160)
    plt.close(figure)


def animate(trial: Trial, output: Path) -> None:
    frame_indices = np.linspace(0, len(trial.time) - 1, 96, dtype=int)
    figure, axes = plt.subplots(3, 1, figsize=(7.5, 7), sharex=True)
    axes[0].set(xlim=(0, DURATION), ylim=(-0.1, TARGET + 0.5), ylabel="altitude (m)")
    axes[1].set(xlim=(0, DURATION), ylim=(trial.correction.min() - 0.5, trial.correction.max() + 0.5), ylabel="correction (m/s²)")
    axes[2].set(xlim=(0, DURATION), ylim=(trial.disturbance_estimate.min() - 0.5, 0.5), ylabel="estimate (m/s²)", xlabel="simulated time (s)")
    axes[0].axhline(TARGET, color="black", linestyle="--", label="target")
    axes[0].axhspan(TARGET - TARGET_BAND, TARGET + TARGET_BAND, color="tab:green", alpha=0.10, label="target band")
    for axis in axes:
        axis.axvline(PAYLOAD_TIME, color="tab:red", linestyle=":")
    altitude_line, = axes[0].plot([], [], label="measurement")
    correction_line, = axes[1].plot([], [], color="tab:orange", label="ADRC correction")
    estimate_line, = axes[2].plot([], [], color="tab:green", label="ADRC estimate")
    time_markers = [axis.axvline(0.0, color="tab:gray", alpha=0.6) for axis in axes]
    for axis in axes:
        axis.legend(loc="best")
    figure.suptitle("ADRC estimate follows an added payload")
    figure.tight_layout()

    def update(frame: int):
        end = frame_indices[frame] + 1
        altitude_line.set_data(trial.time[:end], trial.altitude[:end])
        correction_line.set_data(trial.time[:end], trial.correction[:end])
        estimate_line.set_data(trial.time[:end], trial.disturbance_estimate[:end])
        for marker in time_markers:
            marker.set_xdata([trial.time[end - 1], trial.time[end - 1]])
        return altitude_line, correction_line, estimate_line, *time_markers

    animation = FuncAnimation(figure, update, frames=len(frame_indices), interval=83, blit=True, repeat=True)
    animation.save(output, writer=PillowWriter(fps=12))
    plt.close(figure)


def main() -> None:
    args = parse_args()
    trial = run_adrc(args.reaction, args.detection, args.payload_mass)
    plot(trial, args.output, args.detection, args.payload_mass)
    animate(trial, args.animation)
    report_metrics(trial)
    print(f"Saved plot: {args.output}")
    print(f"Saved animation: {args.animation}")


if __name__ == "__main__":
    main()
