"""Compare baseline feedback and ADRC under the same mass mismatch.

Both controllers assume a 1.0 kg plant while the simulated plant is 1.4 kg.
Change only --detection when testing how quickly ADRC updates its estimate.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation, PillowWriter


TARGET = 3.0
TARGET_START = 0.5
DURATION = 8.0
TIMESTEP = 0.01
ASSUMED_MASS = 1.0
ACTUAL_MASS = 1.4
GRAVITY = 9.81
TARGET_BAND = 0.10


@dataclass
class Trial:
    """Signals recorded for one controller facing the shared plant."""

    time: np.ndarray
    target: np.ndarray
    altitude: np.ndarray
    correction: np.ndarray
    disturbance_estimate: np.ndarray


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reaction", type=float, default=2.2, help="shared reaction setting")
    parser.add_argument("--detection", type=float, default=6.4, help="ADRC detection setting")
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("adrc_same_mismatch.png"))
    parser.add_argument("--animation", type=Path, default=Path(__file__).with_name("adrc_same_mismatch.gif"))
    args = parser.parse_args()
    if args.reaction <= 0 or args.detection <= 0:
        parser.error("reaction and detection must be positive")
    return args


def run_trial(*, use_adrc: bool, reaction: float, detection: float) -> Trial:
    """Run either controller against exactly the same target and heavy plant."""
    # --8<-- [start:shared-adrc-loop]
    time = np.arange(0.0, DURATION + TIMESTEP, TIMESTEP)
    target = np.where(time >= TARGET_START, TARGET, 0.0)
    altitude = np.zeros_like(time)
    velocity = np.zeros_like(time)
    correction = np.zeros_like(time)
    disturbance_estimate = np.zeros_like(time)
    reaction_gain = reaction**2
    damping_gain = 2.0 * reaction

    # The observer starts without knowing the mismatch and learns from the
    # gap between its predicted altitude and the measured altitude.
    estimated_altitude = 0.0
    estimated_velocity = 0.0
    estimated_disturbance = 0.0
    beta1 = 3.0 * detection
    beta2 = 3.0 * detection**2
    beta3 = detection**3

    for index in range(len(time) - 1):
        measurement = altitude[index]

        if use_adrc:
            measurement_error = measurement - estimated_altitude
            estimated_altitude += TIMESTEP * (estimated_velocity + beta1 * measurement_error)
            estimated_velocity += TIMESTEP * (
                correction[index] + estimated_disturbance + beta2 * measurement_error
            )
            estimated_disturbance += TIMESTEP * beta3 * measurement_error
            feedback_altitude = estimated_altitude
            feedback_velocity = estimated_velocity
        else:
            feedback_altitude = measurement
            feedback_velocity = velocity[index]

        desired_change = reaction_gain * (target[index] - feedback_altitude) - damping_gain * feedback_velocity
        # ADRC subtracts its learned combined effect; the baseline has no
        # estimate, so it can only continue reacting to remaining error.
        estimated_effect = estimated_disturbance if use_adrc else 0.0
        correction[index + 1] = desired_change - estimated_effect

        # Both trials use the same incorrect mass assumption to turn their
        # correction into force, then face the same heavier physical plant.
        thrust = ASSUMED_MASS * (GRAVITY + correction[index + 1])
        acceleration = thrust / ACTUAL_MASS - GRAVITY
        velocity[index + 1] = velocity[index] + acceleration * TIMESTEP
        altitude[index + 1] = max(0.0, altitude[index] + velocity[index + 1] * TIMESTEP)
        if altitude[index + 1] == 0.0 and velocity[index + 1] < 0.0:
            velocity[index + 1] = 0.0
        disturbance_estimate[index + 1] = estimated_disturbance

    return Trial(time, target, altitude, correction, disturbance_estimate)
    # --8<-- [end:shared-adrc-loop]


def recovery_time(trial: Trial) -> float | None:
    """Return stable target-band recovery after the target step, when reached."""
    start_index = int(np.searchsorted(trial.time, TARGET_START))
    within_band = np.abs(trial.target - trial.altitude) <= TARGET_BAND
    for index in range(start_index, len(trial.time)):
        if np.all(within_band[index:]):
            return float(trial.time[index] - TARGET_START)
    return None


def format_recovery(trial: Trial) -> str:
    settled = recovery_time(trial)
    if settled is None:
        return f"not reached by {DURATION:.1f} s"
    return f"{settled:.3f} s after target step"


def report_metrics(baseline: Trial, adrc: Trial) -> None:
    # --8<-- [start:matched-metrics]
    # Report the same target-band test for both trials so their recovery
    # evidence remains comparable rather than favoring either controller.
    baseline_error = float(baseline.target[-1] - baseline.altitude[-1])
    adrc_error = float(adrc.target[-1] - adrc.altitude[-1])
    print(f"Baseline final tracking error: {baseline_error:.3f} m")
    print(f"ADRC final tracking error:     {adrc_error:.3f} m")
    print(f"Baseline recovery to within {TARGET_BAND:.2f} m: {format_recovery(baseline)}")
    print(f"ADRC recovery to within {TARGET_BAND:.2f} m:     {format_recovery(adrc)}")
    print(f"ADRC final disturbance estimate: {adrc.disturbance_estimate[-1]:.3f} m/s²")
    # --8<-- [end:matched-metrics]


def plot(baseline: Trial, adrc: Trial, output: Path, detection: float) -> None:
    figure, axes = plt.subplots(3, 1, figsize=(9, 8), sharex=True)
    axes[0].plot(baseline.time, baseline.target, "k--", label="target")
    axes[0].plot(baseline.time, baseline.altitude, label="baseline measurement")
    axes[0].plot(adrc.time, adrc.altitude, label="ADRC measurement")
    axes[0].axhspan(TARGET - TARGET_BAND, TARGET + TARGET_BAND, color="tab:green", alpha=0.10, label="target band")
    axes[0].set_ylabel("altitude (m)")
    axes[0].legend(loc="best")
    axes[1].plot(baseline.time, baseline.correction, label="baseline correction")
    axes[1].plot(adrc.time, adrc.correction, label="ADRC correction")
    axes[1].set_ylabel("correction (m/s²)")
    axes[1].legend(loc="best")
    axes[2].plot(adrc.time, adrc.disturbance_estimate, color="tab:green", label="ADRC estimate")
    axes[2].set_xlabel("simulated time (s)")
    axes[2].set_ylabel("estimate (m/s²)")
    axes[2].legend(loc="best")
    figure.suptitle(
        f"Same mass mismatch: baseline versus ADRC, detection={detection:.1f}"
    )
    figure.tight_layout()
    figure.savefig(output, dpi=160)
    plt.close(figure)


def animate(baseline: Trial, adrc: Trial, output: Path) -> None:
    """Reveal the matched comparison and the ADRC estimate as a looping GIF."""
    frame_indices = np.linspace(0, len(baseline.time) - 1, 96, dtype=int)
    figure, axes = plt.subplots(3, 1, figsize=(7.5, 7), sharex=True)
    axes[0].set(xlim=(0, DURATION), ylim=(-0.1, TARGET + 0.5), ylabel="altitude (m)")
    axes[1].set(
        xlim=(0, DURATION),
        ylim=(min(baseline.correction.min(), adrc.correction.min()) - 0.5, max(baseline.correction.max(), adrc.correction.max()) + 0.5),
        ylabel="correction (m/s²)",
    )
    axes[2].set(
        xlim=(0, DURATION),
        ylim=(adrc.disturbance_estimate.min() - 0.5, max(0.5, adrc.disturbance_estimate.max() + 0.5)),
        ylabel="estimate (m/s²)",
        xlabel="simulated time (s)",
    )
    axes[0].axhline(TARGET, color="black", linestyle="--", label="target")
    axes[0].axhspan(TARGET - TARGET_BAND, TARGET + TARGET_BAND, color="tab:green", alpha=0.10, label="target band")
    baseline_altitude, = axes[0].plot([], [], label="baseline")
    adrc_altitude, = axes[0].plot([], [], label="ADRC")
    baseline_correction, = axes[1].plot([], [], label="baseline")
    adrc_correction, = axes[1].plot([], [], label="ADRC")
    estimate_line, = axes[2].plot([], [], color="tab:green", label="ADRC estimate")
    time_markers = [axis.axvline(0.0, color="tab:gray", alpha=0.6) for axis in axes]
    for axis in axes:
        axis.legend(loc="best")
    figure.suptitle("Same heavy plant: baseline feedback versus ADRC")
    figure.tight_layout()

    def update(frame: int):
        end = frame_indices[frame] + 1
        baseline_altitude.set_data(baseline.time[:end], baseline.altitude[:end])
        adrc_altitude.set_data(adrc.time[:end], adrc.altitude[:end])
        baseline_correction.set_data(baseline.time[:end], baseline.correction[:end])
        adrc_correction.set_data(adrc.time[:end], adrc.correction[:end])
        estimate_line.set_data(adrc.time[:end], adrc.disturbance_estimate[:end])
        for marker in time_markers:
            marker.set_xdata([baseline.time[end - 1], baseline.time[end - 1]])
        return (
            baseline_altitude,
            adrc_altitude,
            baseline_correction,
            adrc_correction,
            estimate_line,
            *time_markers,
        )

    animation = FuncAnimation(figure, update, frames=len(frame_indices), interval=83, blit=True, repeat=True)
    animation.save(output, writer=PillowWriter(fps=12))
    plt.close(figure)


def main() -> None:
    args = parse_args()
    baseline = run_trial(use_adrc=False, reaction=args.reaction, detection=args.detection)
    adrc = run_trial(use_adrc=True, reaction=args.reaction, detection=args.detection)
    plot(baseline, adrc, args.output, args.detection)
    animate(baseline, adrc, args.animation)
    report_metrics(baseline, adrc)
    print(f"Saved plot: {args.output}")
    print(f"Saved animation: {args.animation}")


if __name__ == "__main__":
    main()
