"""Explore how mass, drag, and thrust limit change a vertical plant response."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


GRAVITY = 9.81
NOMINAL_MASS = 1.0
TARGET = 3.0
TIMESTEP = 0.01
DURATION = 8.0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mass", type=float, default=1.0, help="actual plant mass in kg")
    parser.add_argument("--drag", type=float, default=0.20, help="linear drag in N s/m")
    parser.add_argument("--max-thrust", type=float, default=20.0, help="maximum upward thrust in N")
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("vertical_plant_sandbox.png"))
    args = parser.parse_args()
    if args.mass <= 0 or args.drag < 0 or args.max_thrust <= 0:
        parser.error("mass and maximum thrust must be positive; drag must be non-negative")
    return args


def run(mass: float, drag: float, max_thrust: float) -> tuple[np.ndarray, ...]:
    """Run a simple physical plant with a fixed baseline feedback controller."""
    # --8<-- [start:physical-plant-loop]
    time = np.arange(0.0, DURATION + TIMESTEP, TIMESTEP)
    target = np.where(time >= 0.5, TARGET, 0.0)
    altitude = np.zeros_like(time)
    velocity = np.zeros_like(time)
    requested_thrust = np.zeros_like(time)
    applied_thrust = np.zeros_like(time)
    weight = np.full_like(time, mass * GRAVITY)
    drag_force = np.zeros_like(time)
    reaction = 2.2
    kp, kd = reaction**2, 2.0 * reaction

    for index in range(len(time) - 1):
        error = target[index] - altitude[index]
        # The controller assumes a 1.0 kg plant, so changing actual mass
        # changes plant behavior without changing the requested target.
        requested_thrust[index] = NOMINAL_MASS * GRAVITY + kp * error - kd * velocity[index]
        applied_thrust[index] = np.clip(requested_thrust[index], 0.0, max_thrust)
        drag_force[index] = drag * velocity[index]
        acceleration = (applied_thrust[index] - weight[index] - drag_force[index]) / mass
        velocity[index + 1] = velocity[index] + acceleration * TIMESTEP
        altitude[index + 1] = max(0.0, altitude[index] + velocity[index + 1] * TIMESTEP)
        if altitude[index + 1] == 0.0 and velocity[index + 1] < 0:
            velocity[index + 1] = 0.0

    requested_thrust[-1] = requested_thrust[-2]
    applied_thrust[-1] = applied_thrust[-2]
    drag_force[-1] = drag_force[-2]
    return time, target, altitude, velocity, requested_thrust, applied_thrust, weight, drag_force
    # --8<-- [end:physical-plant-loop]


def plot(results: tuple[np.ndarray, ...], output: Path, mass: float, drag: float, max_thrust: float) -> None:
    time, target, altitude, velocity, requested, applied, weight, drag_force = results
    figure, axes = plt.subplots(3, 1, figsize=(9, 8), sharex=True)
    axes[0].plot(time, target, "k--", label="target")
    axes[0].plot(time, altitude, label="measurement")
    axes[0].set_ylabel("altitude (m)")
    axes[0].legend(loc="best")
    axes[1].plot(time, velocity, color="tab:purple", label="velocity")
    axes[1].set_ylabel("velocity (m/s)")
    axes[1].legend(loc="best")
    axes[2].plot(time, requested, label="requested thrust")
    axes[2].plot(time, applied, label="applied thrust")
    axes[2].plot(time, weight, label="weight")
    axes[2].plot(time, drag_force, label="drag force")
    axes[2].axhline(max_thrust, color="tab:red", linestyle="--", label="thrust limit")
    axes[2].set_xlabel("simulated time (s)")
    axes[2].set_ylabel("force (N)")
    axes[2].legend(loc="best", ncol=2)
    figure.suptitle(f"Physical plant: mass={mass:.1f} kg, drag={drag:.2f} N s/m, max thrust={max_thrust:.1f} N")
    figure.tight_layout()
    figure.savefig(output, dpi=160)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    results = run(args.mass, args.drag, args.max_thrust)
    final_error = TARGET - results[2][-1]
    saturation_time = float(np.count_nonzero(np.abs(results[4] - results[5]) > 1e-9) * TIMESTEP)
    plot(results, args.output, args.mass, args.drag, args.max_thrust)
    print(f"Final tracking error: {final_error:.3f} m")
    print(f"Saturation time: {saturation_time:.3f} s")
    print(f"Weight: {args.mass * GRAVITY:.3f} N")
    print(f"Saved plot: {args.output}")


if __name__ == "__main__":
    main()
