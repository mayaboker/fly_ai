"""Run baseline feedback or ADRC against an adjustable physical plant."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


GRAVITY = 9.81
NOMINAL_MASS = 1.0
TARGET = 3.0
TIMESTEP = 0.01
DURATION = 8.0


@dataclass
class Trial:
    time: np.ndarray
    target: np.ndarray
    altitude: np.ndarray
    requested: np.ndarray
    applied: np.ndarray
    estimate: np.ndarray


class ADRCController:
    """Compact ADRC whose observer receives the applied thrust correction."""

    # --8<-- [start:studio-adrc-controller]
    def __init__(self, reaction: float, detection: float) -> None:
        self.kp, self.kd = reaction**2, 2.0 * reaction
        self.beta1, self.beta2, self.beta3 = 3.0 * detection, 3.0 * detection**2, detection**3
        self.z1 = self.z2 = self.z3 = 0.0
        self.applied_correction = 0.0

    def request(self, measurement: float, target: float) -> float:
        error = measurement - self.z1
        # The observer predicts from applied correction, not a thrust request
        # that a limited actuator might be unable to deliver.
        self.z1 += TIMESTEP * (self.z2 + self.beta1 * error)
        self.z2 += TIMESTEP * (self.applied_correction + self.z3 + self.beta2 * error)
        self.z3 += TIMESTEP * self.beta3 * error
        return self.kp * (target - self.z1) - self.kd * self.z2 - self.z3

    def record_applied_thrust(self, thrust: float) -> None:
        self.applied_correction = thrust / NOMINAL_MASS - GRAVITY
    # --8<-- [end:studio-adrc-controller]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("baseline", "adrc"), default="adrc")
    parser.add_argument("--mass", type=float, default=1.4)
    parser.add_argument("--drag", type=float, default=0.20)
    parser.add_argument("--max-thrust", type=float, default=20.0)
    parser.add_argument("--reaction", type=float, default=2.2)
    parser.add_argument("--detection", type=float, default=6.5)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("adrc_physical_plant.png"))
    args = parser.parse_args()
    if args.mass <= 0 or args.drag < 0 or args.max_thrust <= 0 or args.reaction <= 0 or args.detection <= 0:
        parser.error("mass, thrust, reaction, and detection must be positive; drag must be non-negative")
    return args


def run(args: argparse.Namespace) -> Trial:
    """Run the selected controller against one physical-plant configuration."""
    # --8<-- [start:studio-plant-loop]
    controller = ADRCController(args.reaction, args.detection) if args.mode == "adrc" else None
    time = np.arange(0.0, DURATION + TIMESTEP, TIMESTEP)
    target = np.where(time >= 0.5, TARGET, 0.0)
    altitude = np.zeros_like(time)
    velocity = np.zeros_like(time)
    requested = np.zeros_like(time)
    applied = np.zeros_like(time)
    estimate = np.zeros_like(time)
    kp, kd = args.reaction**2, 2.0 * args.reaction

    for index in range(len(time) - 1):
        if controller is None:
            correction = kp * (target[index] - altitude[index]) - kd * velocity[index]
        else:
            correction = controller.request(altitude[index], target[index])
        requested[index + 1] = NOMINAL_MASS * (GRAVITY + correction)
        applied[index + 1] = np.clip(requested[index + 1], 0.0, args.max_thrust)
        if controller is not None:
            controller.record_applied_thrust(applied[index + 1])
            estimate[index + 1] = controller.z3

        drag_force = args.drag * velocity[index]
        acceleration = (applied[index + 1] - args.mass * GRAVITY - drag_force) / args.mass
        velocity[index + 1] = velocity[index] + acceleration * TIMESTEP
        altitude[index + 1] = max(0.0, altitude[index] + velocity[index + 1] * TIMESTEP)
        if altitude[index + 1] == 0.0 and velocity[index + 1] < 0.0:
            velocity[index + 1] = 0.0
    return Trial(time, target, altitude, requested, applied, estimate)
    # --8<-- [end:studio-plant-loop]


def plot(trial: Trial, args: argparse.Namespace) -> None:
    figure, axes = plt.subplots(3, 1, figsize=(9, 8), sharex=True)
    axes[0].plot(trial.time, trial.target, "k--", label="target")
    axes[0].plot(trial.time, trial.altitude, label="measurement")
    axes[0].set_ylabel("altitude (m)")
    axes[0].legend(loc="best")
    axes[1].plot(trial.time, trial.requested, label="requested thrust")
    axes[1].plot(trial.time, trial.applied, label="applied thrust")
    axes[1].axhline(args.max_thrust, color="tab:red", linestyle="--", label="thrust limit")
    axes[1].set_ylabel("thrust (N)")
    axes[1].legend(loc="best")
    axes[2].plot(trial.time, trial.estimate, color="tab:green", label="ADRC estimate")
    axes[2].set_xlabel("simulated time (s)")
    axes[2].set_ylabel("estimate (m/s²)")
    axes[2].legend(loc="best")
    figure.suptitle(f"{args.mode.upper()} physical plant: mass={args.mass:.1f} kg, drag={args.drag:.2f}, thrust limit={args.max_thrust:.1f} N")
    figure.tight_layout()
    figure.savefig(args.output, dpi=160)
    plt.close(figure)


def main() -> None:
    args = parse_args()
    trial = run(args)
    final_error = TARGET - trial.altitude[-1]
    saturation = float(np.count_nonzero(np.abs(trial.requested - trial.applied) > 1e-9) * TIMESTEP)
    plot(trial, args)
    print(f"Mode: {args.mode}")
    print(f"Final tracking error: {final_error:.3f} m")
    print(f"Saturation time: {saturation:.3f} s")
    print(f"Final disturbance estimate: {trial.estimate[-1]:.3f} m/s²")
    print(f"Saved plot: {args.output}")


if __name__ == "__main__":
    main()
