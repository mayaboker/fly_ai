function runPhysicalPlant({ mass, drag, maxThrust }) {
  const gravity = 9.81;
  const nominalMass = 1.0;
  const reaction = 2.2;
  const dt = 0.01;
  const duration = 8.0;
  const count = Math.round(duration / dt) + 1;
  const time = Array(count).fill(0);
  const target = Array(count).fill(0);
  const altitude = Array(count).fill(0);
  const velocity = Array(count).fill(0);
  const requested = Array(count).fill(0);
  const applied = Array(count).fill(0);
  const kp = reaction ** 2;
  const kd = 2 * reaction;

  for (let index = 0; index < count - 1; index += 1) {
    time[index] = index * dt;
    target[index] = time[index] >= 0.5 ? 3.0 : 0.0;
    requested[index] = nominalMass * gravity + kp * (target[index] - altitude[index]) - kd * velocity[index];
    applied[index] = Math.max(0, Math.min(maxThrust, requested[index]));
    const acceleration = (applied[index] - mass * gravity - drag * velocity[index]) / mass;
    velocity[index + 1] = velocity[index] + acceleration * dt;
    altitude[index + 1] = Math.max(0, altitude[index] + velocity[index + 1] * dt);
    if (altitude[index + 1] === 0 && velocity[index + 1] < 0) velocity[index + 1] = 0;
  }
  time[count - 1] = duration;
  target[count - 1] = 3.0;
  requested[count - 1] = requested[count - 2];
  applied[count - 1] = applied[count - 2];
  const saturationTime = requested.reduce((total, value, index) => total + (Math.abs(value - applied[index]) > 1e-8 ? dt : 0), 0);
  return { time, target, altitude, velocity, requested, applied, finalError: target.at(-1) - altitude.at(-1), saturationTime };
}

function drawPhysicalPlant(canvas, results) {
  const width = Math.max(320, canvas.clientWidth || 760);
  const height = 500;
  const scale = window.devicePixelRatio || 1;
  canvas.width = width * scale;
  canvas.height = height * scale;
  const context = canvas.getContext("2d");
  context.scale(scale, scale);
  context.clearRect(0, 0, width, height);
  const panels = [
    { title: "Altitude", series: [[results.target, "#222", true], [results.altitude, "#1f77b4"]], min: -0.2, max: 3.6 },
    { title: "Velocity", series: [[results.velocity, "#9467bd"]] },
    { title: "Thrust", series: [[results.requested, "#ff7f0e"], [results.applied, "#2ca02c"]] },
  ];
  const left = 58; const right = 16; const top = 18; const gap = 18;
  const panelHeight = (height - top - 36 - gap * 2) / 3;
  panels.forEach((panel, panelIndex) => {
    const y = top + panelIndex * (panelHeight + gap);
    const values = panel.series.flatMap(([series]) => series);
    const min = panel.min ?? Math.min(...values, 0);
    const max = panel.max ?? Math.max(...values, 0.1);
    const padding = Math.max((max - min) * 0.12, 0.1);
    const low = min - padding; const high = max + padding;
    const xFor = (index) => left + (index / (results.time.length - 1)) * (width - left - right);
    const yFor = (value) => y + panelHeight - ((value - low) / (high - low)) * panelHeight;
    context.strokeStyle = "#9e9e9e"; context.lineWidth = 1;
    context.strokeRect(left, y, width - left - right, panelHeight);
    context.fillStyle = "#555"; context.font = "12px sans-serif";
    context.fillText(panel.title, 4, y + 14);
    context.fillText(`${high.toFixed(1)}`, 8, y + 30);
    context.fillText(`${low.toFixed(1)}`, 8, y + panelHeight);
    panel.series.forEach(([series, color, dashed]) => {
      context.beginPath(); context.strokeStyle = color; context.lineWidth = 2;
      context.setLineDash(dashed ? [6, 4] : []);
      series.forEach((value, index) => {
        if (index === 0) context.moveTo(xFor(index), yFor(value));
        else context.lineTo(xFor(index), yFor(value));
      });
      context.stroke(); context.setLineDash([]);
    });
  });
  context.fillStyle = "#555"; context.font = "12px sans-serif";
  context.fillText("simulated time (s)", width / 2 - 42, height - 8);
}

function bindPhysicalSimulators() {
  document.querySelectorAll(".physical-simulator:not([data-bound])").forEach((host) => {
    host.dataset.bound = "true";
    host.innerHTML = `
      <div class="physical-simulator__controls">
        <label class="physical-simulator__control">Mass: <output data-output="mass"></output> kg<input data-input="mass" type="range" min="0.6" max="2.0" step="0.1" value="1.0"></label>
        <label class="physical-simulator__control">Drag: <output data-output="drag"></output> N·s/m<input data-input="drag" type="range" min="0" max="1" step="0.05" value="0.20"></label>
        <label class="physical-simulator__control">Maximum thrust: <output data-output="maxThrust"></output> N<input data-input="maxThrust" type="range" min="10" max="30" step="1" value="20"></label>
      </div>
      <canvas aria-label="Altitude, velocity, and thrust graphs for the physical plant simulator"></canvas>
      <p class="physical-simulator__metrics" aria-live="polite"></p>
      <p class="physical-simulator__note"><strong>Note:</strong> This sandbox uses baseline feedback that assumes a 1.0 kg plant. If you increase mass, settling below the target can be expected: the controller has no disturbance estimate or integral compensation.</p>`;
    const canvas = host.querySelector("canvas");
    const metrics = host.querySelector(".physical-simulator__metrics");
    const update = () => {
      const settings = Object.fromEntries([...host.querySelectorAll("[data-input]")].map((input) => [input.dataset.input, Number(input.value)]));
      Object.entries(settings).forEach(([name, value]) => { host.querySelector(`[data-output="${name}"]`).textContent = value.toFixed(name === "drag" ? 2 : 1); });
      const results = runPhysicalPlant(settings);
      drawPhysicalPlant(canvas, results);
      metrics.textContent = `Final tracking error: ${results.finalError.toFixed(3)} m · Saturation time: ${results.saturationTime.toFixed(2)} s`;
    };
    host.querySelectorAll("[data-input]").forEach((input) => input.addEventListener("input", update));
    update();
  });
}

if (typeof document$ === "undefined") bindPhysicalSimulators();
else document$.subscribe(bindPhysicalSimulators);
