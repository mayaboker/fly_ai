function simulateAdrcStudio(settings) {
  const g = 9.81, nominalMass = 1.0, dt = 0.01, duration = 8, count = duration / dt + 1;
  const time = Array(count).fill(0), target = Array(count).fill(0), altitude = Array(count).fill(0), velocity = Array(count).fill(0), requested = Array(count).fill(0), applied = Array(count).fill(0), estimate = Array(count).fill(0);
  const kp = settings.reaction ** 2, kd = 2 * settings.reaction;
  const b1 = 3 * settings.detection, b2 = 3 * settings.detection ** 2, b3 = settings.detection ** 3;
  let z1 = 0, z2 = 0, z3 = 0, observerInput = 0;
  for (let i = 0; i < count - 1; i += 1) {
    time[i] = i * dt; target[i] = time[i] >= 0.5 ? 3 : 0;
    let correction;
    if (settings.mode === "adrc") {
      const error = altitude[i] - z1;
      z1 += dt * (z2 + b1 * error);
      z2 += dt * (observerInput + z3 + b2 * error);
      z3 += dt * b3 * error;
      correction = kp * (target[i] - z1) - kd * z2 - z3;
    } else {
      correction = kp * (target[i] - altitude[i]) - kd * velocity[i];
    }
    requested[i] = nominalMass * (g + correction);
    applied[i] = Math.max(0, Math.min(settings.maxThrust, requested[i]));
    observerInput = applied[i] / nominalMass - g;
    const acceleration = (applied[i] - settings.mass * g - settings.drag * velocity[i]) / settings.mass;
    velocity[i + 1] = velocity[i] + acceleration * dt;
    altitude[i + 1] = Math.max(0, altitude[i] + velocity[i + 1] * dt);
    if (altitude[i + 1] === 0 && velocity[i + 1] < 0) velocity[i + 1] = 0;
    estimate[i] = settings.mode === "adrc" ? z3 : 0;
  }
  time[count - 1] = duration; target[count - 1] = 3; requested[count - 1] = requested[count - 2]; applied[count - 1] = applied[count - 2]; estimate[count - 1] = estimate[count - 2];
  const saturation = requested.reduce((sum, value, i) => sum + (Math.abs(value - applied[i]) > 1e-8 ? dt : 0), 0);
  return { time, target, altitude, requested, applied, estimate, finalError: 3 - altitude.at(-1), saturation };
}

function drawAdrcStudio(canvas, result, mode) {
  const width = Math.max(320, canvas.clientWidth || 760), height = 500, dpr = window.devicePixelRatio || 1;
  canvas.width = width * dpr; canvas.height = height * dpr;
  const ctx = canvas.getContext("2d"); ctx.scale(dpr, dpr); ctx.clearRect(0, 0, width, height);
  const panels = [
    { name: "Altitude", lines: [[result.target, "#222", true], [result.altitude, "#1f77b4"]], low: -0.2, high: 3.6 },
    { name: "Thrust", lines: [[result.requested, "#ff7f0e"], [result.applied, "#2ca02c"]] },
    { name: mode === "adrc" ? "ADRC estimate" : "ADRC estimate (baseline has none)", lines: [[result.estimate, "#2ca02c"]] },
  ];
  const left = 58, right = 16, top = 18, gap = 18, panelHeight = (height - top - 36 - gap * 2) / 3;
  panels.forEach((panel, panelIndex) => {
    const y = top + panelIndex * (panelHeight + gap), values = panel.lines.flatMap(([line]) => line);
    const min = panel.low ?? Math.min(...values, 0), max = panel.high ?? Math.max(...values, 0.1), pad = Math.max((max - min) * 0.12, 0.1), low = min - pad, high = max + pad;
    const xFor = (i) => left + i / (result.time.length - 1) * (width - left - right), yFor = (value) => y + panelHeight - (value - low) / (high - low) * panelHeight;
    ctx.strokeStyle = "#9e9e9e"; ctx.strokeRect(left, y, width - left - right, panelHeight); ctx.fillStyle = "#555"; ctx.font = "12px sans-serif"; ctx.fillText(panel.name, 4, y + 14);
    panel.lines.forEach(([line, color, dashed]) => { ctx.beginPath(); ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.setLineDash(dashed ? [6, 4] : []); line.forEach((value, i) => i ? ctx.lineTo(xFor(i), yFor(value)) : ctx.moveTo(xFor(i), yFor(value))); ctx.stroke(); ctx.setLineDash([]); });
  });
  ctx.fillStyle = "#555"; ctx.font = "12px sans-serif"; ctx.fillText("simulated time (s)", width / 2 - 42, height - 8);
}

function bindAdrcStudios() {
  document.querySelectorAll(".adrc-studio:not([data-bound])").forEach((host) => {
    host.dataset.bound = "true";
    host.innerHTML = `<div class="adrc-studio__controls">
      <label class="adrc-studio__control">Controller mode<select data-input="mode"><option value="baseline">Baseline feedback</option><option value="adrc" selected>ADRC</option></select></label>
      <label class="adrc-studio__control">Mass: <output data-output="mass"></output> kg<input data-input="mass" type="range" min="0.6" max="2" step="0.1" value="1.4"></label>
      <label class="adrc-studio__control">Drag: <output data-output="drag"></output> N·s/m<input data-input="drag" type="range" min="0" max="1" step="0.05" value="0.20"></label>
      <label class="adrc-studio__control">Maximum thrust: <output data-output="maxThrust"></output> N<input data-input="maxThrust" type="range" min="10" max="30" step="1" value="20"></label>
      <label class="adrc-studio__control">Reaction: <output data-output="reaction"></output><input data-input="reaction" type="range" min="1" max="4" step="0.2" value="2.2"></label>
      <label class="adrc-studio__control">Detection: <output data-output="detection"></output><input data-input="detection" type="range" min="2" max="12" step="0.5" value="6.5"></label>
      </div><canvas aria-label="ADRC studio plots of altitude, thrust, and disturbance estimate"></canvas><p class="adrc-studio__metrics" aria-live="polite"></p><p class="adrc-studio__note"><strong>Compare fairly:</strong> choose Baseline or ADRC, then change one physical or controller setting at a time. The baseline has no estimate; ADRC uses the applied thrust after any limit is enforced.</p>`;
    const update = () => {
      const settings = Object.fromEntries([...host.querySelectorAll("[data-input]")].map((input) => [input.dataset.input, input.tagName === "SELECT" ? input.value : Number(input.value)]));
      ["mass", "drag", "maxThrust", "reaction", "detection"].forEach((name) => { host.querySelector(`[data-output="${name}"]`).textContent = Number(settings[name]).toFixed(name === "drag" ? 2 : 1); });
      const result = simulateAdrcStudio(settings); drawAdrcStudio(host.querySelector("canvas"), result, settings.mode);
      host.querySelector(".adrc-studio__metrics").textContent = `${settings.mode === "adrc" ? "ADRC" : "Baseline"} · Final tracking error: ${result.finalError.toFixed(3)} m · Saturation time: ${result.saturation.toFixed(2)} s · Final estimate: ${result.estimate.at(-1).toFixed(3)} m/s²`;
    };
    host.querySelectorAll("[data-input]").forEach((input) => input.addEventListener("input", update)); update();
  });
}
if (typeof document$ === "undefined") bindAdrcStudios(); else document$.subscribe(bindAdrcStudios);
