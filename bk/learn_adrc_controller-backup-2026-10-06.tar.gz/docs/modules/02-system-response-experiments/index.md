# Module 2: System Response Experiments

Use thermal, tank-level, and moving-mass simulations to observe slow response,
actuator limits, overshoot, and oscillation. Compare runs and describe what
makes a controller look patient, fast, calm, or unable to reach its target.

Next: [Module 2.5 — From Physical Plant to ADRC Signals](../02-5-physical-plant-to-adrc-signals/index.md).
