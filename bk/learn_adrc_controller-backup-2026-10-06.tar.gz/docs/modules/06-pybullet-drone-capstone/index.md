# Module 6: PyBullet Drone Capstone

Start by preparing documented, fair test conditions: target, starting state,
sensor condition, controller settings, and disturbance schedule. Then run a
drone test suite: takeoff, hover, altitude and attitude steps, followed by
deterministic step, pulse, and ramped gusts. Compare a baseline controller with
ADRC using the same scenarios and report plot evidence.

Position control remains an optional extension.
