# Module 5: Optional ADRC Variants

Test linear and nonlinear ADRC choices over small and large errors. Choose a
variant from observed recovery, smoothness, and actuator use rather than from
a symbolic derivation.

Next: [Module 6 — PyBullet Drone Capstone](../06-pybullet-drone-capstone/index.md).
