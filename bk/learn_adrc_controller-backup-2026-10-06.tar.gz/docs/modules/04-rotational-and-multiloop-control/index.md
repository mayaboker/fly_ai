# Module 4: Rotational and Multi-Loop Control

Use motor, rotation, and two-axis simulators as test benches. Change a load,
actuator limit, sensor condition, or one-axis disturbance; then compare speed,
angle, and cross-axis recovery in the plots. Build cascade loops by testing one
loop at a time.

Next: [Module 6 — PyBullet Drone Capstone](../06-pybullet-drone-capstone/index.md).

Optional next: [Module 5 — ADRC Variants](../05-optional-adrc-variants/index.md).
