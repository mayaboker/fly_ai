# Experiment: Baseline Feedback Under a Mass Mismatch

## By the end, you will be able to

- run a baseline feedback controller against a plant that is heavier than it
  expects;
- identify persistent tracking error, overshoot, peak correction, and an
  unreached recovery band in the evidence;
- explain why continued correction does not make the baseline controller a
  disturbance estimator; and
- change the reaction setting once and describe the resulting trade-off.

Prerequisite: [Module 2.5 — From Physical Plant to ADRC Signals](../02-5-physical-plant-to-adrc-signals/index.md).

---

## The question

What can feedback recover from when its plant is heavier than expected but it
has no disturbance estimate?

The controller assumes a 1.0 kg plant. The simulated plant is actually 1.4 kg.
It requests enough force for the mass it expects, then reacts whenever the
altitude measurement is below the 3 m target. This is a deliberately fair
baseline for a later ADRC comparison: the target, actual plant, timestep, and
duration will stay the same.

```mermaid
flowchart LR
  T[3 m target] --> C[Baseline feedback]
  M[Altitude measurement] --> C
  C -->|Force command for assumed 1.0 kg| P[Actual 1.4 kg plant]
  P --> M
  X[Mass mismatch] -. unplanned effect .-> P
```

Baseline feedback is useful here. When it sees a low measurement, it increases
its command. But it has no separate running estimate for the extra weight, so
it must retain an error to keep asking for more force. That residual error is
the behavior this experiment makes visible.

### Checkpoint: identify the mismatch

<div class="quiz" data-answer="b" data-correct-feedback="The controller calculates its force for 1.0 kg while the plant needs force for 1.4 kg, so the mass difference is an unplanned effect.">
  <p><strong>What is the unplanned effect in this experiment?</strong></p>
  <label><input type="radio" name="module3-mismatch" value="a"> The 3 m target.</label><br>
  <label><input type="radio" name="module3-mismatch" value="b"> The actual plant being heavier than the assumed plant.</label><br>
  <label><input type="radio" name="module3-mismatch" value="c"> The measurement being sent to the controller.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Run the baseline

From the repository root, run:

```bash
uv run python examples/03-feedback-and-adrc/baseline_mismatch.py
```

The full runnable source is `examples/03-feedback-and-adrc/baseline_mismatch.py`.
Its key default console output is:

```text
Final tracking error: 0.811 m
Recovery to within 0.10 m: not reached by 8.0 s
Overshoot: 0.000 m
Peak correction: 14.520 m/s²
```

The recovery metric asks whether the measurement enters and stays within 0.10 m
of the target. `Not reached` is useful evidence, not a missing result: with
these conditions, baseline feedback still settles below the target by the end
of the test.

### Watch the scene

The animation reveals the same evidence over simulated time. The moving marker
shows the baseline correction reacting as altitude rises, then settling below
the target band because the controller continues to assume the wrong mass.

![Animated altitude and baseline-correction traces for a heavier-than-assumed plant.](images/baseline_mismatch.gif)

Use the static plot for careful inspection. The top panel shows that the
measurement remains below the target band; the lower panel shows a sustained
positive correction. Feedback reacts, but the sustained correction comes from
the persistent error rather than a separate estimate of the extra weight.

![Baseline feedback settling below the target under a mass mismatch.](images/baseline_mismatch.png)

### Checkpoint: interpret the recovery result

<div class="quiz" data-answer="c" data-correct-feedback="The controller is reacting to the error, but its final measurement remains outside the target band under this mismatch.">
  <p><strong>What does “not reached by 8.0 s” show in this baseline run?</strong></p>
  <label><input type="radio" name="module3-recovery" value="a"> The simulator did not record altitude.</label><br>
  <label><input type="radio" name="module3-recovery" value="b"> The target was removed from the experiment.</label><br>
  <label><input type="radio" name="module3-recovery" value="c"> The baseline did not enter and remain in the defined near-target band.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Read the important code

The source contains only one controller path: error-driven baseline feedback.
The `reaction` setting creates proportional and velocity-based corrections.
Those corrections are converted into a force using the assumed mass, then the
actual heavier plant updates its motion. There is no observer and no
disturbance estimate in this loop.

??? example "Show the baseline feedback and plant-update loop"

    ```python
    --8<-- "examples/03-feedback-and-adrc/baseline_mismatch.py:baseline-loop"
    ```

The metrics deliberately distinguish the final error from recovery. A trace
can move closer to the target without ever staying inside the target band. The
peak correction records how hard the controller had to push while responding.

??? example "Show how the experiment reports its evidence"

    ```python
    --8<-- "examples/03-feedback-and-adrc/baseline_mismatch.py:report-metrics"
    ```

### Checkpoint: separate correction from estimation

<div class="quiz" data-answer="a" data-correct-feedback="A baseline controller can increase its correction because it sees error, but it does not maintain a separate estimate of the unplanned mass effect.">
  <p><strong>Why does the sustained baseline correction not count as a disturbance estimate?</strong></p>
  <label><input type="radio" name="module3-estimation" value="a"> It is driven by the remaining tracking error rather than a separate estimate of the unplanned effect.</label><br>
  <label><input type="radio" name="module3-estimation" value="b"> It removes the heavier mass from the plant.</label><br>
  <label><input type="radio" name="module3-estimation" value="c"> It gives the controller a different target.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Hands-on exercise: change one reaction setting

Create a three-row experiment log. Keep the actual and assumed masses,
timestep, duration, and target fixed. Change only `--reaction`.

| Run | Reaction setting | Prediction | Evidence to record |
| --- | --- | --- | --- |
| Reference | 2.2 | Predict the final tracking error and target-band outcome. | Final error, recovery result, and peak correction. |
| Stronger response | 3.0 | Predict whether the remaining error shrinks and whether the command demand grows. | The same metrics and one observation from the plot. |
| Gentler response | 1.6 | Predict whether the altitude settles farther below the target. | The same metrics and one observation from the plot. |

Run one changed setting at a time:

```bash
uv run python examples/03-feedback-and-adrc/baseline_mismatch.py --reaction 3.0
uv run python examples/03-feedback-and-adrc/baseline_mismatch.py --reaction 1.6
```

For every row, finish with: **“With the same mass mismatch, changing only the
reaction setting changed ___, while the baseline still ___.”** Do not call a
larger correction an estimate; reserve that term for an ADRC observer in the
next topic.

### Checkpoint: plan a fair tuning test

<div class="quiz" data-answer="b" data-correct-feedback="Keeping the mismatch and every other stated condition fixed lets the changed reaction setting explain the difference in evidence.">
  <p><strong>Which change makes the exercise a fair test of reaction setting?</strong></p>
  <label><input type="radio" name="module3-tuning" value="a"> Change reaction and actual mass together.</label><br>
  <label><input type="radio" name="module3-tuning" value="b"> Change only reaction while preserving the mismatch and all other test conditions.</label><br>
  <label><input type="radio" name="module3-tuning" value="c"> Change the target whenever the plot looks slow.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

You now have the baseline evidence needed for a fair ADRC comparison. Next:
**Topic 2 — ADRC under the same test**, where the target, plant, mismatch,
timestep, and duration stay fixed while a disturbance estimate is added.
