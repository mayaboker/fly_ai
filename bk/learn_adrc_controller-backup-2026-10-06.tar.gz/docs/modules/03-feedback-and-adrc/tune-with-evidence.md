# Experiment: Tune ADRC with Evidence

## By the end, you will be able to

- compare detection settings under the same timed-payload test;
- use recovery time, tracking error, and estimate traces to describe a tuning trade-off;
- change one observer setting without changing the plant or success criteria; and
- choose a setting based on recorded evidence rather than a universal rule.

Prerequisite: [Topic 3 — Read the Disturbance Estimate](read-the-estimate.md).

---

## The question

How does the detection setting change observer behavior and recovery under the same unplanned payload?

Detection controls how quickly the observer updates its disturbance estimate. It is not a “higher is always better” control. A faster estimate may shorten recovery in one clean simulation, while another test could reveal a less calm trace or greater sensitivity to measurement noise. Make one change, inspect the evidence, and state the tested conditions.

```mermaid
flowchart LR
  P[Same target, payload, reaction, and timestep] --> R[Run one detection setting]
  R --> E[Read altitude, recovery, and estimate]
  E --> C[Compare with the reference setting]
  C --> N[Make one next tuning choice]
```

---

## What you tune and what counts as evidence

You tune exactly one setting: **detection**. It controls how rapidly ADRC's
observer updates its disturbance estimate. A lower value makes the observer
more gradual; a higher value makes it react more quickly. This topic does not
tune reaction, payload mass, target, or timestep.

Everything else is evidence to read, not a setting to change:

| Item | Role in this experiment | What to ask |
| --- | --- | --- |
| Detection setting | The single tuning input | How quickly should the observer update? |
| Final tracking error | End-of-test evidence | Did the altitude finish close to target? |
| Payload recovery | Target-band evidence | How long after the payload did altitude enter and stay within 0.10 m of target? |
| Altitude trace | Visible response evidence | Did the payload cause an unacceptable dip, overshoot, or slow return? |
| Estimate trace | Observer-behavior evidence | When did the estimate move, and was its behavior acceptable for this test? |

For example, a setting that produces a faster recovery but a jumpy estimate is
not automatically the right choice. Record both observations, then choose the
next test based on the trade-off you actually observed.

### Checkpoint: isolate the tuning change

<div class="quiz" data-answer="c" data-correct-feedback="A detection-only change lets the observer update rate explain any changed recovery or estimate behavior.">
  <p><strong>What must stay fixed in a fair detection-setting comparison?</strong></p>
  <label><input type="radio" name="module3-tune-fairness" value="a"> Only the plot title.</label><br>
  <label><input type="radio" name="module3-tune-fairness" value="b"> Detection and payload mass together.</label><br>
  <label><input type="radio" name="module3-tune-fairness" value="c"> Target, payload, reaction setting, timestep, and success metrics.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Run the detection sweep

From the repository root, run:

```bash
uv run python examples/03-feedback-and-adrc/detection_sweep.py
```

The full runnable source is `examples/03-feedback-and-adrc/detection_sweep.py`. Its default console output is:

```text
Detection | final error (m) | payload recovery | final estimate (m/s²)
      4.0 |          -0.052 | 2.860 s          |                 -3.753
      6.4 |           0.010 | 2.220 s          |                 -3.912
      8.0 |           0.008 | 1.970 s          |                 -3.932
```

In this clean timed-payload test, higher detection reaches the target band sooner. The evidence does not establish a universal best value: it only records what happened for these settings, plant conditions, and metric definitions.

![Altitude, correction, and estimate traces for three detection settings under the same payload.](images/detection_sweep.png)

## How to monitor the graphs while tuning

Read the three panels in order after every detection change. The red vertical
line marks when the payload changes the plant; compare what happens after that
line, not just the final point.

| Graph | What to monitor | How it helps you tune |
| --- | --- | --- |
| **Altitude** (top) | Depth of the post-payload dip, overshoot, target-band recovery time, and final error. | This is the main success test. If recovery is too slow or the dip is unacceptable, try a detection change and compare the same metrics. |
| **Correction** (middle) | Peak size, sudden jumps, sustained demand, and whether the trace becomes less calm. | A faster altitude recovery is not automatically better if it requires an excessive or jumpy command. Use this graph to reject an unacceptable control-effort trade-off. |
| **Estimate** (bottom) | When the estimate starts moving after the payload, how quickly it settles, and whether it oscillates or jitters. | This explains the observer's contribution. If it responds too slowly, a higher detection may help; if it becomes too jumpy in a realistic noisy test, reduce detection or investigate the measurement. |

Use altitude to decide whether the response is acceptable, then use correction
and estimate traces to decide whether the cost of that response is acceptable.
Never tune from only one graph: a shorter recovery time can hide excessive
command demand, and a smooth estimate can hide poor tracking.

### Checkpoint: interpret the sweep

<div class="quiz" data-answer="a" data-correct-feedback="Detection 8.0 has the shortest recorded payload recovery in this sweep, but that is a scenario-specific result rather than a universal tuning law.">
  <p><strong>What is the strongest conclusion from the default table?</strong></p>
  <label><input type="radio" name="module3-tune-result" value="a"> Detection 8.0 recovered fastest in this tested sweep.</label><br>
  <label><input type="radio" name="module3-tune-result" value="b"> Detection 8.0 is always the best ADRC setting.</label><br>
  <label><input type="radio" name="module3-tune-result" value="c"> Final estimates directly measure payload mass.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Read the important code

The sweep calls the same timed-payload ADRC trial for every detection value. It fixes reaction, payload mass, timestep, duration, and target by reusing the same experiment function. Only detection changes between traces.

??? example "Show the one-setting detection sweep"

    ```python
    --8<-- "examples/03-feedback-and-adrc/detection_sweep.py:detection-sweep"
    ```

Each row uses the same final-error, target-band recovery, and final-estimate definitions. A common scorecard prevents a changed measurement rule from being mistaken for an improvement in controller behavior.

??? example "Show the shared metric reporting"

    ```python
    --8<-- "examples/03-feedback-and-adrc/detection_sweep.py:sweep-metrics"
    ```

### Checkpoint: choose evidence over appearance

<div class="quiz" data-answer="b" data-correct-feedback="Recovery time and the estimate trace together show the target-return outcome and how the observer behaved while producing it.">
  <p><strong>Which evidence best supports a detection-setting choice?</strong></p>
  <label><input type="radio" name="module3-tune-evidence" value="a"> The setting with the largest number.</label><br>
  <label><input type="radio" name="module3-tune-evidence" value="b"> Recovery metrics together with the altitude and estimate traces.</label><br>
  <label><input type="radio" name="module3-tune-evidence" value="c"> A controller name without a test result.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Hands-on exercise: test a wider range

Keep the same test and run a three-setting comparison of your own:

```bash
uv run python examples/03-feedback-and-adrc/detection_sweep.py --detections 3.0 6.4 10.0
```

Create a three-row log. For each setting, predict whether the estimate will develop more slowly or quickly than the 6.4 reference. Record final error, payload recovery, and one observation from the estimate trace. If a trace looks less calm or recovery becomes unacceptable, record that as evidence rather than treating the larger number as an automatic improvement.

Finish with: **“For this timed-payload test, I would try detection ___ next because the evidence shows ___; I would verify it under ___ next.”**

### Checkpoint: make a bounded recommendation

<div class="quiz" data-answer="c" data-correct-feedback="A bounded recommendation names the tested scenario and leaves room to verify the setting under another relevant condition.">
  <p><strong>Which tuning recommendation is evidence-based?</strong></p>
  <label><input type="radio" name="module3-tune-recommendation" value="a"> Always choose the largest detection setting.</label><br>
  <label><input type="radio" name="module3-tune-recommendation" value="b"> Ignore the estimate trace if recovery looks fast.</label><br>
  <label><input type="radio" name="module3-tune-recommendation" value="c"> Choose a setting for this test, then verify it under another relevant condition.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

You have evidence for a bounded tuning choice. Next: [Topic 5 — Build a Compact ADRC Controller](build-full-adrc-controller.md), where you connect the observer and compensation into one working class.
