# Module 3 Roadmap

Module 3 turns the first ADRC result into a repeatable comparison method. You
will use the same plant, target, disturbance or mismatch, timestep, and test
duration for both controllers. That isolates the controller strategy as the
meaningful difference.

## Learning path

1. **[Establish the baseline](baseline-feedback-under-mismatch.md).** Run
   feedback without a disturbance estimate under a defined mass mismatch.
2. **[Enable ADRC fairly](adrc-under-same-test.md).** Repeat the same scenario
   with ADRC and compare the evidence, rather than comparing differently
   configured runs.
3. **[Read the estimate carefully](read-the-estimate.md).** Identify when the
   disturbance estimate changes and relate that timing to plant behavior. It
   estimates the combined unexplained effect; it is not a direct sensor reading.
4. **[Tune one setting](tune-with-evidence.md).** Change either the reaction
   setting or detection setting, state a prediction, and record the resulting
   trade-off.
5. **[Build the compact controller](build-full-adrc-controller.md).** Connect
   observer state, compensation, and the plant test into one working ADRC loop.
6. **[Test actuator limits](actuator-limits-and-saturation.md).** Feed applied
   saturated commands into the observer and distinguish control handling from
   insufficient physical authority.
7. **[Test observer robustness](measurement-noise-and-observer-robustness.md).** Compare detection settings under the same noisy measurement and make a bounded tuning decision.

## Experiment scorecard

Use the same scorecard for every baseline-versus-ADRC test:

| Evidence | What it answers |
| --- | --- |
| Tracking error | Which controller remains closer to the target? |
| Recovery time | Which controller returns sooner after the unplanned effect? |
| Overshoot | Did faster recovery carry the output too far past the target? |
| Control effort | Did recovery require an excessive command? |
| Disturbance estimate | Did the estimate change while the unexplained effect mattered? |

## Boundary

This module does not require observer derivations, state-space notation, or
hand-calculated gains. Treat reaction and detection as testable learner-facing
settings. Optional material may later connect them to controller and observer
bandwidth.

## Exit check

Before continuing, you should be able to:

- set up a fair baseline-versus-ADRC comparison;
- state a conclusion that matches the plots and recorded metrics;
- explain why an estimate is not a direct disturbance measurement; and
- make one tuning change and identify its recovery trade-off.

Prerequisite: [Module 2.5 — From Physical Plant to ADRC Signals](../02-5-physical-plant-to-adrc-signals/index.md).
Next: [Module 4 — Rotational and Multi-Loop Control](../04-rotational-and-multiloop-control/index.md).
