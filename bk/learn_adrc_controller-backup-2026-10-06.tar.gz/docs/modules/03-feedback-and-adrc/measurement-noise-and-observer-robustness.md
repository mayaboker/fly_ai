# Experiment: Measurement Noise and Observer Robustness

## By the end, you will be able to

- compare slow and fast detection settings with the same noisy measurement;
- recognize estimate jitter and command jitter as observer-tuning evidence;
- explain why faster detection is not automatically better; and
- make a bounded tuning recommendation for a noisy test.

Prerequisite: [Topic 6 — Actuator Limits and Saturation](actuator-limits-and-saturation.md).

---

## The question

What changes when the observer receives a noisy altitude measurement instead of a perfectly clean one?

The physical plant and payload are identical in both runs. The simulator gives both detection settings the same seeded noise sequence, so detection is the only intended difference. The dots in the altitude panel are noisy measurements; the continuous lines are the plant's true altitude.

```mermaid
flowchart LR
  P[Plant altitude] --> N[Add the same measurement noise]
  N --> M[Noisy measurement]
  M --> O[Observer]
  O --> E[Disturbance estimate]
  E --> C[ADRC correction]
  C --> P
```

### Checkpoint: preserve a fair noise test

<div class="quiz" data-answer="b" data-correct-feedback="Giving both trials the same seeded noise sequence isolates detection as the intended cause of the different observer behavior.">
  <p><strong>Why do both trials receive the same noise sequence?</strong></p>
  <label><input type="radio" name="module3-noise-fairness" value="a"> To remove all measurement noise from the test.</label><br>
  <label><input type="radio" name="module3-noise-fairness" value="b"> To make detection the single intended difference between the trials.</label><br>
  <label><input type="radio" name="module3-noise-fairness" value="c"> To give the faster observer more information.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Run the noisy-measurement comparison

From the repository root, run:

```bash
uv run python examples/03-feedback-and-adrc/measurement_noise.py
```

The full runnable source is `examples/03-feedback-and-adrc/measurement_noise.py`. Its default console output is:

```text
Detection | payload recovery | late estimate jitter (m/s²) | final error (m)
      4.0 | 2.890 s          |                        0.202 |          -0.054
     10.0 | 1.690 s          |                        0.685 |          -0.006
```

The fast setting returns to the target band sooner in this test, but its late estimate jitter is larger. The table makes the trade-off explicit: response speed and estimate calmness must both be judged.

![Slow and fast detection under the same noisy altitude measurement.](images/measurement_noise.png)

## How to read the noisy graphs

| Graph | What to monitor | Tuning meaning |
| --- | --- | --- |
| Altitude | Target recovery and true-altitude calmness. | Fast recovery is useful only if the true motion remains acceptable. |
| Correction | Rapid changes or visible jitter after the payload settles. | A jumpy command can be an unacceptable cost of reacting strongly to noisy measurements. |
| Estimate | Late-trace jitter after the payload response has settled. | More jitter means the observer is following more measurement noise as if it were disturbance evidence. |

### Checkpoint: interpret estimate jitter

<div class="quiz" data-answer="c" data-correct-feedback="A fast observer can treat more short-term measurement variation as evidence, so its estimate can become less calm even when recovery is faster.">
  <p><strong>What does larger late estimate jitter suggest in this noisy test?</strong></p>
  <label><input type="radio" name="module3-noise-jitter" value="a"> The payload has disappeared from the plant.</label><br>
  <label><input type="radio" name="module3-noise-jitter" value="b"> The target band has changed size.</label><br>
  <label><input type="radio" name="module3-noise-jitter" value="c"> The observer is responding more strongly to measurement variation.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Read the important code

The simulation receives a supplied noise array instead of generating random values inside each trial. This keeps the noise evidence identical for slow and fast detection. The observer still follows the same update sequence as Topic 5, but it now sees the noisy measurement.

??? example "Show the noisy observer loop"

    ```python
    --8<-- "examples/03-feedback-and-adrc/measurement_noise.py:noisy-observer-loop"
    ```

The report measures late estimate jitter after 6 s, when the payload response should have settled. It uses the same recovery definition for both trials.

??? example "Show the noise evidence scorecard"

    ```python
    --8<-- "examples/03-feedback-and-adrc/measurement_noise.py:noise-evidence"
    ```

### Checkpoint: choose a tuning basis

<div class="quiz" data-answer="a" data-correct-feedback="A detection choice should balance recovery evidence with correction and estimate behavior, not optimize only one number.">
  <p><strong>Which evidence should guide a noisy-measurement tuning choice?</strong></p>
  <label><input type="radio" name="module3-noise-evidence" value="a"> Recovery, correction behavior, and estimate jitter together.</label><br>
  <label><input type="radio" name="module3-noise-evidence" value="b"> Only the fastest recovery time.</label><br>
  <label><input type="radio" name="module3-noise-evidence" value="c"> Only the smallest detection number.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Hands-on exercise: increase measurement noise

Keep both detection settings and the seed fixed. Change only the noise magnitude:

```bash
uv run python examples/03-feedback-and-adrc/measurement_noise.py --noise-std 0.08
```

Create a two-row log for noise standard deviations 0.04 and 0.08. For each detection setting, record recovery, final error, late estimate jitter, and one correction-trace observation. State which detection setting you would use for this test and what noise condition you would test next.

### Checkpoint: make a bounded decision

<div class="quiz" data-answer="b" data-correct-feedback="A setting that works under one measured noise level should be verified when the sensor condition changes; the evidence does not justify a universal value.">
  <p><strong>What is the best conclusion after one noisy-measurement sweep?</strong></p>
  <label><input type="radio" name="module3-noise-decision" value="a"> The fastest detection setting is best for every sensor.</label><br>
  <label><input type="radio" name="module3-noise-decision" value="b"> Choose a setting for these conditions, then verify it under another relevant noise level.</label><br>
  <label><input type="radio" name="module3-noise-decision" value="c"> Noise does not affect observer tuning.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

You have completed Module 3's experiment-to-implementation path. Next: [Module 4 — Rotational and Multi-Loop Control](../04-rotational-and-multiloop-control/index.md).
