# Guided Build: A Compact ADRC Controller

## By the end, you will be able to

- identify the state a compact ADRC controller must remember;
- implement the observer update and disturbance compensation in the correct order;
- connect the controller to the familiar timed-payload plant; and
- verify the completed controller with tracking, recovery, and estimate evidence.

Prerequisite: [Topic 4 — Tune with Evidence](tune-with-evidence.md).

---

## What “full” means in this course

This topic builds a complete working ADRC loop for the one-dimensional learning plant. It is complete enough to estimate altitude, velocity, and a combined disturbance; compensate for that estimate; and run a repeatable payload test. It is not a production drone controller: it has no sensor-noise model, actuator safety layer, or three-dimensional attitude control.

You will see a short, partially completed scaffold for each step. Use it to reason about the missing behavior first. The full working reference is available in the matching collapsed section and in `examples/03-feedback-and-adrc/full_adrc_controller.py`.

```mermaid
flowchart LR
  M[Altitude measurement] --> O[Observer update]
  U1[Previous correction] --> O
  O --> E[Combined-effect estimate]
  T[Target] --> F[Feedback correction]
  E --> F
  F --> U[Command]
  U --> P[Plant]
  P --> M
```

### One controller update, in sequence

The controller does not receive the payload mass. It sees the target and the
latest altitude measurement, updates its observer, forms a compensated command,
and then the plant produces the next measurement.

```mermaid
sequenceDiagram
    participant Plant as Plant
    participant Sensor as Altitude measurement
    participant ADRC as ADRC controller
    participant Observer as Observer state

    Plant->>Sensor: current altitude
    Sensor->>ADRC: measurement
    ADRC->>Observer: compare measurement with prediction
    Observer-->>ADRC: altitude, velocity, and combined-effect estimate
    ADRC->>ADRC: feedback toward target minus estimate
    ADRC->>Plant: compensated force command
    Note over Plant: Payload changes plant behavior at 4 s
    Plant-->>Sensor: next altitude
```

### Checkpoint: identify the build goal

<div class="quiz" data-answer="b" data-correct-feedback="The course controller estimates motion and the combined unplanned effect, then uses that estimate to improve its correction in the same simulated plant.">
  <p><strong>What makes this a complete course-level ADRC loop?</strong></p>
  <label><input type="radio" name="module3-build-goal" value="a"> It directly reads the payload mass from a sensor.</label><br>
  <label><input type="radio" name="module3-build-goal" value="b"> It updates an observer, estimates the combined effect, and compensates in feedback.</label><br>
  <label><input type="radio" name="module3-build-goal" value="c"> It controls every axis of a physical drone.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Step 1: create controller state

Start with a controller that remembers estimates between updates. Fill the three state values and the previous correction. They begin at zero because the controller starts without knowledge of the plant or payload.

```python
class ADRCController:
    def __init__(self, reaction: float, detection: float) -> None:
        self.reaction_gain = reaction**2
        self.damping_gain = 2.0 * reaction
        self.beta1 = 3.0 * detection
        self.beta2 = 3.0 * detection**2
        self.beta3 = detection**3

        # TODO: initialize estimated altitude, velocity, disturbance,
        # and the previous correction.
```

The reaction setting shapes feedback strength. The detection setting shapes how rapidly the observer uses new measurement evidence. Neither setting reveals the payload directly.

| Setting | Used for in this controller | What a larger value tends to do |
| --- | --- | --- |
| `reaction` | Creates `reaction_gain` and `damping_gain` for target-following feedback. | Pushes altitude toward the target more strongly; it can also increase overshoot or correction demand. |
| `detection` | Creates `beta1`, `beta2`, and `beta3` for the observer update. | Makes the disturbance estimate respond sooner; it can also make the estimate less calm or more sensitive to measurement noise. |

In short: tune **reaction** to change how strongly the controller follows the target, and tune **detection** to change how quickly the observer learns the combined unplanned effect. Keep them separate in an experiment so the resulting evidence has one clear explanation.

??? example "Show the working controller state"

    ```python
    --8<-- "examples/03-feedback-and-adrc/full_adrc_controller.py:controller-state"
    ```

### Checkpoint: choose remembered state

<div class="quiz" data-answer="a" data-correct-feedback="The observer needs persistent estimates so it can compare prediction with later measurements and update its combined-effect estimate over time.">
  <p><strong>Why does ADRC keep estimated state between updates?</strong></p>
  <label><input type="radio" name="module3-build-state" value="a"> It uses prior estimates and corrections to interpret the next measurement.</label><br>
  <label><input type="radio" name="module3-build-state" value="b"> It avoids receiving any altitude measurement.</label><br>
  <label><input type="radio" name="module3-build-state" value="c"> It guarantees the payload will not change.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Step 2: update the observer, then compensate

On every update, first compare the altitude measurement with the estimated altitude. Use that gap to update the estimated altitude, velocity, and combined effect. Then calculate feedback toward the target and subtract the effect estimate from the desired correction.

```python
def update(self, measurement: float, target: float, timestep: float) -> float:
    measurement_error = measurement - self.estimated_altitude

    # TODO: update estimated altitude, velocity, and disturbance.
    # TODO: calculate feedback from target and estimated motion.
    # TODO: subtract the disturbance estimate and save the correction.
    return correction
```

The order matters. The observer incorporates the newest measurement before its estimate is used for the current correction. A negative estimate represents a downward combined effect; subtracting it increases the upward correction.

??? example "Show the working observer and compensation update"

    ```python
    --8<-- "examples/03-feedback-and-adrc/full_adrc_controller.py:controller-update"
    ```

### Checkpoint: compensate the estimate

<div class="quiz" data-answer="c" data-correct-feedback="Subtracting a negative downward-effect estimate adds upward correction, which counteracts the behavior the assumed plant did not explain.">
  <p><strong>What does the controller do with a negative downward-effect estimate?</strong></p>
  <label><input type="radio" name="module3-build-compensation" value="a"> It changes the target altitude to a negative value.</label><br>
  <label><input type="radio" name="module3-build-compensation" value="b"> It ignores the estimate and keeps the same baseline correction.</label><br>
  <label><input type="radio" name="module3-build-compensation" value="c"> It subtracts the estimate, increasing upward correction.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Step 3: connect the controller to a fair plant test

Call `controller.update` with the current altitude measurement, then let the plant receive the resulting correction. At 4 s, the plant receives the extra payload, but the controller does not. Record the estimate after each update so the plot can show when it develops.

```python
controller = ADRCController(reaction, detection)

for index in range(len(time) - 1):
    correction[index + 1] = controller.update(
        measurement=altitude[index], target=target[index], timestep=TIMESTEP
    )

    # TODO: update the plant with its actual mass.
    # TODO: record controller.estimated_disturbance.
```

??? example "Show the working controller test loop"

    ```python
    --8<-- "examples/03-feedback-and-adrc/full_adrc_controller.py:controller-test"
    ```

### Checkpoint: preserve the test boundary

<div class="quiz" data-answer="b" data-correct-feedback="The controller sees only its usual measurement and target; withholding the payload event lets the observer demonstrate learned compensation from behavior.">
  <p><strong>Why is the payload mass kept inside the plant update instead of passed to `controller.update`?</strong></p>
  <label><input type="radio" name="module3-build-boundary" value="a"> The target should change whenever payload changes.</label><br>
  <label><input type="radio" name="module3-build-boundary" value="b"> ADRC must infer the unplanned effect from measurement evidence.</label><br>
  <label><input type="radio" name="module3-build-boundary" value="c"> The plant does not need a mass value.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Run the completed reference

Run the full working implementation after attempting the scaffolds:

```bash
uv run python examples/03-feedback-and-adrc/full_adrc_controller.py
```

Its default console output is:

```text
Final tracking error: 0.010 m
Recovery after payload to within 0.10 m: 2.220 s
Final disturbance estimate: -3.912 m/s²
```

![Complete compact ADRC controller responding to a timed payload.](images/full_adrc_controller.png)

The plot is the final verification. The estimate is near zero before the payload, becomes negative after the payload changes plant behavior, and supports a correction that returns altitude to the target band.

---

## Full working controller reference

The three guided steps above cover the controller state, observer update, and
plant-test integration separately. Expand this section when you want to see
the complete runnable reference in one place. It remains synchronized with the
file used by the command above.

??? example "Show the full compact ADRC controller"

    ```python
    --8<-- "examples/03-feedback-and-adrc/full_adrc_controller.py"
    ```

### Checkpoint: verify the completed loop

<div class="quiz" data-answer="a" data-correct-feedback="Near-zero final error, target-band recovery, and an estimate that changes after the payload together show the completed loop behaving as intended in this scenario.">
  <p><strong>Which evidence best verifies the completed controller in this test?</strong></p>
  <label><input type="radio" name="module3-build-verify" value="a"> Target-band recovery, small final error, and an estimate that changes after the payload.</label><br>
  <label><input type="radio" name="module3-build-verify" value="b"> A controller class name without a plot.</label><br>
  <label><input type="radio" name="module3-build-verify" value="c"> The payload mass passed directly into the observer.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Hands-on exercise: make one safe modification

Copy `full_adrc_controller.py` to a scratch file, then change **only** the detection default from `6.4` to `4.0` or `8.0`. Run it and record final error, recovery time, and the estimate trace. Explain whether the changed behavior matches your prediction.

Do not add payload mass as an input to `ADRCController.update`. That would remove the learning problem the observer solves.

Next: [Topic 6 — Actuator Limits and Saturation](actuator-limits-and-saturation.md), where the controller handles a command the plant cannot fully apply.
