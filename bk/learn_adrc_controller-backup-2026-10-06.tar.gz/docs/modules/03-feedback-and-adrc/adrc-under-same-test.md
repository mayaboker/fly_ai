# Experiment: ADRC Under the Same Mass Mismatch

## By the end, you will be able to

- run baseline feedback and ADRC against the same heavier-than-assumed plant;
- use matched tracking and recovery metrics to describe the result;
- interpret the ADRC disturbance estimate as a combined unplanned effect, not
  a direct mass measurement; and
- change the detection setting once and identify the evidence it changes.

Prerequisite: [Topic 1 — Baseline Feedback Under a Mass Mismatch](baseline-feedback-under-mismatch.md).

---

## The question

Does adding a disturbance estimate improve recovery when all of Topic 1's test
conditions stay fixed?

Both trials use the same 3 m target, 1.0 kg assumed mass, 1.4 kg actual mass,
0.01 s timestep, 8 s duration, and reaction setting. The baseline corrects
the measured error. ADRC also corrects error, but its observer maintains a
running estimate of the effect that the assumed plant does not explain.

```mermaid
flowchart LR
  T[Same 3 m target] --> B[Baseline feedback]
  T --> A[ADRC controller]
  B --> P1[Same 1.4 kg plant]
  A --> P2[Same 1.4 kg plant]
  M1[Baseline measurement] --> B
  M2[ADRC measurement] --> A
  P1 --> M1
  P2 --> M2
  O[Observer: combined-effect estimate] --> A
  M2 --> O
```

The estimate is not a scale reading. It combines the persistent effect of the
wrong mass with any other behavior the simple assumed plant fails to explain.
That is why the lesson calls it a **disturbance estimate**, not a mass sensor.

### Checkpoint: preserve a fair comparison

<div class="quiz" data-answer="b" data-correct-feedback="Keeping the plant and all test conditions the same means the added estimate is the intended explanation for any difference in recovery.">
  <p><strong>What is the intended difference between the two trials?</strong></p>
  <label><input type="radio" name="module3-adrc-fairness" value="a"> ADRC receives a lighter plant.</label><br>
  <label><input type="radio" name="module3-adrc-fairness" value="b"> ADRC adds an observer and its disturbance estimate.</label><br>
  <label><input type="radio" name="module3-adrc-fairness" value="c"> ADRC receives a different target.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Run the matched comparison

From the repository root, run:

```bash
uv run python examples/03-feedback-and-adrc/adrc_same_mismatch.py
```

The full runnable source is `examples/03-feedback-and-adrc/adrc_same_mismatch.py`.
Its key default console output is:

```text
Baseline final tracking error: 0.811 m
ADRC final tracking error:     0.001 m
Baseline recovery to within 0.10 m: not reached by 8.0 s
ADRC recovery to within 0.10 m:     2.260 s after target step
ADRC final disturbance estimate: -3.925 m/s²
```

The matched result supports a narrow conclusion: in this mass-mismatch test,
the ADRC estimate improved recovery. It does not show that ADRC measured mass
directly or that it will improve every possible controller test.

### Watch the comparison

The animation reveals the two altitude traces, their corrections, and ADRC's
estimate together. The green estimate becomes negative as the observer learns
the plant's unexplained downward effect; ADRC uses that negative estimate to
request additional correction without relying on the same large residual error.

![Animated comparison of baseline feedback and ADRC under the same mass mismatch.](images/adrc_same_mismatch.gif)

Use the static plot to inspect the complete traces. In the top panel, ADRC
enters the target band while baseline remains below it. The middle panel shows
that the corrections differ, and the bottom panel shows when the estimate
develops. Read all three panels together before making a claim.

![Baseline feedback and ADRC under the same mass mismatch.](images/adrc_same_mismatch.png)

### Checkpoint: state the evidence

<div class="quiz" data-answer="a" data-correct-feedback="ADRC enters the target band and has a much smaller final tracking error under the same recorded conditions.">
  <p><strong>Which conclusion best matches this experiment?</strong></p>
  <label><input type="radio" name="module3-adrc-result" value="a"> In this scenario, the ADRC estimate improved recovery under the same mismatch.</label><br>
  <label><input type="radio" name="module3-adrc-result" value="b"> ADRC measured the plant's mass exactly.</label><br>
  <label><input type="radio" name="module3-adrc-result" value="c"> Baseline feedback can never recover from any mismatch.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Read the important code

The two trials share the same plant update. Only the `use_adrc` branch adds an
observer: it compares predicted and measured altitude, updates estimated
motion and the combined effect, then subtracts that estimate from the desired
correction. The baseline branch uses measured altitude and velocity directly
and supplies no estimated effect.

??? example "Show the shared baseline-and-ADRC trial loop"

    ```python
    --8<-- "examples/03-feedback-and-adrc/adrc_same_mismatch.py:shared-adrc-loop"
    ```

The reporting code applies the same target-band definition to both trials.
This is what makes `not reached` for baseline and the ADRC recovery time
comparable evidence rather than differently scored results.

??? example "Show the matched metric reporting code"

    ```python
    --8<-- "examples/03-feedback-and-adrc/adrc_same_mismatch.py:matched-metrics"
    ```

### Checkpoint: interpret the estimate

<div class="quiz" data-answer="c" data-correct-feedback="The observer estimates the combined effect that its assumed plant does not explain, so the value is useful for compensation without being a direct mass reading.">
  <p><strong>What does the negative ADRC estimate mean here?</strong></p>
  <label><input type="radio" name="module3-adrc-estimate" value="a"> The observer has directly weighed the plant.</label><br>
  <label><input type="radio" name="module3-adrc-estimate" value="b"> The target altitude has become negative.</label><br>
  <label><input type="radio" name="module3-adrc-estimate" value="c"> The observer has learned a combined effect that pulls the response below the assumed-plant behavior.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Hands-on exercise: change one detection setting

Keep reaction, assumed mass, actual mass, target, timestep, and duration
fixed. Create a three-row log and change only `--detection`.

| Run | Detection setting | Prediction | Evidence to record |
| --- | --- | --- | --- |
| Reference | 6.4 | Predict when the estimate will settle and whether ADRC reaches the target band. | Final error, recovery result, and estimate behavior. |
| Slower detection | 4.0 | Predict whether the estimate develops more gradually. | The same metrics and one estimate-trace observation. |
| Faster detection | 8.0 | Predict whether the estimate responds sooner and whether its trace becomes less calm. | The same metrics and one estimate-trace observation. |

Run one changed setting at a time:

```bash
uv run python examples/03-feedback-and-adrc/adrc_same_mismatch.py --detection 4.0
uv run python examples/03-feedback-and-adrc/adrc_same_mismatch.py --detection 8.0
```

For every row, finish with: **“With the same plant mismatch, changing only
detection changed ___ in the estimate and ___ in the recovery evidence.”** A
faster-looking estimate is not automatically better; use the plot and metrics
to judge its trade-off.

### Checkpoint: plan the detection test

<div class="quiz" data-answer="b" data-correct-feedback="Changing detection alone isolates how quickly the observer updates its estimate while preserving the controller comparison conditions.">
  <p><strong>Which change tests the detection setting fairly?</strong></p>
  <label><input type="radio" name="module3-adrc-detection" value="a"> Change detection and the actual mass together.</label><br>
  <label><input type="radio" name="module3-adrc-detection" value="b"> Change only detection while preserving reaction and the same mass mismatch.</label><br>
  <label><input type="radio" name="module3-adrc-detection" value="c"> Change the target band until ADRC appears successful.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

You now have a fair matched comparison and have seen an estimate develop.
Next: **Topic 3 — Read the estimate**, where you will make plot-based claims
without confusing an estimate with a direct disturbance measurement.
