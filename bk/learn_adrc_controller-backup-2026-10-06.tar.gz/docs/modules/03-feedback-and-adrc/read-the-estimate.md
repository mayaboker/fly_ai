# Experiment: Read the Disturbance Estimate

## By the end, you will be able to

- identify when a known payload change begins in an ADRC plot;
- relate the timing of a changing disturbance estimate to plant behavior;
- explain why the estimate is a combined effect rather than a direct payload measurement; and
- test one changed payload mass while keeping the observer settings fixed.

Prerequisite: [Topic 2 — ADRC Under the Same Mass Mismatch](adrc-under-same-test.md).

---

## The question

When does the observer begin to learn about an unplanned effect?

This experiment starts with the expected 1.0 kg plant. At 4 s, the plant becomes 1.4 kg while the controller continues to assume 1.0 kg. The observer is not told when the payload arrives. It can respond only after changed plant behavior creates a gap between its prediction and the altitude measurement.

```mermaid
flowchart LR
  P[1.0 kg plant before 4 s] --> M[Altitude measurement]
  X[Payload added at 4 s] --> H[1.4 kg plant after 4 s]
  H --> M
  M --> O[Observer]
  O --> E[Combined-effect estimate]
  E --> C[ADRC correction]
  C --> P
  C --> H
```

The red line in the plots marks a known test event, not a signal given to the observer. Use it to compare timing: the payload changes the plant, altitude changes, then the estimate moves and ADRC corrects.

### Checkpoint: identify observer evidence

<div class="quiz" data-answer="a" data-correct-feedback="The observer uses the gap between predicted and measured plant behavior as evidence of an unplanned effect.">
  <p><strong>How can the observer react to the payload if it is not told the payload time?</strong></p>
  <label><input type="radio" name="module3-estimate-evidence" value="a"> It updates from the gap between its prediction and the measured plant behavior.</label><br>
  <label><input type="radio" name="module3-estimate-evidence" value="b"> It reads the payload mass directly from the command line while running.</label><br>
  <label><input type="radio" name="module3-estimate-evidence" value="c"> It changes the target altitude to compensate.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Run the timing test

From the repository root, run:

```bash
uv run python examples/03-feedback-and-adrc/estimate_timing.py
```

The full runnable source is `examples/03-feedback-and-adrc/estimate_timing.py`. Its key default console output is:

```text
Estimate before payload: 0.004 m/s²
Final disturbance estimate: -3.912 m/s²
Recovery after payload to within 0.10 m: 2.220 s
Lowest altitude after payload: 2.530 m
```

The estimate is nearly zero before the payload because the assumed and actual plants initially agree. Its later negative value represents the downward combined effect that the assumed 1.0 kg plant does not explain.

### Watch the timing

The animation shows the payload event at the red line, the altitude dip, the estimate's negative movement, and the correction that brings altitude back to the target band.

![Animated timing of a payload event, ADRC estimate, and recovery.](images/estimate_timing.gif)

The static plot is the careful reference. Do not infer an exact payload mass from the estimate's final number. A different plant or another disturbance could produce a similar combined estimate.

![ADRC estimate changing after a known payload event.](images/estimate_timing.png)

### Checkpoint: make the right claim

<div class="quiz" data-answer="c" data-correct-feedback="The estimate's timing supports a learned downward combined effect after the payload, not an exact physical-cause measurement.">
  <p><strong>What does the negative estimate after 4 s support?</strong></p>
  <label><input type="radio" name="module3-estimate-claim" value="a"> The observer measured the payload as exactly 0.4 kg.</label><br>
  <label><input type="radio" name="module3-estimate-claim" value="b"> The target altitude has become negative.</label><br>
  <label><input type="radio" name="module3-estimate-claim" value="c"> The observer learned a downward combined effect after the plant behavior changed.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Read the important code

The observer continually corrects predicted altitude and velocity from the measurement gap. It stores remaining unexplained behavior in `estimated_disturbance`, then subtracts that value from the desired correction. The payload change exists only in the plant update, so the estimate is learned from behavior rather than supplied as a fact.

??? example "Show the estimate-timing loop"

    ```python
    --8<-- "examples/03-feedback-and-adrc/estimate_timing.py:estimate-timing-loop"
    ```

The reported before-and-after values are tied to the known event time. They show when the estimate changed while preserving its correct meaning as a combined effect.

??? example "Show the timing evidence metrics"

    ```python
    --8<-- "examples/03-feedback-and-adrc/estimate_timing.py:timing-metrics"
    ```

### Checkpoint: order the evidence

<div class="quiz" data-answer="b" data-correct-feedback="The added payload changes the plant first; the observer then sees the resulting measurement mismatch and updates its estimate.">
  <p><strong>Which sequence is most faithful to the experiment?</strong></p>
  <label><input type="radio" name="module3-estimate-order" value="a"> The estimate changes, then the payload is added.</label><br>
  <label><input type="radio" name="module3-estimate-order" value="b"> The payload changes plant behavior, then the estimate responds to the measurement evidence.</label><br>
  <label><input type="radio" name="module3-estimate-order" value="c"> The target changes, then the observer removes the payload.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Hands-on exercise: change one payload mass

Keep reaction, detection, target, payload time, timestep, and duration fixed. Run one heavier-payload variation:

```bash
uv run python examples/03-feedback-and-adrc/estimate_timing.py --payload-mass 1.6
```

Create a two-row log: the 1.4 kg reference and the 1.6 kg variation. Before the second run, predict whether the altitude dip and final estimate magnitude will grow. Record the final estimate, lowest altitude after the payload, and one observation about when the estimate starts moving.

Finish with: **“With only payload mass changed, the estimate became ___ after the event, which is evidence of ___.”** Avoid claiming that its numerical value is a direct reading of the payload mass.

### Checkpoint: preserve the estimate test

<div class="quiz" data-answer="a" data-correct-feedback="Keeping observer settings and event timing fixed makes payload mass the intended explanation for the changed estimate trace.">
  <p><strong>Which condition should remain fixed when testing a heavier payload?</strong></p>
  <label><input type="radio" name="module3-estimate-test" value="a"> Detection setting and payload time.</label><br>
  <label><input type="radio" name="module3-estimate-test" value="b"> The payload mass and the target band must both change.</label><br>
  <label><input type="radio" name="module3-estimate-test" value="c"> The observer must be told the new mass.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

You can now make a careful claim about estimate timing. Next: [Topic 4 — Tune with Evidence](tune-with-evidence.md), where you will change detection and compare recovery trade-offs.
