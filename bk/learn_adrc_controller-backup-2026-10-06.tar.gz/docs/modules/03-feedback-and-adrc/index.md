# Module 3: Feedback and ADRC

## By the end, you will be able to

- describe what baseline feedback can recover from when the plant differs from
  its expected behavior;
- compare baseline feedback and ADRC under the same model mismatch or
  disturbance;
- interpret a disturbance estimate as a running estimate of combined
  unplanned effects; and
- tune reaction and detection settings one at a time using plot and metric
  evidence.

---

## Why this module matters

The response experiments in Module 2 taught you to recognize slow behavior,
overshoot, oscillation, and actuator limits. This module asks a more specific
question: when the same plant receives an unexpected push or differs from what
the controller expects, what does disturbance estimation add to ordinary
feedback?

Start with a baseline controller. It reacts after a measurement shows an
error. Then run ADRC under exactly the same conditions. ADRC still uses the
measurement, but its observer also maintains a disturbance estimate that can
help compensate for effects the controller did not plan for.

```mermaid
flowchart LR
  T[Target] --> B[Baseline feedback]
  T --> A[ADRC controller]
  D[Same mismatch or disturbance] --> P1[Plant]
  D --> P2[Plant]
  B --> P1
  A --> P2
  P1 --> M1[Baseline measurement]
  P2 --> M2[ADRC measurement]
  M1 --> B
  M2 --> A
  M2 --> O[Observer]
  O --> A
```

The comparison is about evidence, not perfect behavior. A better recovery in
one test does not mean ADRC directly measured the disturbance or will solve
every failure condition.

---

## Module roadmap

| Stop | Topic | Question you will answer | Evidence you will produce |
| --- | --- | --- | --- |
| 1 | [Baseline feedback under mismatch](baseline-feedback-under-mismatch.md) | What can error-driven feedback recover from on its own? | A baseline plot and recovery metrics. |
| 2 | [ADRC under the same test](adrc-under-same-test.md) | Does the disturbance estimate improve recovery in this scenario? | A matched baseline-versus-ADRC comparison. |
| 3 | [Read the estimate](read-the-estimate.md) | What does an estimate changing with the disturbance show? | A plot-based explanation that does not claim direct measurement. |
| 4 | [Tune with evidence](tune-with-evidence.md) | What trade-off follows from changing reaction or detection? | A one-setting experiment log with metrics. |
| 5 | [Build a compact ADRC controller](build-full-adrc-controller.md) | How do observer, estimate, and compensation form one working loop? | A complete controller verified against the timed-payload test. |
| 6 | [Actuator limits and saturation](actuator-limits-and-saturation.md) | What can ADRC handle when requested and applied commands differ? | A controller-versus-physical-authority diagnosis. |
| 7 | [Measurement noise and observer robustness](measurement-noise-and-observer-robustness.md) | How does measurement noise change the detection trade-off? | A bounded detection choice supported by recovery and jitter evidence. |

Read the detailed [Module 3 roadmap](roadmap.md) before beginning the
experiments.

Next: [Module 4 — Rotational and Multi-Loop Control](../04-rotational-and-multiloop-control/index.md).
