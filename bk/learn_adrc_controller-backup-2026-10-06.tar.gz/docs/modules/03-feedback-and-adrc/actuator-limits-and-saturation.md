# Experiment: ADRC with Actuator Limits

## By the end, you will be able to

- distinguish a requested correction from the correction a limited actuator applies;
- identify saturation by comparing requested and applied command traces;
- feed the applied command back into an ADRC observer; and
- distinguish controller-handling limits from insufficient physical authority.

Prerequisite: [Topic 5 — Build a Compact ADRC Controller](build-full-adrc-controller.md).

---

## The question

What happens when ADRC requests more correction than a motor with maximum RPM can deliver?

This simulator represents a motor-RPM or thrust limit as a maximum correction. The controller may request any correction, but the actuator applies only the request clamped to that limit. When requested and applied traces differ, the actuator is saturated.

```mermaid
flowchart LR
  R[ADRC requested correction] --> L{Maximum RPM / thrust limit}
  L -->|within limit| A[Applied correction]
  L -->|beyond limit| C[Clamp to limit]
  C --> A
  A --> P[Plant]
  P --> M[Altitude measurement]
  M --> O[Observer]
  A --> O
```

The saturation-aware observer uses the correction actually applied to the plant. A naive observer uses the unavailable requested correction and predicts motion the plant could not produce.

### Checkpoint: recognize saturation

<div class="quiz" data-answer="b" data-correct-feedback="Saturation is present when the actuator limit clips a larger requested correction, so the applied command no longer matches the request.">
  <p><strong>Which plot evidence proves the actuator is saturated?</strong></p>
  <label><input type="radio" name="module3-limit-saturation" value="a"> The altitude equals the target.</label><br>
  <label><input type="radio" name="module3-limit-saturation" value="b"> The requested correction differs from the applied correction at the limit.</label><br>
  <label><input type="radio" name="module3-limit-saturation" value="c"> The disturbance estimate is zero.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Run the feasible-limit comparison

From the repository root, run:

```bash
uv run python examples/03-feedback-and-adrc/adrc_actuator_limits.py
```

The full runnable source is `examples/03-feedback-and-adrc/adrc_actuator_limits.py`. Its default output is:

```text
Maximum correction: 5.000 m/s²
Required correction to hover after payload: 3.924 m/s²
Naive saturation time: 2.140 s
Aware saturation time: 1.600 s
Naive payload recovery: not reached
Aware payload recovery: 2.790 s
Naive final estimate: -3.697 m/s²
Aware final estimate: -3.839 m/s²
```

The 5.0 m/s² limit exceeds the 3.924 m/s² correction required to hover after the payload. Recovery is physically possible, so the default difference comes from controller handling: the aware observer predicts using the applied command and recovers.

![Naive and saturation-aware ADRC with a feasible actuator limit.](images/adrc_actuator_limits.png)

## How to read the saturation graphs

| Panel | What to monitor | What it tells you |
| --- | --- | --- |
| Altitude | Target-band recovery after payload. | Whether the plant-level response is acceptable. |
| Naive correction | Gap between requested and applied correction. | How long the actuator clipped the request while the observer predicted unavailable authority. |
| Aware correction | Gap between requested and applied correction. | The same physical saturation, but with the applied command available to the observer. |
| Estimates | Whether each estimate stays plausible during saturation. | Whether observer state matches what the plant could actually receive. |

Read correction panels before blaming a tuning setting. If requested and applied lines differ, the actuator—not only the controller preference—is limiting the response.

### Checkpoint: separate two failure types

<div class="quiz" data-answer="a" data-correct-feedback="Available correction exceeds the hover requirement, and feeding the applied command into the observer addresses the controller-handling error created by saturation.">
  <p><strong>Why can the aware controller improve the default run?</strong></p>
  <label><input type="radio" name="module3-limit-handling" value="a"> The actuator has enough steady authority, and the observer uses the command that was actually applied.</label><br>
  <label><input type="radio" name="module3-limit-handling" value="b"> ADRC removes the motor limit from the plant.</label><br>
  <label><input type="radio" name="module3-limit-handling" value="c"> The aware controller receives a lighter payload.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Extend the controller with applied-command feedback

Start from Topic 5. After it requests a correction, clamp the request to the actuator limit, then record the applied correction for the next observer update.

```python
requested = controller.request_correction(measurement, target)
applied = np.clip(requested, -max_correction, max_correction)

# TODO: give the observer the applied command, not an impossible request.
controller.record_applied_command(requested, applied)
```

The complete extension stores `observer_command`. In aware mode it receives `applied`; in naive mode it receives `requested` so the difference remains visible.

??? example "Show the saturation-aware controller extension"

    ```python
    --8<-- "examples/03-feedback-and-adrc/adrc_actuator_limits.py:saturation-aware-controller"
    ```

The plant loop makes the boundary explicit: clipping happens before the plant update, and the same applied correction is recorded for the observer.

??? example "Show the actuator-limit experiment loop"

    ```python
    --8<-- "examples/03-feedback-and-adrc/adrc_actuator_limits.py:actuator-limit-loop"
    ```

### Checkpoint: choose the observer input

<div class="quiz" data-answer="c" data-correct-feedback="The observer should predict the input the saturated actuator actually delivered; otherwise it assumes motion the plant could not receive.">
  <p><strong>Which correction should a saturation-aware observer use on its next update?</strong></p>
  <label><input type="radio" name="module3-limit-input" value="a"> A larger correction than the controller requested.</label><br>
  <label><input type="radio" name="module3-limit-input" value="b"> The target altitude.</label><br>
  <label><input type="radio" name="module3-limit-input" value="c"> The correction actually applied after clamping.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Hands-on exercise: find the physical boundary

Lower the maximum correction below the 3.924 m/s² hover requirement:

```bash
uv run python examples/03-feedback-and-adrc/adrc_actuator_limits.py --max-correction 3.0
```

Record required hover correction, maximum correction, saturation time, and recovery result for both controllers. Neither controller can recover because the actuator cannot supply enough steady upward authority after the payload. Aware ADRC can keep a more honest observer state, but cannot create missing thrust.

Then try `--max-correction 6.5` with reaction and detection fixed. Explain which change comes from controller handling and which comes from physical authority.

### Checkpoint: identify a physical limit

<div class="quiz" data-answer="b" data-correct-feedback="No controller can hover after the payload when available correction is below the correction required to balance the heavier plant.">
  <p><strong>What does a 3.0 m/s² limit mean when 3.924 m/s² is required to hover after the payload?</strong></p>
  <label><input type="radio" name="module3-limit-physics" value="a"> Increasing detection alone guarantees recovery.</label><br>
  <label><input type="radio" name="module3-limit-physics" value="b"> Recovery is physically impossible until thrust authority or demand changes.</label><br>
  <label><input type="radio" name="module3-limit-physics" value="c"> The observer can directly create additional motor RPM.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

You can now distinguish controller handling from physical authority. Next: [Topic 7 — Measurement Noise and Observer Robustness](measurement-noise-and-observer-robustness.md), where detection must be judged with noisy measurements.
