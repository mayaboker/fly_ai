# Experiment: Signals and a Fair Test

## By the end, you will be able to

- name the target, measurement, command, disturbance, and timestep in a
  vertical-motion simulator;
- distinguish an intentional experimental change from a condition that must
  stay fixed;
- run two mass scenarios with one shared controller setting; and
- use a plot and a final error to support a limited conclusion.

Prerequisite: [Module 0 — Baseline Feedback versus ADRC](../00-first-adrc-experiment/vertical-takeoff-and-hover.md).

---

## Intuition: follow one message around the loop

Think of the simulator as a short conversation repeated many times. The target
states where the drone should be. The plant returns a measurement of where it
is. The controller sends a command upward or downward. A disturbance pushes on
the plant without asking the controller. The timestep says how much simulated
time passes before this conversation repeats.

You do not need a detailed drone model to use this loop well. You do need to
record the inputs that could explain a changed result.

```mermaid
flowchart LR
  T[Target altitude] --> C[Controller]
  M[Measurement] --> C
  C -->|Command| P[Vertical-motion plant]
  D[Disturbance] --> P
  P -->|Next measurement| M
  DT[Timestep] -. advances each update .-> P
```

| Signal | In this experiment | Why it matters |
| --- | --- | --- |
| Target | 3 m altitude | Defines success. |
| Measurement | Simulated altitude | What the controller can react to. |
| Command | Upward-force request | The controller's attempt to change altitude. |
| Disturbance | Extra downward force | The unplanned effect being tested. |
| Timestep | Simulated seconds per update | Defines how frequently the loop updates. |

### Checkpoint: identify a signal

<div class="quiz" data-answer="b" data-correct-feedback="The command is the controller output that asks the plant to change its motion.">
  <p><strong>Which signal is sent from the controller to the plant?</strong></p>
  <label><input type="radio" name="module1-signal-command" value="a"> The measurement.</label><br>
  <label><input type="radio" name="module1-signal-command" value="b"> The command.</label><br>
  <label><input type="radio" name="module1-signal-command" value="c"> The timestep.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Fair means one explanatory change

Suppose a heavier simulated drone finishes farther below its target. That is
useful evidence only if the mass was the intended difference. If the target,
controller gain, disturbance, and timestep also changed, the plot cannot tell
you which change caused the result.

For this lesson, the **changed factor** is mass. Keep these conditions fixed:

| Keep fixed | Default value |
| --- | --- |
| Target | 3.0 m |
| Controller reaction setting | 3.0 |
| Downward disturbance | -1.5 N after 2 s |
| Timestep | 0.01 s |
| Simulated duration | 8 s |

The mass is 1.0 kg in the reference run and 1.4 kg in the comparison run. The
controller deliberately does not receive the mass, so the extra mass tests how
the same command behaves under a changed plant assumption.

### Checkpoint: choose a fair comparison

<div class="quiz" data-answer="a" data-correct-feedback="With every other stated condition fixed, mass is the only plausible intended cause of a difference.">
  <p><strong>Which pair of runs can support a conclusion about mass?</strong></p>
  <label><input type="radio" name="module1-fairness" value="a"> Same target, gain, disturbance, timestep, and duration; only mass changes.</label><br>
  <label><input type="radio" name="module1-fairness" value="b"> Mass and controller reaction setting both change.</label><br>
  <label><input type="radio" name="module1-fairness" value="c"> Mass changes, but one run ends earlier.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Run the two scenarios

From the repository root, run the reference scenario:

```bash
uv run python examples/01-simulator-experiments/simulator_signals.py --mass 1.0 --output reference.png
```

The full runnable source is `examples/01-simulator-experiments/simulator_signals.py`.
Its default run produces this console output:

```text
Final tracking error: 0.540 m
Saved plot: simulator_signals.png
```

The final tracking error is the target altitude minus the final measurement.
It is one recorded result to compare alongside the full trace; it does not
describe overshoot or the whole recovery by itself.

![Default signal plot showing the target and measurement, command, and disturbance.](images/simulator_signals_default.png)

The top panel compares the measurement with the 3 m target. The middle panel
shows the command that responds to tracking error and velocity. The bottom
panel marks the added downward disturbance after 2 seconds. This is the
reference evidence before you change mass or timestep.

### Inspect the simulator code

The update loop records every signal that the lesson asks you to trace. Each
timestep first selects the disturbance, then calculates a command from the
target and measurement, updates the plant motion, and records the next
measurement. The `mass` and `dt` arguments are explicit inputs so a learner
can change exactly one test condition.

??? example "Show the signal update loop"

    ```python
    --8<-- "examples/01-simulator-experiments/simulator_signals.py:signal-update-loop"
    ```

The plotting function turns those recorded arrays into the three panels. It
does not change the experiment; it makes the target, measurement, command,
and disturbance available as evidence.

??? example "Show how the signal plot is built"

    ```python
    --8<-- "examples/01-simulator-experiments/simulator_signals.py:plot-signals"
    ```

Then run the comparison. Leave every other argument unchanged:

```bash
uv run python examples/01-simulator-experiments/simulator_signals.py --mass 1.4 --output heavy.png
```

Each command prints the final tracking error and writes a plot with target,
measurement, command, and disturbance. Compare the final portion of the
measurement plot, then check whether the command plot shows the same reaction
setting attempting to compensate.

The result does not prove how every controller behaves with every mass. It
supports a narrower statement: under these recorded conditions, the heavier
plant produced this observed tracking behavior.

### Checkpoint: read the evidence carefully

<div class="quiz" data-answer="c" data-correct-feedback="That statement stays within the evidence from these recorded conditions instead of generalizing beyond the test.">
  <p><strong>What is the strongest conclusion if the heavier run ends farther below the target?</strong></p>
  <label><input type="radio" name="module1-evidence" value="a"> Every controller fails with a heavier plant.</label><br>
  <label><input type="radio" name="module1-evidence" value="b"> The plot measured mass directly.</label><br>
  <label><input type="radio" name="module1-evidence" value="c"> With the recorded conditions, the mass change worsened this run's final tracking.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Timestep is a test condition, not decoration

The timestep is the amount of simulated time added on each update. With a
0.01 s timestep, an 8 s scenario performs 800 updates. Changing it changes
how often the plant and controller update, so it is a new experiment condition
even when the chart still says “8 seconds.”

You do not need to predict the exact numerical effect yet. Simply treat a
timestep change as a separate experiment and never mix it into a mass-only
comparison.

### Checkpoint: record the timestep

<div class="quiz" data-answer="b" data-correct-feedback="A different timestep changes the update frequency, so it can change the simulated response.">
  <p><strong>Why should the timestep be recorded beside a simulation result?</strong></p>
  <label><input type="radio" name="module1-timestep" value="a"> It only changes how the plot is colored.</label><br>
  <label><input type="radio" name="module1-timestep" value="b"> It changes how often the simulated loop updates and can affect the result.</label><br>
  <label><input type="radio" name="module1-timestep" value="c"> It tells the controller the true mass.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Hands-on exercise: make a defensible experiment log

Create the following three-row log in your notes. Do not combine changes.

| Run | Single changed factor | Prediction | Evidence to record |
| --- | --- | --- | --- |
| Reference | None: mass 1.0 kg | State what you expect at the end of the run. | Final error and one observation from the plot. |
| Mass test | Mass 1.4 kg | Predict how the measurement will differ. | Final error and one measurement-versus-target observation. |
| Timestep test | Timestep 0.02 s, with mass back at 1.0 kg | Predict whether the trace will differ. | Final error, timestep, and one plot observation. |

For the third row, run:

```bash
uv run python examples/01-simulator-experiments/simulator_signals.py --mass 1.0 --dt 0.02 --output timestep.png
```

Finish each row with one sentence in this form: **“Because only ___ changed,
the plot and final error are evidence that ___ under these conditions.”** If
you changed two things by mistake, rerun it rather than trying to explain an
ambiguous result.

### Checkpoint: choose the next action

<div class="quiz" data-answer="a" data-correct-feedback="Restoring the original timestep isolates mass as the single changed factor.">
  <p><strong>You changed mass and timestep together. What should you do before drawing a conclusion about mass?</strong></p>
  <label><input type="radio" name="module1-recovery" value="a"> Rerun with the original timestep and only the mass changed.</label><br>
  <label><input type="radio" name="module1-recovery" value="b"> Average the two changes into one result.</label><br>
  <label><input type="radio" name="module1-recovery" value="c"> Declare the controller better because it produced a plot.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

You now have a controlled experiment log. Next, [Module 2 — System Response
Experiments](../02-system-response-experiments/index.md) uses the same signals
to explore why a response can be slow, overshoot, or oscillate.
