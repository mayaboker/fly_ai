# Module 1: Simulator Experiments

## By the end, you will be able to

- trace a target, measurement, command, disturbance, and timestep through a
  small simulator;
- explain why a fair comparison changes exactly one stated factor;
- run a mass-change experiment and support a conclusion with plot evidence; and
- prepare a concise experiment log for the response experiments in Module 2.

---

## Why this module comes next

Module 0 showed a useful result: ADRC can improve recovery in one hover test.
Before comparing more controller behavior, you need to know what a simulator
actually sends and records. Otherwise, an apparent controller improvement
could be caused by a changed target, a different disturbance, or even a
different timestep.

The focus is a useful simulator, not a hand-built physical model.

---

## Module roadmap

| Stop | Topic | Question you will answer | Evidence you will produce |
| --- | --- | --- | --- |
| 1 | [Signals and a fair test](signals-and-fair-tests.md) | What must remain fixed to attribute a change to one assumption? | A plot and a two-run mass experiment log. |
| 2 | Timestep awareness | Why does the simulated update interval belong in every test record? | The timestep recorded beside each result. |
| 3 | Experiment handoff | What makes a result ready to compare in Module 2? | A prediction, one changed factor, and plot evidence. |

Start with [Signals and a fair test](signals-and-fair-tests.md).

Next: [Module 2 — System Response Experiments](../02-system-response-experiments/index.md).
