# Experiment: Physical-Plant Sandbox

## By the end, you will be able to

- change mass, drag, and maximum thrust in a vertical-plant simulation;
- read altitude, velocity, requested thrust, and applied thrust graphs;
- recognize a thrust limit as the difference between requested and applied command; and
- connect physical changes to the combined effect ADRC later estimates.

Prerequisite: [Module 2 — System Response Experiments](../02-system-response-experiments/index.md).

---

## Intuition: the plant answers every command with physics

The controller requests upward thrust to reach 3 m. The plant turns that request into motion, but mass pulls downward through gravity, drag opposes velocity, and maximum thrust can limit what the actuator applies. The controller sees altitude; it does not automatically know every physical property causing the response.

```mermaid
flowchart LR
  T[Target altitude] --> C[Baseline feedback]
  C --> R[Requested thrust]
  R --> L[Thrust limit]
  L --> A[Applied thrust]
  M[Mass + gravity] --> P[Vertical plant]
  D[Drag] --> P
  A --> P
  P --> Y[Altitude measurement]
  Y --> C
```

### Checkpoint: name a physical property

<div class="quiz" data-answer="b" data-correct-feedback="Mass is a plant property: it changes how a given thrust becomes acceleration without changing the requested target.">
  <p><strong>Which item is a physical plant property rather than a controller setting?</strong></p>
  <label><input type="radio" name="module25-property" value="a"> Detection setting.</label><br>
  <label><input type="radio" name="module25-property" value="b"> Mass.</label><br>
  <label><input type="radio" name="module25-property" value="c"> Target altitude.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Try it in the page

Move one slider at a time. The browser reruns the same simulation immediately; it does not send data anywhere or replace the reproducible Python experiment below.

<div class="physical-simulator"></div>

> **Note:** The sandbox uses baseline feedback that assumes a 1.0 kg plant.
> When actual mass increases, settling below the target is expected: this
> controller has no disturbance estimate or integral compensation.

Use the graphs in this order:

| Graph | What to look for |
| --- | --- |
| Altitude | Does the plant reach the 3 m target, overshoot, or settle below it? |
| Velocity | Does the physical change make the plant accelerate or slow down differently? |
| Thrust | Do requested and applied thrust differ? If so, the actuator is saturated. |

Try these controlled changes:

1. Increase mass from 1.0 to 1.4 kg; keep drag and maximum thrust fixed.
2. Reset mass, then increase drag from 0.20 to 0.60 N·s/m.
3. Reset drag, then lower maximum thrust until requested and applied thrust separate for longer.

### Checkpoint: detect a limit

<div class="quiz" data-answer="a" data-correct-feedback="A gap means the actuator clipped the requested thrust to its maximum available value, so the plant cannot receive everything the controller asked for.">
  <p><strong>What does a gap between requested and applied thrust mean?</strong></p>
  <label><input type="radio" name="module25-limit" value="a"> The thrust limit is active.</label><br>
  <label><input type="radio" name="module25-limit" value="b"> The altitude sensor has disappeared.</label><br>
  <label><input type="radio" name="module25-limit" value="c"> The target changed automatically.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Run the reproducible Python experiment

The page sandbox is for quick exploration. Use the Python version when you want commands, saved plots, and repeatable evidence:

```bash
uv run python examples/02-5-physical-plant-to-adrc-signals/vertical_plant_sandbox.py
```

The full runnable source is `examples/02-5-physical-plant-to-adrc-signals/vertical_plant_sandbox.py`. Its default output is:

```text
Final tracking error: 0.000 m
Saturation time: 0.100 s
Weight: 9.810 N
```

![Default physical-plant response showing altitude, velocity, and force signals.](images/vertical_plant_sandbox.png)

Run one physical change at a time:

```bash
uv run python examples/02-5-physical-plant-to-adrc-signals/vertical_plant_sandbox.py --mass 1.4
uv run python examples/02-5-physical-plant-to-adrc-signals/vertical_plant_sandbox.py --drag 0.60
uv run python examples/02-5-physical-plant-to-adrc-signals/vertical_plant_sandbox.py --max-thrust 14
```

### Checkpoint: interpret mass

<div class="quiz" data-answer="c" data-correct-feedback="With the same thrust request, a heavier plant has less acceleration available, so its altitude response changes even though the target is unchanged.">
  <p><strong>Why does increasing actual mass change the altitude trace?</strong></p>
  <label><input type="radio" name="module25-mass" value="a"> It directly changes the target altitude.</label><br>
  <label><input type="radio" name="module25-mass" value="b"> It removes drag from the plant.</label><br>
  <label><input type="radio" name="module25-mass" value="c"> The same applied thrust produces less acceleration.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Read the important code

The loop makes each physical relationship visible. Requested thrust comes from a fixed baseline controller; applied thrust is clamped by the thrust limit; weight and drag reduce the force available for acceleration. Changing only one command-line property changes one part of this plant calculation.

??? example "Show the physical plant update loop"

    ```python
    --8<-- "examples/02-5-physical-plant-to-adrc-signals/vertical_plant_sandbox.py:physical-plant-loop"
    ```

### From physical effects to ADRC signals

| Physical behavior | Learner-facing signal | ADRC interpretation later |
| --- | --- | --- |
| Requested altitude | Target | The value the controller should follow. |
| Actual altitude | Measurement | Evidence of what the plant did. |
| Applied thrust | Command | The force the plant actually received. |
| Wrong mass, unplanned drag, or unavailable thrust | Unplanned effect | Part of the combined effect the observer may estimate. |

ADRC does not need separate perfect measurements of mass and drag to be useful. It estimates the combined plant behavior its assumed model did not explain. Topic 6 in Module 3 will add the important detail that a saturated actuator must report its applied—not merely requested—command to that observer.

### Checkpoint: connect to ADRC

<div class="quiz" data-answer="b" data-correct-feedback="Mass mismatch, drag, and saturation can all make the plant behave differently from the assumed plant, so ADRC can treat their unexplained combined behavior as one estimated effect.">
  <p><strong>Why can ADRC use one combined disturbance estimate for several physical effects?</strong></p>
  <label><input type="radio" name="module25-adrc-map" value="a"> It proves that mass, drag, and thrust are physically identical.</label><br>
  <label><input type="radio" name="module25-adrc-map" value="b"> They can all create plant behavior the assumed model did not explain.</label><br>
  <label><input type="radio" name="module25-adrc-map" value="c"> It removes physical limits from the actuator.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Hands-on exercise: produce a physical explanation

Create a three-row log from your controlled changes. For each row record: **one property changed → prediction → altitude and force evidence → physical explanation**.

Finish each explanation with: **“Because only ___ changed, the graph shows ___; physically, this happened because ___.”**

Next: [Module 3 — Feedback and ADRC](../03-feedback-and-adrc/index.md), where the observer uses these unexplained physical effects as evidence for compensation.
