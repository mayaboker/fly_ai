# Module 2.5: From Physical Plant to ADRC Signals

## By the end, you will be able to

- connect mass, gravity, drag, and thrust limit to vertical-motion behavior;
- identify how physical properties appear in target, measurement, command, and disturbance signals;
- change one physical property and support a conclusion with graph evidence; and
- explain why an ADRC observer treats unexplained physical effects as a combined disturbance.

---

## Why this bridge matters

Module 2 taught you to read slow response, overshoot, and actuator limits. This bridge makes the plant behind those behaviors visible. Before ADRC estimates an unexplained effect, you should know which physical effects—mass, drag, gravity, and limited thrust—can create it.

## Module roadmap

| Stop | Topic | Question you will answer | Evidence you will produce |
| --- | --- | --- |
| 1 | [Physical-plant sandbox](physical-plant-sandbox.md) | How do mass, drag, and thrust limit change the same vertical plant? | Interactive and reproducible plots with one changed property. |
| 2 | Signal mapping | Which physical effects are planned, measured, commanded, or unexplained? | A plant-to-ADRC signal map. |
| 3 | ADRC handoff | Why can several physical effects become one combined disturbance estimate? | A bounded explanation ready for Module 3. |

Start with the [Physical-Plant Sandbox](physical-plant-sandbox.md).

Next: [Module 3 — Feedback and ADRC](../03-feedback-and-adrc/index.md).
