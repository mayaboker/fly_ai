# Module 3.5: ADRC Physical-Plant Studio

## By the end, you will be able to

- assemble baseline feedback, ADRC observation, and an adjustable physical plant into one test bench;
- compare baseline feedback and ADRC under identical mass, drag, and thrust limits;
- change one physical or controller property at a time in an embedded simulator; and
- explain whether a result comes from plant physics, saturation, or ADRC compensation.

---

## Why this studio follows Module 3

Module 3 taught each ADRC idea separately: fair comparison, observer estimate, tuning, implementation, saturation, and noise. This studio assembles those parts into one system. Module 2.5 supplied the plant; Module 3 supplied the controller.

## Module roadmap

| Stop | Topic | Question you will answer | Evidence you will produce |
| --- | --- | --- |
| 1 | [Build the studio](build-adrc-physical-plant-studio.md) | How do physical properties and controller settings meet in one loop? | A Baseline-versus-ADRC interactive comparison. |
| 2 | Physical experiments | Which changed property explains the graph difference? | A one-change experiment log. |
| 3 | Controller experiments | Which reaction or detection change has an acceptable trade-off? | Recovery, thrust, and estimate evidence. |

Start with [Build the ADRC Physical-Plant Studio](build-adrc-physical-plant-studio.md).

Next: [Module 4 — Rotational and Multi-Loop Control](../04-rotational-and-multiloop-control/index.md).
