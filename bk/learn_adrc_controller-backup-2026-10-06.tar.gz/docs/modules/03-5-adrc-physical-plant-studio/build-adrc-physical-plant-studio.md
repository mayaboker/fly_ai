# Guided Build: ADRC Physical-Plant Studio

## By the end, you will be able to

- select Baseline or ADRC control for the same physical plant;
- change mass, drag, thrust limit, reaction, and detection in a controlled way;
- read altitude, requested/applied thrust, and estimate evidence together; and
- connect the full working controller to a reproducible Python experiment.

Prerequisite: [Module 3 — Feedback and ADRC](../03-feedback-and-adrc/index.md).

---

## Assemble the system

The studio has one physical plant and two controller choices. Baseline feedback reacts only to altitude error. ADRC adds an observer and uses its combined-effect estimate in the correction. Both controllers face the same mass, drag, and thrust limit.

```mermaid
flowchart LR
  T[Target] --> S{Controller mode}
  S -->|Baseline| B[Feedback correction]
  S -->|ADRC| O[Observer + compensation]
  B --> R[Requested thrust]
  O --> R
  R --> L[Thrust limit]
  L --> P[Mass + drag plant]
  P --> M[Altitude measurement]
  M --> S
  L --> O
```

### Checkpoint: preserve the comparison

<div class="quiz" data-answer="b" data-correct-feedback="Keeping the plant settings fixed means the controller mode is the intended explanation for a difference in response.">
  <p><strong>What should remain fixed when comparing Baseline and ADRC modes?</strong></p>
  <label><input type="radio" name="module35-fairness" value="a"> Only the graph colors.</label><br>
  <label><input type="radio" name="module35-fairness" value="b"> Mass, drag, thrust limit, target, and timestep.</label><br>
  <label><input type="radio" name="module35-fairness" value="c"> The controller mode and the final error.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Try the interactive studio

Choose **Baseline feedback** first, then switch to **ADRC** without changing any slider. The altitude panel shows the plant response, the thrust panel shows requested versus applied authority, and the estimate panel shows what only ADRC maintains.

<div class="adrc-studio"></div>

Use this experiment loop:

1. With mass 1.4 kg, drag 0.20, and maximum thrust 20 N, compare Baseline and ADRC.
2. In ADRC mode, increase mass to 1.8 kg and predict the estimate and altitude changes.
3. Restore mass, lower maximum thrust until requested and applied thrust separate, then inspect whether the physical limit prevents recovery.
4. Keep the plant fixed and change only reaction or detection.

### Checkpoint: read the estimate panel

<div class="quiz" data-answer="a" data-correct-feedback="Baseline feedback has no observer, so it has no disturbance estimate; ADRC's estimate represents combined unexplained plant behavior.">
  <p><strong>Why is the estimate trace zero in Baseline mode?</strong></p>
  <label><input type="radio" name="module35-estimate" value="a"> Baseline feedback has no observer or disturbance estimate.</label><br>
  <label><input type="radio" name="module35-estimate" value="b"> The plant has no mass or drag.</label><br>
  <label><input type="radio" name="module35-estimate" value="c"> The thrust limit is disabled.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Build the controller connection

The only difference between the two modes is how correction is produced. The baseline uses measured altitude and velocity directly. ADRC first updates its estimates, then subtracts the combined-effect estimate from its target-following correction.

```python
if mode == "baseline":
    correction = kp * (target - altitude) - kd * velocity
else:
    # TODO: update observer state from the altitude measurement.
    # TODO: calculate feedback from estimated motion.
    # TODO: subtract the combined-effect estimate.
    correction = ...
```

The physical plant is the same after either branch. Requested thrust is clamped, and ADRC records the resulting applied thrust for the next observer update.

??? example "Show the complete studio ADRC controller"

    ```python
    --8<-- "examples/03-5-adrc-physical-plant-studio/adrc_physical_plant.py:studio-adrc-controller"
    ```

??? example "Show the shared physical-plant loop"

    ```python
    --8<-- "examples/03-5-adrc-physical-plant-studio/adrc_physical_plant.py:studio-plant-loop"
    ```

### Checkpoint: handle thrust limits

<div class="quiz" data-answer="c" data-correct-feedback="A saturation-aware observer should use the applied thrust because it is the input the plant actually received after the thrust limit.">
  <p><strong>What should ADRC record after the requested thrust is clamped?</strong></p>
  <label><input type="radio" name="module35-limit" value="a"> A different target altitude.</label><br>
  <label><input type="radio" name="module35-limit" value="b"> Only the requested thrust.</label><br>
  <label><input type="radio" name="module35-limit" value="c"> The applied thrust after clamping.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Run the complete Python reference

The JavaScript studio is for rapid exploration. The Python version gives you a reproducible implementation and saved plot:

```bash
uv run python examples/03-5-adrc-physical-plant-studio/adrc_physical_plant.py
```

Its default ADRC output is:

```text
Mode: adrc
Final tracking error: 0.001 m
Saturation time: 0.100 s
Final disturbance estimate: -3.925 m/s²
```

![ADRC controlling the adjustable physical plant.](images/adrc_physical_plant.png)

Compare the same configuration with baseline feedback:

```bash
uv run python examples/03-5-adrc-physical-plant-studio/adrc_physical_plant.py --mode baseline
```

The baseline reference ends with a `0.811 m` tracking error in this 1.4 kg, drag 0.20 scenario; ADRC improves this by estimating the combined physical effect.

### Checkpoint: use all the evidence

<div class="quiz" data-answer="b" data-correct-feedback="Altitude judges recovery, requested versus applied thrust reveals actuator authority, and the estimate explains ADRC's learned compensation.">
  <p><strong>Which three signals should you inspect before judging an ADRC studio run?</strong></p>
  <label><input type="radio" name="module35-evidence" value="a"> Only the final altitude value.</label><br>
  <label><input type="radio" name="module35-evidence" value="b"> Altitude, requested/applied thrust, and the disturbance estimate.</label><br>
  <label><input type="radio" name="module35-evidence" value="c"> Only the detection setting.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Hands-on exercise: write a controller diagnosis

Choose one plant change—mass, drag, or maximum thrust—and one controller change—reaction or detection. Do **not** change both in the same run.

For each run, record: **mode → one changed setting → prediction → altitude evidence → thrust evidence → estimate evidence**.

Finish with: **“With the same physical plant, ADRC changed ___ because its estimate ___; the thrust graph shows ___.”** If requested and applied thrust diverge, say whether the limit is a controller-handling issue or insufficient physical authority.

Next: [Module 4 — Rotational and Multi-Loop Control](../04-rotational-and-multiloop-control/index.md).
