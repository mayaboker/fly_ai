# Module 0: Start with an ADRC Experiment

## By the end, you will be able to

- run the same disturbance scenario with a baseline controller and ADRC;
- identify the target, disturbance, and recovery in a plot;
- change one tuning setting and test your prediction; and
- describe ADRC as feedback plus a running disturbance estimate.

---

## Intuition

Imagine a drone is told to hover at 3 m. A baseline controller sees that the
drone has drifted and pushes it back. ADRC does that too, but it also watches
for a persistent unexplained push—such as a gust or unexpectedly heavy drone—
and learns a correction for it.

You will not calculate that estimate in this course. You will test whether it
helps. Math is reserved for cases where it helps you interpret a result, define
a safe limit, or modify the implementation.

```mermaid
flowchart LR
  T[Target altitude] --> C[Controller]
  C --> P[Drone simulator]
  D[Wind or wrong mass] --> P
  P --> M[Altitude measurement]
  M --> C
  M --> O[ADRC observer]
  O --> C
```

---

## Your first experiment

Read and run [Baseline versus ADRC under a disturbance](vertical-takeoff-and-hover.md).
It has the exact command, prediction questions, tuning exercises, and plots.

---

## Course map

The next modules preserve the same pattern: explore a simulation, compare a
fair baseline, inject one disturbance, then explain the evidence.

1. Simulation signals and fair tests
2. Slow and fast plant behavior
3. Overshoot and calm-versus-fast tuning
4. Baseline feedback under model mismatch
5. ADRC disturbance estimation
6. Rotation, cascade loops, and coupled axes
7. A repeatable PyBullet drone test suite

Next: [Module 1 — Simulator Experiments](../01-simulator-experiments/index.md).
