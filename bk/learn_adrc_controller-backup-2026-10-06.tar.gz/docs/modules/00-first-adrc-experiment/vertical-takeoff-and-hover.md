# Experiment: Baseline Feedback versus ADRC

## By the end, you will be able to

- run a controlled hover test with a wrong mass assumption and a wind-like force;
- compare baseline feedback and ADRC using the same test conditions;
- identify a disturbance estimate and recovery in the output plot; and
- tune reaction and detection settings one at a time.

---

## The question

Which controller gets a simulated drone back to its 3 m target better after
the simulator makes it heavier than expected and applies a downward gust?

The comparison is fair: both controllers receive the same altitude
measurement, target, wrong mass assumption, and gust. The only difference is
that ADRC keeps a running estimate of the unexplained effect and uses it as a
correction.

```mermaid
flowchart LR
  A[3 m target] --> B[Baseline feedback]
  A --> C[ADRC]
  B --> D[Same simulated drone]
  C --> E[Same simulated drone]
  F[Wrong mass + gust] --> D
  F --> E
  D --> G[Baseline altitude]
  E --> H[ADRC altitude + disturbance estimate]
```

### Checkpoint: recognize a fair comparison

<div class="quiz" data-answer="b" data-correct-feedback="Keeping those conditions fixed means a difference in recovery can be attributed to the controller.">
  <p><strong>What should stay the same when comparing the two controllers?</strong></p>
  <label><input type="radio" name="experiment-fairness" value="a"> Only the ADRC wind disturbance.</label><br>
  <label><input type="radio" name="experiment-fairness" value="b"> Target, plant, disturbance, and measurement conditions.</label><br>
  <label><input type="radio" name="experiment-fairness" value="c"> The final plot color.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Run the experiment

From the repository root:

```bash
uv run python examples/00-first-adrc-experiment/adrc_experiment.py
```

The full runnable source is `examples/00-first-adrc-experiment/adrc_experiment.py`.
With its default settings, it produces this console output:

```text
Saved examples/00-first-adrc-experiment/adrc_disturbance_experiment.png
Baseline late-test error: 0.985 m
ADRC late-test error:     0.239 m
```

The late-test error is the average distance from the target after the gust has
finished. In this one controlled scenario, the smaller ADRC value is evidence
of closer late recovery; it is not a claim that ADRC will win every test.

The script saves the following representative default plot. Use its three
panels as follows:

![Baseline feedback and ADRC responding to the same downward gust.](images/adrc_disturbance_experiment.png)

The dashed line in the top panel is the 3 m target; the shaded interval is the
downward gust. Both controllers rise toward the target before the gust, but
the orange ADRC trace develops a stronger temporary correction and returns
closer to the target afterward. The green trace is not a direct wind reading:
it is ADRC's estimate of the combined unexplained effect, so it becomes more
negative while the added downward force matters and relaxes after the gust.

### Inspect the experiment code

Both controller trials share the same actual mass, target, timestep, and gust.
The `use_adrc` switch changes only where feedback values and the estimated
effect come from. In the ADRC branch, the observer updates a running estimate;
that estimate is subtracted from the requested correction before the shared
plant update.

??? example "Show the shared trial and ADRC estimate loop"

    ```python
    --8<-- "examples/00-first-adrc-experiment/adrc_experiment.py:trial-loop"
    ```

The reporting path runs that shared trial once for baseline feedback and once
for ADRC, asserts that the default test demonstrates the intended learning
comparison, then saves the plot and prints the two late-test errors.

??? example "Show the matched comparison and reporting code"

    ```python
    --8<-- "examples/00-first-adrc-experiment/adrc_experiment.py:comparison-and-report"
    ```

| Panel | What to look for |
| --- | --- |
| Altitude | After the gust begins, which line returns closer to 3 m? |
| Control correction | Which controller develops a sustained extra correction? |
| ADRC estimate | Does the estimate move when the wrong mass and gust matter? |

The estimate is not a direct wind sensor reading. It combines effects the
controller did not plan for. That is why the experiment includes both wrong
mass and wind.

### Checkpoint: interpret the result

<div class="quiz" data-answer="c" data-correct-feedback="The comparison supports an improvement in this tested scenario, not a perfect wind measurement or a universal claim.">
  <p><strong>If the ADRC line returns nearer the target after the gust, what is the strongest conclusion?</strong></p>
  <label><input type="radio" name="experiment-result" value="a"> ADRC has perfectly measured the wind.</label><br>
  <label><input type="radio" name="experiment-result" value="b"> The baseline controller can never work.</label><br>
  <label><input type="radio" name="experiment-result" value="c"> In this scenario, the disturbance estimate improved recovery.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Tune by testing, not calculating

The script exposes two learner-facing settings:

| Setting | Try it when you want... | Watch for... |
| --- | --- | --- |
| `--reaction` | stronger or gentler return toward the target | faster recovery versus overshoot or oscillation |
| `--detection` | a faster or slower disturbance estimate | quicker correction versus a noisy or jumpy estimate |

Make a prediction before every run. For example: “Increasing detection from
4 to 8 will make the estimate react sooner, but may make it less smooth.”

```bash
uv run python examples/00-first-adrc-experiment/adrc_experiment.py --detection 8
uv run python examples/00-first-adrc-experiment/adrc_experiment.py --reaction 2.4
uv run python examples/00-first-adrc-experiment/adrc_experiment.py --gust -5
```

Do not change two settings in the same run. If the behavior changes, you want
to know which change caused it.

### Checkpoint: choose a tuning method

<div class="quiz" data-answer="a" data-correct-feedback="A smaller, isolated follow-up change makes it possible to identify what caused the worse recovery.">
  <p><strong>What is the best first response if a change makes recovery worse?</strong></p>
  <label><input type="radio" name="experiment-tuning" value="a"> Return to the previous setting and test one smaller change.</label><br>
  <label><input type="radio" name="experiment-tuning" value="b"> Change every setting until the line looks good.</label><br>
  <label><input type="radio" name="experiment-tuning" value="c"> Ignore the plot and keep the setting.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Hands-on exercise

Create a three-row experiment log.

1. Run the default scenario and record which controller has the smaller
   late-test error.
2. Double `--detection`; record whether the ADRC estimate reacts earlier and
   whether the altitude becomes less calm.
3. Make the gust stronger with `--gust -6`; record whether ADRC still improves
   recovery and where its limit appears.

For every row, record: **one setting changed → your prediction → plot evidence**.

### Checkpoint: name ADRC's role

<div class="quiz" data-answer="b" data-correct-feedback="ADRC adds a running estimate of unplanned effects and uses it to compensate; it does not change the target or remove the gust.">
  <p><strong>What makes ADRC different from the baseline in this experiment?</strong></p>
  <label><input type="radio" name="experiment-adrc-role" value="a"> It receives a different target altitude.</label><br>
  <label><input type="radio" name="experiment-adrc-role" value="b"> It estimates the combined unplanned effect and compensates for it.</label><br>
  <label><input type="radio" name="experiment-adrc-role" value="c"> It removes the gust from the simulator.</label><br>
  <button class="quiz-check" type="button">Check answer</button><p class="quiz-result" aria-live="polite"></p>
</div>

---

## Under the hood (optional)

The implementation contains a compact linear observer. You do not need to
read or derive it now. Its job is only to update estimates of altitude,
vertical motion, and the combined disturbance. Later optional references can
connect this behavior to the standard names LESO and bandwidth.

Prerequisite: none. Next: [Module 1 — Simulator Experiments](../01-simulator-experiments/index.md).
