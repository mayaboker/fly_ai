# Module 0 Roadmap

Module 0 proves the learning method before it introduces terminology: make one
prediction, run one repeatable test, and use the plot as evidence.

## Demonstration system

The simulation is a drone hovering at a 3 m target. It deliberately includes:

- a drone that is heavier than the controller assumes;
- a downward gust between 4 and 7 seconds; and
- the same target and disturbance for baseline feedback and ADRC.

That makes a useful first question: does the ADRC disturbance estimate improve
recovery when the simulator behaves differently than expected?

## Learning path

1. Predict which controller will recover better after the gust.
2. Run the default experiment without reading the implementation.
3. Identify the gust interval, recovery, and ADRC estimate in the plots.
4. Change either reaction or detection, never both together.
5. Record a conclusion supported by the late-test error and a visible plot
   feature.

## Boundary

This module intentionally avoids derivations, state-space notation, transfer
functions, and gain calculations. It uses only the words needed to run and
interpret the experiment: target, measurement, controller, disturbance,
estimate, and recovery.

An optional later reference may explain the observer implementation for
learners who decide to build ADRC from scratch.

## Exit check

Before continuing, the learner should be able to:

- distinguish a disturbance from a target change;
- explain why the two controllers must face the same test conditions;
- find evidence of better or worse recovery in a plot; and
- make a controlled tuning change and explain its outcome.

Next: [Module 1 — Simulator Experiments](../01-simulator-experiments/index.md).
