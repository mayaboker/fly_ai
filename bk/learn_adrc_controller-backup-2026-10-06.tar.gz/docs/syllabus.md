# Syllabus

Each module is organized around simulator behavior and testable questions—not
around mathematical derivations. Mathematics is introduced only if it directly
helps a learner interpret a result, define a safe test, or change code.

| Module | Experiment question | Main learner action |
| --- | --- | --- |
| [0. First ADRC experiment](modules/00-first-adrc-experiment/index.md) | What makes ADRC recover from a gust or wrong mass? | Run a baseline-versus-ADRC comparison. |
| [1. Simulator experiments](modules/01-simulator-experiments/index.md) | Which signals must a useful simulator expose, and what makes a comparison fair? | Change one physical assumption, record the timestep, and read the plot. |
| [2. System response experiments](modules/02-system-response-experiments/index.md) | Why can a system be slow, overshoot, or oscillate? | Tune for calm versus fast behavior. |
| [2.5. Physical plant to ADRC signals](modules/02-5-physical-plant-to-adrc-signals/index.md) | How do mass, drag, and thrust limits become controller evidence? | Change one physical property and read altitude, velocity, and force plots. |
| [3. Feedback and ADRC](modules/03-feedback-and-adrc/index.md) | What does disturbance estimation add to baseline feedback? | Compare recovery under the same mismatch. |
| [3.5. ADRC physical-plant studio](modules/03-5-adrc-physical-plant-studio/index.md) | How do physical properties and ADRC form one complete loop? | Assemble and compare Baseline and ADRC in an adjustable plant. |
| [4. Rotational and multi-loop control](modules/04-rotational-and-multiloop-control/index.md) | How do rotation, cascade loops, and coupled axes interact? | Test one loop or axis at a time. |
| [5. Optional ADRC variants](modules/05-optional-adrc-variants/index.md) | When does a different ADRC choice improve behavior? | Compare variants over a range of errors. |
| [6. PyBullet drone capstone](modules/06-pybullet-drone-capstone/index.md) | Can the controller reject defined disturbances safely? | Run and report a repeatable test suite. |

Optional “under the hood” notes may introduce standard ADRC terms such as
LESO and bandwidth. They are never prerequisites for completing an experiment.
