# Roadmap

## Final goal

Build confidence tuning an ADRC-controlled simulated drone by running fair
experiments: introduce a disturbance, compare it with a baseline controller,
read the evidence in the plots, and make one tuning change at a time.

The core course does not require calculus, transfer functions, state-space
notation, or hand-derived controller gains. Use mathematics only when it
directly helps interpret a plotted result, define a safe test, or alter an
implementation. Optional technical notes can explain theory after learners
have observed why it is useful.

| Milestone | Modules | What you can do |
| --- | --- | --- |
| Read a simulation | 0–2.5 | Identify the target, measurement, command, physical properties, disturbance, and evidence in a plot. |
| Use feedback and ADRC | 3 | Compare baseline feedback with ADRC under the same mismatch and tune recovery. |
| Assemble ADRC with physics | 3.5 | Build an adjustable plant-and-controller studio and diagnose physics, compensation, and saturation together. |
| Control rotation | 4 | Test rotation, cascade loops, and cross-axis effects one at a time. |
| Control a drone | 6 | Test altitude and attitude scenarios in PyBullet and report reproducible results. |
| Optional extension | 5 | Compare ADRC variants after completing the core path. |

## Standard experiment scorecard

Every controller comparison should report the same evidence:

- **Tracking error:** how far the output remains from its target.
- **Overshoot:** how far it goes beyond the target, if it does.
- **Recovery time:** how quickly it returns after a disturbance.
- **Control effort:** whether the controller demands excessive actuator action.
- **Failure condition:** saturation, unstable behavior, or an unacceptable
  tracking result.

These are measurements to compare, not formulas to derive.

## Repeat this loop in every module

```mermaid
flowchart LR
  P[Predict] --> C[Change one setting]
  C --> R[Run the simulator]
  R --> E[Read plot and metric evidence]
  E --> X[Explain the result]
  X --> P
```

## Recommended sequence

1. Begin with Module 0 and run the supplied comparison before reading code.
2. Complete each experiment's prediction and exercise before changing several
   settings together.
3. Keep a short experiment log: setting changed, prediction, result, and one
   sentence of evidence.
4. Treat formulas as optional “under the hood” material. Return to them only
   if you need to implement or modify the controller itself.
