# ADRC Controller: Learn by Running Experiments

Learn active disturbance rejection control (ADRC) by changing a simulator,
making a prediction, and reading the resulting plots. The course moves from a
small vertical-drone simulation to a PyBullet drone capstone.

## Course goal

By the end, you will be able to set up repeatable disturbance tests, compare a
baseline feedback controller with ADRC, tune learner-facing reaction and
detection settings, and explain the plot evidence for your choice.

You do **not** need to derive equations, use calculus, or learn state-space
notation to follow the core path. Math appears only when it helps you read a
result, choose a safe test limit, or change the controller implementation.
The simulator contains the implementation; the lessons focus on what to test,
what to change, and how to interpret the results. Optional technical notes can
be added later for learners who want to implement ADRC from scratch.

## Start here

Run the [first ADRC experiment](modules/00-first-adrc-experiment/vertical-takeoff-and-hover.md):

```bash
uv run python examples/00-first-adrc-experiment/adrc_experiment.py
```

The output compares a baseline controller and ADRC when their assumed drone
mass is wrong and a wind-like force arrives. Your first task is simply to
decide which line recovers better and why.

## How to learn in this course

1. Predict what a single change will do.
2. Run the exact experiment.
3. Use the plot and reported metric as evidence.
4. Change one setting at a time and repeat.

See the complete [roadmap](roadmap.md) and [syllabus](syllabus.md).
