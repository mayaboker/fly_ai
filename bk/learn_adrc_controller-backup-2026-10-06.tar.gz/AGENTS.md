# Learning Repository

This repository is a technical learning site.

## Goal

Teach **[topic]** progressively, from fundamentals to a practical capstone.
Keep `CONTEXT.md` to the current domain model and terminology.

## Agent role

Act as a course-design and documentation collaborator. Before writing, first
understand the learner profile, course goal, progression, and existing project
structure. Keep requirements, syllabus, navigation, and lessons consistent;
ask focused questions when a decision materially changes the course; and verify
documentation builds after edits.

## Documentation rules

When adding a lesson:

1. Start with “By the end, you will be able to”.
2. Explain the intuition before the necessary mathematics.
3. Add a diagram when it clarifies the concept.
4. Add a small runnable example and a hands-on exercise.
5. Add 3–5 option-based checkpoint quizzes, especially immediately after
   physics and mathematics explanations, and link the prerequisite and next
   topic.
6. Separate major sections with `---`.
7. Keep MkDocs Material code-copy enabled.
8. For every runnable simulator example, embed its representative default
   console output and generated plot in the lesson. Store the plot in that
   lesson's `images/` folder. Embed only the important source excerpts with
   source-synchronized MkDocs snippets, place each excerpt in a
   collapsed-by-default `???` details block, and explain the inputs, control
   logic, and recorded evidence around it. Identify the full runnable example
   path for learners who want to inspect everything. Add concise,
   learner-oriented comments inside every embedded source region to explain
   non-obvious control decisions and evidence calculations; explain why the
   code exists rather than restating its syntax.

Use the existing `.quiz` radio-option pattern from `docs/javascripts/quiz.js`:
each checkpoint must have plausible options, one correct answer, a unique radio
`name`, a visible `Check answer` button, and a brief `data-correct-feedback`
explanation of why the correct option is right. Do not use free-form review
questions as the only knowledge check.

Put lessons in `docs/modules/<module>/`, images in that lesson's `images/`
folder, and runnable code in the matching `examples/<module>/` folder.
After documentation changes, run `uv run mkdocs build --strict`.

## Git rules

When asked to commit, show the proposed commit message and wait for explicit
approval before creating the commit.
